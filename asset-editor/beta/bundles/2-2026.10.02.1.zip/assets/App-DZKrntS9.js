import{a as e,c as t,i as n,n as r,o as i,r as a,s as o,t as s}from"./jsx-runtime-CCBp0mYb.js";import{$ as c,$a as l,$i as u,$n as d,$r as f,$t as p,A as m,Aa as h,Ai as g,An as _,Ao as v,Ar as y,At as b,B as x,Ba as S,Bi as C,Bn as w,Bo as T,Br as E,Bt as D,C as O,Ca as k,Ci as A,Cn as j,Co as M,Cr as N,Ct as P,D as F,Da as I,Di as L,Dn as ee,Do as te,Dr as ne,Dt as R,E as z,Ea as B,Ei as V,En as re,Eo as ie,Er as ae,Et as oe,F as se,Fa as ce,Fi as le,Fn as ue,Fo as de,Fr as fe,Ft as pe,G as me,Ga as he,Gi as ge,Gn as H,Gr as _e,Gt as ve,H as ye,Ha as U,Hi as be,Hn as W,Ho as xe,Hr as Se,Ht as Ce,I as we,Ia as Te,Ii as Ee,In as De,Io as Oe,Ir as ke,It as Ae,J as je,Ja as Me,Ji as Ne,Jn as Pe,Jr as Fe,Jt as Ie,K as Le,Ka as Re,Ki as ze,Kn as Be,Kr as Ve,Kt as He,L as Ue,La as We,Li as Ge,Ln as Ke,Lo as qe,Lr as Je,Lt as Ye,M as Xe,Ma as Ze,Mi as Qe,Mn as $e,Mo as et,Mr as tt,Mt as nt,N as rt,Na as it,Ni as at,Nn as ot,No as st,Nr as ct,Nt as lt,O as ut,Oa as dt,Oi as ft,On as pt,Oo as mt,Or as ht,Ot as gt,P as _t,Pa as vt,Pi as yt,Pn as bt,Po as xt,Pr as St,Pt as Ct,Q as wt,Qa as Tt,Qi as Et,Qn as Dt,Qr as Ot,Qt as kt,R as At,Ra as jt,Ri as Mt,Rn as Nt,Ro as Pt,Rr as Ft,Rt as It,S as Lt,Sa as Rt,Si as zt,Sn as Bt,So as Vt,Sr as Ht,St as Ut,T as Wt,Ta as Gt,Ti as Kt,Tn as qt,To as Jt,Tr as Yt,Tt as Xt,U as Zt,Ua as Qt,Ui as $t,Un as en,Uo as tn,Ur as nn,Ut as rn,V as an,Va as on,Vi as sn,Vn as cn,Vo as ln,Vr as un,Vt as dn,W as fn,Wa as pn,Wi as mn,Wn as hn,Wr as gn,Wt as _n,X as vn,Xa as yn,Xi as bn,Xn as xn,Xr as Sn,Xt as Cn,Y as wn,Ya as Tn,Yi as En,Yn as Dn,Yr as On,Yt as kn,Z as An,Za as jn,Zi as Mn,Zn as Nn,Zr as Pn,Zt as Fn,_ as In,_a as Ln,_i as Rn,_n as zn,_o as Bn,_r as G,_t as Vn,a as Hn,aa as Un,ai as Wn,an as Gn,ao as Kn,ar as qn,at as Jn,b as Yn,ba as Xn,bi as Zn,bn as Qn,bo as $n,br as er,bt as tr,c as nr,ca as rr,ci as ir,cn as ar,co as or,cr as sr,ct as cr,d as lr,da as ur,di as dr,dn as fr,do as pr,dr as mr,dt as hr,ea as gr,ei as _r,en as vr,eo as yr,er as br,et as xr,f as Sr,fa as Cr,fi as wr,fn as Tr,fo as Er,fr as Dr,ft as Or,g as kr,ga as Ar,gi as jr,gn as Mr,go as Nr,gr as Pr,gt as Fr,h as Ir,ha as Lr,hi as Rr,hn as zr,ho as Br,hr as Vr,ht as Hr,i as Ur,ia as Wr,ii as Gr,in as Kr,io as qr,ir as Jr,it as Yr,j as Xr,ja as Zr,ji as Qr,jn as $r,jo as ei,jr as ti,jt as ni,k as ri,ka as ii,ki as ai,kn as oi,ko as si,kr as ci,kt as li,l as ui,la as di,li as fi,ln as pi,lo as mi,lr as hi,lt as gi,m as _i,ma as vi,mi as yi,mn as bi,mo as xi,mr as Si,mt as Ci,n as wi,na as Ti,ni as Ei,nn as Di,no as Oi,nr as ki,nt as Ai,o as ji,oa as Mi,oi as Ni,on as Pi,oo as Fi,or as Ii,ot as Li,p as Ri,pa as zi,pi as Bi,pn as Vi,po as K,pr as Hi,pt as Ui,q as Wi,qa as Gi,qi as Ki,qn as qi,qr as Ji,qt as Yi,r as Xi,ra as Zi,ri as Qi,rn as $i,ro as ea,rr as ta,rt as na,s as ra,sa as ia,si as aa,sn as oa,so as sa,sr as ca,st as la,t as q,ta as ua,ti as da,tn as fa,to as pa,tr as ma,tt as ha,u as ga,ua as _a,ui as va,un as ya,uo as ba,ur as xa,ut as Sa,v as Ca,va as wa,vi as Ta,vn as Ea,vo as Da,vr as Oa,vt as ka,w as Aa,wa as ja,wi as Ma,wn as Na,wo as Pa,wr as Fa,wt as Ia,x as La,xa as Ra,xi as za,xn as Ba,xo as Va,xr as Ha,xt as Ua,y as J,ya as Wa,yi as Ga,yn as Ka,yo as qa,yr as Ja,yt as Ya,z as Xa,za as Za,zi as Qa,zn as $a,zo as eo,zr as to,zt as no}from"./editorStore-CgAKebc7.js";import{t as ro}from"./react-dom-Dr085Jqu.js";var Y=t(e(),1),io=o({ACESFilmicToneMapping:()=>4,AddEquation:()=>100,AddOperation:()=>2,AdditiveAnimationBlendMode:()=>_i,AdditiveBlending:()=>2,AgXToneMapping:()=>6,AlphaFormat:()=>Ir,AlwaysCompare:()=>519,AlwaysDepth:()=>1,AlwaysStencilFunc:()=>519,AmbientLight:()=>kr,AnimationAction:()=>In,AnimationClip:()=>Ca,AnimationLoader:()=>J,AnimationMixer:()=>Yn,AnimationObjectGroup:()=>La,AnimationUtils:()=>Lt,ArcCurve:()=>O,ArrayCamera:()=>Aa,ArrowHelper:()=>Wt,AttachedBindMode:()=>z,Audio:()=>F,AudioAnalyser:()=>ut,AudioContext:()=>ri,AudioListener:()=>m,AudioLoader:()=>Xr,AxesHelper:()=>Xe,BackSide:()=>1,BasicDepthPacking:()=>rt,BasicShadowMap:()=>0,BatchedMesh:()=>_t,BezierInterpolant:()=>se,Bone:()=>we,BooleanKeyframeTrack:()=>Ue,Box2:()=>At,Box3:()=>Xa,Box3Helper:()=>x,BoxGeometry:()=>an,BoxHelper:()=>ye,BufferAttribute:()=>Zt,BufferGeometry:()=>fn,BufferGeometryLoader:()=>me,ByteType:()=>Le,Cache:()=>Wi,Camera:()=>je,CameraHelper:()=>wn,CanvasTexture:()=>vn,CapsuleGeometry:()=>An,CatmullRomCurve3:()=>wt,CineonToneMapping:()=>3,CircleGeometry:()=>c,ClampToEdgeWrapping:()=>xr,Clock:()=>ha,Color:()=>Ai,ColorKeyframeTrack:()=>na,ColorManagement:()=>Yr,Compatibility:()=>Jn,CompressedArrayTexture:()=>Li,CompressedCubeTexture:()=>la,CompressedTexture:()=>cr,CompressedTextureLoader:()=>gi,ConeGeometry:()=>Sa,ConstantAlphaFactor:()=>213,ConstantColorFactor:()=>211,Controls:()=>hr,CubeCamera:()=>Or,CubeDepthTexture:()=>Ui,CubeReflectionMapping:()=>301,CubeRefractionMapping:()=>302,CubeTexture:()=>Ci,CubeTextureLoader:()=>Hr,CubeUVReflectionMapping:()=>306,CubicBezierCurve:()=>Fr,CubicBezierCurve3:()=>Vn,CubicInterpolant:()=>ka,CullFaceBack:()=>1,CullFaceFront:()=>2,CullFaceFrontBack:()=>3,CullFaceNone:()=>0,Curve:()=>Ya,CurvePath:()=>tr,CustomBlending:()=>5,CustomToneMapping:()=>5,CylinderGeometry:()=>Ua,Cylindrical:()=>Ut,Data3DTexture:()=>P,DataArrayTexture:()=>Ia,DataTexture:()=>Xt,DataTextureLoader:()=>oe,DataUtils:()=>R,DecrementStencilOp:()=>gt,DecrementWrapStencilOp:()=>li,DefaultLoadingManager:()=>b,DepthFormat:()=>ni,DepthStencilFormat:()=>nt,DepthTexture:()=>lt,DetachedBindMode:()=>Ct,DirectionalLight:()=>pe,DirectionalLightHelper:()=>Ae,DiscreteInterpolant:()=>Ye,DodecahedronGeometry:()=>It,DoubleSide:()=>2,DstAlphaFactor:()=>206,DstColorFactor:()=>208,DynamicCopyUsage:()=>no,DynamicDrawUsage:()=>D,DynamicReadUsage:()=>dn,EdgesGeometry:()=>Ce,EllipseCurve:()=>rn,EqualCompare:()=>514,EqualDepth:()=>4,EqualStencilFunc:()=>514,EquirectangularReflectionMapping:()=>303,EquirectangularRefractionMapping:()=>304,Euler:()=>_n,EventDispatcher:()=>ve,ExternalTexture:()=>He,ExtrudeGeometry:()=>Yi,FileLoader:()=>Ie,Float16BufferAttribute:()=>kn,Float32BufferAttribute:()=>Cn,FloatType:()=>Fn,Fog:()=>kt,FogExp2:()=>p,FramebufferTexture:()=>vr,FrontSide:()=>0,Frustum:()=>fa,FrustumArray:()=>Di,GLBufferAttribute:()=>$i,GLSL1:()=>`100`,GLSL3:()=>Kr,GreaterCompare:()=>516,GreaterDepth:()=>6,GreaterEqualCompare:()=>518,GreaterEqualDepth:()=>5,GreaterEqualStencilFunc:()=>518,GreaterStencilFunc:()=>516,GridHelper:()=>Gn,Group:()=>Pi,HTMLTexture:()=>oa,HalfFloatType:()=>ar,HemisphereLight:()=>pi,HemisphereLightHelper:()=>ya,IcosahedronGeometry:()=>fr,ImageBitmapLoader:()=>Tr,ImageLoader:()=>Vi,ImageUtils:()=>bi,IncrementStencilOp:()=>zr,IncrementWrapStencilOp:()=>Mr,InstancedBufferAttribute:()=>zn,InstancedBufferGeometry:()=>Ea,InstancedInterleavedBuffer:()=>Ka,InstancedMesh:()=>Qn,Int16BufferAttribute:()=>Ba,Int32BufferAttribute:()=>Bt,Int8BufferAttribute:()=>j,IntType:()=>Na,InterleavedBuffer:()=>qt,InterleavedBufferAttribute:()=>re,Interpolant:()=>ee,InterpolateBezier:()=>pt,InterpolateDiscrete:()=>oi,InterpolateLinear:()=>_,InterpolateSmooth:()=>$r,InterpolationSamplingMode:()=>$e,InterpolationSamplingType:()=>ot,InvertStencilOp:()=>bt,KeepStencilOp:()=>ue,KeyframeTrack:()=>De,LOD:()=>Ke,LatheGeometry:()=>Nt,Layers:()=>$a,LessCompare:()=>513,LessDepth:()=>2,LessEqualCompare:()=>515,LessEqualDepth:()=>3,LessEqualStencilFunc:()=>515,LessStencilFunc:()=>513,Light:()=>w,LightProbe:()=>cn,Line:()=>W,Line3:()=>en,LineBasicMaterial:()=>hn,LineCurve:()=>H,LineCurve3:()=>Be,LineDashedMaterial:()=>qi,LineLoop:()=>Pe,LineSegments:()=>Dn,LinearFilter:()=>xn,LinearInterpolant:()=>Nn,LinearMipMapLinearFilter:()=>Dt,LinearMipMapNearestFilter:()=>d,LinearMipmapLinearFilter:()=>br,LinearMipmapNearestFilter:()=>ma,LinearSRGBColorSpace:()=>ki,LinearToneMapping:()=>1,LinearTransfer:()=>ta,Loader:()=>Jr,LoaderUtils:()=>qn,LoadingManager:()=>Ii,LoopOnce:()=>ca,LoopPingPong:()=>sr,LoopRepeat:()=>hi,MOUSE:()=>xa,Material:()=>mr,MaterialBlending:()=>6,MaterialLoader:()=>Dr,MathUtils:()=>Hi,Matrix2:()=>Si,Matrix3:()=>Vr,Matrix4:()=>Pr,MaxEquation:()=>104,Mesh:()=>G,MeshBasicMaterial:()=>Oa,MeshDepthMaterial:()=>Ja,MeshDistanceMaterial:()=>er,MeshLambertMaterial:()=>Ha,MeshMatcapMaterial:()=>Ht,MeshNormalMaterial:()=>N,MeshPhongMaterial:()=>Fa,MeshPhysicalMaterial:()=>Yt,MeshStandardMaterial:()=>ae,MeshToonMaterial:()=>ne,MinEquation:()=>103,MirroredRepeatWrapping:()=>ht,MixOperation:()=>1,MultiplyBlending:()=>4,MultiplyOperation:()=>0,NearestFilter:()=>ci,NearestMipMapLinearFilter:()=>y,NearestMipMapNearestFilter:()=>ti,NearestMipmapLinearFilter:()=>tt,NearestMipmapNearestFilter:()=>ct,NeutralToneMapping:()=>7,NeverCompare:()=>512,NeverDepth:()=>0,NeverStencilFunc:()=>512,NoBlending:()=>0,NoColorSpace:()=>``,NoNormalPacking:()=>``,NoToneMapping:()=>0,NormalAnimationBlendMode:()=>St,NormalBlending:()=>1,NormalGAPacking:()=>`ga`,NormalRGPacking:()=>`rg`,NotEqualCompare:()=>517,NotEqualDepth:()=>7,NotEqualStencilFunc:()=>517,NumberKeyframeTrack:()=>fe,Object3D:()=>ke,ObjectLoader:()=>Je,ObjectSpaceNormalMap:()=>1,OctahedronGeometry:()=>Ft,OneFactor:()=>201,OneMinusConstantAlphaFactor:()=>214,OneMinusConstantColorFactor:()=>212,OneMinusDstAlphaFactor:()=>207,OneMinusDstColorFactor:()=>209,OneMinusSrcAlphaFactor:()=>205,OneMinusSrcColorFactor:()=>203,OrthographicCamera:()=>to,PCFShadowMap:()=>1,PCFSoftShadowMap:()=>2,PMREMGenerator:()=>Oo,Path:()=>E,PerspectiveCamera:()=>un,Plane:()=>Se,PlaneGeometry:()=>nn,PlaneHelper:()=>gn,PointLight:()=>_e,PointLightHelper:()=>Ve,Points:()=>Ji,PointsMaterial:()=>Fe,PolarGridHelper:()=>On,PolyhedronGeometry:()=>Sn,PositionalAudio:()=>Pn,PropertyBinding:()=>Ot,PropertyMixer:()=>f,QuadraticBezierCurve:()=>_r,QuadraticBezierCurve3:()=>da,Quaternion:()=>Ei,QuaternionKeyframeTrack:()=>Qi,QuaternionLinearInterpolant:()=>Gr,R11_EAC_Format:()=>Wn,RED_GREEN_RGTC2_Format:()=>aa,RED_RGTC1_Format:()=>ir,REVISION:()=>`185`,RG11_EAC_Format:()=>fi,RGBADepthPacking:()=>va,RGBAFormat:()=>dr,RGBAIntegerFormat:()=>wr,RGBA_ASTC_10x10_Format:()=>Bi,RGBA_ASTC_10x5_Format:()=>yi,RGBA_ASTC_10x6_Format:()=>Rr,RGBA_ASTC_10x8_Format:()=>jr,RGBA_ASTC_12x10_Format:()=>Rn,RGBA_ASTC_12x12_Format:()=>Ta,RGBA_ASTC_4x4_Format:()=>Ga,RGBA_ASTC_5x4_Format:()=>Zn,RGBA_ASTC_5x5_Format:()=>za,RGBA_ASTC_6x5_Format:()=>zt,RGBA_ASTC_6x6_Format:()=>A,RGBA_ASTC_8x5_Format:()=>Ma,RGBA_ASTC_8x6_Format:()=>Kt,RGBA_ASTC_8x8_Format:()=>V,RGBA_BPTC_Format:()=>L,RGBA_ETC2_EAC_Format:()=>ft,RGBA_PVRTC_2BPPV1_Format:()=>ai,RGBA_PVRTC_4BPPV1_Format:()=>g,RGBA_S3TC_DXT1_Format:()=>Qr,RGBA_S3TC_DXT3_Format:()=>Qe,RGBA_S3TC_DXT5_Format:()=>at,RGBDepthPacking:()=>yt,RGBFormat:()=>le,RGBIntegerFormat:()=>Ee,RGB_BPTC_SIGNED_Format:()=>Ge,RGB_BPTC_UNSIGNED_Format:()=>Mt,RGB_ETC1_Format:()=>Qa,RGB_ETC2_Format:()=>C,RGB_PVRTC_2BPPV1_Format:()=>sn,RGB_PVRTC_4BPPV1_Format:()=>be,RGB_S3TC_DXT1_Format:()=>$t,RGDepthPacking:()=>mn,RGFormat:()=>ge,RGIntegerFormat:()=>ze,RawShaderMaterial:()=>Ki,Ray:()=>Ne,Raycaster:()=>En,RectAreaLight:()=>bn,RedFormat:()=>Mn,RedIntegerFormat:()=>Et,ReinhardToneMapping:()=>2,RenderTarget:()=>u,RenderTarget3D:()=>gr,RepeatWrapping:()=>ua,ReplaceStencilOp:()=>Ti,ReverseSubtractEquation:()=>102,RingGeometry:()=>Wr,SIGNED_R11_EAC_Format:()=>Un,SIGNED_RED_GREEN_RGTC2_Format:()=>Mi,SIGNED_RED_RGTC1_Format:()=>ia,SIGNED_RG11_EAC_Format:()=>rr,SRGBColorSpace:()=>di,SRGBTransfer:()=>_a,Scene:()=>ur,ShaderChunk:()=>X,ShaderLib:()=>so,ShaderMaterial:()=>Cr,ShadowMaterial:()=>zi,Shape:()=>vi,ShapeGeometry:()=>Lr,ShapePath:()=>Ar,ShapeUtils:()=>Ln,ShortType:()=>wa,Skeleton:()=>Wa,SkeletonHelper:()=>Xn,SkinnedMesh:()=>Ra,Source:()=>Rt,Sphere:()=>k,SphereGeometry:()=>ja,Spherical:()=>Gt,SphericalHarmonics3:()=>B,SplineCurve:()=>I,SpotLight:()=>dt,SpotLightHelper:()=>ii,Sprite:()=>h,SpriteMaterial:()=>Zr,SrcAlphaFactor:()=>204,SrcAlphaSaturateFactor:()=>210,SrcColorFactor:()=>202,StaticCopyUsage:()=>Ze,StaticDrawUsage:()=>it,StaticReadUsage:()=>vt,StereoCamera:()=>ce,StreamCopyUsage:()=>Te,StreamDrawUsage:()=>We,StreamReadUsage:()=>jt,StringKeyframeTrack:()=>Za,SubtractEquation:()=>101,SubtractiveBlending:()=>3,TOUCH:()=>S,TangentSpaceNormalMap:()=>0,TetrahedronGeometry:()=>on,Texture:()=>U,TextureLoader:()=>Qt,TextureUtils:()=>pn,Timer:()=>he,TimestampQuery:()=>Re,TorusGeometry:()=>Gi,TorusKnotGeometry:()=>Me,Triangle:()=>Tn,TriangleFanDrawMode:()=>2,TriangleStripDrawMode:()=>1,TrianglesDrawMode:()=>0,TubeGeometry:()=>yn,UVMapping:()=>300,Uint16BufferAttribute:()=>jn,Uint32BufferAttribute:()=>Tt,Uint8BufferAttribute:()=>l,Uint8ClampedBufferAttribute:()=>yr,Uniform:()=>pa,UniformsGroup:()=>Oi,UniformsLib:()=>Z,UniformsUtils:()=>ea,UnsignedByteType:()=>qr,UnsignedInt101111Type:()=>Kn,UnsignedInt248Type:()=>Fi,UnsignedInt5999Type:()=>sa,UnsignedIntType:()=>or,UnsignedShort4444Type:()=>mi,UnsignedShort5551Type:()=>ba,UnsignedShortType:()=>pr,VSMShadowMap:()=>3,Vector2:()=>Er,Vector3:()=>K,Vector4:()=>xi,VectorKeyframeTrack:()=>Br,VideoFrameTexture:()=>Nr,VideoTexture:()=>Bn,WebGL3DRenderTarget:()=>Da,WebGLArrayRenderTarget:()=>qa,WebGLCoordinateSystem:()=>$n,WebGLCubeRenderTarget:()=>Lo,WebGLRenderTarget:()=>Va,WebGLRenderer:()=>xl,WebGLUtils:()=>ll,WebGPUCoordinateSystem:()=>Vt,WebXRController:()=>M,WireframeGeometry:()=>Pa,WrapAroundEnding:()=>Jt,ZeroCurvatureEnding:()=>ie,ZeroFactor:()=>200,ZeroSlopeEnding:()=>te,ZeroStencilOp:()=>0,createCanvasElement:()=>si,error:()=>ei,getConsoleFunction:()=>st,log:()=>de,setConsoleFunction:()=>Pt,warn:()=>eo,warnOnce:()=>T});function ao(){let e=null,t=!1,n=null,r=null;function i(t,a){n(t,a),r=e.requestAnimationFrame(i)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function oo(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var X={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},Z={common:{diffuse:{value:new Ai(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Vr},alphaMap:{value:null},alphaMapTransform:{value:new Vr},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Vr}},envmap:{envMap:{value:null},envMapRotation:{value:new Vr},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Vr}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Vr}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Vr},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Vr},normalScale:{value:new Er(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Vr},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Vr}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Vr}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Vr}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ai(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new K},probesMax:{value:new K},probesResolution:{value:new K}},points:{diffuse:{value:new Ai(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Vr},alphaTest:{value:0},uvTransform:{value:new Vr}},sprite:{diffuse:{value:new Ai(16777215)},opacity:{value:1},center:{value:new Er(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Vr},alphaMap:{value:null},alphaMapTransform:{value:new Vr},alphaTest:{value:0}}},so={basic:{uniforms:Oe([Z.common,Z.specularmap,Z.envmap,Z.aomap,Z.lightmap,Z.fog]),vertexShader:X.meshbasic_vert,fragmentShader:X.meshbasic_frag},lambert:{uniforms:Oe([Z.common,Z.specularmap,Z.envmap,Z.aomap,Z.lightmap,Z.emissivemap,Z.bumpmap,Z.normalmap,Z.displacementmap,Z.fog,Z.lights,{emissive:{value:new Ai(0)},envMapIntensity:{value:1}}]),vertexShader:X.meshlambert_vert,fragmentShader:X.meshlambert_frag},phong:{uniforms:Oe([Z.common,Z.specularmap,Z.envmap,Z.aomap,Z.lightmap,Z.emissivemap,Z.bumpmap,Z.normalmap,Z.displacementmap,Z.fog,Z.lights,{emissive:{value:new Ai(0)},specular:{value:new Ai(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:X.meshphong_vert,fragmentShader:X.meshphong_frag},standard:{uniforms:Oe([Z.common,Z.envmap,Z.aomap,Z.lightmap,Z.emissivemap,Z.bumpmap,Z.normalmap,Z.displacementmap,Z.roughnessmap,Z.metalnessmap,Z.fog,Z.lights,{emissive:{value:new Ai(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:X.meshphysical_vert,fragmentShader:X.meshphysical_frag},toon:{uniforms:Oe([Z.common,Z.aomap,Z.lightmap,Z.emissivemap,Z.bumpmap,Z.normalmap,Z.displacementmap,Z.gradientmap,Z.fog,Z.lights,{emissive:{value:new Ai(0)}}]),vertexShader:X.meshtoon_vert,fragmentShader:X.meshtoon_frag},matcap:{uniforms:Oe([Z.common,Z.bumpmap,Z.normalmap,Z.displacementmap,Z.fog,{matcap:{value:null}}]),vertexShader:X.meshmatcap_vert,fragmentShader:X.meshmatcap_frag},points:{uniforms:Oe([Z.points,Z.fog]),vertexShader:X.points_vert,fragmentShader:X.points_frag},dashed:{uniforms:Oe([Z.common,Z.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:X.linedashed_vert,fragmentShader:X.linedashed_frag},depth:{uniforms:Oe([Z.common,Z.displacementmap]),vertexShader:X.depth_vert,fragmentShader:X.depth_frag},normal:{uniforms:Oe([Z.common,Z.bumpmap,Z.normalmap,Z.displacementmap,{opacity:{value:1}}]),vertexShader:X.meshnormal_vert,fragmentShader:X.meshnormal_frag},sprite:{uniforms:Oe([Z.sprite,Z.fog]),vertexShader:X.sprite_vert,fragmentShader:X.sprite_frag},background:{uniforms:{uvTransform:{value:new Vr},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:X.background_vert,fragmentShader:X.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Vr}},vertexShader:X.backgroundCube_vert,fragmentShader:X.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:X.cube_vert,fragmentShader:X.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:X.equirect_vert,fragmentShader:X.equirect_frag},distance:{uniforms:Oe([Z.common,Z.displacementmap,{referencePosition:{value:new K},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:X.distance_vert,fragmentShader:X.distance_frag},shadow:{uniforms:Oe([Z.lights,Z.fog,{color:{value:new Ai(0)},opacity:{value:1}}]),vertexShader:X.shadow_vert,fragmentShader:X.shadow_frag}};so.physical={uniforms:Oe([so.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Vr},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Vr},clearcoatNormalScale:{value:new Er(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Vr},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Vr},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Vr},sheen:{value:0},sheenColor:{value:new Ai(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Vr},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Vr},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Vr},transmissionSamplerSize:{value:new Er},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Vr},attenuationDistance:{value:0},attenuationColor:{value:new Ai(0)},specularColor:{value:new Ai(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Vr},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Vr},anisotropyVector:{value:new Er},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Vr}}]),vertexShader:X.meshphysical_vert,fragmentShader:X.meshphysical_frag};var co={r:0,b:0,g:0},lo=new Pr,uo=new Vr;uo.set(-1,0,0,0,1,0,0,0,1);function fo(e,t,n,r,i,a){let o=new Ai(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new G(new an(1,1,1),new Cr({name:`BackgroundCubeMaterial`,uniforms:mt(so.backgroundCube.uniforms),vertexShader:so.backgroundCube.vertexShader,fragmentShader:so.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(lo.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(uo),l.material.toneMapped=Yr.getTransfer(i.colorSpace)!==_a,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new G(new nn(2,2),new Cr({name:`BackgroundMaterial`,uniforms:mt(so.background.uniforms),vertexShader:so.background.vertexShader,fragmentShader:so.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=Yr.getTransfer(i.colorSpace)!==_a,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(co,xt(e)),n.buffers.color.setClear(co.r,co.g,co.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function po(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function mo(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function ho(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return!(t!==1023&&r.convert(t)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT))}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)&&n!==1015&&!i)}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(eo(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&eo(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function go(e){let t=this,n=null,r=0,i=!1,a=!1,o=new Se,s=new Vr,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var _o=4,vo=[.125,.215,.35,.446,.526,.582],yo=20,bo=256,xo=new to,So=new Ai,Co=null,wo=0,To=0,Eo=!1,Do=new K,Oo=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=Do}=i;Co=this._renderer.getRenderTarget(),wo=this._renderer.getActiveCubeFace(),To=this._renderer.getActiveMipmapLevel(),Eo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Fo(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Po(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Co,wo,To),this._renderer.xr.enabled=Eo,e.scissorTest=!1,jo(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Co=this._renderer.getRenderTarget(),wo=this._renderer.getActiveCubeFace(),To=this._renderer.getActiveMipmapLevel(),Eo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:xn,minFilter:xn,generateMipmaps:!1,type:ar,format:dr,colorSpace:ki,depthBuffer:!1},r=Ao(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Ao(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=ko(r)),this._blurMaterial=No(r,e,t),this._ggxMaterial=Mo(r,e,t)}return r}_compileMaterial(e){let t=new G(new fn,e);this._renderer.compile(t,xo)}_sceneToCubeUV(e,t,n,r,i){let a=new un(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(So),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new G(new an,new Oa({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(So),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;jo(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Fo()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Po());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;jo(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,xo)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(0+c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-_o?n-d+_o:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,jo(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,xo),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,jo(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,xo)}_blur(e,t,n,r,i){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,r,`latitudinal`,i),this._halfBlur(a,e,n,n,r,`longitudinal`,i)}_halfBlur(e,t,n,r,i,a,o){let s=this._renderer,c=this._blurMaterial;a!==`latitudinal`&&a!==`longitudinal`&&ei(`blur direction must be either latitudinal or longitudinal!`);let l=this._lodMeshes[r];l.material=c;let u=c.uniforms,d=this._sizeLods[n]-1,f=isFinite(i)?Math.PI/(2*d):2*Math.PI/(2*yo-1),p=i/f,m=isFinite(i)?1+Math.floor(3*p):yo;m>yo&&eo(`sigmaRadians, ${i}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${yo}`);let h=[],g=0;for(let e=0;e<yo;++e){let t=e/p,n=Math.exp(-t*t/2);h.push(n),e===0?g+=n:e<m&&(g+=2*n)}for(let e=0;e<h.length;e++)h[e]=h[e]/g;u.envMap.value=e.texture,u.samples.value=m,u.weights.value=h,u.latitudinal.value=a===`latitudinal`,o&&(u.poleAxis.value=o);let{_lodMax:_}=this;u.dTheta.value=f,u.mipInt.value=_-n;let v=this._sizeLods[r];jo(t,3*v*(r>_-_o?r-_+_o:0),4*(this._cubeSize-v),3*v,2*v),s.setRenderTarget(t),s.render(l,xo)}};function ko(e){let t=[],n=[],r=[],i=e,a=e-_o+1+vo.length;for(let o=0;o<a;o++){let a=2**i;t.push(a);let s=1/a;o>e-_o?s=vo[o-e+_o-1]:o===0&&(s=0),n.push(s);let c=1/(a-2),l=-c,u=1+c,d=[l,l,u,l,u,u,l,l,u,u,l,u],f=new Float32Array(108),p=new Float32Array(72),m=new Float32Array(36);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];f.set(r,18*e),p.set(d,12*e);let i=[e,e,e,e,e,e];m.set(i,6*e)}let h=new fn;h.setAttribute(`position`,new Zt(f,3)),h.setAttribute(`uv`,new Zt(p,2)),h.setAttribute(`faceIndex`,new Zt(m,1)),r.push(new G(h,null)),i>_o&&i--}return{lodMeshes:r,sizeLods:t,sigmas:n}}function Ao(e,t,n){let r=new Va(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function jo(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function Mo(e,t,n){return new Cr({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:bo,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Io(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function No(e,t,n){let r=new Float32Array(yo),i=new K(0,1,0);return new Cr({name:`SphericalGaussianBlur`,defines:{n:yo,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Io(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Po(){return new Cr({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:Io(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Fo(){return new Cr({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Io(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Io(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}var Lo=class extends Va{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Ci(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new an(5,5,5),i=new Cr({name:`CubemapFromEquirect`,uniforms:mt(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new G(r,i),o=t.minFilter;return t.minFilter===1008&&(t.minFilter=xn),new Or(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function Ro(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304)if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}else{let r=n.image;if(r&&r.height>0){let i=new Lo(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}else return null}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new Oo(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new Oo(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function zo(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&T(`WebGLRenderer: `+e+` extension not supported.`),t}}}function Bo(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0?t:(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++,t)}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?Tt:jn)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function Vo(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function Ho(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:ei(`WebGLInfo: Unknown draw mode:`,r);break}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function Uo(e,t,n){let r=new WeakMap,i=new xi;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let h=new Float32Array(p*m*4*u),g=new Ia(h,p,m,u);g.type=Fn,g.needsUpdate=!0;let _=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*_;e===!0&&(i.fromBufferAttribute(r,t),h[d+s+0]=i.x,h[d+s+1]=i.y,h[d+s+2]=i.z,h[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),h[d+s+4]=i.x,h[d+s+5]=i.y,h[d+s+6]=i.z,h[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),h[d+s+8]=i.x,h[d+s+9]=i.y,h[d+s+10]=i.z,h[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:g,size:new Er(p,m)},r.set(o,d);function v(){g.dispose(),r.delete(o),o.removeEventListener(`dispose`,v)}o.addEventListener(`dispose`,v)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function Wo(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var Go={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Ko(e,t,n,r,i,a){let o=new Va(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,depthTexture:i?new lt(t,n):void 0}),s=new Va(t,n,{type:ar,depthBuffer:!1,stencilBuffer:!1}),c=new fn;c.setAttribute(`position`,new Cn([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute(`uv`,new Cn([0,2,0,0,2,0],2));let l=new Ki({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new G(c,l),d=new to(-1,1,1,-1,0,1),f=null,p=null,m=!1,h,g=null,_=[],v=!1;this.setSize=function(e,t){o.setSize(e,t),s.setSize(e,t);for(let n=0;n<_.length;n++){let r=_[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){_=e,v=_.length>0&&_[0].isRenderPass===!0;let t=o.width,n=o.height;for(let e=0;e<_.length;e++){let r=_[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(m||e.toneMapping===0&&_.length===0)return!1;if(g=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return v===!1&&e.setRenderTarget(o),h=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return v},this.end=function(e,t){e.toneMapping=h,m=!0;let n=o,r=s;for(let i=0;i<_.length;i++){let a=_[i];if(a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1)){let e=n;n=r,r=e}}if(f!==e.outputColorSpace||p!==e.toneMapping){f=e.outputColorSpace,p=e.toneMapping,l.defines={},Yr.getTransfer(f)===`srgb`&&(l.defines.SRGB_TRANSFER=``);let t=Go[p];t&&(l.defines[t]=``),l.needsUpdate=!0}l.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(g),e.render(u,d),g=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){o.depthTexture&&o.depthTexture.dispose(),o.dispose(),s.dispose(),c.dispose(),l.dispose()}}var qo=new U,Jo=new lt(1,1),Yo=new Ia,Xo=new P,Zo=new Ci,Qo=[],$o=[],es=new Float32Array(16),ts=new Float32Array(9),ns=new Float32Array(4);function rs(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=Qo[i];if(a===void 0&&(a=new Float32Array(i),Qo[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function is(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function as(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function os(e,t){let n=$o[t];n===void 0&&(n=new Int32Array(t),$o[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function ss(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function cs(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(is(n,t))return;e.uniform2fv(this.addr,t),as(n,t)}}function ls(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(is(n,t))return;e.uniform3fv(this.addr,t),as(n,t)}}function us(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(is(n,t))return;e.uniform4fv(this.addr,t),as(n,t)}}function ds(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(is(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),as(n,t)}else{if(is(n,r))return;ns.set(r),e.uniformMatrix2fv(this.addr,!1,ns),as(n,r)}}function fs(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(is(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),as(n,t)}else{if(is(n,r))return;ts.set(r),e.uniformMatrix3fv(this.addr,!1,ts),as(n,r)}}function ps(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(is(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),as(n,t)}else{if(is(n,r))return;es.set(r),e.uniformMatrix4fv(this.addr,!1,es),as(n,r)}}function ms(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function hs(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(is(n,t))return;e.uniform2iv(this.addr,t),as(n,t)}}function gs(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(is(n,t))return;e.uniform3iv(this.addr,t),as(n,t)}}function _s(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(is(n,t))return;e.uniform4iv(this.addr,t),as(n,t)}}function vs(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function ys(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(is(n,t))return;e.uniform2uiv(this.addr,t),as(n,t)}}function bs(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(is(n,t))return;e.uniform3uiv(this.addr,t),as(n,t)}}function xs(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(is(n,t))return;e.uniform4uiv(this.addr,t),as(n,t)}}function Ss(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(Jo.compareFunction=n.isReversedDepthBuffer()?518:515,a=Jo):a=qo,n.setTexture2D(t||a,i)}function Cs(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Xo,i)}function ws(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||Zo,i)}function Ts(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||Yo,i)}function Es(e){switch(e){case 5126:return ss;case 35664:return cs;case 35665:return ls;case 35666:return us;case 35674:return ds;case 35675:return fs;case 35676:return ps;case 5124:case 35670:return ms;case 35667:case 35671:return hs;case 35668:case 35672:return gs;case 35669:case 35673:return _s;case 5125:return vs;case 36294:return ys;case 36295:return bs;case 36296:return xs;case 35678:case 36198:case 36298:case 36306:case 35682:return Ss;case 35679:case 36299:case 36307:return Cs;case 35680:case 36300:case 36308:case 36293:return ws;case 36289:case 36303:case 36311:case 36292:return Ts}}function Ds(e,t){e.uniform1fv(this.addr,t)}function Os(e,t){let n=rs(t,this.size,2);e.uniform2fv(this.addr,n)}function ks(e,t){let n=rs(t,this.size,3);e.uniform3fv(this.addr,n)}function As(e,t){let n=rs(t,this.size,4);e.uniform4fv(this.addr,n)}function js(e,t){let n=rs(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function Ms(e,t){let n=rs(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function Ns(e,t){let n=rs(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function Ps(e,t){e.uniform1iv(this.addr,t)}function Fs(e,t){e.uniform2iv(this.addr,t)}function Is(e,t){e.uniform3iv(this.addr,t)}function Ls(e,t){e.uniform4iv(this.addr,t)}function Rs(e,t){e.uniform1uiv(this.addr,t)}function zs(e,t){e.uniform2uiv(this.addr,t)}function Bs(e,t){e.uniform3uiv(this.addr,t)}function Vs(e,t){e.uniform4uiv(this.addr,t)}function Hs(e,t,n){let r=this.cache,i=t.length,a=os(n,i);is(r,a)||(e.uniform1iv(this.addr,a),as(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?Jo:qo;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function Us(e,t,n){let r=this.cache,i=t.length,a=os(n,i);is(r,a)||(e.uniform1iv(this.addr,a),as(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Xo,a[e])}function Ws(e,t,n){let r=this.cache,i=t.length,a=os(n,i);is(r,a)||(e.uniform1iv(this.addr,a),as(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||Zo,a[e])}function Gs(e,t,n){let r=this.cache,i=t.length,a=os(n,i);is(r,a)||(e.uniform1iv(this.addr,a),as(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||Yo,a[e])}function Ks(e){switch(e){case 5126:return Ds;case 35664:return Os;case 35665:return ks;case 35666:return As;case 35674:return js;case 35675:return Ms;case 35676:return Ns;case 5124:case 35670:return Ps;case 35667:case 35671:return Fs;case 35668:case 35672:return Is;case 35669:case 35673:return Ls;case 5125:return Rs;case 36294:return zs;case 36295:return Bs;case 36296:return Vs;case 35678:case 36198:case 36298:case 36306:case 35682:return Hs;case 35679:case 36299:case 36307:return Us;case 35680:case 36300:case 36308:case 36293:return Ws;case 36289:case 36303:case 36311:case 36292:return Gs}}var qs=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Es(t.type)}},Js=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Ks(t.type)}},Ys=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},Xs=/(\w+)(\])?(\[|\.)?/g;function Zs(e,t){e.seq.push(t),e.map[t.id]=t}function Qs(e,t,n){let r=e.name,i=r.length;for(Xs.lastIndex=0;;){let a=Xs.exec(r),o=Xs.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){Zs(n,l===void 0?new qs(s,e,t):new Js(s,e,t));break}else{let e=n.map[s];e===void 0&&(e=new Ys(s),Zs(n,e)),n=e}}}var $s=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);Qs(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function ec(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var tc=37297,nc=0;function rc(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var ic=new Vr;function ac(e){Yr._getMatrix(ic,Yr.workingColorSpace,e);let t=`mat3( ${ic.elements.map(e=>e.toFixed(4))} )`;switch(Yr.getTransfer(e)){case ta:return[t,`LinearTransferOETF`];case _a:return[t,`sRGBTransferOETF`];default:return eo(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function oc(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+rc(e.getShaderSource(t),r)}else return i}function sc(e,t){let n=ac(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var cc={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function lc(e,t){let n=cc[t];return n===void 0?(eo(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var uc=new K;function dc(){return Yr.getLuminanceCoefficients(uc),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${uc.x.toFixed(4)}, ${uc.y.toFixed(4)}, ${uc.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function fc(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(hc).join(`
`)}function pc(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function mc(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function hc(e){return e!==``}function gc(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function _c(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var vc=/^[ \t]*#include +<([\w\d./]+)>/gm;function yc(e){return e.replace(vc,xc)}var bc=new Map;function xc(e,t){let n=X[t];if(n===void 0){let e=bc.get(t);if(e!==void 0)n=X[e],eo(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return yc(n)}var Sc=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Cc(e){return e.replace(Sc,wc)}function wc(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function Tc(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var Ec={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function Dc(e){return Ec[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var Oc={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function kc(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:Oc[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var Ac={302:`ENVMAP_MODE_REFRACTION`};function jc(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:Ac[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var Mc={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function Nc(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:Mc[e.combine]||`ENVMAP_BLENDING_NONE`}function Pc(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function Fc(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=Dc(n),l=kc(n),u=jc(n),d=Nc(n),f=Pc(n),p=fc(n),m=pc(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(hc).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(hc).join(`
`),_.length>0&&(_+=`
`)):(g=[Tc(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(hc).join(`
`),_=[Tc(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:X.tonemapping_pars_fragment,n.toneMapping===0?``:lc(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,X.colorspace_pars_fragment,sc(`linearToOutputTexel`,n.outputColorSpace),dc(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(hc).join(`
`)),o=yc(o),o=gc(o,n),o=_c(o,n),s=yc(s),s=gc(s,n),s=_c(s,n),o=Cc(o),s=Cc(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=ec(i,i.VERTEX_SHADER,y),S=ec(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1)if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=oc(i,x,`vertex`),n=oc(i,S,`fragment`);ei(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}else o===``?(s===``||c===``)&&(u=!1):eo(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new $s(i,h),T=mc(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,tc)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=nc++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var Ic=0,Lc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Rc(e),t.set(e,n)),n}},Rc=class{constructor(e){this.id=Ic++,this.code=e,this.usedTimes=0}};function zc(e){return e===1030||e===37490||e===36285}function Bc(e,t,n,r,i,a){let o=new $a,s=new Lc,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&eo(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=so[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),M=e.state.buffers.depth.getReversed(),N=h.isInstancedMesh===!0,P=h.isBatchedMesh===!0,F=!!i.map,I=!!i.matcap,L=!!x,ee=!!i.aoMap,te=!!i.lightMap,ne=!!i.bumpMap&&i.wireframe===!1,R=!!i.normalMap,z=!!i.displacementMap,B=!!i.emissiveMap,V=!!i.metalnessMap,re=!!i.roughnessMap,ie=i.anisotropy>0,ae=i.clearcoat>0,oe=i.dispersion>0,se=i.iridescence>0,ce=i.sheen>0,le=i.transmission>0,ue=ie&&!!i.anisotropyMap,de=ae&&!!i.clearcoatMap,fe=ae&&!!i.clearcoatNormalMap,pe=ae&&!!i.clearcoatRoughnessMap,me=se&&!!i.iridescenceMap,he=se&&!!i.iridescenceThicknessMap,ge=ce&&!!i.sheenColorMap,H=ce&&!!i.sheenRoughnessMap,_e=!!i.specularMap,ve=!!i.specularColorMap,ye=!!i.specularIntensityMap,U=le&&!!i.transmissionMap,be=le&&!!i.thicknessMap,W=!!i.gradientMap,xe=!!i.alphaMap,Se=i.alphaTest>0,Ce=!!i.alphaHash,we=!!i.extensions,Te=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Te=e.toneMapping);let Ee={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:P,batchingColor:P&&h._colorsTexture!==null,instancing:N,instancingColor:N&&h.instanceColor!==null,instancingMorph:N&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:Yr.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:F,matcap:I,envMap:L,envMapMode:L&&x.mapping,envMapCubeUVHeight:S,aoMap:ee,lightMap:te,bumpMap:ne,normalMap:R,displacementMap:z,emissiveMap:B,normalMapObjectSpace:R&&i.normalMapType===1,normalMapTangentSpace:R&&i.normalMapType===0,packedNormalMap:R&&i.normalMapType===0&&zc(i.normalMap.format),metalnessMap:V,roughnessMap:re,anisotropy:ie,anisotropyMap:ue,clearcoat:ae,clearcoatMap:de,clearcoatNormalMap:fe,clearcoatRoughnessMap:pe,dispersion:oe,iridescence:se,iridescenceMap:me,iridescenceThicknessMap:he,sheen:ce,sheenColorMap:ge,sheenRoughnessMap:H,specularMap:_e,specularColorMap:ve,specularIntensityMap:ye,transmission:le,transmissionMap:U,thicknessMap:be,gradientMap:W,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:xe,alphaTest:Se,alphaHash:Ce,combine:i.combine,mapUv:F&&m(i.map.channel),aoMapUv:ee&&m(i.aoMap.channel),lightMapUv:te&&m(i.lightMap.channel),bumpMapUv:ne&&m(i.bumpMap.channel),normalMapUv:R&&m(i.normalMap.channel),displacementMapUv:z&&m(i.displacementMap.channel),emissiveMapUv:B&&m(i.emissiveMap.channel),metalnessMapUv:V&&m(i.metalnessMap.channel),roughnessMapUv:re&&m(i.roughnessMap.channel),anisotropyMapUv:ue&&m(i.anisotropyMap.channel),clearcoatMapUv:de&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:fe&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:pe&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:me&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:he&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:ge&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:H&&m(i.sheenRoughnessMap.channel),specularMapUv:_e&&m(i.specularMap.channel),specularColorMapUv:ve&&m(i.specularColorMap.channel),specularIntensityMapUv:ye&&m(i.specularIntensityMap.channel),transmissionMapUv:U&&m(i.transmissionMap.channel),thicknessMapUv:be&&m(i.thicknessMap.channel),alphaMapUv:xe&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(R||ie),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(F||xe),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&R===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:M,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Te,decodeVideoTexture:F&&i.map.isVideoTexture===!0&&Yr.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:B&&i.emissiveMap.isVideoTexture===!0&&Yr.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:we&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(we&&i.extensions.multiDraw===!0||P)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return Ee.vertexUv1s=c.has(1),Ee.vertexUv2s=c.has(2),Ee.vertexUv3s=c.has(3),c.clear(),Ee}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=so[t];n=ea.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new Fc(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function Vc(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function Hc(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Uc(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Wc(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.push(u):a.transparent===!0?i.push(u):n.push(u)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t,a){n.length>1&&n.sort(e||Hc),r.length>1&&r.sort(t||Uc),i.length>1&&i.sort(t||Uc),a&&(n.reverse(),r.reverse(),i.reverse())}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function Gc(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new Wc,e.set(t,[i])):n>=r.length?(i=new Wc,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function Kc(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`DirectionalLight`:n={direction:new K,color:new Ai};break;case`SpotLight`:n={position:new K,direction:new K,color:new Ai,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new K,color:new Ai,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new K,skyColor:new Ai,groundColor:new Ai};break;case`RectAreaLight`:n={color:new Ai,position:new K,halfWidth:new K,halfHeight:new K};break}return e[t.id]=n,n}}}function qc(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Er};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Er};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Er,shadowCameraNear:1,shadowCameraFar:1e3};break}return e[t.id]=n,n}}}var Jc=0;function Yc(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Xc(e){let t=new Kc,n=qc(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new K);let i=new K,a=new Pr,o=new Pr;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0;i.sort(Yc);for(let e=0,y=i.length;e<y;e++){let y=i[e],b=y.color,x=y.intensity,S=y.distance,C=null;if(y.shadow&&y.shadow.map&&(C=y.shadow.map.texture.format===1030?y.shadow.map.texture:y.shadow.map.depthTexture||y.shadow.map.texture),y.isAmbientLight)a+=b.r*x,o+=b.g*x,s+=b.b*x;else if(y.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(y.sh.coefficients[e],x);v++}else if(y.isDirectionalLight){let e=t.get(y);if(e.color.copy(y.color).multiplyScalar(y.intensity),y.castShadow){let e=y.shadow,t=n.get(y);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[c]=t,r.directionalShadowMap[c]=C,r.directionalShadowMatrix[c]=y.shadow.matrix,p++}r.directional[c]=e,c++}else if(y.isSpotLight){let e=t.get(y);e.position.setFromMatrixPosition(y.matrixWorld),e.color.copy(b).multiplyScalar(x),e.distance=S,e.coneCos=Math.cos(y.angle),e.penumbraCos=Math.cos(y.angle*(1-y.penumbra)),e.decay=y.decay,r.spot[u]=e;let i=y.shadow;if(y.map&&(r.spotLightMap[g]=y.map,g++,i.updateMatrices(y),y.castShadow&&_++),r.spotLightMatrix[u]=i.matrix,y.castShadow){let e=n.get(y);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[u]=e,r.spotShadowMap[u]=C,h++}u++}else if(y.isRectAreaLight){let e=t.get(y);e.color.copy(b).multiplyScalar(x),e.halfWidth.set(y.width*.5,0,0),e.halfHeight.set(0,y.height*.5,0),r.rectArea[d]=e,d++}else if(y.isPointLight){let e=t.get(y);if(e.color.copy(y.color).multiplyScalar(y.intensity),e.distance=y.distance,e.decay=y.decay,y.castShadow){let e=y.shadow,t=n.get(y);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[l]=t,r.pointShadowMap[l]=C,r.pointShadowMatrix[l]=y.shadow.matrix,m++}r.point[l]=e,l++}else if(y.isHemisphereLight){let e=t.get(y);e.skyColor.copy(y.color).multiplyScalar(x),e.groundColor.copy(y.groundColor).multiplyScalar(x),r.hemi[f]=e,f++}}d>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=Z.LTC_FLOAT_1,r.rectAreaLTC2=Z.LTC_FLOAT_2):(r.rectAreaLTC1=Z.LTC_HALF_1,r.rectAreaLTC2=Z.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let y=r.hash;(y.directionalLength!==c||y.pointLength!==l||y.spotLength!==u||y.rectAreaLength!==d||y.hemiLength!==f||y.numDirectionalShadows!==p||y.numPointShadows!==m||y.numSpotShadows!==h||y.numSpotMaps!==g||y.numLightProbes!==v)&&(r.directional.length=c,r.spot.length=u,r.rectArea.length=d,r.point.length=l,r.hemi.length=f,r.directionalShadow.length=p,r.directionalShadowMap.length=p,r.pointShadow.length=m,r.pointShadowMap.length=m,r.spotShadow.length=h,r.spotShadowMap.length=h,r.directionalShadowMatrix.length=p,r.pointShadowMatrix.length=m,r.spotLightMatrix.length=h+g-_,r.spotLightMap.length=g,r.numSpotLightShadowsWithMaps=_,r.numLightProbes=v,y.directionalLength=c,y.pointLength=l,y.spotLength=u,y.rectAreaLength=d,y.hemiLength=f,y.numDirectionalShadows=p,y.numPointShadows=m,y.numSpotShadows=h,y.numSpotMaps=g,y.numLightProbes=v,r.version=Jc++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=t.matrixWorldInverse;for(let t=0,f=e.length;t<f;t++){let f=e[t];if(f.isDirectionalLight){let e=r.directional[n];e.direction.setFromMatrixPosition(f.matrixWorld),i.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(d),n++}else if(f.isSpotLight){let e=r.spot[c];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),e.direction.setFromMatrixPosition(f.matrixWorld),i.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(d),c++}else if(f.isRectAreaLight){let e=r.rectArea[l];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),o.identity(),a.copy(f.matrixWorld),a.premultiply(d),o.extractRotation(a),e.halfWidth.set(f.width*.5,0,0),e.halfHeight.set(0,f.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),l++}else if(f.isPointLight){let e=r.point[s];e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(d),s++}else if(f.isHemisphereLight){let e=r.hemi[u];e.direction.setFromMatrixPosition(f.matrixWorld),e.direction.transformDirection(d),u++}}}return{setup:s,setupView:c,state:r}}function Zc(e){let t=new Xc(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function Qc(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new Zc(e),t.set(n,[a])):r>=i.length?(a=new Zc(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var $c=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,el=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,tl=[new K(1,0,0),new K(-1,0,0),new K(0,1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1)],nl=[new K(0,-1,0),new K(0,-1,0),new K(0,0,1),new K(0,0,-1),new K(0,-1,0),new K(0,-1,0)],rl=new Pr,il=new K,al=new K;function ol(e,t,n){let r=new fa,i=new Er,a=new Er,o=new xi,s=new Ja,c=new er,l={},u=n.maxTextureSize,d={0:1,1:0,2:2},f=new Cr({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Er},radius:{value:4}},vertexShader:$c,fragmentShader:el}),p=f.clone();p.defines.HORIZONTAL_PASS=1;let m=new fn;m.setAttribute(`position`,new Zt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let h=new G(m,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let _=this.type;this.render=function(t,n,s){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||t.length===0)return;this.type===2&&(eo(`WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead.`),this.type=1);let c=e.getRenderTarget(),l=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),f=e.state;f.setBlending(0),f.buffers.depth.getReversed()===!0?f.buffers.color.setClear(0,0,0,0):f.buffers.color.setClear(1,1,1,1),f.buffers.depth.setTest(!0),f.setScissorTest(!1);let p=_!==this.type;p&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let c=0,l=t.length;c<l;c++){let l=t[c],d=l.shadow;if(d===void 0){eo(`WebGLShadowMap:`,l,`has no shadow.`);continue}if(d.autoUpdate===!1&&d.needsUpdate===!1)continue;i.copy(d.mapSize);let m=d.getFrameExtents();i.multiply(m),a.copy(d.mapSize),(i.x>u||i.y>u)&&(i.x>u&&(a.x=Math.floor(u/m.x),i.x=a.x*m.x,d.mapSize.x=a.x),i.y>u&&(a.y=Math.floor(u/m.y),i.y=a.y*m.y,d.mapSize.y=a.y));let h=e.state.buffers.depth.getReversed();if(d.camera._reversedDepth=h,d.map===null||p===!0){if(d.map!==null&&(d.map.depthTexture!==null&&(d.map.depthTexture.dispose(),d.map.depthTexture=null),d.map.dispose()),this.type===3){if(l.isPointLight){eo(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}d.map=new Va(i.x,i.y,{format:ge,type:ar,minFilter:xn,magFilter:xn,generateMipmaps:!1}),d.map.texture.name=l.name+`.shadowMap`,d.map.depthTexture=new lt(i.x,i.y,Fn),d.map.depthTexture.name=l.name+`.shadowMapDepth`,d.map.depthTexture.format=ni,d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=ci,d.map.depthTexture.magFilter=ci}else l.isPointLight?(d.map=new Lo(i.x),d.map.depthTexture=new Ui(i.x,or)):(d.map=new Va(i.x,i.y),d.map.depthTexture=new lt(i.x,i.y,or)),d.map.depthTexture.name=l.name+`.shadowMap`,d.map.depthTexture.format=ni,this.type===1?(d.map.depthTexture.compareFunction=h?518:515,d.map.depthTexture.minFilter=xn,d.map.depthTexture.magFilter=xn):(d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=ci,d.map.depthTexture.magFilter=ci);d.camera.updateProjectionMatrix()}let g=d.map.isWebGLCubeRenderTarget?6:1;for(let t=0;t<g;t++){if(d.map.isWebGLCubeRenderTarget)e.setRenderTarget(d.map,t),e.clear();else{t===0&&(e.setRenderTarget(d.map),e.clear());let n=d.getViewport(t);o.set(a.x*n.x,a.y*n.y,a.x*n.z,a.y*n.w),f.viewport(o)}if(l.isPointLight){let e=d.camera,n=d.matrix,r=l.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),il.setFromMatrixPosition(l.matrixWorld),e.position.copy(il),al.copy(e.position),al.add(tl[t]),e.up.copy(nl[t]),e.lookAt(al),e.updateMatrixWorld(),n.makeTranslation(-il.x,-il.y,-il.z),rl.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),d._frustum.setFromProjectionMatrix(rl,e.coordinateSystem,e.reversedDepth)}else d.updateMatrices(l);r=d.getFrustum(),b(n,s,d.camera,l,this.type)}d.isPointLightShadow!==!0&&this.type===3&&v(d,s),d.needsUpdate=!1}_=this.type,g.needsUpdate=!1,e.setRenderTarget(c,l,d)};function v(n,r){let a=t.update(h);f.defines.VSM_SAMPLES!==n.blurSamples&&(f.defines.VSM_SAMPLES=n.blurSamples,p.defines.VSM_SAMPLES=n.blurSamples,f.needsUpdate=!0,p.needsUpdate=!0),n.mapPass===null&&(n.mapPass=new Va(i.x,i.y,{format:ge,type:ar})),f.uniforms.shadow_pass.value=n.map.depthTexture,f.uniforms.resolution.value=n.mapSize,f.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,a,f,h,null),p.uniforms.shadow_pass.value=n.mapPass.texture,p.uniforms.resolution.value=n.mapSize,p.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,a,p,h,null)}function y(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?c:s,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=l[e];r===void 0&&(r={},l[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,x)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?d[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function b(n,i,a,o,s){if(n.visible===!1)return;if(n.layers.test(i.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||r.intersectsObject(n))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let r=t.update(n),c=n.material;if(Array.isArray(c)){let t=r.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=y(n,d,o,s);n.onBeforeShadow(e,n,i,a,r,t,u),e.renderBufferDirect(a,null,r,t,n,u),n.onAfterShadow(e,n,i,a,r,t,u)}}}else if(c.visible){let t=y(n,c,o,s);n.onBeforeShadow(e,n,i,a,r,t,null),e.renderBufferDirect(a,null,r,t,n,null),n.onAfterShadow(e,n,i,a,r,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)b(c[e],i,a,o,s)}function x(e){e.target.removeEventListener(`dispose`,x);for(let t in l){let n=l[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function sl(e,t){function n(){let t=!1,n=new xi,r=null,i=new xi(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?V(e.DEPTH_TEST):re(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=Zi[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?V(e.STENCIL_TEST):re(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new Ai(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,M=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),N=!1,P=0,F=e.getParameter(e.VERSION);F.indexOf(`WebGL`)===-1?F.indexOf(`OpenGL ES`)!==-1&&(P=parseFloat(/^OpenGL ES (\d)/.exec(F)[1]),N=P>=2):(P=parseFloat(/^WebGL (\d)/.exec(F)[1]),N=P>=1);let I=null,L={},ee=e.getParameter(e.SCISSOR_BOX),te=e.getParameter(e.VIEWPORT),ne=new xi().fromArray(ee),R=new xi().fromArray(te);function z(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let B={};B[e.TEXTURE_2D]=z(e.TEXTURE_2D,e.TEXTURE_2D,1),B[e.TEXTURE_CUBE_MAP]=z(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),B[e.TEXTURE_2D_ARRAY]=z(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),B[e.TEXTURE_3D]=z(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),V(e.DEPTH_TEST),o.setFunc(3),de(!1),fe(1),V(e.CULL_FACE),le(0);function V(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function re(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function ie(t,n){return f[t]===n?!1:(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function ae(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function oe(t){return h===t?!1:(e.useProgram(t),h=t,!0)}let se={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};se[103]=e.MIN,se[104]=e.MAX;let ce={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function le(t,n,r,i,a,o,s,c,l,u){if(t===0){g===!0&&(re(e.BLEND),g=!1);return}if(g===!1&&(V(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:ei(`WebGLState: Invalid blending: `,t);break}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:ei(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:ei(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:ei(`WebGLState: Invalid blending: `,t);break}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}return}a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(se[n],se[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(ce[r],ce[i],ce[o],ce[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function ue(t,n){t.side===2?re(e.CULL_FACE):V(e.CULL_FACE);let r=t.side===1;n&&(r=!r),de(r),t.blending===1&&t.transparent===!1?le(0):le(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),me(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?V(e.SAMPLE_ALPHA_TO_COVERAGE):re(e.SAMPLE_ALPHA_TO_COVERAGE)}function de(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function fe(t){t===0?re(e.CULL_FACE):(V(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function pe(t){t!==k&&(N&&e.lineWidth(t),k=t)}function me(t,n,r){t?(V(e.POLYGON_OFFSET_FILL),(A!==n||j!==r)&&(A=n,j=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):re(e.POLYGON_OFFSET_FILL)}function he(t){t?V(e.SCISSOR_TEST):re(e.SCISSOR_TEST)}function ge(t){t===void 0&&(t=e.TEXTURE0+M-1),I!==t&&(e.activeTexture(t),I=t)}function H(t,n,r){r===void 0&&(r=I===null?e.TEXTURE0+M-1:I);let i=L[r];i===void 0&&(i={type:void 0,texture:void 0},L[r]=i),(i.type!==t||i.texture!==n)&&(I!==r&&(e.activeTexture(r),I=r),e.bindTexture(t,n||B[t]),i.type=t,i.texture=n)}function _e(){let t=L[I];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function ve(){try{e.compressedTexImage2D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function ye(){try{e.compressedTexImage3D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function U(){try{e.texSubImage2D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function be(){try{e.texSubImage3D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function W(){try{e.compressedTexSubImage2D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function xe(){try{e.compressedTexSubImage3D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function Se(){try{e.texStorage2D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function Ce(){try{e.texStorage3D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function we(){try{e.texImage2D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function Te(){try{e.texImage3D(...arguments)}catch(e){ei(`WebGLState:`,e)}}function Ee(t){return d[t]===void 0?e.getParameter(t):d[t]}function De(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function Oe(t){ne.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),ne.copy(t))}function ke(t){R.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),R.copy(t))}function Ae(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function je(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function Me(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},I=null,L={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new Ai(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ne.set(0,0,e.canvas.width,e.canvas.height),R.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:V,disable:re,bindFramebuffer:ie,drawBuffers:ae,useProgram:oe,setBlending:le,setMaterial:ue,setFlipSided:de,setCullFace:fe,setLineWidth:pe,setPolygonOffset:me,setScissorTest:he,activeTexture:ge,bindTexture:H,unbindTexture:_e,compressedTexImage2D:ve,compressedTexImage3D:ye,texImage2D:we,texImage3D:Te,pixelStorei:De,getParameter:Ee,updateUBOMapping:Ae,uniformBlockBinding:je,texStorage2D:Se,texStorage3D:Ce,texSubImage2D:U,texSubImage3D:be,compressedTexSubImage2D:W,compressedTexSubImage3D:xe,scissor:Oe,viewport:ke,reset:Me}}function cl(e,t,n,r,i,a,o){let s=t.has(`WEBGL_multisampled_render_to_texture`)?t.get(`WEBGL_multisampled_render_to_texture`):null,c=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),l=new Er,u=new WeakMap,d=new Set,f,p=new WeakMap,m=!1;try{m=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function h(e,t){return m?new OffscreenCanvas(e,t):v(`canvas`)}function g(e,t,n){let r=1,i=ye(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1)if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);f===void 0&&(f=h(n,a));let o=t?h(n,a):f;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),eo(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}else return`data`in e&&eo(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e;return e}function _(e){return e.generateMipmaps}function y(t){e.generateMipmap(t)}function b(t){return t.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:t.isWebGL3DRenderTarget?e.TEXTURE_3D:t.isWebGLArrayRenderTarget||t.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function x(n,r,i,a,o,s=!1){if(n!==null){if(e[n]!==void 0)return e[n];eo(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+n+`'`)}let c;a&&(c=t.get(`EXT_texture_norm16`),c||eo(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let l=r;if(r===e.RED&&(i===e.FLOAT&&(l=e.R32F),i===e.HALF_FLOAT&&(l=e.R16F),i===e.UNSIGNED_BYTE&&(l=e.R8),i===e.UNSIGNED_SHORT&&c&&(l=c.R16_EXT),i===e.SHORT&&c&&(l=c.R16_SNORM_EXT)),r===e.RED_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.R8UI),i===e.UNSIGNED_SHORT&&(l=e.R16UI),i===e.UNSIGNED_INT&&(l=e.R32UI),i===e.BYTE&&(l=e.R8I),i===e.SHORT&&(l=e.R16I),i===e.INT&&(l=e.R32I)),r===e.RG&&(i===e.FLOAT&&(l=e.RG32F),i===e.HALF_FLOAT&&(l=e.RG16F),i===e.UNSIGNED_BYTE&&(l=e.RG8),i===e.UNSIGNED_SHORT&&c&&(l=c.RG16_EXT),i===e.SHORT&&c&&(l=c.RG16_SNORM_EXT)),r===e.RG_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RG8UI),i===e.UNSIGNED_SHORT&&(l=e.RG16UI),i===e.UNSIGNED_INT&&(l=e.RG32UI),i===e.BYTE&&(l=e.RG8I),i===e.SHORT&&(l=e.RG16I),i===e.INT&&(l=e.RG32I)),r===e.RGB_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGB8UI),i===e.UNSIGNED_SHORT&&(l=e.RGB16UI),i===e.UNSIGNED_INT&&(l=e.RGB32UI),i===e.BYTE&&(l=e.RGB8I),i===e.SHORT&&(l=e.RGB16I),i===e.INT&&(l=e.RGB32I)),r===e.RGBA_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGBA8UI),i===e.UNSIGNED_SHORT&&(l=e.RGBA16UI),i===e.UNSIGNED_INT&&(l=e.RGBA32UI),i===e.BYTE&&(l=e.RGBA8I),i===e.SHORT&&(l=e.RGBA16I),i===e.INT&&(l=e.RGBA32I)),r===e.RGB&&(i===e.UNSIGNED_SHORT&&c&&(l=c.RGB16_EXT),i===e.SHORT&&c&&(l=c.RGB16_SNORM_EXT),i===e.UNSIGNED_INT_5_9_9_9_REV&&(l=e.RGB9_E5),i===e.UNSIGNED_INT_10F_11F_11F_REV&&(l=e.R11F_G11F_B10F)),r===e.RGBA){let t=s?ta:Yr.getTransfer(o);i===e.FLOAT&&(l=e.RGBA32F),i===e.HALF_FLOAT&&(l=e.RGBA16F),i===e.UNSIGNED_BYTE&&(l=t===`srgb`?e.SRGB8_ALPHA8:e.RGBA8),i===e.UNSIGNED_SHORT&&c&&(l=c.RGBA16_EXT),i===e.SHORT&&c&&(l=c.RGBA16_SNORM_EXT),i===e.UNSIGNED_SHORT_4_4_4_4&&(l=e.RGBA4),i===e.UNSIGNED_SHORT_5_5_5_1&&(l=e.RGB5_A1)}return(l===e.R16F||l===e.R32F||l===e.RG16F||l===e.RG32F||l===e.RGBA16F||l===e.RGBA32F)&&t.get(`EXT_color_buffer_float`),l}function S(t,n){let r;return t?n===null||n===1014||n===1020?r=e.DEPTH24_STENCIL8:n===1015?r=e.DEPTH32F_STENCIL8:n===1012&&(r=e.DEPTH24_STENCIL8,eo(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):n===null||n===1014||n===1020?r=e.DEPTH_COMPONENT24:n===1015?r=e.DEPTH_COMPONENT32F:n===1012&&(r=e.DEPTH_COMPONENT16),r}function C(e,t){return _(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function w(e){let t=e.target;t.removeEventListener(`dispose`,w),E(t),t.isVideoTexture&&u.delete(t),t.isHTMLTexture&&d.delete(t)}function T(e){let t=e.target;t.removeEventListener(`dispose`,T),O(t)}function E(e){let t=r.get(e);if(t.__webglInit===void 0)return;let n=e.source,i=p.get(n);if(i){let r=i[t.__cacheKey];r.usedTimes--,r.usedTimes===0&&D(e),Object.keys(i).length===0&&p.delete(n)}r.remove(e)}function D(t){let n=r.get(t);e.deleteTexture(n.__webglTexture);let i=t.source,a=p.get(i);delete a[n.__cacheKey],o.memory.textures--}function O(t){let n=r.get(t);if(t.depthTexture&&(t.depthTexture.dispose(),r.remove(t.depthTexture)),t.isWebGLCubeRenderTarget)for(let t=0;t<6;t++){if(Array.isArray(n.__webglFramebuffer[t]))for(let r=0;r<n.__webglFramebuffer[t].length;r++)e.deleteFramebuffer(n.__webglFramebuffer[t][r]);else e.deleteFramebuffer(n.__webglFramebuffer[t]);n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer[t])}else{if(Array.isArray(n.__webglFramebuffer))for(let t=0;t<n.__webglFramebuffer.length;t++)e.deleteFramebuffer(n.__webglFramebuffer[t]);else e.deleteFramebuffer(n.__webglFramebuffer);if(n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer),n.__webglMultisampledFramebuffer&&e.deleteFramebuffer(n.__webglMultisampledFramebuffer),n.__webglColorRenderbuffer)for(let t=0;t<n.__webglColorRenderbuffer.length;t++)n.__webglColorRenderbuffer[t]&&e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);n.__webglDepthRenderbuffer&&e.deleteRenderbuffer(n.__webglDepthRenderbuffer)}let i=t.textures;for(let t=0,n=i.length;t<n;t++){let n=r.get(i[t]);n.__webglTexture&&(e.deleteTexture(n.__webglTexture),o.memory.textures--),r.remove(i[t])}r.remove(t)}let k=0;function A(){k=0}function j(){return k}function M(e){k=e}function N(){let e=k;return e>=i.maxTextures&&eo(`WebGLTextures: Trying to use `+e+` texture units while this GPU supports only `+i.maxTextures),k+=1,e}function P(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function F(t,i){let a=r.get(t);if(t.isVideoTexture&&_e(t),t.isRenderTargetTexture===!1&&t.isExternalTexture!==!0&&t.version>0&&a.__version!==t.version){let e=t.image;if(e===null)eo(`WebGLRenderer: Texture marked for update but no image data found.`);else if(e.complete===!1)eo(`WebGLRenderer: Texture marked for update but image is incomplete`);else{ie(a,t,i);return}}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D,a.__webglTexture,e.TEXTURE0+i)}function I(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){ie(a,t,i);return}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+i)}function L(t,i){let a=r.get(t);if(t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version){ie(a,t,i);return}n.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+i)}function ee(t,i){let a=r.get(t);if(t.isCubeDepthTexture!==!0&&t.version>0&&a.__version!==t.version){ae(a,t,i);return}n.bindTexture(e.TEXTURE_CUBE_MAP,a.__webglTexture,e.TEXTURE0+i)}let te={[ua]:e.REPEAT,[xr]:e.CLAMP_TO_EDGE,[ht]:e.MIRRORED_REPEAT},ne={[ci]:e.NEAREST,[ct]:e.NEAREST_MIPMAP_NEAREST,[tt]:e.NEAREST_MIPMAP_LINEAR,[xn]:e.LINEAR,[ma]:e.LINEAR_MIPMAP_NEAREST,[br]:e.LINEAR_MIPMAP_LINEAR},R={512:e.NEVER,519:e.ALWAYS,513:e.LESS,515:e.LEQUAL,514:e.EQUAL,518:e.GEQUAL,516:e.GREATER,517:e.NOTEQUAL};function z(n,a){if(a.type===1015&&t.has(`OES_texture_float_linear`)===!1&&(a.magFilter===1006||a.magFilter===1007||a.magFilter===1005||a.magFilter===1008||a.minFilter===1006||a.minFilter===1007||a.minFilter===1005||a.minFilter===1008)&&eo(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),e.texParameteri(n,e.TEXTURE_WRAP_S,te[a.wrapS]),e.texParameteri(n,e.TEXTURE_WRAP_T,te[a.wrapT]),(n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY)&&e.texParameteri(n,e.TEXTURE_WRAP_R,te[a.wrapR]),e.texParameteri(n,e.TEXTURE_MAG_FILTER,ne[a.magFilter]),e.texParameteri(n,e.TEXTURE_MIN_FILTER,ne[a.minFilter]),a.compareFunction&&(e.texParameteri(n,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(n,e.TEXTURE_COMPARE_FUNC,R[a.compareFunction])),t.has(`EXT_texture_filter_anisotropic`)===!0){if(a.magFilter===1003||a.minFilter!==1005&&a.minFilter!==1008||a.type===1015&&t.has(`OES_texture_float_linear`)===!1)return;if(a.anisotropy>1||r.get(a).__currentAnisotropy){let o=t.get(`EXT_texture_filter_anisotropic`);e.texParameterf(n,o.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,i.getMaxAnisotropy())),r.get(a).__currentAnisotropy=a.anisotropy}}}function B(t,n){let r=!1;t.__webglInit===void 0&&(t.__webglInit=!0,n.addEventListener(`dispose`,w));let i=n.source,a=p.get(i);a===void 0&&(a={},p.set(i,a));let s=P(n);if(s!==t.__cacheKey){a[s]===void 0&&(a[s]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,r=!0),a[s].usedTimes++;let i=a[t.__cacheKey];i!==void 0&&(a[t.__cacheKey].usedTimes--,i.usedTimes===0&&D(n)),t.__cacheKey=s,t.__webglTexture=a[s].texture}return r}function V(e,t,n){return Math.floor(Math.floor(e/n)/t)}function re(t,r,i,a){let o=t.updateRanges;if(o.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,r.width,r.height,i,a,r.data);else{o.sort((e,t)=>e.start-t.start);let s=0;for(let e=1;e<o.length;e++){let t=o[s],n=o[e],i=t.start+t.count,a=V(n.start,r.width,4),c=V(t.start,r.width,4);n.start<=i+1&&a===c&&V(n.start+n.count-1,r.width,4)===a?t.count=Math.max(t.count,n.start+n.count-t.start):(++s,o[s]=n)}o.length=s+1;let c=n.getParameter(e.UNPACK_ROW_LENGTH),l=n.getParameter(e.UNPACK_SKIP_PIXELS),u=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,r.width);for(let t=0,s=o.length;t<s;t++){let s=o[t],c=Math.floor(s.start/4),l=Math.ceil(s.count/4),u=c%r.width,d=Math.floor(c/r.width),f=l;n.pixelStorei(e.UNPACK_SKIP_PIXELS,u),n.pixelStorei(e.UNPACK_SKIP_ROWS,d),n.texSubImage2D(e.TEXTURE_2D,0,u,d,f,1,i,a,r.data)}t.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,c),n.pixelStorei(e.UNPACK_SKIP_PIXELS,l),n.pixelStorei(e.UNPACK_SKIP_ROWS,u)}}function ie(t,o,s){let c=e.TEXTURE_2D;(o.isDataArrayTexture||o.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),o.isData3DTexture&&(c=e.TEXTURE_3D);let l=B(t,o),u=o.source;n.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);let f=r.get(u);if(u.version!==f.__version||l===!0){if(n.activeTexture(e.TEXTURE0+s),!(typeof ImageBitmap<`u`&&o.image instanceof ImageBitmap)){let t=Yr.getPrimaries(Yr.workingColorSpace),r=o.colorSpace===``?null:Yr.getPrimaries(o.colorSpace),i=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,i)}n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment);let t=g(o.image,!1,i.maxTextureSize);t=ve(o,t);let r=a.convert(o.format,o.colorSpace),p=a.convert(o.type),m=x(o.internalFormat,r,p,o.normalized,o.colorSpace,o.isVideoTexture);z(c,o);let h,v=o.mipmaps,b=o.isVideoTexture!==!0,w=f.__version===void 0||l===!0,T=u.dataReady,E=C(o,t);if(o.isDepthTexture)m=S(o.format===nt,o.type),w&&(b?n.texStorage2D(e.TEXTURE_2D,1,m,t.width,t.height):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,null));else if(o.isDataTexture)if(v.length>0){b&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,v[0].width,v[0].height);for(let t=0,i=v.length;t<i;t++)h=v[t],b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data);o.generateMipmaps=!1}else b?(w&&n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height),T&&re(o,t,r,p)):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,t.data);else if(o.isCompressedTexture)if(o.isCompressedArrayTexture){b&&w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,v[0].width,v[0].height,t.depth);for(let i=0,a=v.length;i<a;i++)if(h=v[i],o.format!==1023)if(r!==null)if(b){if(T)if(o.layerUpdates.size>0){let t=et(h.width,h.height,o.format,o.type);for(let a of o.layerUpdates){let o=h.data.subarray(a*t/h.data.BYTES_PER_ELEMENT,(a+1)*t/h.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,a,h.width,h.height,1,r,o)}o.clearLayerUpdates()}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,h.data)}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,h.data,0,0);else eo(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`);else b?T&&n.texSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,p,h.data):n.texImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,r,p,h.data)}else{b&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,v[0].width,v[0].height);for(let t=0,i=v.length;t<i;t++)h=v[t],o.format===1023?b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data):r===null?eo(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):b?T&&n.compressedTexSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,h.data):n.compressedTexImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,h.data)}else if(o.isDataArrayTexture)if(b){if(w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,t.width,t.height,t.depth),T)if(o.layerUpdates.size>0){let i=et(t.width,t.height,o.format,o.type);for(let a of o.layerUpdates){let o=t.data.subarray(a*i/t.data.BYTES_PER_ELEMENT,(a+1)*i/t.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,a,t.width,t.height,1,r,p,o)}o.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isData3DTexture)b?(w&&n.texStorage3D(e.TEXTURE_3D,E,m,t.width,t.height,t.depth),T&&n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)):n.texImage3D(e.TEXTURE_3D,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isFramebufferTexture){if(w)if(b)n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height);else{let i=t.width,a=t.height;for(let t=0;t<E;t++)n.texImage2D(e.TEXTURE_2D,t,m,i,a,0,r,p,null),i>>=1,a>>=1}}else if(o.isHTMLTexture){if(`texElementImage2D`in e){let n=e.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),t.parentNode!==n){n.appendChild(t),d.add(o),n.onpaint=e=>{let t=e.changedElements;for(let e of d)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,t);else{let n=e.RGBA,r=e.RGBA,i=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,n,r,i,t)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(v.length>0){if(b&&w){let t=ye(v[0]);n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height)}for(let t=0,i=v.length;t<i;t++)h=v[t],b?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,r,p,h):n.texImage2D(e.TEXTURE_2D,t,m,r,p,h);o.generateMipmaps=!1}else if(b){if(w){let r=ye(t);n.texStorage2D(e.TEXTURE_2D,E,m,r.width,r.height)}T&&n.texSubImage2D(e.TEXTURE_2D,0,0,0,r,p,t)}else n.texImage2D(e.TEXTURE_2D,0,m,r,p,t);_(o)&&y(c),f.__version=u.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function ae(t,o,s){if(o.image.length!==6)return;let c=B(t,o),l=o.source;n.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);let u=r.get(l);if(l.version!==u.__version||c===!0){n.activeTexture(e.TEXTURE0+s);let t=Yr.getPrimaries(Yr.workingColorSpace),r=o.colorSpace===``?null:Yr.getPrimaries(o.colorSpace),d=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,d);let f=o.isCompressedTexture||o.image[0].isCompressedTexture,p=o.image[0]&&o.image[0].isDataTexture,m=[];for(let e=0;e<6;e++)!f&&!p?m[e]=g(o.image[e],!0,i.maxCubemapSize):m[e]=p?o.image[e].image:o.image[e],m[e]=ve(o,m[e]);let h=m[0],v=a.convert(o.format,o.colorSpace),b=a.convert(o.type),S=x(o.internalFormat,v,b,o.normalized,o.colorSpace),w=o.isVideoTexture!==!0,T=u.__version===void 0||c===!0,E=l.dataReady,D=C(o,h);z(e.TEXTURE_CUBE_MAP,o);let O;if(f){w&&T&&n.texStorage2D(e.TEXTURE_CUBE_MAP,D,S,h.width,h.height);for(let t=0;t<6;t++){O=m[t].mipmaps;for(let r=0;r<O.length;r++){let i=O[r];o.format===1023?w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,v,b,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,S,i.width,i.height,0,v,b,i.data):v===null?eo(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):w?E&&n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,v,i.data):n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,S,i.width,i.height,0,i.data)}}}else{if(O=o.mipmaps,w&&T){O.length>0&&D++;let t=ye(m[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,D,S,t.width,t.height)}for(let t=0;t<6;t++)if(p){w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,m[t].width,m[t].height,v,b,m[t].data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,S,m[t].width,m[t].height,0,v,b,m[t].data);for(let r=0;r<O.length;r++){let i=O[r].image[t].image;w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,i.width,i.height,v,b,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,S,i.width,i.height,0,v,b,i.data)}}else{w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,v,b,m[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,S,v,b,m[t]);for(let r=0;r<O.length;r++){let i=O[r];w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,v,b,i.image[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,S,v,b,i.image[t])}}}_(o)&&y(e.TEXTURE_CUBE_MAP),u.__version=l.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function oe(t,i,o,c,l,u){let d=a.convert(o.format,o.colorSpace),f=a.convert(o.type),p=x(o.internalFormat,d,f,o.normalized,o.colorSpace),m=r.get(i),h=r.get(o);if(h.__renderTarget=i,!m.__hasExternalTextures){let t=Math.max(1,i.width>>u),r=Math.max(1,i.height>>u);l===e.TEXTURE_3D||l===e.TEXTURE_2D_ARRAY?n.texImage3D(l,u,p,t,r,i.depth,0,d,f,null):n.texImage2D(l,u,p,t,r,0,d,f,null)}n.bindFramebuffer(e.FRAMEBUFFER,t),H(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,c,l,h.__webglTexture,0,ge(i)):(l===e.TEXTURE_2D||l>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&l<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,c,l,h.__webglTexture,u),n.bindFramebuffer(e.FRAMEBUFFER,null)}function se(t,n,r){if(e.bindRenderbuffer(e.RENDERBUFFER,t),n.depthBuffer){let i=n.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=S(n.stencilBuffer,a),c=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;H(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,ge(n),o,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,ge(n),o,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,o,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,c,e.RENDERBUFFER,t)}else{let t=n.textures;for(let i=0;i<t.length;i++){let o=t[i],c=a.convert(o.format,o.colorSpace),l=a.convert(o.type),u=x(o.internalFormat,c,l,o.normalized,o.colorSpace);H(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,ge(n),u,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,ge(n),u,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,u,n.width,n.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function ce(t,i,o){let c=i.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,t),!(i.depthTexture&&i.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let l=r.get(i.depthTexture);if(l.__renderTarget=i,(!l.__webglTexture||i.depthTexture.image.width!==i.width||i.depthTexture.image.height!==i.height)&&(i.depthTexture.image.width=i.width,i.depthTexture.image.height=i.height,i.depthTexture.needsUpdate=!0),c){if(l.__webglInit===void 0&&(l.__webglInit=!0,i.depthTexture.addEventListener(`dispose`,w)),l.__webglTexture===void 0){l.__webglTexture=e.createTexture(),n.bindTexture(e.TEXTURE_CUBE_MAP,l.__webglTexture),z(e.TEXTURE_CUBE_MAP,i.depthTexture);let t=a.convert(i.depthTexture.format),r=a.convert(i.depthTexture.type),o;i.depthTexture.format===1026?o=e.DEPTH_COMPONENT24:i.depthTexture.format===1027&&(o=e.DEPTH24_STENCIL8);for(let n=0;n<6;n++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,o,i.width,i.height,0,t,r,null)}}else F(i.depthTexture,0);let u=l.__webglTexture,d=ge(i),f=c?e.TEXTURE_CUBE_MAP_POSITIVE_X+o:e.TEXTURE_2D,p=i.depthTexture.format===1027?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(i.depthTexture.format===1026)H(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else if(i.depthTexture.format===1027)H(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function le(t){let i=r.get(t),a=t.isWebGLCubeRenderTarget===!0;if(i.__boundDepthTexture!==t.depthTexture){let e=t.depthTexture;if(i.__depthDisposeCallback&&i.__depthDisposeCallback(),e){let t=()=>{delete i.__boundDepthTexture,delete i.__depthDisposeCallback,e.removeEventListener(`dispose`,t)};e.addEventListener(`dispose`,t),i.__depthDisposeCallback=t}i.__boundDepthTexture=e}if(t.depthTexture&&!i.__autoAllocateDepthBuffer)if(a)for(let e=0;e<6;e++)ce(i.__webglFramebuffer[e],t,e);else{let e=t.texture.mipmaps;e&&e.length>0?ce(i.__webglFramebuffer[0],t,0):ce(i.__webglFramebuffer,t,0)}else if(a){i.__webglDepthbuffer=[];for(let r=0;r<6;r++)if(n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[r]),i.__webglDepthbuffer[r]===void 0)i.__webglDepthbuffer[r]=e.createRenderbuffer(),se(i.__webglDepthbuffer[r],t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=i.__webglDepthbuffer[r];e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,a)}}else{let r=t.texture.mipmaps;if(r&&r.length>0?n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[0]):n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer),i.__webglDepthbuffer===void 0)i.__webglDepthbuffer=e.createRenderbuffer(),se(i.__webglDepthbuffer,t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,r=i.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,r),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,r)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function ue(t,n,i){let a=r.get(t);n!==void 0&&oe(a.__webglFramebuffer,t,t.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),i!==void 0&&le(t)}function de(t){let i=t.texture,s=r.get(t),c=r.get(i);t.addEventListener(`dispose`,T);let l=t.textures,u=t.isWebGLCubeRenderTarget===!0,d=l.length>1;if(d||(c.__webglTexture===void 0&&(c.__webglTexture=e.createTexture()),c.__version=i.version,o.memory.textures++),u){s.__webglFramebuffer=[];for(let t=0;t<6;t++)if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer[t]=[];for(let n=0;n<i.mipmaps.length;n++)s.__webglFramebuffer[t][n]=e.createFramebuffer()}else s.__webglFramebuffer[t]=e.createFramebuffer()}else{if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer=[];for(let t=0;t<i.mipmaps.length;t++)s.__webglFramebuffer[t]=e.createFramebuffer()}else s.__webglFramebuffer=e.createFramebuffer();if(d)for(let t=0,n=l.length;t<n;t++){let n=r.get(l[t]);n.__webglTexture===void 0&&(n.__webglTexture=e.createTexture(),o.memory.textures++)}if(t.samples>0&&H(t)===!1){s.__webglMultisampledFramebuffer=e.createFramebuffer(),s.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,s.__webglMultisampledFramebuffer);for(let n=0;n<l.length;n++){let r=l[n];s.__webglColorRenderbuffer[n]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,s.__webglColorRenderbuffer[n]);let i=a.convert(r.format,r.colorSpace),o=a.convert(r.type),c=x(r.internalFormat,i,o,r.normalized,r.colorSpace,t.isXRRenderTarget===!0),u=ge(t);e.renderbufferStorageMultisample(e.RENDERBUFFER,u,c,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,s.__webglColorRenderbuffer[n])}e.bindRenderbuffer(e.RENDERBUFFER,null),t.depthBuffer&&(s.__webglDepthRenderbuffer=e.createRenderbuffer(),se(s.__webglDepthRenderbuffer,t,!0)),n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(u){n.bindTexture(e.TEXTURE_CUBE_MAP,c.__webglTexture),z(e.TEXTURE_CUBE_MAP,i);for(let n=0;n<6;n++)if(i.mipmaps&&i.mipmaps.length>0)for(let r=0;r<i.mipmaps.length;r++)oe(s.__webglFramebuffer[n][r],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,r);else oe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0);_(i)&&y(e.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(d){for(let i=0,a=l.length;i<a;i++){let a=l[i],o=r.get(a),c=e.TEXTURE_2D;(t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(c=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(c,o.__webglTexture),z(c,a),oe(s.__webglFramebuffer,t,a,e.COLOR_ATTACHMENT0+i,c,0),_(a)&&y(c)}n.unbindTexture()}else{let r=e.TEXTURE_2D;if((t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(r=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(r,c.__webglTexture),z(r,i),i.mipmaps&&i.mipmaps.length>0)for(let n=0;n<i.mipmaps.length;n++)oe(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,r,n);else oe(s.__webglFramebuffer,t,i,e.COLOR_ATTACHMENT0,r,0);_(i)&&y(r),n.unbindTexture()}t.depthBuffer&&le(t)}function fe(e){let t=e.textures;for(let i=0,a=t.length;i<a;i++){let a=t[i];if(_(a)){let t=b(e),i=r.get(a).__webglTexture;n.bindTexture(t,i),y(t),n.unbindTexture()}}}let pe=[],me=[];function he(t){if(t.samples>0){if(H(t)===!1){let i=t.textures,a=t.width,o=t.height,s=e.COLOR_BUFFER_BIT,l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,u=r.get(t),d=i.length>1;if(d)for(let t=0;t<i.length;t++)n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,null,0);n.bindFramebuffer(e.READ_FRAMEBUFFER,u.__webglMultisampledFramebuffer);let f=t.texture.mipmaps;f&&f.length>0?n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer[0]):n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer);for(let n=0;n<i.length;n++){if(t.resolveDepthBuffer&&(t.depthBuffer&&(s|=e.DEPTH_BUFFER_BIT),t.stencilBuffer&&t.resolveStencilBuffer&&(s|=e.STENCIL_BUFFER_BIT)),d){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,u.__webglColorRenderbuffer[n]);let t=r.get(i[n]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0)}e.blitFramebuffer(0,0,a,o,0,0,a,o,s,e.NEAREST),c===!0&&(pe.length=0,me.length=0,pe.push(e.COLOR_ATTACHMENT0+n),t.depthBuffer&&t.resolveDepthBuffer===!1&&(pe.push(l),me.push(l),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,me)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,pe))}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),d)for(let t=0;t<i.length;t++){n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,u.__webglColorRenderbuffer[t]);let a=r.get(i[t]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,a,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglMultisampledFramebuffer)}else if(t.depthBuffer&&t.resolveDepthBuffer===!1&&c){let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[n])}}}function ge(e){return Math.min(i.maxSamples,e.samples)}function H(e){let n=r.get(e);return e.samples>0&&t.has(`WEBGL_multisampled_render_to_texture`)===!0&&n.__useRenderToTexture!==!1}function _e(e){let t=o.render.frame;u.get(e)!==t&&(u.set(e,t),e.update())}function ve(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(Yr.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&eo(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):ei(`WebGLTextures: Unsupported texture color space:`,n)),t}function ye(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(l.width=e.naturalWidth||e.width,l.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(l.width=e.displayWidth,l.height=e.displayHeight):(l.width=e.width,l.height=e.height),l}this.allocateTextureUnit=N,this.resetTextureUnits=A,this.getTextureUnits=j,this.setTextureUnits=M,this.setTexture2D=F,this.setTexture2DArray=I,this.setTexture3D=L,this.setTextureCube=ee,this.rebindTextures=ue,this.setupRenderTarget=de,this.updateRenderTargetMipmap=fe,this.updateMultisampleRenderTarget=he,this.setupDepthRenderbuffer=le,this.setupFrameBufferTexture=oe,this.useMultisampledRTT=H,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function ll(e,t){function n(n,r=``){let i,a=Yr.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779)if(a===`srgb`)if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===35840||n===35841||n===35842||n===35843)if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491)if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821)if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===36492||n===36494||n===36495)if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===36283||n===36284||n===36285||n===36286)if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var ul=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,dl=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,fl=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new He(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Cr({vertexShader:ul,fragmentShader:dl,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new G(new nn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},pl=class extends ve{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,l=null,u=null,d=null,f=null,p=null,m=typeof XRWebGLBinding<`u`,h=new fl,g={},_=t.getContextAttributes(),v=null,y=null,b=[],x=[],S=new Er,C=null,w=new un;w.viewport=new xi;let T=new un;T.viewport=new xi;let E=[w,T],D=new Aa,O=null,k=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=b[e];return t===void 0&&(t=new M,b[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=b[e];return t===void 0&&(t=new M,b[e]=t),t.getGripSpace()},this.getHand=function(e){let t=b[e];return t===void 0&&(t=new M,b[e]=t),t.getHandSpace()};function A(e){let t=x.indexOf(e.inputSource);if(t===-1)return;let n=b[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function j(){r.removeEventListener(`select`,A),r.removeEventListener(`selectstart`,A),r.removeEventListener(`selectend`,A),r.removeEventListener(`squeeze`,A),r.removeEventListener(`squeezestart`,A),r.removeEventListener(`squeezeend`,A),r.removeEventListener(`end`,j),r.removeEventListener(`inputsourceschange`,N);for(let e=0;e<b.length;e++){let t=x[e];t!==null&&(x[e]=null,b[e].disconnect(t))}O=null,k=null,h.reset();for(let e in g)delete g[e];e.setRenderTarget(v),f=null,d=null,u=null,r=null,y=null,R.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(S.width,S.height,!1),n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&eo(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&eo(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return d===null?f:d},this.getBinding=function(){return u===null&&m&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return p},this.getSession=function(){return r},this.setSession=async function(l){if(r=l,r!==null){if(v=e.getRenderTarget(),r.addEventListener(`select`,A),r.addEventListener(`selectstart`,A),r.addEventListener(`selectend`,A),r.addEventListener(`squeeze`,A),r.addEventListener(`squeezestart`,A),r.addEventListener(`squeezeend`,A),r.addEventListener(`end`,j),r.addEventListener(`inputsourceschange`,N),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(S),m&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;_.depth&&(o=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=_.stencil?nt:ni,a=_.stencil?Fi:or);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};u=this.getBinding(),d=u.createProjectionLayer(s),r.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new Va(d.textureWidth,d.textureHeight,{format:dr,type:qr,depthTexture:new lt(d.textureWidth,d.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{let n={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:i};f=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new Va(f.framebufferWidth,f.framebufferHeight,{format:dr,type:qr,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),R.setContext(r),R.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return h.getDepthTexture()};function N(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=x.indexOf(n);r>=0&&(x[r]=null,b[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=x.indexOf(n);if(r===-1){for(let e=0;e<b.length;e++)if(e>=x.length){x.push(n),r=e;break}else if(x[e]===null){x[e]=n,r=e;break}if(r===-1)break}let i=b[r];i&&i.connect(n)}}let P=new K,F=new K;function I(e,t,n){P.setFromMatrixPosition(t.matrixWorld),F.setFromMatrixPosition(n.matrixWorld);let r=P.distanceTo(F),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function L(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;h.texture!==null&&(h.depthNear>0&&(t=h.depthNear),h.depthFar>0&&(n=h.depthFar)),D.near=T.near=w.near=t,D.far=T.far=w.far=n,(O!==D.near||k!==D.far)&&(r.updateRenderState({depthNear:D.near,depthFar:D.far}),O=D.near,k=D.far),D.layers.mask=e.layers.mask|6,w.layers.mask=D.layers.mask&-5,T.layers.mask=D.layers.mask&-3;let i=e.parent,a=D.cameras;L(D,i);for(let e=0;e<a.length;e++)L(a[e],i);a.length===2?I(D,w,T):D.projectionMatrix.copy(w.projectionMatrix),ee(e,D,i)};function ee(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=Ni*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return D},this.getFoveation=function(){if(!(d===null&&f===null))return s},this.setFoveation=function(e){s=e,d!==null&&(d.fixedFoveation=e),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=e)},this.hasDepthSensing=function(){return h.texture!==null},this.getDepthSensingMesh=function(){return h.getMesh(D)},this.getCameraTexture=function(e){return g[e]};let te=null;function ne(t,i){if(l=i.getViewerPose(c||a),p=i,l!==null){let t=l.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let i=!1;t.length!==D.cameras.length&&(D.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(f!==null)a=f.getViewport(r);else{let t=u.getViewSubImage(d,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(y,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(y))}let o=E[n];o===void 0&&(o=new un,o.layers.enable(n),o.viewport=new xi,E[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(D.matrix.copy(o.matrix),D.matrix.decompose(D.position,D.quaternion,D.scale)),i===!0&&D.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&m){u=n.getBinding();let e=u.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&h.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&m){e.state.unbindTexture(),u=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=g[n];e||(e=new He,g[n]=e);let t=u.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<b.length;e++){let t=x[e],n=b[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}te&&te(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),p=null}let R=new ao;R.setAnimationLoop(ne),this.setAnimationLoop=function(e){te=e},this.dispose=function(){}}},ml=new Pr,hl=new Vr;hl.set(-1,0,0,0,1,0,0,0,1);function gl(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,xt(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(ml.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(hl),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function _l(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return ei(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return typeof i==`number`||typeof i==`boolean`?r[a]=i:ArrayBuffer.isView(i)?r[a]=i.slice():r[a]=i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?eo(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):eo(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var vl=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),yl=null;function bl(){return yl===null&&(yl=new Xt(vl,16,16,ge,ar),yl.name=`DFG_LUT`,yl.minFilter=xn,yl.magFilter=xn,yl.wrapS=xr,yl.wrapT=xr,yl.generateMipmaps=!1,yl.needsUpdate=!0),yl}var xl=class{constructor(e={}){let{canvas:t=si(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:c=!1,powerPreference:l=`default`,failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=qr}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);p=n.getContextAttributes().alpha}else p=a;let m=f,h=new Set([wr,ze,Et]),g=new Set([qr,or,pr,Fi,mi,ba]),_=new Uint32Array(4),v=new Int32Array(4),y=new K,b=null,x=null,S=[],C=[],w=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let T=this,E=!1,D=null,O=null,k=null,A=null;this._outputColorSpace=di;let j=0,M=0,N=null,P=-1,F=null,I=new xi,L=new xi,ee=null,te=new Ai(0),ne=0,R=t.width,z=t.height,B=1,V=null,re=null,ie=new xi(0,0,R,z),ae=new xi(0,0,R,z),oe=!1,se=new fa,ce=!1,le=!1,ue=new Pr,fe=new K,pe=new xi,me={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},he=!1;function ge(){return N===null?B:1}let H=n;function _e(e,n){return t.getContext(e,n)}try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:c,powerPreference:l,failIfMajorPerformanceCaveat:u};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r185`),t.addEventListener(`webglcontextlost`,He,!1),t.addEventListener(`webglcontextrestored`,Ue,!1),t.addEventListener(`webglcontextcreationerror`,We,!1),H===null){let t=`webgl2`;if(H=_e(t,e),H===null)throw _e(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}}catch(e){throw ei(`WebGLRenderer: `+e.message),e}let ve,ye,U,be,W,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,Le,Re;function Be(){ve=new zo(H),ve.init(),Ie=new ll(H,ve),ye=new ho(H,ve,e,Ie),U=new sl(H,ve),ye.reversedDepthBuffer&&d&&U.buffers.depth.setReversed(!0),O=H.createFramebuffer(),k=H.createFramebuffer(),A=H.createFramebuffer(),be=new Ho(H),W=new Vc,xe=new cl(H,ve,U,W,ye,Ie,be),Se=new Ro(T),Ce=new oo(H),Le=new po(H,Ce),we=new Bo(H,Ce,be,Le),Te=new Wo(H,we,Ce,Le,be),Ne=new Uo(H,ye,xe),Ae=new go(W),Ee=new Bc(T,Se,ve,ye,Le,Ae),De=new gl(T,W),Oe=new Gc,ke=new Qc(ve),Me=new fo(T,Se,U,Te,p,s),je=new ol(T,Te,ye),Re=new _l(H,be,ye,U),Pe=new mo(H,ve,be),Fe=new Vo(H,ve,be),be.programs=Ee.programs,T.capabilities=ye,T.extensions=ve,T.properties=W,T.renderLists=Oe,T.shadowMap=je,T.state=U,T.info=be}Be(),m!==1009&&(w=new Ko(m,t.width,t.height,o,r,i));let Ve=new pl(T,H);this.xr=Ve,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){let e=ve.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=ve.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return B},this.setPixelRatio=function(e){e!==void 0&&(B=e,this.setSize(R,z,!1))},this.getSize=function(e){return e.set(R,z)},this.setSize=function(e,n,r=!0){if(Ve.isPresenting){eo(`WebGLRenderer: Can't change size while VR device is presenting.`);return}R=e,z=n,t.width=Math.floor(e*B),t.height=Math.floor(n*B),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),w!==null&&w.setSize(t.width,t.height),this.setViewport(0,0,e,n)},this.getDrawingBufferSize=function(e){return e.set(R*B,z*B).floor()},this.setDrawingBufferSize=function(e,n,r){R=e,z=n,B=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(m===1009){ei(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);return}if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){eo(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}w.setEffects(e||[])},this.getCurrentViewport=function(e){return e.copy(I)},this.getViewport=function(e){return e.copy(ie)},this.setViewport=function(e,t,n,r){e.isVector4?ie.set(e.x,e.y,e.z,e.w):ie.set(e,t,n,r),U.viewport(I.copy(ie).multiplyScalar(B).round())},this.getScissor=function(e){return e.copy(ae)},this.setScissor=function(e,t,n,r){e.isVector4?ae.set(e.x,e.y,e.z,e.w):ae.set(e,t,n,r),U.scissor(L.copy(ae).multiplyScalar(B).round())},this.getScissorTest=function(){return oe},this.setScissorTest=function(e){U.setScissorTest(oe=e)},this.setOpaqueSort=function(e){V=e},this.setTransparentSort=function(e){re=e},this.getClearColor=function(e){return e.copy(Me.getClearColor())},this.setClearColor=function(){Me.setClearColor(...arguments)},this.getClearAlpha=function(){return Me.getClearAlpha()},this.setClearAlpha=function(){Me.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(N!==null){let t=N.texture.format;e=h.has(t)}if(e){let e=N.texture.type,t=g.has(e),n=Me.getClearColor(),r=Me.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(_[0]=i,_[1]=a,_[2]=o,_[3]=r,H.clearBufferuiv(H.COLOR,0,_)):(v[0]=i,v[1]=a,v[2]=o,v[3]=r,H.clearBufferiv(H.COLOR,0,v))}else r|=H.COLOR_BUFFER_BIT}t&&(r|=H.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&H.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),D=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,He,!1),t.removeEventListener(`webglcontextrestored`,Ue,!1),t.removeEventListener(`webglcontextcreationerror`,We,!1),Me.dispose(),Oe.dispose(),ke.dispose(),W.dispose(),Se.dispose(),Te.dispose(),Le.dispose(),Re.dispose(),Ee.dispose(),Ve.dispose(),Ve.removeEventListener(`sessionstart`,Qe),Ve.removeEventListener(`sessionend`,$e),et.stop()};function He(e){e.preventDefault(),de(`WebGLRenderer: Context Lost.`),E=!0}function Ue(){de(`WebGLRenderer: Context Restored.`),E=!1;let e=be.autoReset,t=je.enabled,n=je.autoUpdate,r=je.needsUpdate,i=je.type;Be(),be.autoReset=e,je.enabled=t,je.autoUpdate=n,je.needsUpdate=r,je.type=i}function We(e){ei(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function Ge(e){let t=e.target;t.removeEventListener(`dispose`,Ge),Ke(t)}function Ke(e){Je(e),W.remove(e)}function Je(e){let t=W.get(e).programs;t!==void 0&&(t.forEach(function(e){Ee.releaseProgram(e)}),e.isShaderMaterial&&Ee.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=me);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=ut(e,t,n,r,i);U.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=we.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;Le.setup(i,r,s,n,c);let h,g=Pe;if(c!==null&&(h=Ce.get(c),g=Fe,g.setIndex(h)),i.isMesh)r.wireframe===!0?(U.setLineWidth(r.wireframeLinewidth*ge()),g.setMode(H.LINES)):g.setMode(H.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),U.setLineWidth(e*ge()),i.isLineSegments?g.setMode(H.LINES):i.isLineLoop?g.setMode(H.LINE_LOOP):g.setMode(H.LINE_STRIP)}else i.isPoints?g.setMode(H.POINTS):i.isSprite&&g.setMode(H.TRIANGLES);if(i.isBatchedMesh)if(ve.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?Ce.get(c).bytesPerElement:1,o=W.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(H,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function Ye(e,t,n){e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,ot(e,t,n),e.side=0,e.needsUpdate=!0,ot(e,t,n),e.side=2):ot(e,t,n)}this.compile=function(e,t,n=null){n===null&&(n=e),x=ke.get(n),x.init(t),C.push(x),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),x.setupLights();let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let t=e.material;if(t)if(Array.isArray(t))for(let i=0;i<t.length;i++){let a=t[i];Ye(a,n,e),r.add(a)}else Ye(t,n,e),r.add(t)}),x=C.pop(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){if(r.forEach(function(e){W.get(e).currentProgram.isReady()&&r.delete(e)}),r.size===0){t(e);return}setTimeout(n,10)}ve.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let Xe=null;function Ze(e){Xe&&Xe(e)}function Qe(){et.stop()}function $e(){et.start()}let et=new ao;et.setAnimationLoop(Ze),typeof self<`u`&&et.setContext(self),this.setAnimationLoop=function(e){Xe=e,Ve.setAnimationLoop(e),e===null?et.stop():et.start()},Ve.addEventListener(`sessionstart`,Qe),Ve.addEventListener(`sessionend`,$e),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){ei(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(E===!0)return;D!==null&&D.renderStart(e,t);let n=Ve.enabled===!0&&Ve.isPresenting===!0,r=w!==null&&(N===null||n)&&w.begin(T,N);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),Ve.enabled===!0&&Ve.isPresenting===!0&&(w===null||w.isCompositing()===!1)&&(Ve.cameraAutoUpdate===!0&&Ve.updateCamera(t),t=Ve.getCamera()),e.isScene===!0&&e.onBeforeRender(T,e,t,N),x=ke.get(e,C.length),x.init(t),x.state.textureUnits=xe.getTextureUnits(),C.push(x),ue.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),se.setFromProjectionMatrix(ue,$n,t.reversedDepth),le=this.localClippingEnabled,ce=Ae.init(this.clippingPlanes,le),b=Oe.get(e,S.length),b.init(),S.push(b),Ve.enabled===!0&&Ve.isPresenting===!0){let e=T.xr.getDepthSensingMesh();e!==null&&tt(e,t,-1/0,T.sortObjects)}tt(e,t,0,T.sortObjects),b.finish(),T.sortObjects===!0&&b.sort(V,re,t.reversedDepth),he=Ve.enabled===!1||Ve.isPresenting===!1||Ve.hasDepthSensing()===!1,he&&Me.addToRenderList(b,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),ce===!0&&Ae.beginShadows();let i=x.state.shadowsArray;if(je.render(i,e,t),ce===!0&&Ae.endShadows(),(r&&w.hasRenderPass())===!1){let n=b.opaque,r=b.transmissive;if(x.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];rt(n,r,e,a)}he&&Me.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];nt(b,e,n,n.viewport)}}else r.length>0&&rt(n,r,e,t),he&&Me.render(e),nt(b,e,t)}N!==null&&M===0&&(xe.updateMultisampleRenderTarget(N),xe.updateRenderTargetMipmap(N)),r&&w.end(T),e.isScene===!0&&e.onAfterRender(T,e,t),Le.resetDefaultState(),P=-1,F=null,C.pop(),C.length>0?(x=C[C.length-1],xe.setTextureUnits(x.state.textureUnits),ce===!0&&Ae.setGlobalState(T.clippingPlanes,x.state.camera)):x=null,S.pop(),b=S.length>0?S[S.length-1]:null,D!==null&&D.renderEnd()};function tt(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)x.pushLightProbeGrid(e);else if(e.isLight)x.pushLight(e),e.castShadow&&x.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||se.intersectsSprite(e)){r&&pe.setFromMatrixPosition(e.matrixWorld).applyMatrix4(ue);let t=Te.update(e),i=e.material;i.visible&&b.push(e,t,i,n,pe.z,null)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||se.intersectsObject(e))){let t=Te.update(e),i=e.material;if(r&&(e.boundingSphere===void 0?(t.boundingSphere===null&&t.computeBoundingSphere(),pe.copy(t.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),pe.copy(e.boundingSphere.center)),pe.applyMatrix4(e.matrixWorld).applyMatrix4(ue)),Array.isArray(i)){let r=t.groups;for(let a=0,o=r.length;a<o;a++){let o=r[a],s=i[o.materialIndex];s&&s.visible&&b.push(e,t,s,n,pe.z,o)}}else i.visible&&b.push(e,t,i,n,pe.z,null)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)tt(i[e],t,n,r)}function nt(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;x.setupLightsView(n),ce===!0&&Ae.setGlobalState(T.clippingPlanes,n),r&&U.viewport(I.copy(r)),i.length>0&&it(i,t,n),a.length>0&&it(a,t,n),o.length>0&&it(o,t,n),U.buffers.depth.setTest(!0),U.buffers.depth.setMask(!0),U.buffers.color.setMask(!0),U.setPolygonOffset(!1)}function rt(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(x.state.transmissionRenderTarget[r.id]===void 0){let e=ve.has(`EXT_color_buffer_half_float`)||ve.has(`EXT_color_buffer_float`);x.state.transmissionRenderTarget[r.id]=new Va(1,1,{generateMipmaps:!0,type:e?ar:qr,minFilter:br,samples:Math.max(4,ye.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Yr.workingColorSpace})}let a=x.state.transmissionRenderTarget[r.id],o=r.viewport||I;a.setSize(o.z*T.transmissionResolutionScale,o.w*T.transmissionResolutionScale);let s=T.getRenderTarget(),c=T.getActiveCubeFace(),l=T.getActiveMipmapLevel();T.setRenderTarget(a),T.getClearColor(te),ne=T.getClearAlpha(),ne<1&&T.setClearColor(16777215,.5),T.clear(),he&&Me.render(n);let u=T.toneMapping;T.toneMapping=0;let d=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),x.setupLightsView(r),ce===!0&&Ae.setGlobalState(T.clippingPlanes,r),it(e,n,r),xe.updateMultisampleRenderTarget(a),xe.updateRenderTargetMipmap(a),ve.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,at(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(xe.updateMultisampleRenderTarget(a),xe.updateRenderTargetMipmap(a))}T.setRenderTarget(s,c,l),T.setClearColor(te,ne),d!==void 0&&(r.viewport=d),T.toneMapping=u}function it(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&at(o,t,n,s,l,c)}}function at(e,t,n,r,i,a){e.onBeforeRender(T,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(T,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=2):T.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(T,t,n,r,i,a)}function ot(e,t,n){t.isScene!==!0&&(t=me);let r=W.get(e),i=x.state.lights,a=x.state.shadowsArray,o=i.state.version,s=Ee.getParameters(e,i.state,a,t,n,x.state.lightProbeGridArray),c=Ee.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=Se.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,Ge),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return ct(e,s),d}else s.uniforms=Ee.getUniforms(e),D!==null&&e.isNodeMaterial&&D.build(e,n,s),e.onBeforeCompile(s,T),d=Ee.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=Ae.uniform),ct(e,s),r.needsLights=ft(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=x.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function st(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=$s.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function ct(e,t){let n=W.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function lt(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];y.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(y))return n}return null}function ut(e,t,n,r,i){t.isScene!==!0&&(t=me),xe.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=N===null?T.outputColorSpace:N.isXRRenderTarget===!0?N.texture.colorSpace:Yr.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=Se.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(N===null||N.isXRRenderTarget===!0)&&(h=T.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=W.get(r),y=x.state.lights;if(ce===!0&&(le===!0||e!==F)){let t=e===F&&r.id===P;Ae.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i.colorTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i.colorTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==Ae.numPlanes||v.numIntersection!==Ae.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=x.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let S=v.currentProgram;b===!0&&(S=ot(r,t,i),D&&r.isNodeMaterial&&D.onUpdateProgram(r,S,v));let C=!1,w=!1,E=!1,O=S.getUniforms(),k=v.uniforms;if(U.useProgram(S.program)&&(C=!0,w=!0,E=!0),r.id!==P&&(P=r.id,w=!0),v.needsLights){let e=lt(x.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,w=!0)}if(C||F!==e){U.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),O.setValue(H,`projectionMatrix`,e.projectionMatrix),O.setValue(H,`viewMatrix`,e.matrixWorldInverse);let t=O.map.cameraPosition;t!==void 0&&t.setValue(H,fe.setFromMatrixPosition(e.matrixWorld)),ye.logarithmicDepthBuffer&&O.setValue(H,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&O.setValue(H,`isOrthographic`,e.isOrthographicCamera===!0),F!==e&&(F=e,w=!0,E=!0)}if(v.needsLights&&(y.state.directionalShadowMap.length>0&&O.setValue(H,`directionalShadowMap`,y.state.directionalShadowMap,xe),y.state.spotShadowMap.length>0&&O.setValue(H,`spotShadowMap`,y.state.spotShadowMap,xe),y.state.pointShadowMap.length>0&&O.setValue(H,`pointShadowMap`,y.state.pointShadowMap,xe)),i.isSkinnedMesh){O.setOptional(H,i,`bindMatrix`),O.setOptional(H,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),O.setValue(H,`boneTexture`,e.boneTexture,xe))}i.isBatchedMesh&&(O.setOptional(H,i,`batchingTexture`),O.setValue(H,`batchingTexture`,i._matricesTexture,xe),O.setOptional(H,i,`batchingIdTexture`),O.setValue(H,`batchingIdTexture`,i._indirectTexture,xe),O.setOptional(H,i,`batchingColorTexture`),i._colorsTexture!==null&&O.setValue(H,`batchingColorTexture`,i._colorsTexture,xe));let A=n.morphAttributes;if((A.position!==void 0||A.normal!==void 0||A.color!==void 0)&&Ne.update(i,n,S),(w||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,O.setValue(H,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(k.envMapIntensity.value=t.environmentIntensity),k.dfgLUT!==void 0&&(k.dfgLUT.value=bl()),w){if(O.setValue(H,`toneMappingExposure`,T.toneMappingExposure),v.needsLights&&dt(k,E),a&&r.fog===!0&&De.refreshFogUniforms(k,a),De.refreshMaterialUniforms(k,r,B,z,x.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;k.probesSH.value=e.texture,k.probesMin.value.copy(e.boundingBox.min),k.probesMax.value.copy(e.boundingBox.max),k.probesResolution.value.copy(e.resolution)}$s.upload(H,st(v),k,xe)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&($s.upload(H,st(v),k,xe),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&O.setValue(H,`center`,i.center),O.setValue(H,`modelViewMatrix`,i.modelViewMatrix),O.setValue(H,`normalMatrix`,i.normalMatrix),O.setValue(H,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];Re.update(n,S),Re.bind(n,S)}}return S}function dt(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function ft(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return j},this.getActiveMipmapLevel=function(){return M},this.getRenderTarget=function(){return N},this.setRenderTargetTextures=function(e,t,n){let r=W.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),W.get(e.texture).__webglTexture=t,W.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=W.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){N=e,j=t,M=n;let r=null,i=!1,a=!1;if(e){let o=W.get(e);if(o.__useDefaultFramebuffer!==void 0){U.bindFramebuffer(H.FRAMEBUFFER,o.__webglFramebuffer),I.copy(e.viewport),L.copy(e.scissor),ee=e.scissorTest,U.viewport(I),U.scissor(L),U.setScissorTest(ee),P=-1;return}else if(o.__webglFramebuffer===void 0)xe.setupRenderTarget(e);else if(o.__hasExternalTextures)xe.rebindTextures(e,W.get(e.texture).__webglTexture,W.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&W.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);xe.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=W.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&xe.useMultisampledRTT(e)===!1?W.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,I.copy(e.viewport),L.copy(e.scissor),ee=e.scissorTest}else I.copy(ie).multiplyScalar(B).floor(),L.copy(ae).multiplyScalar(B).floor(),ee=oe;if(n!==0&&(r=O),U.bindFramebuffer(H.FRAMEBUFFER,r)&&U.drawBuffers(e,r),U.viewport(I),U.scissor(L),U.setScissorTest(ee),i){let r=W.get(e.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=W.get(e.textures[t]);H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=W.get(e.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,t.__webglTexture,n)}P=-1},this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){ei(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=W.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){U.bindFramebuffer(H.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;if(e.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+s),!ye.textureFormatReadable(c)){ei(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(!ye.textureTypeReadable(l)){ei(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&H.readPixels(t,n,r,i,Ie.convert(c),Ie.convert(l),a)}finally{let e=N===null?null:W.get(N).__webglFramebuffer;U.bindFramebuffer(H.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=W.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c)if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){U.bindFramebuffer(H.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;if(e.textures.length>1&&H.readBuffer(H.COLOR_ATTACHMENT0+s),!ye.textureFormatReadable(l))throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(!ye.textureTypeReadable(u))throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let d=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,d),H.bufferData(H.PIXEL_PACK_BUFFER,a.byteLength,H.STREAM_READ),H.readPixels(t,n,r,i,Ie.convert(l),Ie.convert(u),0);let f=N===null?null:W.get(N).__webglFramebuffer;U.bindFramebuffer(H.FRAMEBUFFER,f);let p=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await qe(H,p,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,d),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,a),H.deleteBuffer(d),H.deleteSync(p),a}else throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;xe.setTexture2D(e,0),H.copyTexSubImage2D(H.TEXTURE_2D,n,0,0,o,s,i,a),U.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=Ie.convert(t.format),_=Ie.convert(t.type),v;t.isData3DTexture?(xe.setTexture3D(t,0),v=H.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(xe.setTexture2DArray(t,0),v=H.TEXTURE_2D_ARRAY):(xe.setTexture2D(t,0),v=H.TEXTURE_2D),U.activeTexture(H.TEXTURE0),U.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,t.flipY),U.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),U.pixelStorei(H.UNPACK_ALIGNMENT,t.unpackAlignment);let y=U.getParameter(H.UNPACK_ROW_LENGTH),b=U.getParameter(H.UNPACK_IMAGE_HEIGHT),x=U.getParameter(H.UNPACK_SKIP_PIXELS),S=U.getParameter(H.UNPACK_SKIP_ROWS),C=U.getParameter(H.UNPACK_SKIP_IMAGES);U.pixelStorei(H.UNPACK_ROW_LENGTH,h.width),U.pixelStorei(H.UNPACK_IMAGE_HEIGHT,h.height),U.pixelStorei(H.UNPACK_SKIP_PIXELS,l),U.pixelStorei(H.UNPACK_SKIP_ROWS,u),U.pixelStorei(H.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=W.get(e),r=W.get(t),h=W.get(n.__renderTarget),g=W.get(r.__renderTarget);U.bindFramebuffer(H.READ_FRAMEBUFFER,h.__webglFramebuffer),U.bindFramebuffer(H.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,W.get(e).__webglTexture,i,d+n),H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,W.get(t).__webglTexture,a,m+n)),H.blitFramebuffer(l,u,o,s,f,p,o,s,H.DEPTH_BUFFER_BIT,H.NEAREST);U.bindFramebuffer(H.READ_FRAMEBUFFER,null),U.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||W.has(e)){let n=W.get(e),r=W.get(t);U.bindFramebuffer(H.READ_FRAMEBUFFER,k),U.bindFramebuffer(H.DRAW_FRAMEBUFFER,A);for(let e=0;e<c;e++)w?H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):H.framebufferTexture2D(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,n.__webglTexture,i),T?H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):H.framebufferTexture2D(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_2D,r.__webglTexture,a),i===0?T?H.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):H.copyTexSubImage2D(v,a,f,p,l,u,o,s):H.blitFramebuffer(l,u,o,s,f,p,o,s,H.COLOR_BUFFER_BIT,H.NEAREST);U.bindFramebuffer(H.READ_FRAMEBUFFER,null),U.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?H.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?H.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):H.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):H.texSubImage2D(H.TEXTURE_2D,a,f,p,o,s,g,_,h);U.pixelStorei(H.UNPACK_ROW_LENGTH,y),U.pixelStorei(H.UNPACK_IMAGE_HEIGHT,b),U.pixelStorei(H.UNPACK_SKIP_PIXELS,x),U.pixelStorei(H.UNPACK_SKIP_ROWS,S),U.pixelStorei(H.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&H.generateMipmap(v),U.unbindTexture()},this.initRenderTarget=function(e){W.get(e).__webglFramebuffer===void 0&&xe.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?xe.setTextureCube(e,0):e.isData3DTexture?xe.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?xe.setTexture2DArray(e,0):xe.setTexture2D(e,0),U.unbindTexture()},this.resetState=function(){j=0,M=0,N=null,U.reset(),Le.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return $n}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=Yr._getDrawingBufferColorSpace(e),t.unpackColorSpace=Yr._getUnpackColorSpace()}};function Sl(e){let t=Ur(e),n=t.index?t.index.count/3:t.getAttribute(`position`).count/3;return t.dispose(),Math.round(n)}var Cl=`0.3.27`,wl=`northcore-asset-editor`,Tl=`northcore-asset-editor.autosave.v1`,El=new Set([`box`,`cuboid`,`sphere`,`hemisphere`,`cylinder`,`cone`,`pyramid`,`plane`,`torus`,`wedge`,`prism`,`wall`,`floor`,`flatRoof`,`gableRoof`,`shedRoof`,`door`,`window`,`column`,`chimney`,`stairs`]),Dl=e=>Array.isArray(e)&&e.length===3&&e.every(e=>typeof e==`number`&&Number.isFinite(e)),Ol=e=>typeof e==`object`&&!!e&&!Array.isArray(e),kl=e=>typeof e==`number`&&Number.isFinite(e),Al=e=>kl(e)&&e>=0&&e<=1,jl=e=>kl(e)&&e>0,Ml=e=>Number.isInteger(e)&&jl(e),Nl=e=>typeof e==`string`&&/^#[0-9a-fA-F]{6}$/.test(e),Pl=e=>typeof e==`string`&&/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/u.test(e);function Fl(e,t,n){if(!Ol(e))throw Error(`Objekt ${t+1}: Malfläche ${n+1} ist ungültig.`);if(typeof e.label!=`string`||e.label.length===0)throw Error(`Objekt ${t+1}: Malfläche ${n+1} hat keine Bezeichnung.`);if(!Ml(e.width)||!Ml(e.height))throw Error(`Objekt ${t+1}: Rastergröße der Malfläche ${n+1} ist ungültig.`);if(!Al(e.coverageU)||e.coverageU<=0||!Al(e.coverageV)||e.coverageV<=0)throw Error(`Objekt ${t+1}: Rasterabdeckung der Malfläche ${n+1} ist ungültig.`);if(e.sourceWidth!==void 0&&!Ml(e.sourceWidth))throw Error(`Objekt ${t+1}: Quellbreite der Malfläche ${n+1} ist ungültig.`);if(e.sourceHeight!==void 0&&!Ml(e.sourceHeight))throw Error(`Objekt ${t+1}: Quellhöhe der Malfläche ${n+1} ist ungültig.`);return{label:e.label,width:e.width,height:e.height,coverageU:e.coverageU,coverageV:e.coverageV,...e.sourceWidth===void 0?{}:{sourceWidth:e.sourceWidth},...e.sourceHeight===void 0?{}:{sourceHeight:e.sourceHeight}}}function Il(e,t){if(!Ol(e))throw Error(`Objekt ${t+1}: Flächenraster der Bemalung ist ungültig.`);if(e.version!==1&&e.version!==2)throw Error(`Objekt ${t+1}: Unbekannte Flächenraster-Version.`);if(typeof e.atlasSignature!=`string`||e.atlasSignature.length===0)throw Error(`Objekt ${t+1}: Atlas-Signatur der Bemalung fehlt.`);if(!jl(e.pixelsPerWorldUnit))throw Error(`Objekt ${t+1}: Rasterauflösung der Bemalung ist ungültig.`);if(e.baseColor!==void 0&&!Nl(e.baseColor))throw Error(`Objekt ${t+1}: Grundfarbe der Bemalung ist ungültig.`);if(!Array.isArray(e.surfaces)||e.surfaces.length===0)throw Error(`Objekt ${t+1}: Malflächen der Bemalung fehlen.`);if(e.sourceDataUrl!==void 0&&!Pl(e.sourceDataUrl))throw Error(`Objekt ${t+1}: Quelldaten der Bemalung sind ungültig.`);if(e.sourceWidth!==void 0&&!Ml(e.sourceWidth))throw Error(`Objekt ${t+1}: Quellbreite der Bemalung ist ungültig.`);if(e.sourceHeight!==void 0&&!Ml(e.sourceHeight))throw Error(`Objekt ${t+1}: Quellhöhe der Bemalung ist ungültig.`);return{version:e.version,atlasSignature:e.atlasSignature,pixelsPerWorldUnit:e.pixelsPerWorldUnit,...e.baseColor===void 0?{}:{baseColor:e.baseColor.toUpperCase()},surfaces:e.surfaces.map((e,n)=>Fl(e,t,n)),...e.sourceDataUrl===void 0?{}:{sourceDataUrl:e.sourceDataUrl},...e.sourceWidth===void 0?{}:{sourceWidth:e.sourceWidth},...e.sourceHeight===void 0?{}:{sourceHeight:e.sourceHeight}}}function Ll(e,t){if(!Ol(e))throw Error(`Objekt ${t+1}: Bemalung ist ungültig.`);if(!Pl(e.dataUrl))throw Error(`Objekt ${t+1}: Bilddaten der Bemalung sind ungültig.`);if(!Ml(e.width)||!Ml(e.height))throw Error(`Objekt ${t+1}: Bildgröße der Bemalung ist ungültig.`);if(typeof e.pixelated!=`boolean`)throw Error(`Objekt ${t+1}: Pixelmodus der Bemalung ist ungültig.`);return{dataUrl:e.dataUrl,width:e.width,height:e.height,pixelated:e.pixelated,...e.surfaceGrid===void 0?{}:{surfaceGrid:Il(e.surfaceGrid,t)}}}function Rl(e,t){if(!Ol(e))throw Error(`Objekt ${t+1} ist ungültig.`);if(typeof e.id!=`string`||e.id.length===0)throw Error(`Objekt ${t+1}: Feld „id“ fehlt.`);if(typeof e.name!=`string`||e.name.length===0)throw Error(`Objekt ${t+1}: Feld „name“ fehlt.`);if(typeof e.type!=`string`||!El.has(e.type))throw Error(`Objekt ${t+1}: Unbekannter Typ „${String(e.type)}“.`);if(typeof e.visible!=`boolean`||typeof e.locked!=`boolean`)throw Error(`Objekt ${t+1}: Sichtbarkeit oder Sperrstatus ist ungültig.`);if(!Dl(e.position)||!Dl(e.rotation)||!Dl(e.scale))throw Error(`Objekt ${t+1}: Transformation ist ungültig.`);if(e.scale.some(e=>e===0))throw Error(`Objekt ${t+1}: Skalierung darf nicht 0 sein.`);if(!Ol(e.geometry)||Object.values(e.geometry).some(e=>!kl(e)))throw Error(`Objekt ${t+1}: Geometriedaten sind ungültig.`);if(!Ol(e.material))throw Error(`Objekt ${t+1}: Material fehlt.`);if(!Nl(e.material.color))throw Error(`Objekt ${t+1}: Materialfarbe ist ungültig.`);if(!Al(e.material.roughness)||!Al(e.material.metalness)||!Al(e.material.opacity))throw Error(`Objekt ${t+1}: Materialwerte müssen zwischen 0 und 1 liegen.`);if(typeof e.material.flatShading!=`boolean`)throw Error(`Objekt ${t+1}: Shading-Einstellung ist ungültig.`);return{id:e.id,name:e.name,type:e.type,visible:e.visible,locked:e.locked,position:e.position,rotation:e.rotation,scale:e.scale,geometry:e.geometry,material:{color:e.material.color.toUpperCase(),roughness:e.material.roughness,metalness:e.material.metalness,opacity:e.material.opacity,flatShading:e.material.flatShading,...e.material.paintTexture===void 0?{}:{paintTexture:Ll(e.material.paintTexture,t)}},...typeof e.parentId==`string`?{parentId:e.parentId}:{}}}function zl(e){return JSON.stringify({format:wl,version:1,...e},null,2)}function Bl(e){let t;try{t=JSON.parse(e)}catch{throw Error(`Die Datei enthält kein gültiges JSON.`)}if(!Ol(t))throw Error(`Die Projektdatei ist ungültig.`);if(t.format!==`northcore-asset-editor`)throw Error(`Unbekanntes Projektformat.`);if(t.version!==1)throw Error(`Projektversion ${String(t.version)} wird nicht unterstützt.`);if(!Ol(t.project)||typeof t.project.name!=`string`||t.project.name.length===0||typeof t.project.createdAt!=`string`||typeof t.project.updatedAt!=`string`)throw Error(`Projektmetadaten fehlen oder sind ungültig.`);if(!Ol(t.scene)||!Nl(t.scene.background)||typeof t.scene.gridVisible!=`boolean`||typeof t.scene.axesVisible!=`boolean`||!kl(t.scene.gridSize)||t.scene.gridSize<=0)throw Error(`Szeneneinstellungen fehlen oder sind ungültig.`);if(!Array.isArray(t.objects))throw Error(`Die Objektliste fehlt.`);let n=t.objects.map(Rl);if(new Set(n.map(e=>e.id)).size!==n.length)throw Error(`Die Projektdatei enthält doppelte Objekt-IDs.`);return{format:wl,version:1,project:{name:t.project.name,createdAt:t.project.createdAt,updatedAt:t.project.updatedAt},scene:{background:t.scene.background.toUpperCase(),gridVisible:t.scene.gridVisible,axesVisible:t.scene.axesVisible,gridSize:t.scene.gridSize},objects:n}}function Vl(e,t,n){return{format:wl,version:1,project:{...e,updatedAt:new Date().toISOString()},scene:t,objects:n}}var Hl=e=>e.trim().replace(/[^a-zA-Z0-9äöüÄÖÜß_-]+/g,`-`).replace(/^-+|-+$/g,``)||`asset`,Ul=new Set([`plane`]);function Wl(e,t,n){return e.filter(e=>e.visible&&(!n||e.id===t))}function Gl(e){return!Ul.has(e.type)&&e.material.opacity>0}function Kl(e){let t=Ur(e);t.computeBoundingBox();let n=t.boundingBox?.clone();if(t.dispose(),!n)return!1;let r=new Pr().compose(new K(...e.position),new Ei().setFromEuler(new _n(...e.rotation)),new K(...e.scale));return n.applyMatrix4(r),n.min.y<-.001}function ql(e,t,n,r=`separate`){let i=Wl(e,t,n),a=i.reduce((e,t)=>e+Sl(t),0),o=[],s=i.filter(Gl).length,c=i.length-s;return i.length===0&&o.push(`Keine sichtbaren Objekte zum Exportieren.`),a>1e5&&o.push(`Sehr hohe Polygonzahl: über 100.000 Dreiecke.`),i.some(Kl)&&o.push(`Mindestens ein Objekt liegt teilweise unterhalb der Bodenebene.`),i.some(e=>e.material.opacity<=0)&&o.push(`Mindestens ein Objekt ist vollständig transparent.`),r===`union`&&(s<2&&o.push(`Union benötigt mindestens zwei geschlossene Volumenkörper. Der Export bleibt für diese Auswahl getrennt.`),c>0&&o.push(`${c} nicht union-fähige${c===1?`s`:``} Objekt${c===1?``:`e`} (z. B. Ebene oder vollständig transparent) ${c===1?`wird`:`werden`} separat exportiert.`)),{objects:i,triangles:a,warnings:o,unionEligible:s,unionSeparate:c}}var Jl=1.25,Yl=65535;Yl<<16;var Xl=2**-24,Zl=Symbol(`SKIP_GENERATION`),Ql={strategy:0,maxDepth:40,targetLeafSize:10,useSharedArrayBuffer:!1,setBoundingBox:!0,onProgress:null,indirect:!1,verbose:!0,range:null,[Zl]:!1};function $l(e,t,n){return n.min.x=t[e],n.min.y=t[e+1],n.min.z=t[e+2],n.max.x=t[e+3],n.max.y=t[e+4],n.max.z=t[e+5],n}function eu(e){let t=-1,n=-1/0;for(let r=0;r<3;r++){let i=e[r+3]-e[r];i>n&&(n=i,t=r)}return t}function tu(e,t){t.set(e)}function nu(e,t,n){let r,i;for(let a=0;a<3;a++){let o=a+3;r=e[a],i=t[a],n[a]=r<i?r:i,r=e[o],i=t[o],n[o]=r>i?r:i}}function ru(e,t,n){for(let r=0;r<3;r++){let i=t[e+2*r],a=t[e+2*r+1],o=i-a,s=i+a;o<n[r]&&(n[r]=o),s>n[r+3]&&(n[r+3]=s)}}function iu(e){let t=e[3]-e[0],n=e[4]-e[1],r=e[5]-e[2];return 2*(t*n+n*r+r*t)}function au(e,t){return t[e+15]===Yl}function ou(e,t){return t[e+6]}function su(e,t){return t[e+14]}function cu(e){return e+8}function lu(e,t){return e+t[e+6]*8}function uu(e,t){return t[e+7]}function du(e){return e}function fu(e,t,n,r,i){let a=1/0,o=1/0,s=1/0,c=-1/0,l=-1/0,u=-1/0,d=1/0,f=1/0,p=1/0,m=-1/0,h=-1/0,g=-1/0,_=e.offset||0;for(let r=(t-_)*6,i=(t+n-_)*6;r<i;r+=6){let t=e[r+0],n=e[r+1],i=t-n,_=t+n;i<a&&(a=i),_>c&&(c=_),t<d&&(d=t),t>m&&(m=t);let v=e[r+2],y=e[r+3],b=v-y,x=v+y;b<o&&(o=b),x>l&&(l=x),v<f&&(f=v),v>h&&(h=v);let S=e[r+4],C=e[r+5],w=S-C,T=S+C;w<s&&(s=w),T>u&&(u=T),S<p&&(p=S),S>g&&(g=S)}r[0]=a,r[1]=o,r[2]=s,r[3]=c,r[4]=l,r[5]=u,i[0]=d,i[1]=f,i[2]=p,i[3]=m,i[4]=h,i[5]=g}var pu=32,mu=(e,t)=>e.candidate-t.candidate,hu=Array(pu).fill().map(()=>({count:0,bounds:new Float32Array(6),rightCacheBounds:new Float32Array(6),leftCacheBounds:new Float32Array(6),candidate:0})),gu=new Float32Array(6);function _u(e,t,n,r,i,a){let o=-1,s=0;if(a===0)o=eu(t),o!==-1&&(s=(t[o]+t[o+3])/2);else if(a===1)o=eu(e),o!==-1&&(s=vu(n,r,i,o));else if(a===2){let a=iu(e),c=Jl*i,l=n.offset||0,u=(r-l)*6,d=(r+i-l)*6;for(let e=0;e<3;e++){let r=t[e],l=(t[e+3]-r)/pu;if(i<pu/4){let t=[...hu];t.length=i;let r=0;for(let i=u;i<d;i+=6,r++){let a=t[r];a.candidate=n[i+2*e],a.count=0;let{bounds:o,leftCacheBounds:s,rightCacheBounds:c}=a;for(let e=0;e<3;e++)c[e]=1/0,c[e+3]=-1/0,s[e]=1/0,s[e+3]=-1/0,o[e]=1/0,o[e+3]=-1/0;ru(i,n,o)}t.sort(mu);let l=i;for(let e=0;e<l;e++){let n=t[e];for(;e+1<l&&t[e+1].candidate===n.candidate;)t.splice(e+1,1),l--}for(let r=u;r<d;r+=6){let i=n[r+2*e];for(let e=0;e<l;e++){let a=t[e];i>=a.candidate?ru(r,n,a.rightCacheBounds):(ru(r,n,a.leftCacheBounds),a.count++)}}for(let n=0;n<l;n++){let r=t[n],l=r.count,u=i-r.count,d=r.leftCacheBounds,f=r.rightCacheBounds,p=0;l!==0&&(p=iu(d)/a);let m=0;u!==0&&(m=iu(f)/a);let h=1+Jl*(p*l+m*u);h<c&&(o=e,c=h,s=r.candidate)}}else{for(let e=0;e<pu;e++){let t=hu[e];t.count=0,t.candidate=r+l+e*l;let n=t.bounds;for(let e=0;e<3;e++)n[e]=1/0,n[e+3]=-1/0}for(let t=u;t<d;t+=6){let i=~~((n[t+2*e]-r)/l);i>=pu&&(i=pu-1);let a=hu[i];a.count++,ru(t,n,a.bounds)}let t=hu[pu-1];tu(t.bounds,t.rightCacheBounds);for(let e=pu-2;e>=0;e--){let t=hu[e],n=hu[e+1];nu(t.bounds,n.rightCacheBounds,t.rightCacheBounds)}let f=0;for(let t=0;t<pu-1;t++){let n=hu[t],r=n.count,l=n.bounds,u=hu[t+1].rightCacheBounds;r!==0&&(f===0?tu(l,gu):nu(l,gu,gu)),f+=r;let d=0,p=0;f!==0&&(d=iu(gu)/a);let m=i-f;m!==0&&(p=iu(u)/a);let h=1+Jl*(d*f+p*m);h<c&&(o=e,c=h,s=n.candidate)}}}}else console.warn(`BVH: Invalid build strategy value ${a} used.`);return{axis:o,pos:s}}function vu(e,t,n,r){let i=0,a=e.offset;for(let o=t,s=t+n;o<s;o++)i+=e[(o-a)*6+r*2];return i/n}var yu=class{constructor(){this.boundingData=new Float32Array(6)}};function bu(e,t,n,r,i,a){let o=r,s=r+i-1,c=a.pos,l=a.axis*2,u=n.offset||0;for(;;){for(;o<=s&&n[(o-u)*6+l]<c;)o++;for(;o<=s&&n[(s-u)*6+l]>=c;)s--;if(o<s){for(let n=0;n<t;n++){let r=e[o*t+n];e[o*t+n]=e[s*t+n],e[s*t+n]=r}for(let e=0;e<6;e++){let t=o-u,r=s-u,i=n[t*6+e];n[t*6+e]=n[r*6+e],n[r*6+e]=i}o++,s--}else return o}}var xu,Su,Cu,wu,Tu=2**32;function Eu(e){return`count`in e?1:1+Eu(e.left)+Eu(e.right)}function Du(e,t,n){return xu=new Float32Array(n),Su=new Uint32Array(n),Cu=new Uint16Array(n),wu=new Uint8Array(n),Ou(e,t)}function Ou(e,t){let n=e/4,r=e/2,i=`count`in t,a=t.boundingData;for(let e=0;e<6;e++)xu[n+e]=a[e];if(i)return t.buffer?(wu.set(new Uint8Array(t.buffer),e),e+t.buffer.byteLength):(Su[n+6]=t.offset,Cu[r+14]=t.count,Cu[r+15]=Yl,e+32);{let{left:r,right:i,splitAxis:a}=t,o=Ou(e+32,r),s=e/32,c=o/32-s;if(c>Tu)throw Error(`MeshBVH: Cannot store relative child node offset greater than 32 bits.`);return Su[n+6]=c,Su[n+7]=a,Ou(o,i)}}function ku(e,t,n,r,i,a){let{maxDepth:o,verbose:s,targetLeafSize:c,_strictLeafSize:l=1/0,strategy:u,onProgress:d}=i,f=e.primitiveBuffer,p=e.primitiveBufferStride,m=new Float32Array(6),h=!1,g=new yu;return fu(t,n,r,g.boundingData,m),v(g,n,r,m),g;function _(e){d&&d((e-a.offset)/a.count)}function v(e,n,r,i=null,a=0){!h&&a>=o&&(h=!0,s&&console.warn(`BVH: Max depth of ${o} reached when generating BVH. Consider increasing maxDepth.`));let d=r>l;if(r<=c&&!d||a>=o)return _(n+r),e.offset=n,e.count=r,e;let g=_u(e.boundingData,i,t,n,r,u),y=g.axis===-1?-1:bu(f,p,t,n,r,g);if(g.axis===-1||y===n||y===n+r){if(!d)return _(n+r),e.offset=n,e.count=r,e;g.axis=Math.max(0,eu(e.boundingData)),y=n+Math.max(1,Math.floor(r/2))}e.splitAxis=g.axis;let b=new yu,x=n,S=y-n;e.left=b,fu(t,x,S,b.boundingData,m),v(b,x,S,m,a+1);let C=new yu,w=y,T=r-S;return e.right=C,fu(t,w,T,C.boundingData,m),v(C,w,T,m,a+1),e}}function Au(e,t){let n=t.useSharedArrayBuffer?SharedArrayBuffer:ArrayBuffer,r=e.getRootRanges(t.range),i=r[0],a=r[r.length-1],o={offset:i.offset,count:a.offset+a.count-i.offset},s=new Float32Array(6*o.count);s.offset=o.offset,e.computePrimitiveBounds(o.offset,o.count,s),e._roots=r.map(r=>{let i=ku(e,s,r.offset,r.count,t,o),a=Eu(i),c=new n(32*a);return Du(0,i,c),c})}var ju=class{constructor(e){this._getNewPrimitive=e,this._primitives=[]}getPrimitive(){let e=this._primitives;return e.length===0?this._getNewPrimitive():e.pop()}releasePrimitive(e){this._primitives.push(e)}},Mu=new class{constructor(){this.float32Array=null,this.uint16Array=null,this.uint32Array=null;let e=[],t=null;this.setBuffer=n=>{t&&e.push(t),t=n,this.float32Array=new Float32Array(n),this.uint16Array=new Uint16Array(n),this.uint32Array=new Uint32Array(n)},this.clearBuffer=()=>{t=null,this.float32Array=null,this.uint16Array=null,this.uint32Array=null,e.length!==0&&this.setBuffer(e.pop())}}},Nu,Pu,Fu=[],Iu=new ju(()=>new Xa);function Lu(e,t,n,r,i,a){Nu=Iu.getPrimitive(),Pu=Iu.getPrimitive(),Fu.push(Nu,Pu),Mu.setBuffer(e._roots[t]);let o=Ru(0,e.geometry,n,r,i,a);Mu.clearBuffer(),Iu.releasePrimitive(Nu),Iu.releasePrimitive(Pu),Fu.pop(),Fu.pop();let s=Fu.length;return s>0&&(Pu=Fu[s-1],Nu=Fu[s-2]),o}function Ru(e,t,n,r,i=null,a=0,o=0){let{float32Array:s,uint16Array:c,uint32Array:l}=Mu,u=e*2;if(au(u,c)){let t=ou(e,l),n=su(u,c);return $l(du(e),s,Nu),r(t,n,!1,o,a+e/8,Nu)}else{let u=cu(e),d=lu(e,l),f=u,p=d,m,h,g,_;if(i&&(g=Nu,_=Pu,$l(du(f),s,g),$l(du(p),s,_),m=i(g),h=i(_),h<m)){f=d,p=u;let e=m;m=h,h=e,g=_}g||(g=Nu,$l(du(f),s,g));let v=au(f*2,c),y=n(g,v,m,o+1,a+f/8),b;if(y===2){let e=w(f);b=r(e,T(f)-e,!0,o+1,a+f/8,g)}else b=y&&Ru(f,t,n,r,i,a,o+1);if(b)return!0;_=Pu,$l(du(p),s,_);let x=au(p*2,c),S=n(_,x,h,o+1,a+p/8),C;if(S===2){let e=w(p);C=r(e,T(p)-e,!0,o+1,a+p/8,_)}else C=S&&Ru(p,t,n,r,i,a,o+1);if(C)return!0;return!1;function w(e){let{uint16Array:t,uint32Array:n}=Mu,r=e*2;for(;!au(r,t);)e=cu(e),r=e*2;return ou(e,n)}function T(e){let{uint16Array:t,uint32Array:n}=Mu,r=e*2;for(;!au(r,t);)e=lu(e,n),r=e*2;return ou(e,n)+su(r,t)}}}var zu=new Mu.constructor,Bu=new Mu.constructor,Vu=new ju(()=>new Xa),Hu=new Xa,Uu=new Xa,Wu=new Xa,Gu=new Xa,Ku=!1;function qu(e,t,n,r){if(Ku)throw Error(`MeshBVH: Recursive calls to bvhcast not supported.`);Ku=!0;let i=e._roots,a=t._roots,o,s=0,c=0,l=new Pr().copy(n).invert();for(let e=0,t=i.length;e<t;e++){zu.setBuffer(i[e]),c=0;let t=Vu.getPrimitive();$l(du(0),zu.float32Array,t),t.applyMatrix4(l);for(let e=0,i=a.length;e<i&&(Bu.setBuffer(a[e]),o=Ju(0,0,n,l,r,s,c,0,0,t),Bu.clearBuffer(),c+=a[e].byteLength/32,!o);e++);if(Vu.releasePrimitive(t),zu.clearBuffer(),s+=i[e].byteLength/32,o)break}return Ku=!1,o}function Ju(e,t,n,r,i,a=0,o=0,s=0,c=0,l=null,u=!1){let d,f;u?(d=Bu,f=zu):(d=zu,f=Bu);let p=d.float32Array,m=d.uint32Array,h=d.uint16Array,g=f.float32Array,_=f.uint32Array,v=f.uint16Array,y=e*2,b=t*2,x=au(y,h),S=au(b,v),C=!1;if(S&&x)C=u?i(ou(t,_),su(t*2,v),ou(e,m),su(e*2,h),c,o+t/8,s,a+e/8):i(ou(e,m),su(e*2,h),ou(t,_),su(t*2,v),s,a+e/8,c,o+t/8);else if(S){let l=Vu.getPrimitive();$l(du(t),g,l),l.applyMatrix4(n);let d=cu(e),f=lu(e,m);$l(du(d),p,Hu),$l(du(f),p,Uu);let h=l.intersectsBox(Hu),_=l.intersectsBox(Uu);C=h&&Ju(t,d,r,n,i,o,a,c,s+1,l,!u)||_&&Ju(t,f,r,n,i,o,a,c,s+1,l,!u),Vu.releasePrimitive(l)}else{let d=cu(t),f=lu(t,_);$l(du(d),g,Wu),$l(du(f),g,Gu);let h=l.intersectsBox(Wu),v=l.intersectsBox(Gu);if(h&&v)C=Ju(e,d,n,r,i,a,o,s,c+1,l,u)||Ju(e,f,n,r,i,a,o,s,c+1,l,u);else if(h)if(x)C=Ju(e,d,n,r,i,a,o,s,c+1,l,u);else{let t=Vu.getPrimitive();t.copy(Wu).applyMatrix4(n);let l=cu(e),f=lu(e,m);$l(du(l),p,Hu),$l(du(f),p,Uu);let h=t.intersectsBox(Hu),g=t.intersectsBox(Uu);C=h&&Ju(d,l,r,n,i,o,a,c,s+1,t,!u)||g&&Ju(d,f,r,n,i,o,a,c,s+1,t,!u),Vu.releasePrimitive(t)}else if(v)if(x)C=Ju(e,f,n,r,i,a,o,s,c+1,l,u);else{let t=Vu.getPrimitive();t.copy(Gu).applyMatrix4(n);let l=cu(e),d=lu(e,m);$l(du(l),p,Hu),$l(du(d),p,Uu);let h=t.intersectsBox(Hu),g=t.intersectsBox(Uu);C=h&&Ju(f,l,r,n,i,o,a,c,s+1,t,!u)||g&&Ju(f,d,r,n,i,o,a,c,s+1,t,!u),Vu.releasePrimitive(t)}}return C}var Yu=new class{constructor(){let e=null,t=null,n=null,r=!1;this.root=null,this.buffer=null,this.uint32Array=null,this.uint16Array=null,this.setBVH=(i,a)=>{if(r)throw Error(`BVHTraversalHelper: cannot call setBVH during an active traversal.`);this.root=a,this.buffer=e=i._roots[a],this.uint16Array=n=new Uint16Array(e),this.uint32Array=t=new Uint32Array(e)},this.reset=()=>{this.root=null,this.buffer=e=null,this.uint16Array=n=null,this.uint32Array=t=null},this.getRangeStart=e=>{let r=e*2;for(;!au(r,n);)e=cu(e),r=e*2;return ou(e,t)},this.getRangeEnd=e=>{let r=e*2;for(;!au(r,n);)e=lu(e,t),r=e*2;return ou(e,t)+su(r,n)};let i=(e,r,a)=>{let o=au(r*2,n);if(!e(a,o,r)&&!o){let n=cu(r),o=lu(r,t);i(e,n,a+1),i(e,o,a+1)}};this.traverseBuffer=e=>{if(r)throw Error(`BVHTraversalHelper: cannot start a traversal during an active traversal.`);r=!0;try{i(e,0,0)}finally{r=!1}},this.traverse=r=>{this.traverseBuffer((i,a,o)=>{if(a){let s=o*2,c=t[o+6],l=n[s+14];return r(i,a,new Float32Array(e,o*4,6),c,l)}else{let n=uu(o,t);return r(i,a,new Float32Array(e,o*4,6),n)}})}}},Xu=new Xa,Zu=new Float32Array(6),Qu=class{constructor(){this._roots=null,this.primitiveBuffer=null,this.primitiveBufferStride=null}init(e){e={...Ql,...e},`maxLeafSize`in e&&(console.warn(`BVH: "maxLeafSize" option has been deprecated. Use "targetLeafSize", instead.`),e={...e,targetLeafSize:e.maxLeafSize}),Au(this,e)}getRootRanges(){throw Error(`BVH: getRootRanges() not implemented`)}writePrimitiveBounds(){throw Error(`BVH: writePrimitiveBounds() not implemented`)}writePrimitiveRangeBounds(e,t,n,r){let i=1/0,a=1/0,o=1/0,s=-1/0,c=-1/0,l=-1/0;for(let n=e,r=e+t;n<r;n++){this.writePrimitiveBounds(n,Zu,0);let[e,t,r,u,d,f]=Zu;e<i&&(i=e),u>s&&(s=u),t<a&&(a=t),d>c&&(c=d),r<o&&(o=r),f>l&&(l=f)}return n[r+0]=i,n[r+1]=a,n[r+2]=o,n[r+3]=s,n[r+4]=c,n[r+5]=l,n}computePrimitiveBounds(e,t,n){let r=n.offset||0;for(let i=e,a=e+t;i<a;i++){this.writePrimitiveBounds(i,Zu,0);let[e,t,a,o,s,c]=Zu,l=(e+o)/2,u=(t+s)/2,d=(a+c)/2,f=(o-e)/2,p=(s-t)/2,m=(c-a)/2,h=(i-r)*6;n[h+0]=l,n[h+1]=f+(Math.abs(l)+f)*Xl,n[h+2]=u,n[h+3]=p+(Math.abs(u)+p)*Xl,n[h+4]=d,n[h+5]=m+(Math.abs(d)+m)*Xl}return n}shiftPrimitiveOffsets(e){let t=this._indirectBuffer;if(t)for(let n=0,r=t.length;n<r;n++)t[n]+=e;else{let t=this._roots;for(let n=0;n<t.length;n++){let r=t[n],i=new Uint32Array(r),a=new Uint16Array(r),o=r.byteLength/32;for(let t=0;t<o;t++){let n=8*t;au(2*n,a)&&(i[n+6]+=e)}}}}traverse(e,t=0){Yu.setBVH(this,t),Yu.traverse(e),Yu.reset()}refit(){let e=this._roots;for(let t=0,n=e.length;t<n;t++){let n=e[t],r=new Uint32Array(n),i=new Uint16Array(n),a=new Float32Array(n),o=n.byteLength/32;for(let e=o-1;e>=0;e--){let t=e*8,n=t*2;if(au(n,i)){let e=ou(t,r),o=su(n,i);this.writePrimitiveRangeBounds(e,o,Zu,0),a.set(Zu,t)}else{let e=cu(t),n=lu(t,r);for(let r=0;r<3;r++){let i=a[e+r],o=a[e+r+3],s=a[n+r],c=a[n+r+3];a[t+r]=i<s?i:s,a[t+r+3]=o>c?o:c}}}}}getBoundingBox(e){return e.makeEmpty(),this._roots.forEach(t=>{$l(0,new Float32Array(t),Xu),e.union(Xu)}),e}shapecast(e){let{boundsTraverseOrder:t,intersectsBounds:n,intersectsRange:r,intersectsPrimitive:i,scratchPrimitive:a,iterate:o}=e;if(r&&i){let e=r;r=(t,n,r,s,c)=>e(t,n,r,s,c)?!0:o(t,n,this,i,r,s,a)}else r||=i?(e,t,n,r)=>o(e,t,this,i,n,r,a):(e,t,n)=>n;let s=!1,c=0,l=this._roots;for(let e=0,i=l.length;e<i;e++){let i=l[e];if(s=Lu(this,e,n,r,t,c),s)break;c+=i.byteLength/32}return s}bvhcast(e,t,n){let{intersectsRanges:r}=n;return qu(this,e,t,r)}};function $u(){return typeof SharedArrayBuffer<`u`}function ed(e){return e.index?e.index.count:e.attributes.position.count}function td(e){return ed(e)/3}function nd(e,t=ArrayBuffer){return e>65535?new Uint32Array(new t(4*e)):new Uint16Array(new t(2*e))}function rd(e,t){if(!e.index){let n=e.attributes.position.count,r=nd(n,t.useSharedArrayBuffer?SharedArrayBuffer:ArrayBuffer);e.setIndex(new Zt(r,1));for(let e=0;e<n;e++)r[e]=e}}function id(e,t,n){let r=ed(e)/n,i=t||e.drawRange,a=i.start/n,o=(i.start+i.count)/n,s=Math.max(0,a),c=Math.min(r,o)-s;return{offset:Math.floor(s),count:Math.floor(c)}}function ad(e,t){return e.groups.map(e=>({offset:e.start/t,count:e.count/t}))}function od(e,t,n){let r=id(e,t,n),i=ad(e,n);if(!i.length)return[r];let a=[],o=r.offset,s=r.offset+r.count,c=ed(e)/n,l=[];for(let e of i){let{offset:t,count:n}=e,r=t,i=t+(isFinite(n)?n:c-t);r<s&&i>o&&(l.push({pos:Math.max(o,r),isStart:!0}),l.push({pos:Math.min(s,i),isStart:!1}))}l.sort((e,t)=>e.pos===t.pos?e.type===`end`?-1:1:e.pos-t.pos);let u=0,d=null;for(let e of l){let t=e.pos;u!==0&&t!==d&&a.push({offset:d,count:t-d}),u+=e.isStart?1:-1,d=t}return a}function sd(e,t){let n=e[e.length-1],r=n.offset+n.count>2**16,i=e.reduce((e,t)=>e+t.count,0),a=r?4:2,o=t?new SharedArrayBuffer(i*a):new ArrayBuffer(i*a),s=r?new Uint32Array(o):new Uint16Array(o),c=0;for(let t=0;t<e.length;t++){let{offset:n,count:r}=e[t];for(let e=0;e<r;e++)s[c+e]=n+e;c+=r}return s}var cd=class extends Qu{get indirect(){return!!this._indirectBuffer}get primitiveStride(){return null}get primitiveBufferStride(){return this.indirect?1:this.primitiveStride}set primitiveBufferStride(e){}get primitiveBuffer(){return this.indirect?this._indirectBuffer:this.geometry.index.array}set primitiveBuffer(e){}constructor(e,t={}){if(!e.isBufferGeometry)throw Error(`BVH: Only BufferGeometries are supported.`);if(e.index&&e.index.isInterleavedBufferAttribute)throw Error(`BVH: InterleavedBufferAttribute is not supported for the index attribute.`);if(t.useSharedArrayBuffer&&!$u())throw Error(`BVH: SharedArrayBuffer is not available.`);super(),this.geometry=e,this.resolvePrimitiveIndex=t.indirect?e=>this._indirectBuffer[e]:e=>e,this.primitiveBuffer=null,this.primitiveBufferStride=null,this._indirectBuffer=null,t={...Ql,...t},t[Zl]||this.init(t)}init(e){let{geometry:t,primitiveStride:n}=this;if(e.indirect){let r=sd(od(t,e.range,n),e.useSharedArrayBuffer);this._indirectBuffer=r}else rd(t,e);super.init(e),!t.boundingBox&&e.setBoundingBox&&(t.boundingBox=this.getBoundingBox(new Xa))}getRootRanges(e){return this.indirect?[{offset:0,count:this._indirectBuffer.length}]:od(this.geometry,e,this.primitiveStride)}raycastObject3D(){throw Error(`BVH: raycastObject3D() not implemented`)}},ld=class{constructor(){this.min=1/0,this.max=-1/0}setFromPointsField(e,t){let n=1/0,r=-1/0;for(let i=0,a=e.length;i<a;i++){let a=e[i][t];n=a<n?a:n,r=a>r?a:r}this.min=n,this.max=r}setFromPoints(e,t){let n=1/0,r=-1/0;for(let i=0,a=t.length;i<a;i++){let a=t[i],o=e.dot(a);n=o<n?o:n,r=o>r?o:r}this.min=n,this.max=r}isSeparated(e){return this.min>e.max||e.min>this.max}};ld.prototype.setFromBox=(function(){let e=new K;return function(t,n){let r=n.min,i=n.max,a=1/0,o=-1/0;for(let n=0;n<=1;n++)for(let s=0;s<=1;s++)for(let c=0;c<=1;c++){e.x=r.x*n+i.x*(1-n),e.y=r.y*s+i.y*(1-s),e.z=r.z*c+i.z*(1-c);let l=t.dot(e);a=Math.min(l,a),o=Math.max(l,o)}this.min=a,this.max=o}})();var ud=(function(){let e=new K,t=new K,n=new K;return function(r,i,a){let o=r.start,s=e,c=i.start,l=t;n.subVectors(o,c),e.subVectors(r.end,r.start),t.subVectors(i.end,i.start);let u=n.dot(l),d=l.dot(s),f=l.dot(l),p=n.dot(s),m=s.dot(s)*f-d*d,h,g;h=m===0?0:(u*d-p*f)/m,g=(u+h*d)/f,a.x=h,a.y=g}})(),dd=(function(){let e=new Er,t=new K,n=new K;return function(r,i,a,o){ud(r,i,e);let s=e.x,c=e.y;if(s>=0&&s<=1&&c>=0&&c<=1){r.at(s,a),i.at(c,o);return}else if(s>=0&&s<=1){c<0?i.at(0,o):i.at(1,o),r.closestPointToPoint(o,!0,a);return}else if(c>=0&&c<=1){s<0?r.at(0,a):r.at(1,a),i.closestPointToPoint(a,!0,o);return}else{let e;e=s<0?r.start:r.end;let l;l=c<0?i.start:i.end;let u=t,d=n;if(r.closestPointToPoint(l,!0,t),i.closestPointToPoint(e,!0,n),u.distanceToSquared(l)<=d.distanceToSquared(e)){a.copy(u),o.copy(l);return}else{a.copy(e),o.copy(d);return}}}})(),fd=(function(){let e=new K,t=new K,n=new Se,r=new en;return function(i,a){let{radius:o,center:s}=i,{a:c,b:l,c:u}=a;if(r.start=c,r.end=l,r.closestPointToPoint(s,!0,e).distanceTo(s)<=o||(r.start=c,r.end=u,r.closestPointToPoint(s,!0,e).distanceTo(s)<=o)||(r.start=l,r.end=u,r.closestPointToPoint(s,!0,e).distanceTo(s)<=o))return!0;let d=a.getPlane(n);if(Math.abs(d.distanceToPoint(s))<=o){let e=d.projectPoint(s,t);if(a.containsPoint(e))return!0}return!1}})(),pd=[`x`,`y`,`z`],md=1e-15,hd=md*md;function gd(e){return Math.abs(e)<md}var _d=class extends Tn{constructor(...e){super(...e),this.isExtendedTriangle=!0,this.satAxes=[,,,,].fill().map(()=>new K),this.satBounds=[,,,,].fill().map(()=>new ld),this.points=[this.a,this.b,this.c],this.plane=new Se,this.isDegenerateIntoSegment=!1,this.isDegenerateIntoPoint=!1,this.degenerateSegment=new en,this.needsUpdate=!0}intersectsSphere(e){return fd(e,this)}update(){let e=this.a,t=this.b,n=this.c,r=this.points,i=this.satAxes,a=this.satBounds,o=i[0],s=a[0];this.getNormal(o),s.setFromPoints(o,r);let c=i[1],l=a[1];c.subVectors(e,t),l.setFromPoints(c,r);let u=i[2],d=a[2];u.subVectors(t,n),d.setFromPoints(u,r);let f=i[3],p=a[3];f.subVectors(n,e),p.setFromPoints(f,r);let m=c.length(),h=u.length(),g=f.length();this.isDegenerateIntoPoint=!1,this.isDegenerateIntoSegment=!1,m<md?h<md||g<md?this.isDegenerateIntoPoint=!0:(this.isDegenerateIntoSegment=!0,this.degenerateSegment.start.copy(e),this.degenerateSegment.end.copy(n)):h<md?g<md?this.isDegenerateIntoPoint=!0:(this.isDegenerateIntoSegment=!0,this.degenerateSegment.start.copy(t),this.degenerateSegment.end.copy(e)):g<md&&(this.isDegenerateIntoSegment=!0,this.degenerateSegment.start.copy(n),this.degenerateSegment.end.copy(t)),this.plane.setFromNormalAndCoplanarPoint(o,e),this.needsUpdate=!1}};_d.prototype.closestPointToSegment=(function(){let e=new K,t=new K,n=new en;return function(r,i=null,a=null){let{start:o,end:s}=r,c=this.points,l,u=1/0;for(let o=0;o<3;o++){let s=(o+1)%3;n.start.copy(c[o]),n.end.copy(c[s]),dd(n,r,e,t),l=e.distanceToSquared(t),l<u&&(u=l,i&&i.copy(e),a&&a.copy(t))}return this.closestPointToPoint(o,e),l=o.distanceToSquared(e),l<u&&(u=l,i&&i.copy(e),a&&a.copy(o)),this.closestPointToPoint(s,e),l=s.distanceToSquared(e),l<u&&(u=l,i&&i.copy(e),a&&a.copy(s)),Math.sqrt(u)}})(),_d.prototype.intersectsTriangle=(function(){let e=new _d,t=new ld,n=new ld,r=new K,i=new K,a=new K,o=new K,s=new en,c=new en,l=new K,u=new Er,d=new Er;function f(e,i,a,s){let c=r;!e.isDegenerateIntoPoint&&!e.isDegenerateIntoSegment?c.copy(e.plane.normal):c.copy(i.plane.normal);let l=e.satBounds,u=e.satAxes;for(let r=1;r<4;r++){let a=l[r],s=u[r];if(t.setFromPoints(s,i.points),a.isSeparated(t)||(o.copy(c).cross(s),t.setFromPoints(o,e.points),n.setFromPoints(o,i.points),t.isSeparated(n)))return!1}let d=i.satBounds,f=i.satAxes;for(let r=1;r<4;r++){let a=d[r],s=f[r];if(t.setFromPoints(s,e.points),a.isSeparated(t)||(o.crossVectors(c,s),t.setFromPoints(o,e.points),n.setFromPoints(o,i.points),t.isSeparated(n)))return!1}return a&&(s||console.warn(`ExtendedTriangle.intersectsTriangle: Triangles are coplanar which does not support an output edge. Setting edge to 0, 0, 0.`),a.start.set(0,0,0),a.end.set(0,0,0)),!0}function p(e,t,n,r,i,a,o,s,c,l,u){let d=o/(o-s);l.x=r+(i-r)*d,u.start.subVectors(t,e).multiplyScalar(d).add(e),d=o/(o-c),l.y=r+(a-r)*d,u.end.subVectors(n,e).multiplyScalar(d).add(e)}function m(e,t,n,r,i,a,o,s,c,l,u){if(i>0)p(e.c,e.a,e.b,r,t,n,c,o,s,l,u);else if(a>0)p(e.b,e.a,e.c,n,t,r,s,o,c,l,u);else if(s*c>0||o!=0)p(e.a,e.b,e.c,t,n,r,o,s,c,l,u);else if(s!=0)p(e.b,e.a,e.c,n,t,r,s,o,c,l,u);else if(c!=0)p(e.c,e.a,e.b,r,t,n,c,o,s,l,u);else return!0;return!1}function h(e,t,n,i){let a=t.degenerateSegment,o=e.plane.distanceToPoint(a.start),s=e.plane.distanceToPoint(a.end);return gd(o)?gd(s)?f(e,t,n,i):(n&&(n.start.copy(a.start),n.end.copy(a.start)),e.containsPoint(a.start)):gd(s)?(n&&(n.start.copy(a.end),n.end.copy(a.end)),e.containsPoint(a.end)):e.plane.intersectLine(a,r)==null?!1:(n&&(n.start.copy(r),n.end.copy(r)),e.containsPoint(r))}function g(e,t,n){let r=t.a;return gd(e.plane.distanceToPoint(r))&&e.containsPoint(r)?(n&&(n.start.copy(r),n.end.copy(r)),!0):!1}function _(e,t,n){let i=e.degenerateSegment,a=t.a;return i.closestPointToPoint(a,!0,r),a.distanceToSquared(r)<hd?(n&&(n.start.copy(a),n.end.copy(a)),!0):!1}function v(e,t,n,o){if(e.isDegenerateIntoSegment)if(t.isDegenerateIntoSegment){let o=e.degenerateSegment,s=t.degenerateSegment,c=i,l=a;o.delta(c),s.delta(l);let u=r.subVectors(s.start,o.start),d=c.x*l.y-c.y*l.x;if(gd(d))return!1;let f=(u.x*l.y-u.y*l.x)/d,p=-(c.x*u.y-c.y*u.x)/d;return f<0||f>1||p<0||p>1?!1:gd(o.start.z+c.z*f-(s.start.z+l.z*p))?(n&&(n.start.copy(o.start).addScaledVector(c,f),n.end.copy(o.start).addScaledVector(c,f)),!0):!1}else if(t.isDegenerateIntoPoint)return _(e,t,n);else return h(t,e,n,o);else if(e.isDegenerateIntoPoint)return t.isDegenerateIntoPoint?t.a.distanceToSquared(e.a)<hd?(n&&(n.start.copy(e.a),n.end.copy(e.a)),!0):!1:t.isDegenerateIntoSegment?_(t,e,n):g(t,e,n);else if(t.isDegenerateIntoPoint)return g(e,t,n);else if(t.isDegenerateIntoSegment)return h(e,t,n,o)}return function(t,n=null,r=!1){this.needsUpdate&&this.update(),t.isExtendedTriangle?t.needsUpdate&&t.update():(e.copy(t),e.update(),t=e);let o=v(this,t,n,r);if(o!==void 0)return o;let p=this.plane,h=t.plane,g=h.distanceToPoint(this.a),_=h.distanceToPoint(this.b),y=h.distanceToPoint(this.c);gd(g)&&(g=0),gd(_)&&(_=0),gd(y)&&(y=0);let b=g*_,x=g*y;if(b>0&&x>0)return!1;let S=p.distanceToPoint(t.a),C=p.distanceToPoint(t.b),w=p.distanceToPoint(t.c);gd(S)&&(S=0),gd(C)&&(C=0),gd(w)&&(w=0);let T=S*C,E=S*w;if(T>0&&E>0)return!1;i.copy(p.normal),a.copy(h.normal);let D=i.cross(a),O=0,k=Math.abs(D.x),A=Math.abs(D.y);A>k&&(k=A,O=1),Math.abs(D.z)>k&&(O=2);let j=pd[O],M=this.a[j],N=this.b[j],P=this.c[j],F=t.a[j],I=t.b[j],L=t.c[j];if(m(this,M,N,P,b,x,g,_,y,u,s)||m(t,F,I,L,T,E,S,C,w,d,c))return f(this,t,n,r);if(u.y<u.x){let e=u.y;u.y=u.x,u.x=e,l.copy(s.start),s.start.copy(s.end),s.end.copy(l)}if(d.y<d.x){let e=d.y;d.y=d.x,d.x=e,l.copy(c.start),c.start.copy(c.end),c.end.copy(l)}return u.y<d.x||d.y<u.x?!1:(n&&(d.x>u.x?n.start.copy(c.start):n.start.copy(s.start),d.y<u.y?n.end.copy(c.end):n.end.copy(s.end)),!0)}})(),_d.prototype.distanceToPoint=(function(){let e=new K;return function(t){return this.closestPointToPoint(t,e),t.distanceTo(e)}})(),_d.prototype.distanceToTriangle=(function(){let e=new K,t=new K,n=[`a`,`b`,`c`],r=new en,i=new en;return function(a,o=null,s=null){let c=o||s?r:null;if(this.intersectsTriangle(a,c,!0))return(o||s)&&(o&&c.getCenter(o),s&&c.getCenter(s)),0;let l=1/0;for(let t=0;t<3;t++){let r,i=n[t],c=a[i];this.closestPointToPoint(c,e),r=c.distanceToSquared(e),r<l&&(l=r,o&&o.copy(e),s&&s.copy(c));let u=this[i];a.closestPointToPoint(u,e),r=u.distanceToSquared(e),r<l&&(l=r,o&&o.copy(u),s&&s.copy(e))}for(let c=0;c<3;c++){let u=n[c],d=n[(c+1)%3];r.set(this[u],this[d]);for(let c=0;c<3;c++){let u=n[c],d=n[(c+1)%3];i.set(a[u],a[d]),dd(r,i,e,t);let f=e.distanceToSquared(t);f<l&&(l=f,o&&o.copy(e),s&&s.copy(t))}}return Math.sqrt(l)}})();var vd=class{constructor(e,t,n){this.isOrientedBox=!0,this.min=new K,this.max=new K,this.matrix=new Pr,this.invMatrix=new Pr,this.points=Array(8).fill().map(()=>new K),this.satAxes=[,,,].fill().map(()=>new K),this.satBounds=[,,,].fill().map(()=>new ld),this.alignedSatBounds=[,,,].fill().map(()=>new ld),this.needsUpdate=!1,e&&this.min.copy(e),t&&this.max.copy(t),n&&this.matrix.copy(n)}set(e,t,n){this.min.copy(e),this.max.copy(t),this.matrix.copy(n),this.needsUpdate=!0}copy(e){this.min.copy(e.min),this.max.copy(e.max),this.matrix.copy(e.matrix),this.needsUpdate=!0}};vd.prototype.update=(function(){return function(){let e=this.matrix,t=this.min,n=this.max,r=this.points;for(let i=0;i<=1;i++)for(let a=0;a<=1;a++)for(let o=0;o<=1;o++){let s=r[1*i|2*a|4*o];s.x=i?n.x:t.x,s.y=a?n.y:t.y,s.z=o?n.z:t.z,s.applyMatrix4(e)}let i=this.satBounds,a=this.satAxes,o=r[0];for(let e=0;e<3;e++){let t=a[e],n=i[e],s=r[1<<e];t.subVectors(o,s),n.setFromPoints(t,r)}let s=this.alignedSatBounds;s[0].setFromPointsField(r,`x`),s[1].setFromPointsField(r,`y`),s[2].setFromPointsField(r,`z`),this.invMatrix.copy(this.matrix).invert(),this.needsUpdate=!1}})(),vd.prototype.intersectsBox=(function(){let e=new ld;return function(t){this.needsUpdate&&this.update();let n=t.min,r=t.max,i=this.satBounds,a=this.satAxes,o=this.alignedSatBounds;if(e.min=n.x,e.max=r.x,o[0].isSeparated(e)||(e.min=n.y,e.max=r.y,o[1].isSeparated(e))||(e.min=n.z,e.max=r.z,o[2].isSeparated(e)))return!1;for(let n=0;n<3;n++){let r=a[n],o=i[n];if(e.setFromBox(r,t),o.isSeparated(e))return!1}return!0}})(),vd.prototype.intersectsTriangle=(function(){let e=new _d,t=[,,,],n=new ld,r=new ld,i=new K;return function(a){this.needsUpdate&&this.update(),a.isExtendedTriangle?a.needsUpdate&&a.update():(e.copy(a),e.update(),a=e);let o=this.satBounds,s=this.satAxes;t[0]=a.a,t[1]=a.b,t[2]=a.c;for(let e=0;e<3;e++){let r=o[e],i=s[e];if(n.setFromPoints(i,t),r.isSeparated(n))return!1}let c=a.satBounds,l=a.satAxes,u=this.points;for(let e=0;e<3;e++){let t=c[e],r=l[e];if(n.setFromPoints(r,u),t.isSeparated(n))return!1}for(let e=0;e<3;e++){let a=s[e];for(let e=0;e<4;e++){let o=l[e];if(i.crossVectors(a,o),n.setFromPoints(i,t),r.setFromPoints(i,u),n.isSeparated(r))return!1}}return!0}})(),vd.prototype.closestPointToPoint=(function(){return function(e,t){return this.needsUpdate&&this.update(),t.copy(e).applyMatrix4(this.invMatrix).clamp(this.min,this.max).applyMatrix4(this.matrix),t}})(),vd.prototype.distanceToPoint=(function(){let e=new K;return function(t){return this.closestPointToPoint(t,e),t.distanceTo(e)}})(),vd.prototype.distanceToBox=(function(){let e=[`x`,`y`,`z`],t=Array(12).fill().map(()=>new en),n=Array(12).fill().map(()=>new en),r=new K,i=new K;return function(a,o=0,s=null,c=null){if(this.needsUpdate&&this.update(),this.intersectsBox(a))return(s||c)&&(a.getCenter(i),this.closestPointToPoint(i,r),a.closestPointToPoint(r,i),s&&s.copy(r),c&&c.copy(i)),0;let l=o*o,u=a.min,d=a.max,f=this.points,p=1/0;for(let e=0;e<8;e++){let t=f[e];i.copy(t).clamp(u,d);let n=t.distanceToSquared(i);if(n<p&&(p=n,s&&s.copy(t),c&&c.copy(i),n<l))return Math.sqrt(n)}let m=0;for(let r=0;r<3;r++)for(let i=0;i<=1;i++)for(let a=0;a<=1;a++){let o=(r+1)%3,s=(r+2)%3,c=i<<o|a<<s,l=1<<r|i<<o|a<<s,p=f[c],h=f[l];t[m].set(p,h);let g=e[r],_=e[o],v=e[s],y=n[m],b=y.start,x=y.end;b[g]=u[g],b[_]=i?u[_]:d[_],b[v]=a?u[v]:d[_],x[g]=d[g],x[_]=i?u[_]:d[_],x[v]=a?u[v]:d[_],m++}for(let e=0;e<=1;e++)for(let t=0;t<=1;t++)for(let n=0;n<=1;n++){i.x=e?d.x:u.x,i.y=t?d.y:u.y,i.z=n?d.z:u.z,this.closestPointToPoint(i,r);let a=i.distanceToSquared(r);if(a<p&&(p=a,s&&s.copy(r),c&&c.copy(i),a<l))return Math.sqrt(a)}for(let e=0;e<12;e++){let a=t[e];for(let e=0;e<12;e++){let t=n[e];dd(a,t,r,i);let o=r.distanceToSquared(i);if(o<p&&(p=o,s&&s.copy(r),c&&c.copy(i),o<l))return Math.sqrt(o)}}return Math.sqrt(p)}})();var yd=new class extends ju{constructor(){super(()=>new _d)}},bd=new K,xd=new K;function Sd(e,t,n={},r=0,i=1/0){let a=r*r,o=i*i,s=1/0,c=null;if(e.shapecast({boundsTraverseOrder:e=>(bd.copy(t).clamp(e.min,e.max),bd.distanceToSquared(t)),intersectsBounds:(e,t,n)=>n<s&&n<o,intersectsTriangle:(e,n)=>{e.closestPointToPoint(t,bd);let r=t.distanceToSquared(bd);return r<s&&(xd.copy(bd),s=r,c=n),r<a}}),s===1/0)return null;let l=Math.sqrt(s);return n.point?n.point.copy(xd):n.point=xd.clone(),n.distance=l,n.faceIndex=c,n}var Cd=!0,wd=new K,Td=new K,Ed=new K,Dd=new Er,Od=new Er,kd=new Er,Ad=new K,jd=new K,Md=new K,Nd=new K;function Pd(e,t,n,r,i,a,o,s){let c;if(c=a===1?e.intersectTriangle(r,n,t,!0,i):e.intersectTriangle(t,n,r,a!==2,i),c===null)return null;let l=e.origin.distanceTo(i);return l<o||l>s?null:{distance:l,point:i.clone()}}function Fd(e,t,n,r,i,a,o,s,c,l,u){wd.fromBufferAttribute(t,a),Td.fromBufferAttribute(t,o),Ed.fromBufferAttribute(t,s);let d=Pd(e,wd,Td,Ed,Nd,c,l,u);if(d){if(r){Dd.fromBufferAttribute(r,a),Od.fromBufferAttribute(r,o),kd.fromBufferAttribute(r,s),d.uv=new Er;let e=Tn.getInterpolation(Nd,wd,Td,Ed,Dd,Od,kd,d.uv);Cd||(d.uv=e)}if(i){Dd.fromBufferAttribute(i,a),Od.fromBufferAttribute(i,o),kd.fromBufferAttribute(i,s),d.uv1=new Er;let e=Tn.getInterpolation(Nd,wd,Td,Ed,Dd,Od,kd,d.uv1);Cd||(d.uv1=e)}if(n){Ad.fromBufferAttribute(n,a),jd.fromBufferAttribute(n,o),Md.fromBufferAttribute(n,s),d.normal=new K;let t=Tn.getInterpolation(Nd,wd,Td,Ed,Ad,jd,Md,d.normal);d.normal.dot(e.direction)>0&&d.normal.multiplyScalar(-1),Cd||(d.normal=t)}let t={a,b:o,c:s,normal:new K,materialIndex:0};if(Tn.getNormal(wd,Td,Ed,t.normal),d.face=t,d.faceIndex=a,Cd){let e=new K;Tn.getBarycoord(Nd,wd,Td,Ed,e),d.barycoord=e}}return d}function Id(e){return e&&e.isMaterial?e.side:e}function Ld(e,t,n,r,i,a,o){let s=r*3,c=s+0,l=s+1,u=s+2,{index:d,groups:f}=e;e.index&&(c=d.getX(c),l=d.getX(l),u=d.getX(u));let{position:p,normal:m,uv:h,uv1:g}=e.attributes;if(Array.isArray(t)){let e=r*3;for(let s=0,d=f.length;s<d;s++){let{start:d,count:_,materialIndex:v}=f[s];if(e>=d&&e<d+_){let e=Id(t[v]),s=Fd(n,p,m,h,g,c,l,u,e,a,o);if(s)if(s.faceIndex=r,s.face.materialIndex=v,i)i.push(s);else return s}}}else{let e=Id(t),s=Fd(n,p,m,h,g,c,l,u,e,a,o);if(s)if(s.faceIndex=r,s.face.materialIndex=0,i)i.push(s);else return s}return null}function Rd(e,t,n,r){let i=e.a,a=e.b,o=e.c,s=t,c=t+1,l=t+2;n&&(s=n.getX(s),c=n.getX(c),l=n.getX(l)),i.x=r.getX(s),i.y=r.getY(s),i.z=r.getZ(s),a.x=r.getX(c),a.y=r.getY(c),a.z=r.getZ(c),o.x=r.getX(l),o.y=r.getY(l),o.z=r.getZ(l)}function zd(e,t,n,r,i,a,o,s){let{geometry:c,_indirectBuffer:l}=e;for(let e=r,l=r+i;e<l;e++)Ld(c,t,n,e,a,o,s)}function Bd(e,t,n,r,i,a,o){let{geometry:s,_indirectBuffer:c}=e,l=1/0,u=null;for(let e=r,c=r+i;e<c;e++){let r;r=Ld(s,t,n,e,null,a,o),r&&r.distance<l&&(u=r,l=r.distance)}return u}function Vd(e,t,n,r,i,a,o){let{geometry:s}=n,{index:c}=s,l=s.attributes.position;for(let n=e,s=t+e;n<s;n++){let e;if(e=n,Rd(o,e*3,c,l),o.needsUpdate=!0,r(o,e,i,a))return!0}return!1}function Hd(e,t=null){t&&Array.isArray(t)&&(t=new Set(t));let n=e.geometry,r=n.index?n.index.array:null,i=n.attributes.position,a,o,s,c,l=0,u=e._roots;for(let e=0,t=u.length;e<t;e++)a=u[e],o=new Uint32Array(a),s=new Uint16Array(a),c=new Float32Array(a),d(0,l),l+=a.byteLength;function d(e,n,a=!1){let l=e*2;if(au(l,s)){let t=ou(e,o),n=su(l,s),a=1/0,u=1/0,d=1/0,f=-1/0,p=-1/0,m=-1/0;for(let e=3*t,o=3*(t+n);e<o;e++){let t=r[e],n=i.getX(t),o=i.getY(t),s=i.getZ(t);n<a&&(a=n),n>f&&(f=n),o<u&&(u=o),o>p&&(p=o),s<d&&(d=s),s>m&&(m=s)}return c[e+0]!==a||c[e+1]!==u||c[e+2]!==d||c[e+3]!==f||c[e+4]!==p||c[e+5]!==m?(c[e+0]=a,c[e+1]=u,c[e+2]=d,c[e+3]=f,c[e+4]=p,c[e+5]=m,!0):!1}else{let r=cu(e),i=lu(e,o),s=a,l=!1,u=!1;if(t){if(!s){let e=r/8+n/32,a=i/8+n/32;l=t.has(e),u=t.has(a),s=!l&&!u}}else l=!0,u=!0;let f=s||l,p=s||u,m=!1;f&&(m=d(r,n,s));let h=!1;p&&(h=d(i,n,s));let g=m||h;if(g)for(let t=0;t<3;t++){let n=r+t,a=i+t,o=c[n],s=c[n+3],l=c[a],u=c[a+3];c[e+t]=o<l?o:l,c[e+t+3]=s>u?s:u}return g}}}function Ud(e,t,n,r,i){let a,o,s,c,l,u,d=1/n.direction.x,f=1/n.direction.y,p=1/n.direction.z,m=n.origin.x,h=n.origin.y,g=n.origin.z,_=t[e],v=t[e+3],y=t[e+1],b=t[e+3+1],x=t[e+2],S=t[e+3+2];return d>=0?(a=(_-m)*d,o=(v-m)*d):(a=(v-m)*d,o=(_-m)*d),f>=0?(s=(y-h)*f,c=(b-h)*f):(s=(b-h)*f,c=(y-h)*f),a>c||s>o||((s>a||isNaN(a))&&(a=s),(c<o||isNaN(o))&&(o=c),p>=0?(l=(x-g)*p,u=(S-g)*p):(l=(S-g)*p,u=(x-g)*p),a>u||l>o)?!1:((l>a||a!==a)&&(a=l),(u<o||o!==o)&&(o=u),a<=i&&o>=r)}function Wd(e,t,n,r,i,a,o,s){let{geometry:c,_indirectBuffer:l}=e;for(let e=r,u=r+i;e<u;e++)Ld(c,t,n,l?l[e]:e,a,o,s)}function Gd(e,t,n,r,i,a,o){let{geometry:s,_indirectBuffer:c}=e,l=1/0,u=null;for(let e=r,d=r+i;e<d;e++){let r;r=Ld(s,t,n,c?c[e]:e,null,a,o),r&&r.distance<l&&(u=r,l=r.distance)}return u}function Kd(e,t,n,r,i,a,o){let{geometry:s}=n,{index:c}=s,l=s.attributes.position;for(let s=e,u=t+e;s<u;s++){let e;if(e=n.resolveTriangleIndex(s),Rd(o,e*3,c,l),o.needsUpdate=!0,r(o,e,i,a))return!0}return!1}function qd(e,t,n,r,i,a,o){Mu.setBuffer(e._roots[t]),Jd(0,e,n,r,i,a,o),Mu.clearBuffer()}function Jd(e,t,n,r,i,a,o){let{float32Array:s,uint16Array:c,uint32Array:l}=Mu,u=e*2;if(au(u,c))zd(t,n,r,ou(e,l),su(u,c),i,a,o);else{let c=cu(e);Ud(c,s,r,a,o)&&Jd(c,t,n,r,i,a,o);let u=lu(e,l);Ud(u,s,r,a,o)&&Jd(u,t,n,r,i,a,o)}}var Yd=[`x`,`y`,`z`];function Xd(e,t,n,r,i,a){Mu.setBuffer(e._roots[t]);let o=Zd(0,e,n,r,i,a);return Mu.clearBuffer(),o}function Zd(e,t,n,r,i,a){let{float32Array:o,uint16Array:s,uint32Array:c}=Mu,l=e*2;if(au(l,s))return Bd(t,n,r,ou(e,c),su(l,s),i,a);{let s=uu(e,c),l=Yd[s],u=r.direction[l]>=0,d,f;u?(d=cu(e),f=lu(e,c)):(d=lu(e,c),f=cu(e));let p=Ud(d,o,r,i,a)?Zd(d,t,n,r,i,a):null;if(p){let e=p.point[l];if(u?e<=o[f+s]:e>=o[f+s+3])return p}let m=Ud(f,o,r,i,a)?Zd(f,t,n,r,i,a):null;return p&&m?p.distance<=m.distance?p:m:p||m||null}}var Qd=new Xa,$d=new _d,ef=new _d,tf=new Pr,nf=new vd,rf=new vd;function af(e,t,n,r){Mu.setBuffer(e._roots[t]);let i=of(0,e,n,r);return Mu.clearBuffer(),i}function of(e,t,n,r,i=null){let{float32Array:a,uint16Array:o,uint32Array:s}=Mu,c=e*2;if(i===null&&(n.boundingBox||n.computeBoundingBox(),nf.set(n.boundingBox.min,n.boundingBox.max,r),i=nf),au(c,o)){let i=t.geometry,l=i.index,u=i.attributes.position,d=n.index,f=n.attributes.position,p=ou(e,s),m=su(c,o);if(tf.copy(r).invert(),n.boundsTree)return $l(du(e),a,rf),rf.matrix.copy(tf),rf.needsUpdate=!0,n.boundsTree.shapecast({intersectsBounds:e=>rf.intersectsBox(e),intersectsTriangle:e=>{e.a.applyMatrix4(r),e.b.applyMatrix4(r),e.c.applyMatrix4(r),e.needsUpdate=!0;for(let t=p*3,n=(m+p)*3;t<n;t+=3)if(Rd(ef,t,l,u),ef.needsUpdate=!0,e.intersectsTriangle(ef))return!0;return!1}});{let e=td(n);for(let t=p*3,n=(m+p)*3;t<n;t+=3){Rd($d,t,l,u),$d.a.applyMatrix4(tf),$d.b.applyMatrix4(tf),$d.c.applyMatrix4(tf),$d.needsUpdate=!0;for(let t=0,n=e*3;t<n;t+=3)if(Rd(ef,t,d,f),ef.needsUpdate=!0,$d.intersectsTriangle(ef))return!0}}}else{let o=cu(e),c=lu(e,s);return $l(du(o),a,Qd),!!(i.intersectsBox(Qd)&&of(o,t,n,r,i)||($l(du(c),a,Qd),i.intersectsBox(Qd)&&of(c,t,n,r,i)))}}var sf=new Pr,cf=new vd,lf=new vd,uf=new K,df=new K,ff=new K,pf=new K;function mf(e,t,n,r={},i={},a=0,o=1/0){t.boundingBox||t.computeBoundingBox(),cf.set(t.boundingBox.min,t.boundingBox.max,n),cf.needsUpdate=!0;let s=e.geometry,c=s.attributes.position,l=s.index,u=t.attributes.position,d=t.index,f=yd.getPrimitive(),p=yd.getPrimitive(),m=uf,h=df,g=null,_=null;i&&(g=ff,_=pf);let v=1/0,y=null,b=null;return sf.copy(n).invert(),lf.matrix.copy(sf),e.shapecast({boundsTraverseOrder:e=>cf.distanceToBox(e),intersectsBounds:(e,t,n)=>n<v&&n<o?(t&&(lf.min.copy(e.min),lf.max.copy(e.max),lf.needsUpdate=!0),!0):!1,intersectsRange:(e,r)=>{if(t.boundsTree)return t.boundsTree.shapecast({boundsTraverseOrder:e=>lf.distanceToBox(e),intersectsBounds:(e,t,n)=>n<v&&n<o,intersectsRange:(t,i)=>{for(let o=t,s=t+i;o<s;o++){Rd(p,3*o,d,u),p.a.applyMatrix4(n),p.b.applyMatrix4(n),p.c.applyMatrix4(n),p.needsUpdate=!0;for(let t=e,n=e+r;t<n;t++){Rd(f,3*t,l,c),f.needsUpdate=!0;let e=f.distanceToTriangle(p,m,g);if(e<v&&(h.copy(m),_&&_.copy(g),v=e,y=t,b=o),e<a)return!0}}}});{let i=td(t);for(let t=0,o=i;t<o;t++){Rd(p,3*t,d,u),p.a.applyMatrix4(n),p.b.applyMatrix4(n),p.c.applyMatrix4(n),p.needsUpdate=!0;for(let n=e,i=e+r;n<i;n++){Rd(f,3*n,l,c),f.needsUpdate=!0;let e=f.distanceToTriangle(p,m,g);if(e<v&&(h.copy(m),_&&_.copy(g),v=e,y=n,b=t),e<a)return!0}}}}}),yd.releasePrimitive(f),yd.releasePrimitive(p),v===1/0?null:(r.point?r.point.copy(h):r.point=h.clone(),r.distance=v,r.faceIndex=y,i&&(i.point?i.point.copy(_):i.point=_.clone(),i.point.applyMatrix4(sf),h.applyMatrix4(sf),i.distance=h.sub(i.point).length(),i.faceIndex=b),r)}function hf(e,t=null){t&&Array.isArray(t)&&(t=new Set(t));let n=e.geometry,r=n.index?n.index.array:null,i=n.attributes.position,a,o,s,c,l=0,u=e._roots;for(let e=0,t=u.length;e<t;e++)a=u[e],o=new Uint32Array(a),s=new Uint16Array(a),c=new Float32Array(a),d(0,l),l+=a.byteLength;function d(n,a,l=!1){let u=n*2;if(au(u,s)){let t=ou(n,o),a=su(u,s),l=1/0,d=1/0,f=1/0,p=-1/0,m=-1/0,h=-1/0;for(let n=t,o=t+a;n<o;n++){let t=3*e.resolveTriangleIndex(n);for(let e=0;e<3;e++){let n=t+e;n=r?r[n]:n;let a=i.getX(n),o=i.getY(n),s=i.getZ(n);a<l&&(l=a),a>p&&(p=a),o<d&&(d=o),o>m&&(m=o),s<f&&(f=s),s>h&&(h=s)}}return c[n+0]!==l||c[n+1]!==d||c[n+2]!==f||c[n+3]!==p||c[n+4]!==m||c[n+5]!==h?(c[n+0]=l,c[n+1]=d,c[n+2]=f,c[n+3]=p,c[n+4]=m,c[n+5]=h,!0):!1}else{let e=cu(n),r=lu(n,o),i=l,s=!1,u=!1;if(t){if(!i){let n=e/8+a/32,o=r/8+a/32;s=t.has(n),u=t.has(o),i=!s&&!u}}else s=!0,u=!0;let f=i||s,p=i||u,m=!1;f&&(m=d(e,a,i));let h=!1;p&&(h=d(r,a,i));let g=m||h;if(g)for(let t=0;t<3;t++){let i=e+t,a=r+t,o=c[i],s=c[i+3],l=c[a],u=c[a+3];c[n+t]=o<l?o:l,c[n+t+3]=s>u?s:u}return g}}}function gf(e,t,n,r,i,a,o){Mu.setBuffer(e._roots[t]),_f(0,e,n,r,i,a,o),Mu.clearBuffer()}function _f(e,t,n,r,i,a,o){let{float32Array:s,uint16Array:c,uint32Array:l}=Mu,u=e*2;if(au(u,c))Wd(t,n,r,ou(e,l),su(u,c),i,a,o);else{let c=cu(e);Ud(c,s,r,a,o)&&_f(c,t,n,r,i,a,o);let u=lu(e,l);Ud(u,s,r,a,o)&&_f(u,t,n,r,i,a,o)}}var vf=[`x`,`y`,`z`];function yf(e,t,n,r,i,a){Mu.setBuffer(e._roots[t]);let o=bf(0,e,n,r,i,a);return Mu.clearBuffer(),o}function bf(e,t,n,r,i,a){let{float32Array:o,uint16Array:s,uint32Array:c}=Mu,l=e*2;if(au(l,s))return Gd(t,n,r,ou(e,c),su(l,s),i,a);{let s=uu(e,c),l=vf[s],u=r.direction[l]>=0,d,f;u?(d=cu(e),f=lu(e,c)):(d=lu(e,c),f=cu(e));let p=Ud(d,o,r,i,a)?bf(d,t,n,r,i,a):null;if(p){let e=p.point[l];if(u?e<=o[f+s]:e>=o[f+s+3])return p}let m=Ud(f,o,r,i,a)?bf(f,t,n,r,i,a):null;return p&&m?p.distance<=m.distance?p:m:p||m||null}}var xf=new Xa,Sf=new _d,Cf=new _d,wf=new Pr,Tf=new vd,Ef=new vd;function Df(e,t,n,r){Mu.setBuffer(e._roots[t]);let i=Of(0,e,n,r);return Mu.clearBuffer(),i}function Of(e,t,n,r,i=null){let{float32Array:a,uint16Array:o,uint32Array:s}=Mu,c=e*2;if(i===null&&(n.boundingBox||n.computeBoundingBox(),Tf.set(n.boundingBox.min,n.boundingBox.max,r),i=Tf),au(c,o)){let i=t.geometry,l=i.index,u=i.attributes.position,d=n.index,f=n.attributes.position,p=ou(e,s),m=su(c,o);if(wf.copy(r).invert(),n.boundsTree)return $l(du(e),a,Ef),Ef.matrix.copy(wf),Ef.needsUpdate=!0,n.boundsTree.shapecast({intersectsBounds:e=>Ef.intersectsBox(e),intersectsTriangle:e=>{e.a.applyMatrix4(r),e.b.applyMatrix4(r),e.c.applyMatrix4(r),e.needsUpdate=!0;for(let n=p,r=m+p;n<r;n++)if(Rd(Cf,3*t.resolveTriangleIndex(n),l,u),Cf.needsUpdate=!0,e.intersectsTriangle(Cf))return!0;return!1}});{let e=td(n);for(let n=p,r=m+p;n<r;n++){Rd(Sf,3*t.resolveTriangleIndex(n),l,u),Sf.a.applyMatrix4(wf),Sf.b.applyMatrix4(wf),Sf.c.applyMatrix4(wf),Sf.needsUpdate=!0;for(let t=0,n=e*3;t<n;t+=3)if(Rd(Cf,t,d,f),Cf.needsUpdate=!0,Sf.intersectsTriangle(Cf))return!0}}}else{let o=cu(e),c=lu(e,s);return $l(du(o),a,xf),!!(i.intersectsBox(xf)&&Of(o,t,n,r,i)||($l(du(c),a,xf),i.intersectsBox(xf)&&Of(c,t,n,r,i)))}}var kf=new Pr,Af=new vd,jf=new vd,Mf=new K,Nf=new K,Pf=new K,Ff=new K;function If(e,t,n,r={},i={},a=0,o=1/0){t.boundingBox||t.computeBoundingBox(),Af.set(t.boundingBox.min,t.boundingBox.max,n),Af.needsUpdate=!0;let s=e.geometry,c=s.attributes.position,l=s.index,u=t.attributes.position,d=t.index,f=yd.getPrimitive(),p=yd.getPrimitive(),m=Mf,h=Nf,g=null,_=null;i&&(g=Pf,_=Ff);let v=1/0,y=null,b=null;return kf.copy(n).invert(),jf.matrix.copy(kf),e.shapecast({boundsTraverseOrder:e=>Af.distanceToBox(e),intersectsBounds:(e,t,n)=>n<v&&n<o?(t&&(jf.min.copy(e.min),jf.max.copy(e.max),jf.needsUpdate=!0),!0):!1,intersectsRange:(r,i)=>{if(t.boundsTree){let s=t.boundsTree;return s.shapecast({boundsTraverseOrder:e=>jf.distanceToBox(e),intersectsBounds:(e,t,n)=>n<v&&n<o,intersectsRange:(t,o)=>{for(let x=t,S=t+o;x<S;x++){let t=s.resolveTriangleIndex(x);Rd(p,3*t,d,u),p.a.applyMatrix4(n),p.b.applyMatrix4(n),p.c.applyMatrix4(n),p.needsUpdate=!0;for(let t=r,n=r+i;t<n;t++){let n=e.resolveTriangleIndex(t);Rd(f,3*n,l,c),f.needsUpdate=!0;let r=f.distanceToTriangle(p,m,g);if(r<v&&(h.copy(m),_&&_.copy(g),v=r,y=t,b=x),r<a)return!0}}}})}else{let o=td(t);for(let t=0,s=o;t<s;t++){Rd(p,3*t,d,u),p.a.applyMatrix4(n),p.b.applyMatrix4(n),p.c.applyMatrix4(n),p.needsUpdate=!0;for(let n=r,o=r+i;n<o;n++){let r=e.resolveTriangleIndex(n);Rd(f,3*r,l,c),f.needsUpdate=!0;let i=f.distanceToTriangle(p,m,g);if(i<v&&(h.copy(m),_&&_.copy(g),v=i,y=n,b=t),i<a)return!0}}}}}),yd.releasePrimitive(f),yd.releasePrimitive(p),v===1/0?null:(r.point?r.point.copy(h):r.point=h.clone(),r.distance=v,r.faceIndex=y,i&&(i.point?i.point.copy(_):i.point=_.clone(),i.point.applyMatrix4(kf),h.applyMatrix4(kf),i.distance=h.sub(i.point).length(),i.faceIndex=b),r)}function Lf(e,t,n){return e===null?null:(e.point.applyMatrix4(t.matrixWorld),e.distance=e.point.distanceTo(n.ray.origin),e.object=t,e)}var Rf=new vd,zf=new Ne,Bf=new K,Vf=new Pr,Hf=new K,Uf=[`getX`,`getY`,`getZ`],Wf=class e extends cd{static serialize(e,t={}){t={cloneBuffers:!0,...t};let n=e.geometry,r=e._roots,i=e._indirectBuffer,a=n.getIndex(),o={version:1,roots:null,index:null,indirectBuffer:null};return t.cloneBuffers?(o.roots=r.map(e=>e.slice()),o.index=a?a.array.slice():null,o.indirectBuffer=i?i.slice():null):(o.roots=r,o.index=a?a.array:null,o.indirectBuffer=i),o}static deserialize(t,n,r={}){r={setIndex:!0,indirect:!!t.indirectBuffer,...r};let{index:i,roots:a,indirectBuffer:o}=t;t.version||(console.warn(`MeshBVH.deserialize: Serialization format has been changed and will be fixed up. It is recommended to regenerate any stored serialized data.`),c(a));let s=new e(n,{...r,[Zl]:!0});if(s._roots=a,s._indirectBuffer=o||null,r.setIndex){let e=n.getIndex();if(e===null){let e=new Zt(t.index,1,!1);n.setIndex(e)}else e.array!==i&&(e.array.set(i),e.needsUpdate=!0)}return s;function c(e){for(let t=0;t<e.length;t++){let n=e[t],r=new Uint32Array(n),i=new Uint16Array(n);for(let e=0,t=n.byteLength/32;e<t;e++){let t=8*e;au(2*t,i)||(r[t+6]=r[t+6]/8-e)}}}}get primitiveStride(){return 3}get resolveTriangleIndex(){return this.resolvePrimitiveIndex}constructor(e,t={}){t.maxLeafTris&&(console.warn(`MeshBVH: "maxLeafTris" option has been deprecated. Use "targetLeafSize", instead.`),t={...t,targetLeafSize:t.maxLeafTris}),super(e,t)}shiftTriangleOffsets(e){return super.shiftPrimitiveOffsets(e)}writePrimitiveBounds(e,t,n){let r=this.geometry,i=this._indirectBuffer,a=r.attributes.position,o=r.index?r.index.array:null,s=(i?i[e]:e)*3,c=s+0,l=s+1,u=s+2;o&&(c=o[c],l=o[l],u=o[u]);for(let e=0;e<3;e++){let r=a[Uf[e]](c),i=a[Uf[e]](l),o=a[Uf[e]](u),s=r;i<s&&(s=i),o<s&&(s=o);let d=r;i>d&&(d=i),o>d&&(d=o),t[n+e]=s,t[n+e+3]=d}return t}computePrimitiveBounds(e,t,n){let r=this.geometry,i=this._indirectBuffer,a=r.attributes.position,o=r.index?r.index.array:null,s=a.normalized;if(e<0||t+e-n.offset>n.length/6)throw Error(`MeshBVH: compute triangle bounds range is invalid.`);let c=a.array,l=a.offset||0,u=3;a.isInterleavedBufferAttribute&&(u=a.data.stride);let d=[`getX`,`getY`,`getZ`],f=n.offset;for(let r=e,p=e+t;r<p;r++){let e=(i?i[r]:r)*3,t=(r-f)*6,p=e+0,m=e+1,h=e+2;o&&(p=o[p],m=o[m],h=o[h]),s||(p=p*u+l,m=m*u+l,h=h*u+l);for(let e=0;e<3;e++){let r,i,o;s?(r=a[d[e]](p),i=a[d[e]](m),o=a[d[e]](h)):(r=c[p+e],i=c[m+e],o=c[h+e]);let l=r;i<l&&(l=i),o<l&&(l=o);let u=r;i>u&&(u=i),o>u&&(u=o);let f=(u-l)/2,g=e*2;n[t+g+0]=l+f,n[t+g+1]=f+(Math.abs(l)+f)*Xl}}return n}raycastObject3D(e,t,n=[]){let{material:r}=e;if(r===void 0)return;Vf.copy(e.matrixWorld).invert(),zf.copy(t.ray).applyMatrix4(Vf),Hf.setFromMatrixScale(e.matrixWorld),Bf.copy(zf.direction).multiply(Hf);let i=Bf.length(),a=t.near/i,o=t.far/i;if(t.firstHitOnly===!0){let i=this.raycastFirst(zf,r,a,o);i=Lf(i,e,t),i&&n.push(i)}else{let i=this.raycast(zf,r,a,o);for(let r=0,a=i.length;r<a;r++){let a=Lf(i[r],e,t);a&&n.push(a)}}return n}refit(e=null){return(this.indirect?hf:Hd)(this,e)}raycast(e,t=0,n=0,r=1/0){let i=this._roots,a=[],o=this.indirect?gf:qd;for(let s=0,c=i.length;s<c;s++)o(this,s,t,e,a,n,r);return a}raycastFirst(e,t=0,n=0,r=1/0){let i=this._roots,a=null,o=this.indirect?yf:Xd;for(let s=0,c=i.length;s<c;s++){let i=o(this,s,t,e,n,r);i!=null&&(a==null||i.distance<a.distance)&&(a=i)}return a}intersectsGeometry(e,t){let n=!1,r=this._roots,i=this.indirect?Df:af;for(let a=0,o=r.length;a<o&&(n=i(this,a,e,t),!n);a++);return n}shapecast(e){let t=yd.getPrimitive(),n=super.shapecast({...e,intersectsPrimitive:e.intersectsTriangle,scratchPrimitive:t,iterate:this.indirect?Kd:Vd});return yd.releasePrimitive(t),n}bvhcast(t,n,r){let{intersectsRanges:i,intersectsTriangles:a}=r,o=yd.getPrimitive(),s=this.geometry.index,c=this.geometry.attributes.position,l=this.indirect?e=>{let t=this.resolveTriangleIndex(e);Rd(o,t*3,s,c)}:e=>{Rd(o,e*3,s,c)},u=yd.getPrimitive(),d=t.geometry.index,f=t.geometry.attributes.position,p=t.indirect?e=>{let n=t.resolveTriangleIndex(e);Rd(u,n*3,d,f)}:e=>{Rd(u,e*3,d,f)};if(a){if(!(t instanceof e))throw Error(`MeshBVH: "intersectsTriangles" callback can only be used with another MeshBVH.`);let r=(e,t,r,i,s,c,d,f)=>{for(let m=r,h=r+i;m<h;m++){p(m),u.a.applyMatrix4(n),u.b.applyMatrix4(n),u.c.applyMatrix4(n),u.needsUpdate=!0;for(let n=e,r=e+t;n<r;n++)if(l(n),o.needsUpdate=!0,a(o,u,n,m,s,c,d,f))return!0}return!1};if(i){let e=i;i=function(t,n,i,a,o,s,c,l){return e(t,n,i,a,o,s,c,l)?!0:r(t,n,i,a,o,s,c,l)}}else i=r}return super.bvhcast(t,n,{intersectsRanges:i})}intersectsBox(e,t){return Rf.set(e.min,e.max,t),Rf.needsUpdate=!0,this.shapecast({intersectsBounds:e=>Rf.intersectsBox(e),intersectsTriangle:e=>Rf.intersectsTriangle(e)})}intersectsSphere(e){return this.shapecast({intersectsBounds:t=>e.intersectsBox(t),intersectsTriangle:t=>t.intersectsSphere(e)})}closestPointToGeometry(e,t,n={},r={},i=0,a=1/0){return(this.indirect?If:mf)(this,e,t,n,r,i,a)}closestPointToPoint(e,t={},n=0,r=1/0){return Sd(this,e,t,n,r)}},Gf=1e-6,Kf=Gf*.5,qf=10**-Math.log10(Gf),Jf=Kf*qf;function Yf(e){return~~(e*qf+Jf)}function Xf(e){return`${Yf(e.x)},${Yf(e.y)}`}function Zf(e){return`${Yf(e.x)},${Yf(e.y)},${Yf(e.z)}`}function Qf(e){return`${Yf(e.x)},${Yf(e.y)},${Yf(e.z)},${Yf(e.w)}`}function $f(e,t,n){n.direction.subVectors(t,e).normalize();let r=e.dot(n.direction);return n.origin.copy(e).addScaledVector(n.direction,-r),n}function ep(){return typeof SharedArrayBuffer<`u`}function tp(e){if(e.buffer instanceof SharedArrayBuffer)return e;let t=e.constructor,n=e.buffer,r=new SharedArrayBuffer(n.byteLength),i=new Uint8Array(n);return new Uint8Array(r).set(i,0),new t(r)}function np(e){return e.index?e.index.count:e.attributes.position.count}function rp(e){return np(e)/3}var ip=1e-8,ap=new K;function op(e){return~~(e/3)}function sp(e){return e%3}function cp(e,t){return e.start-t.start}function lp(e,t){return ap.subVectors(t,e.origin).dot(e.direction)}function up(e,t,n,r=ip){e.sort(cp),t.sort(cp);for(let r=0;r<e.length;r++){let i=e[r];for(let s=0;s<t.length;s++){let c=t[s];if(!(c.start>i.end)){if(i.end<c.start||c.end<i.start)continue;if(i.start<=c.start&&i.end>=c.end)a(c.end,i.end)||e.splice(r+1,0,{start:c.end,end:i.end,index:i.index}),i.end=c.start,c.start=0,c.end=0;else if(i.start>=c.start&&i.end<=c.end)a(i.end,c.end)||t.splice(s+1,0,{start:i.end,end:c.end,index:c.index}),c.end=i.start,i.start=0,i.end=0;else if(i.start<=c.start&&i.end<=c.end){let e=i.end;i.end=c.start,c.start=e}else if(i.start>=c.start&&i.end>=c.end){let e=c.end;c.end=i.start,i.start=e}else throw Error()}if(n.has(i.index)||n.set(i.index,[]),n.has(c.index)||n.set(c.index,[]),n.get(i.index).push(c.index),n.get(c.index).push(i.index),o(c)&&(t.splice(s,1),s--),o(i)){e.splice(r,1),r--;break}}}i(e),i(t);function i(e){for(let t=0;t<e.length;t++)o(e[t])&&(e.splice(t,1),t--)}function a(e,t){return Math.abs(t-e)<r}function o(e){return Math.abs(e.end-e.start)<r}}var dp=1e-5,fp=1e-4,pp=class{constructor(){this._rays=[]}addRay(e){this._rays.push(e)}findClosestRay(e){let t=this._rays,n=e.clone();n.direction.multiplyScalar(-1);let r=1/0,i=null;for(let s=0,c=t.length;s<c;s++){let c=t[s];if(a(c,e)&&a(c,n))continue;let l=o(c,e),u=o(c,n),d=Math.min(l,u);d<r&&(r=d,i=c)}return i;function a(e,t){let n=e.origin.distanceTo(t.origin)>dp;return e.direction.angleTo(t.direction)>fp||n}function o(e,t){let n=e.origin.distanceTo(t.origin),r=e.direction.angleTo(t.direction);return n/dp+r/fp}}},mp=new K,hp=new K,gp=new Ne;function _p(e,t,n){let r=e.attributes,i=e.index,a=r.position,o=new Map,s=new Map,c=Array.from(t),l=new pp;for(let e=0,t=c.length;e<t;e++){let t=c[e],n=op(t),r=sp(t),o=3*n+r,u=3*n+(r+1)%3;i&&(o=i.getX(o),u=i.getX(u)),mp.fromBufferAttribute(a,o),hp.fromBufferAttribute(a,u),$f(mp,hp,gp);let d,f=l.findClosestRay(gp);f===null&&(f=gp.clone(),l.addRay(f)),s.has(f)||s.set(f,{forward:[],reverse:[],ray:f}),d=s.get(f);let p=lp(f,mp),m=lp(f,hp);p>m&&([p,m]=[m,p]),gp.direction.dot(f.direction)<0?d.reverse.push({start:p,end:m,index:t}):d.forward.push({start:p,end:m,index:t})}return s.forEach(({forward:e,reverse:t},r)=>{up(e,t,o,n),e.length===0&&t.length===0&&s.delete(r)}),{disjointConnectivityMap:o,fragmentMap:s}}var vp=new Er,yp=new K,bp=new xi,xp=[``,``,``],Sp=class{constructor(){this.data=null,this.disjointConnections=null,this.unmatchedDisjointEdges=null,this.unmatchedEdges=-1,this.matchedEdges=-1,this.useDrawRange=!0,this.useAllAttributes=!1,this.matchDisjointEdges=!1,this.degenerateEpsilon=1e-8}getSiblingTriangleIndex(e,t){let n=this.data[e*3+t];return n===-1?-1:~~(n/3)}getSiblingEdgeIndex(e,t){let n=this.data[e*3+t];return n===-1?-1:n%3}getDisjointSiblingTriangleIndices(e,t){let n=e*3+t,r=this.disjointConnections.get(n);return r?r.map(e=>~~(e/3)):[]}getDisjointSiblingEdgeIndices(e,t){let n=e*3+t,r=this.disjointConnections.get(n);return r?r.map(e=>e%3):[]}isFullyConnected(){return this.unmatchedEdges===0}updateFrom(e){let{useAllAttributes:t,useDrawRange:n,matchDisjointEdges:r,degenerateEpsilon:i}=this,a=t?v:_,o=new Map,{attributes:s}=e,c=t?Object.keys(s):null,l=e.index,u=s.position,d=rp(e),f=d,p=0;n&&(p=e.drawRange.start,e.drawRange.count!==1/0&&(d=~~(e.drawRange.count/3)));let m=this.data;(!m||m.length<3*f)&&(m=new Int32Array(3*f)),m.fill(-1);let h=0,g=new Set;for(let e=p,t=d*3+p;e<t;e+=3){let t=e;for(let e=0;e<3;e++){let n=t+e;l&&(n=l.getX(n)),xp[e]=a(n)}for(let e=0;e<3;e++){let n=(e+1)%3,r=xp[e],i=xp[n],a=`${i}_${r}`;if(o.has(a)){let n=t+e,r=o.get(a);m[n]=r,m[r]=n,o.delete(a),h+=2,g.delete(r)}else{let n=`${r}_${i}`,a=t+e;o.set(n,a),g.add(a)}}}if(r){let{fragmentMap:t,disjointConnectivityMap:n}=_p(e,g,i);g.clear(),t.forEach(({forward:e,reverse:t})=>{e.forEach(({index:e})=>g.add(e)),t.forEach(({index:e})=>g.add(e))}),this.unmatchedDisjointEdges=t,this.disjointConnections=n,h=d*3-g.size}this.matchedEdges=h,this.unmatchedEdges=g.size,this.data=m;function _(e){return yp.fromBufferAttribute(u,e),Zf(yp)}function v(e){let t=``;for(let n=0,r=c.length;n<r;n++){let r=s[c[n]],i;switch(r.itemSize){case 1:i=Yf(r.getX(e));break;case 2:i=Xf(vp.fromBufferAttribute(r,e));break;case 3:i=Zf(yp.fromBufferAttribute(r,e));break;case 4:i=Qf(bp.fromBufferAttribute(r,e));break}t!==``&&(t+=`|`),t+=i}return t}}},Cp=class extends G{constructor(...e){super(...e),this.isBrush=!0,this._previousMatrix=new Pr,this._previousMatrix.elements.fill(0),this._halfEdges=null,this._boundsTree=null,this._groupIndices=null,this._hash=null}markUpdated(){this._previousMatrix.copy(this.matrix)}isDirty(){let{matrix:e,_previousMatrix:t}=this,n=e.elements,r=t.elements;for(let e=0;e<16;e++)if(n[e]!==r[e])return!0;return!1}prepareGeometry(){let e=this.geometry,t=e.attributes,n=ep(),r=e.index,i=e.attributes.position,a=r?`${r.uuid}_${r.count}_${r.version}`:`-1_-1_-1`,o=`${i.uuid}_${i.count}_${i.version}`,s=`${e.uuid}_${a}_${o}`;if(this._hash===s)return;if(this._hash=s,n)for(let e in t){let n=t[e];if(n.isInterleavedBufferAttribute)throw Error(`Brush: InterleavedBufferAttributes are not supported.`);n.array=tp(n.array)}e.boundsTree=new Wf(e,{maxLeafSize:3,indirect:!0,useSharedArrayBuffer:n}),e.halfEdges||=new Sp,e.halfEdges.updateFrom(e);let c=rp(e);(!e.groupIndices||e.groupIndices.length!==c)&&(e.groupIndices=new Uint16Array(c));let l=e.groupIndices,u=e.groups;for(let e=0,t=u.length;e<t;e++){let{start:t,count:n}=u[e];for(let r=t/3,i=(t+n)/3;r<i;r++)l[r]=e}}disposeCacheData(){let{geometry:e}=this;e.halfEdges=null,e.boundsTree=null,e.groupIndices=null}},wp=Object.getOwnPropertyNames,Tp=(e,t)=>function(){return t||(0,e[wp(e)[0]])((t={exports:{}}).exports,t),t.exports},Ep=Tp({"node_modules/binary-search-bounds/search-bounds.js"(e,t){function n(e,t,n,r,i){for(var a=i+1;r<=i;){var o=r+i>>>1,s=e[o];(n===void 0?s-t:n(s,t))>=0?(a=o,i=o-1):r=o+1}return a}function r(e,t,n,r,i){for(var a=i+1;r<=i;){var o=r+i>>>1,s=e[o];(n===void 0?s-t:n(s,t))>0?(a=o,i=o-1):r=o+1}return a}function i(e,t,n,r,i){for(var a=r-1;r<=i;){var o=r+i>>>1,s=e[o];(n===void 0?s-t:n(s,t))<0?(a=o,r=o+1):i=o-1}return a}function a(e,t,n,r,i){for(var a=r-1;r<=i;){var o=r+i>>>1,s=e[o];(n===void 0?s-t:n(s,t))<=0?(a=o,r=o+1):i=o-1}return a}function o(e,t,n,r,i){for(;r<=i;){var a=r+i>>>1,o=e[a],s=n===void 0?o-t:n(o,t);if(s===0)return a;s<=0?r=a+1:i=a-1}return-1}function s(e,t,n,r,i,a){return typeof n==`function`?a(e,t,n,r===void 0?0:r|0,i===void 0?e.length-1:i|0):a(e,t,void 0,n===void 0?0:n|0,r===void 0?e.length-1:r|0)}t.exports={ge:function(e,t,r,i,a){return s(e,t,r,i,a,n)},gt:function(e,t,n,i,a){return s(e,t,n,i,a,r)},lt:function(e,t,n,r,a){return s(e,t,n,r,a,i)},le:function(e,t,n,r,i){return s(e,t,n,r,i,a)},eq:function(e,t,n,r,i){return s(e,t,n,r,i,o)}}}}),Dp=Tp({"node_modules/two-product/two-product.js"(e,t){t.exports=r;var n=+(2**27+1);function r(e,t,r){var i=e*t,a=n*e,o=a-(a-e),s=e-o,c=n*t,l=c-(c-t),u=t-l,d=i-o*l-s*l-o*u,f=s*u-d;return r?(r[0]=f,r[1]=i,r):[f,i]}}}),Op=Tp({"node_modules/robust-sum/robust-sum.js"(e,t){t.exports=r;function n(e,t){var n=e+t,r=n-e,i=n-r,a=t-r,o=e-i+a;return o?[o,n]:[n]}function r(e,t){var r=e.length|0,i=t.length|0;if(r===1&&i===1)return n(e[0],t[0]);var a=r+i,o=Array(a),s=0,c=0,l=0,u=Math.abs,d=e[c],f=u(d),p=t[l],m=u(p),h,g;f<m?(g=d,c+=1,c<r&&(d=e[c],f=u(d))):(g=p,l+=1,l<i&&(p=t[l],m=u(p))),c<r&&f<m||l>=i?(h=d,c+=1,c<r&&(d=e[c],f=u(d))):(h=p,l+=1,l<i&&(p=t[l],m=u(p)));for(var _=h+g,v=_-h,y=g-v,b=y,x=_,S,C,w,T,E;c<r&&l<i;)f<m?(h=d,c+=1,c<r&&(d=e[c],f=u(d))):(h=p,l+=1,l<i&&(p=t[l],m=u(p))),g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S;for(;c<r;)h=d,g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S,c+=1,c<r&&(d=e[c]);for(;l<i;)h=p,g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S,l+=1,l<i&&(p=t[l]);return b&&(o[s++]=b),x&&(o[s++]=x),s||(o[s++]=0),o.length=s,o}}}),kp=Tp({"node_modules/two-sum/two-sum.js"(e,t){t.exports=n;function n(e,t,n){var r=e+t,i=r-e,a=r-i,o=t-i,s=e-a;return n?(n[0]=s+o,n[1]=r,n):[s+o,r]}}}),Ap=Tp({"node_modules/robust-scale/robust-scale.js"(e,t){var n=Dp(),r=kp();t.exports=i;function i(e,t){var i=e.length;if(i===1){var a=n(e[0],t);return a[0]?a:[a[1]]}var o=Array(2*i),s=[.1,.1],c=[.1,.1],l=0;n(e[0],t,s),s[0]&&(o[l++]=s[0]);for(var u=1;u<i;++u){n(e[u],t,c);var d=s[1];r(d,c[0],s),s[0]&&(o[l++]=s[0]);var f=c[1],p=s[1],m=f+p,h=p-(m-f);s[1]=m,h&&(o[l++]=h)}return s[1]&&(o[l++]=s[1]),l===0&&(o[l++]=0),o.length=l,o}}}),jp=Tp({"node_modules/robust-subtract/robust-diff.js"(e,t){t.exports=r;function n(e,t){var n=e+t,r=n-e,i=n-r,a=t-r,o=e-i+a;return o?[o,n]:[n]}function r(e,t){var r=e.length|0,i=t.length|0;if(r===1&&i===1)return n(e[0],-t[0]);var a=r+i,o=Array(a),s=0,c=0,l=0,u=Math.abs,d=e[c],f=u(d),p=-t[l],m=u(p),h,g;f<m?(g=d,c+=1,c<r&&(d=e[c],f=u(d))):(g=p,l+=1,l<i&&(p=-t[l],m=u(p))),c<r&&f<m||l>=i?(h=d,c+=1,c<r&&(d=e[c],f=u(d))):(h=p,l+=1,l<i&&(p=-t[l],m=u(p)));for(var _=h+g,v=_-h,y=g-v,b=y,x=_,S,C,w,T,E;c<r&&l<i;)f<m?(h=d,c+=1,c<r&&(d=e[c],f=u(d))):(h=p,l+=1,l<i&&(p=-t[l],m=u(p))),g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S;for(;c<r;)h=d,g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S,c+=1,c<r&&(d=e[c]);for(;l<i;)h=p,g=b,_=h+g,v=_-h,y=g-v,y&&(o[s++]=y),S=x+_,C=S-x,w=S-C,T=_-C,E=x-w,b=E+T,x=S,l+=1,l<i&&(p=-t[l]);return b&&(o[s++]=b),x&&(o[s++]=x),s||(o[s++]=0),o.length=s,o}}}),Mp=Tp({"node_modules/robust-orientation/orientation.js"(e,t){var n=Dp(),r=Op(),i=Ap(),a=jp(),o=5,s=11102230246251565e-32,c=(3+16*s)*s,l=(7+56*s)*s;function u(e,t,n,r){return function(n,i,a){var o=r(e(e(t(i[1],a[0]),t(-a[1],i[0])),e(t(n[1],i[0]),t(-i[1],n[0]))),e(t(n[1],a[0]),t(-a[1],n[0])));return o[o.length-1]}}function d(e,t,n,r){return function(i,a,o,s){var c=r(e(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),a[2]),e(n(e(t(a[1],s[0]),t(-s[1],a[0])),-o[2]),n(e(t(a[1],o[0]),t(-o[1],a[0])),s[2]))),e(n(e(t(a[1],s[0]),t(-s[1],a[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),s[2])))),e(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-o[2]),n(e(t(i[1],o[0]),t(-o[1],i[0])),s[2]))),e(n(e(t(a[1],o[0]),t(-o[1],a[0])),i[2]),e(n(e(t(i[1],o[0]),t(-o[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),o[2])))));return c[c.length-1]}}function f(e,t,n,r){return function(i,a,o,s,c){var l=r(e(e(e(n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),o[2]),e(n(e(t(o[1],c[0]),t(-c[1],o[0])),-s[2]),n(e(t(o[1],s[0]),t(-s[1],o[0])),c[2]))),a[3]),e(n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),a[2]),e(n(e(t(a[1],c[0]),t(-c[1],a[0])),-s[2]),n(e(t(a[1],s[0]),t(-s[1],a[0])),c[2]))),-o[3]),n(e(n(e(t(o[1],c[0]),t(-c[1],o[0])),a[2]),e(n(e(t(a[1],c[0]),t(-c[1],a[0])),-o[2]),n(e(t(a[1],o[0]),t(-o[1],a[0])),c[2]))),s[3]))),e(n(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),a[2]),e(n(e(t(a[1],s[0]),t(-s[1],a[0])),-o[2]),n(e(t(a[1],o[0]),t(-o[1],a[0])),s[2]))),-c[3]),e(n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),a[2]),e(n(e(t(a[1],c[0]),t(-c[1],a[0])),-s[2]),n(e(t(a[1],s[0]),t(-s[1],a[0])),c[2]))),i[3]),n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-s[2]),n(e(t(i[1],s[0]),t(-s[1],i[0])),c[2]))),-a[3])))),e(e(n(e(n(e(t(a[1],c[0]),t(-c[1],a[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),c[2]))),s[3]),e(n(e(n(e(t(a[1],s[0]),t(-s[1],a[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),s[2]))),-c[3]),n(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),a[2]),e(n(e(t(a[1],s[0]),t(-s[1],a[0])),-o[2]),n(e(t(a[1],o[0]),t(-o[1],a[0])),s[2]))),i[3]))),e(n(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-o[2]),n(e(t(i[1],o[0]),t(-o[1],i[0])),s[2]))),-a[3]),e(n(e(n(e(t(a[1],s[0]),t(-s[1],a[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),s[2]))),o[3]),n(e(n(e(t(a[1],o[0]),t(-o[1],a[0])),i[2]),e(n(e(t(i[1],o[0]),t(-o[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),o[2]))),-s[3]))))),e(e(e(n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),o[2]),e(n(e(t(o[1],c[0]),t(-c[1],o[0])),-s[2]),n(e(t(o[1],s[0]),t(-s[1],o[0])),c[2]))),i[3]),n(e(n(e(t(s[1],c[0]),t(-c[1],s[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-s[2]),n(e(t(i[1],s[0]),t(-s[1],i[0])),c[2]))),-o[3])),e(n(e(n(e(t(o[1],c[0]),t(-c[1],o[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-o[2]),n(e(t(i[1],o[0]),t(-o[1],i[0])),c[2]))),s[3]),n(e(n(e(t(o[1],s[0]),t(-s[1],o[0])),i[2]),e(n(e(t(i[1],s[0]),t(-s[1],i[0])),-o[2]),n(e(t(i[1],o[0]),t(-o[1],i[0])),s[2]))),-c[3]))),e(e(n(e(n(e(t(o[1],c[0]),t(-c[1],o[0])),a[2]),e(n(e(t(a[1],c[0]),t(-c[1],a[0])),-o[2]),n(e(t(a[1],o[0]),t(-o[1],a[0])),c[2]))),i[3]),n(e(n(e(t(o[1],c[0]),t(-c[1],o[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-o[2]),n(e(t(i[1],o[0]),t(-o[1],i[0])),c[2]))),-a[3])),e(n(e(n(e(t(a[1],c[0]),t(-c[1],a[0])),i[2]),e(n(e(t(i[1],c[0]),t(-c[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),c[2]))),o[3]),n(e(n(e(t(a[1],o[0]),t(-o[1],a[0])),i[2]),e(n(e(t(i[1],o[0]),t(-o[1],i[0])),-a[2]),n(e(t(i[1],a[0]),t(-a[1],i[0])),o[2]))),-c[3])))));return l[l.length-1]}}function p(e){return(e===3?u:e===4?d:f)(r,n,i,a)}var m=p(3),h=p(4),g=[function(){return 0},function(){return 0},function(e,t){return t[0]-e[0]},function(e,t,n){var r=(e[1]-n[1])*(t[0]-n[0]),i=(e[0]-n[0])*(t[1]-n[1]),a=r-i,o;if(r>0){if(i<=0)return a;o=r+i}else if(r<0){if(i>=0)return a;o=-(r+i)}else return a;var s=c*o;return a>=s||a<=-s?a:m(e,t,n)},function(e,t,n,r){var i=e[0]-r[0],a=t[0]-r[0],o=n[0]-r[0],s=e[1]-r[1],c=t[1]-r[1],u=n[1]-r[1],d=e[2]-r[2],f=t[2]-r[2],p=n[2]-r[2],m=a*u,g=o*c,_=o*s,v=i*u,y=i*c,b=a*s,x=d*(m-g)+f*(_-v)+p*(y-b),S=l*((Math.abs(m)+Math.abs(g))*Math.abs(d)+(Math.abs(_)+Math.abs(v))*Math.abs(f)+(Math.abs(y)+Math.abs(b))*Math.abs(p));return x>S||-x>S?x:h(e,t,n,r)}];function _(e){var t=g[e.length];return t||=g[e.length]=p(e.length),t.apply(void 0,e)}function v(e,t,n,r,i,a,o){return function(t,n,s,c,l){switch(arguments.length){case 0:case 1:return 0;case 2:return r(t,n);case 3:return i(t,n,s);case 4:return a(t,n,s,c);case 5:return o(t,n,s,c,l)}for(var u=Array(arguments.length),d=0;d<arguments.length;++d)u[d]=arguments[d];return e(u)}}function y(){for(;g.length<=o;)g.push(p(g.length));t.exports=v.apply(void 0,[_].concat(g));for(var e=0;e<=o;++e)t.exports[e]=g[e]}y()}}),Np=Tp({"node_modules/cdt2d/lib/monotone.js"(e,t){var n=Ep(),r=Mp()[3],i=0,a=1,o=2;t.exports=h;function s(e,t,n,r,i){this.a=e,this.b=t,this.idx=n,this.lowerIds=r,this.upperIds=i}function c(e,t,n,r){this.a=e,this.b=t,this.type=n,this.idx=r}function l(e,t){var n=e.a[0]-t.a[0]||e.a[1]-t.a[1]||e.type-t.type;return n||e.type!==i&&(n=r(e.a,e.b,t.b),n)?n:e.idx-t.idx}function u(e,t){return r(e.a,e.b,t)}function d(e,t,i,a,o){for(var s=n.lt(t,a,u),c=n.gt(t,a,u),l=s;l<c;++l){for(var d=t[l],f=d.lowerIds,p=f.length;p>1&&r(i[f[p-2]],i[f[p-1]],a)>0;)e.push([f[p-1],f[p-2],o]),--p;f.length=p,f.push(o);for(var m=d.upperIds,p=m.length;p>1&&r(i[m[p-2]],i[m[p-1]],a)<0;)e.push([m[p-2],m[p-1],o]),--p;m.length=p,m.push(o)}}function f(e,t){var n=e.a[0]<t.a[0]?r(e.a,e.b,t.a):r(t.b,t.a,e.a);return n||(n=t.b[0]<e.b[0]?r(e.a,e.b,t.b):r(t.b,t.a,e.b),n||e.idx-t.idx)}function p(e,t,r){var i=n.le(e,r,f),a=e[i],o=a.upperIds,c=o[o.length-1];a.upperIds=[c],e.splice(i+1,0,new s(r.a,r.b,r.idx,[c],o))}function m(e,t,r){var i=r.a;r.a=r.b,r.b=i;var a=n.eq(e,r,f),o=e[a],s=e[a-1];s.upperIds=o.upperIds,e.splice(a,1)}function h(e,t){for(var n=e.length,r=t.length,u=[],f=0;f<n;++f)u.push(new c(e[f],null,i,f));for(var f=0;f<r;++f){var h=t[f],g=e[h[0]],_=e[h[1]];g[0]<_[0]?u.push(new c(g,_,o,f),new c(_,g,a,f)):g[0]>_[0]&&u.push(new c(_,g,o,f),new c(g,_,a,f))}u.sort(l);for(var v=u[0].a[0]-(1+Math.abs(u[0].a[0]))*2**-52,y=[new s([v,1],[v,0],-1,[],[],[],[])],b=[],f=0,x=u.length;f<x;++f){var S=u[f],C=S.type;C===i?d(b,y,e,S.a,S.idx):C===o?p(y,e,S):m(y,e,S)}return b}}}),Pp=Tp({"node_modules/cdt2d/lib/triangulation.js"(e,t){var n=Ep();t.exports=o;function r(e,t){this.stars=e,this.edges=t}var i=r.prototype;function a(e,t,n){for(var r=1,i=e.length;r<i;r+=2)if(e[r-1]===t&&e[r]===n){e[r-1]=e[i-2],e[r]=e[i-1],e.length=i-2;return}}i.isConstraint=(function(){var e=[0,0];function t(e,t){return e[0]-t[0]||e[1]-t[1]}return function(r,i){return e[0]=Math.min(r,i),e[1]=Math.max(r,i),n.eq(this.edges,e,t)>=0}})(),i.removeTriangle=function(e,t,n){var r=this.stars;a(r[e],t,n),a(r[t],n,e),a(r[n],e,t)},i.addTriangle=function(e,t,n){var r=this.stars;r[e].push(t,n),r[t].push(n,e),r[n].push(e,t)},i.opposite=function(e,t){for(var n=this.stars[t],r=1,i=n.length;r<i;r+=2)if(n[r]===e)return n[r-1];return-1},i.flip=function(e,t){var n=this.opposite(e,t),r=this.opposite(t,e);this.removeTriangle(e,t,n),this.removeTriangle(t,e,r),this.addTriangle(e,r,n),this.addTriangle(t,n,r)},i.edges=function(){for(var e=this.stars,t=[],n=0,r=e.length;n<r;++n)for(var i=e[n],a=0,o=i.length;a<o;a+=2)t.push([i[a],i[a+1]]);return t},i.cells=function(){for(var e=this.stars,t=[],n=0,r=e.length;n<r;++n)for(var i=e[n],a=0,o=i.length;a<o;a+=2){var s=i[a],c=i[a+1];n<Math.min(s,c)&&t.push([n,s,c])}return t};function o(e,t){for(var n=Array(e),i=0;i<e;++i)n[i]=[];return new r(n,t)}}}),Fp=Tp({"node_modules/robust-in-sphere/in-sphere.js"(e,t){var n=Dp(),r=Op(),i=jp(),a=Ap(),o=6;function s(e){return(e===3?d:e===4?f:e===5?p:m)(r,i,n,a)}function c(){return 0}function l(){return 0}function u(){return 0}function d(e,t,n,r){function i(i,a,o){var s=n(i[0],i[0]),c=r(s,a[0]),l=r(s,o[0]),u=n(a[0],a[0]),d=r(u,i[0]),f=r(u,o[0]),p=n(o[0],o[0]),m=r(p,i[0]),h=t(e(t(r(p,a[0]),f),t(d,c)),t(m,l));return h[h.length-1]}return i}function f(e,t,n,r){function i(i,a,o,s){var c=e(n(i[0],i[0]),n(i[1],i[1])),l=r(c,a[0]),u=r(c,o[0]),d=r(c,s[0]),f=e(n(a[0],a[0]),n(a[1],a[1])),p=r(f,i[0]),m=r(f,o[0]),h=r(f,s[0]),g=e(n(o[0],o[0]),n(o[1],o[1])),_=r(g,i[0]),v=r(g,a[0]),y=r(g,s[0]),b=e(n(s[0],s[0]),n(s[1],s[1])),x=r(b,i[0]),S=r(b,a[0]),C=r(b,o[0]),w=t(e(e(r(t(C,y),a[1]),e(r(t(S,h),-o[1]),r(t(v,m),s[1]))),e(r(t(S,h),i[1]),e(r(t(x,d),-a[1]),r(t(p,l),s[1])))),e(e(r(t(C,y),i[1]),e(r(t(x,d),-o[1]),r(t(_,u),s[1]))),e(r(t(v,m),i[1]),e(r(t(_,u),-a[1]),r(t(p,l),o[1])))));return w[w.length-1]}return i}function p(e,t,n,r){function i(i,a,o,s,c){var l=e(n(i[0],i[0]),e(n(i[1],i[1]),n(i[2],i[2]))),u=r(l,a[0]),d=r(l,o[0]),f=r(l,s[0]),p=r(l,c[0]),m=e(n(a[0],a[0]),e(n(a[1],a[1]),n(a[2],a[2]))),h=r(m,i[0]),g=r(m,o[0]),_=r(m,s[0]),v=r(m,c[0]),y=e(n(o[0],o[0]),e(n(o[1],o[1]),n(o[2],o[2]))),b=r(y,i[0]),x=r(y,a[0]),S=r(y,s[0]),C=r(y,c[0]),w=e(n(s[0],s[0]),e(n(s[1],s[1]),n(s[2],s[2]))),T=r(w,i[0]),E=r(w,a[0]),D=r(w,o[0]),O=r(w,c[0]),k=e(n(c[0],c[0]),e(n(c[1],c[1]),n(c[2],c[2]))),A=r(k,i[0]),j=r(k,a[0]),M=r(k,o[0]),N=r(k,s[0]),P=t(e(e(e(r(e(r(t(N,O),o[1]),e(r(t(M,C),-s[1]),r(t(D,S),c[1]))),a[2]),e(r(e(r(t(N,O),a[1]),e(r(t(j,v),-s[1]),r(t(E,_),c[1]))),-o[2]),r(e(r(t(M,C),a[1]),e(r(t(j,v),-o[1]),r(t(x,g),c[1]))),s[2]))),e(r(e(r(t(D,S),a[1]),e(r(t(E,_),-o[1]),r(t(x,g),s[1]))),-c[2]),e(r(e(r(t(N,O),a[1]),e(r(t(j,v),-s[1]),r(t(E,_),c[1]))),i[2]),r(e(r(t(N,O),i[1]),e(r(t(A,p),-s[1]),r(t(T,f),c[1]))),-a[2])))),e(e(r(e(r(t(j,v),i[1]),e(r(t(A,p),-a[1]),r(t(h,u),c[1]))),s[2]),e(r(e(r(t(E,_),i[1]),e(r(t(T,f),-a[1]),r(t(h,u),s[1]))),-c[2]),r(e(r(t(D,S),a[1]),e(r(t(E,_),-o[1]),r(t(x,g),s[1]))),i[2]))),e(r(e(r(t(D,S),i[1]),e(r(t(T,f),-o[1]),r(t(b,d),s[1]))),-a[2]),e(r(e(r(t(E,_),i[1]),e(r(t(T,f),-a[1]),r(t(h,u),s[1]))),o[2]),r(e(r(t(x,g),i[1]),e(r(t(b,d),-a[1]),r(t(h,u),o[1]))),-s[2]))))),e(e(e(r(e(r(t(N,O),o[1]),e(r(t(M,C),-s[1]),r(t(D,S),c[1]))),i[2]),r(e(r(t(N,O),i[1]),e(r(t(A,p),-s[1]),r(t(T,f),c[1]))),-o[2])),e(r(e(r(t(M,C),i[1]),e(r(t(A,p),-o[1]),r(t(b,d),c[1]))),s[2]),r(e(r(t(D,S),i[1]),e(r(t(T,f),-o[1]),r(t(b,d),s[1]))),-c[2]))),e(e(r(e(r(t(M,C),a[1]),e(r(t(j,v),-o[1]),r(t(x,g),c[1]))),i[2]),r(e(r(t(M,C),i[1]),e(r(t(A,p),-o[1]),r(t(b,d),c[1]))),-a[2])),e(r(e(r(t(j,v),i[1]),e(r(t(A,p),-a[1]),r(t(h,u),c[1]))),o[2]),r(e(r(t(x,g),i[1]),e(r(t(b,d),-a[1]),r(t(h,u),o[1]))),-c[2])))));return P[P.length-1]}return i}function m(e,t,n,r){function i(i,a,o,s,c,l){var u=e(e(n(i[0],i[0]),n(i[1],i[1])),e(n(i[2],i[2]),n(i[3],i[3]))),d=r(u,a[0]),f=r(u,o[0]),p=r(u,s[0]),m=r(u,c[0]),h=r(u,l[0]),g=e(e(n(a[0],a[0]),n(a[1],a[1])),e(n(a[2],a[2]),n(a[3],a[3]))),_=r(g,i[0]),v=r(g,o[0]),y=r(g,s[0]),b=r(g,c[0]),x=r(g,l[0]),S=e(e(n(o[0],o[0]),n(o[1],o[1])),e(n(o[2],o[2]),n(o[3],o[3]))),C=r(S,i[0]),w=r(S,a[0]),T=r(S,s[0]),E=r(S,c[0]),D=r(S,l[0]),O=e(e(n(s[0],s[0]),n(s[1],s[1])),e(n(s[2],s[2]),n(s[3],s[3]))),k=r(O,i[0]),A=r(O,a[0]),j=r(O,o[0]),M=r(O,c[0]),N=r(O,l[0]),P=e(e(n(c[0],c[0]),n(c[1],c[1])),e(n(c[2],c[2]),n(c[3],c[3]))),F=r(P,i[0]),I=r(P,a[0]),L=r(P,o[0]),ee=r(P,s[0]),te=r(P,l[0]),ne=e(e(n(l[0],l[0]),n(l[1],l[1])),e(n(l[2],l[2]),n(l[3],l[3]))),R=r(ne,i[0]),z=r(ne,a[0]),B=r(ne,o[0]),V=r(ne,s[0]),re=r(ne,c[0]),ie=t(e(e(e(r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),o[2]),r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),-s[2])),e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),c[2]),r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),-l[2]))),a[3]),e(r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),a[2]),r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),-s[2])),e(r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),c[2]),r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),-l[2]))),-o[3]),r(e(e(r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),a[2]),r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),-o[2])),e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),c[2]),r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),-l[2]))),s[3]))),e(e(r(e(e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),a[2]),r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),-o[2])),e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),s[2]),r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),-l[2]))),-c[3]),r(e(e(r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),a[2]),r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),-o[2])),e(r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),s[2]),r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),-c[2]))),l[3])),e(r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),a[2]),r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),-s[2])),e(r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),c[2]),r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),-l[2]))),i[3]),r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-s[2])),e(r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),c[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-l[2]))),-a[3])))),e(e(e(r(e(e(r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),c[2]),r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),-l[2]))),s[3]),r(e(e(r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),i[2]),r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),s[2]),r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),-l[2]))),-c[3])),e(r(e(e(r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),i[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-a[2])),e(r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),s[2]),r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),-c[2]))),l[3]),r(e(e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),a[2]),r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),-o[2])),e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),s[2]),r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),-l[2]))),i[3]))),e(e(r(e(e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),i[2]),r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),-o[2])),e(r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),s[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-l[2]))),-a[3]),r(e(e(r(e(r(t(V,N),a[1]),e(r(t(z,x),-s[1]),r(t(A,y),l[1]))),i[2]),r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),s[2]),r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),-l[2]))),o[3])),e(r(e(e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),i[2]),r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-l[2]))),-s[3]),r(e(e(r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),i[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-a[2])),e(r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-s[2]))),l[3]))))),e(e(e(r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),o[2]),r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),-s[2])),e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),c[2]),r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),-l[2]))),i[3]),e(r(e(e(r(e(r(t(re,te),s[1]),e(r(t(V,N),-c[1]),r(t(ee,M),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-s[2])),e(r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),c[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-l[2]))),-o[3]),r(e(e(r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-o[2])),e(r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),c[2]),r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),-l[2]))),s[3]))),e(e(r(e(e(r(e(r(t(V,N),o[1]),e(r(t(B,D),-s[1]),r(t(j,T),l[1]))),i[2]),r(e(r(t(V,N),i[1]),e(r(t(R,h),-s[1]),r(t(k,p),l[1]))),-o[2])),e(r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),s[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-l[2]))),-c[3]),r(e(e(r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),i[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-o[2])),e(r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),s[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-c[2]))),l[3])),e(r(e(e(r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),a[2]),r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),-o[2])),e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),c[2]),r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),-l[2]))),i[3]),r(e(e(r(e(r(t(re,te),o[1]),e(r(t(B,D),-c[1]),r(t(L,E),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-o[2])),e(r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),c[2]),r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),-l[2]))),-a[3])))),e(e(e(r(e(e(r(e(r(t(re,te),a[1]),e(r(t(z,x),-c[1]),r(t(I,b),l[1]))),i[2]),r(e(r(t(re,te),i[1]),e(r(t(R,h),-c[1]),r(t(F,m),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),c[2]),r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),-l[2]))),o[3]),r(e(e(r(e(r(t(B,D),a[1]),e(r(t(z,x),-o[1]),r(t(w,v),l[1]))),i[2]),r(e(r(t(B,D),i[1]),e(r(t(R,h),-o[1]),r(t(C,f),l[1]))),-a[2])),e(r(e(r(t(z,x),i[1]),e(r(t(R,h),-a[1]),r(t(_,d),l[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-l[2]))),-c[3])),e(r(e(e(r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),i[2]),r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),-a[2])),e(r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-c[2]))),l[3]),r(e(e(r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),a[2]),r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),-o[2])),e(r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),s[2]),r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),-c[2]))),i[3]))),e(e(r(e(e(r(e(r(t(ee,M),o[1]),e(r(t(L,E),-s[1]),r(t(j,T),c[1]))),i[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-o[2])),e(r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),s[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-c[2]))),-a[3]),r(e(e(r(e(r(t(ee,M),a[1]),e(r(t(I,b),-s[1]),r(t(A,y),c[1]))),i[2]),r(e(r(t(ee,M),i[1]),e(r(t(F,m),-s[1]),r(t(k,p),c[1]))),-a[2])),e(r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),s[2]),r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),-c[2]))),o[3])),e(r(e(e(r(e(r(t(L,E),a[1]),e(r(t(I,b),-o[1]),r(t(w,v),c[1]))),i[2]),r(e(r(t(L,E),i[1]),e(r(t(F,m),-o[1]),r(t(C,f),c[1]))),-a[2])),e(r(e(r(t(I,b),i[1]),e(r(t(F,m),-a[1]),r(t(_,d),c[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-c[2]))),-s[3]),r(e(e(r(e(r(t(j,T),a[1]),e(r(t(A,y),-o[1]),r(t(w,v),s[1]))),i[2]),r(e(r(t(j,T),i[1]),e(r(t(k,p),-o[1]),r(t(C,f),s[1]))),-a[2])),e(r(e(r(t(A,y),i[1]),e(r(t(k,p),-a[1]),r(t(_,d),s[1]))),o[2]),r(e(r(t(w,v),i[1]),e(r(t(C,f),-a[1]),r(t(_,d),o[1]))),-s[2]))),c[3]))))));return ie[ie.length-1]}return i}var h=[c,l,u];function g(e){var t=h[e.length];return t||=h[e.length]=s(e.length),t.apply(void 0,e)}function _(e,t,n,r,i,a,o,s){function c(t,n,c,l,u,d){switch(arguments.length){case 0:case 1:return 0;case 2:return r(t,n);case 3:return i(t,n,c);case 4:return a(t,n,c,l);case 5:return o(t,n,c,l,u);case 6:return s(t,n,c,l,u,d)}for(var f=Array(arguments.length),p=0;p<arguments.length;++p)f[p]=arguments[p];return e(f)}return c}function v(){for(;h.length<=o;)h.push(s(h.length));t.exports=_.apply(void 0,[g].concat(h));for(var e=0;e<=o;++e)t.exports[e]=h[e]}v()}}),Ip=Tp({"node_modules/cdt2d/lib/delaunay.js"(e,t){var n=Fp()[4];Ep(),t.exports=i;function r(e,t,r,i,a,o){var s=t.opposite(i,a);if(!(s<0)){if(a<i){var c=i;i=a,a=c,c=o,o=s,s=c}t.isConstraint(i,a)||n(e[i],e[a],e[o],e[s])<0&&r.push(i,a)}}function i(e,t){for(var i=[],a=e.length,o=t.stars,s=0;s<a;++s)for(var c=o[s],l=1;l<c.length;l+=2){var u=c[l];if(!(u<s)&&!t.isConstraint(s,u)){for(var d=c[l-1],f=-1,p=1;p<c.length;p+=2)if(c[p-1]===u){f=c[p];break}f<0||n(e[s],e[u],e[d],e[f])<0&&i.push(s,u)}}for(;i.length>0;){for(var u=i.pop(),s=i.pop(),d=-1,f=-1,c=o[s],m=1;m<c.length;m+=2){var h=c[m-1],g=c[m];h===u?f=g:g===u&&(d=h)}d<0||f<0||n(e[s],e[u],e[d],e[f])>=0||(t.flip(s,u),r(e,t,i,d,s,f),r(e,t,i,s,f,d),r(e,t,i,f,u,d),r(e,t,i,u,d,f))}}}}),Lp=Tp({"node_modules/cdt2d/lib/filter.js"(e,t){var n=Ep();t.exports=c;function r(e,t,n,r,i,a,o){this.cells=e,this.neighbor=t,this.flags=r,this.constraint=n,this.active=i,this.next=a,this.boundary=o}var i=r.prototype;function a(e,t){return e[0]-t[0]||e[1]-t[1]||e[2]-t[2]}i.locate=(function(){var e=[0,0,0];return function(t,r,i){var o=t,s=r,c=i;return r<i?r<t&&(o=r,s=i,c=t):i<t&&(o=i,s=t,c=r),o<0?-1:(e[0]=o,e[1]=s,e[2]=c,n.eq(this.cells,e,a))}})();function o(e,t){for(var n=e.cells(),i=n.length,o=0;o<i;++o){var s=n[o],c=s[0],l=s[1],u=s[2];l<u?l<c&&(s[0]=l,s[1]=u,s[2]=c):u<c&&(s[0]=u,s[1]=c,s[2]=l)}n.sort(a);for(var d=Array(i),o=0;o<d.length;++o)d[o]=0;var f=[],p=[],m=Array(3*i),h=Array(3*i),g=null;t&&(g=[]);for(var _=new r(n,m,h,d,f,p,g),o=0;o<i;++o)for(var s=n[o],v=0;v<3;++v){var c=s[v],l=s[(v+1)%3],y=m[3*o+v]=_.locate(l,c,e.opposite(l,c)),b=h[3*o+v]=e.isConstraint(c,l);y<0&&(b?p.push(o):(f.push(o),d[o]=1),t&&g.push([l,c,-1]))}return _}function s(e,t,n){for(var r=0,i=0;i<e.length;++i)t[i]===n&&(e[r++]=e[i]);return e.length=r,e}function c(e,t,n){var r=o(e,n);if(t===0)return n?r.cells.concat(r.boundary):r.cells;for(var i=1,a=r.active,c=r.next,l=r.flags,u=r.cells,d=r.constraint,f=r.neighbor;a.length>0||c.length>0;){for(;a.length>0;){var p=a.pop();if(l[p]!==-i){l[p]=i,u[p];for(var m=0;m<3;++m){var h=f[3*p+m];h>=0&&l[h]===0&&(d[3*p+m]?c.push(h):(a.push(h),l[h]=i))}}}var g=c;c=a,a=g,c.length=0,i=-i}var _=s(u,l,t);return n?_.concat(r.boundary):_}}}),Rp=Tp({"node_modules/cdt2d/cdt2d.js"(e,t){var n=Np(),r=Pp(),i=Ip(),a=Lp();t.exports=u;function o(e){return[Math.min(e[0],e[1]),Math.max(e[0],e[1])]}function s(e,t){return e[0]-t[0]||e[1]-t[1]}function c(e){return e.map(o).sort(s)}function l(e,t,n){return t in e?e[t]:n}function u(e,t,o){Array.isArray(t)?(o||={},t||=[]):(o=t||{},t=[]);var s=!!l(o,`delaunay`,!0),u=!!l(o,`interior`,!0),d=!!l(o,`exterior`,!0),f=!!l(o,`infinity`,!1);if(!u&&!d||e.length===0)return[];var p=n(e,t);if(s||u!==d||f){for(var m=r(e.length,c(t)),h=0;h<p.length;++h){var g=p[h];m.addTriangle(g[0],g[1],g[2])}return s&&i(e,m),d?u?f?a(m,0,f):m.cells():a(m,1,f):a(m,-1)}else return p}}})(),zp=class{constructor(e){this.createFn=e,this._pool=[],this._index=0}getInstance(){return this._index>=this._pool.length&&this._pool.push(this.createFn()),this._pool[this._index++]}clear(){this._index=0}reset(){this._pool.length=0,this._index=0}},Bp=1e-16,Vp=1e-16,Hp=new K,Up=new K,Wp=new zp(()=>({param:0,index:0})),Gp=new zp(()=>new K);function Kp(e,t,n,r){Wp.clear(),t.length=0,n.length=0;for(let t=0,n=e.length;t<n;t++){let n=e[t];c(n.start),c(n.end)}for(let t=0,n=e.length;t<n;t++){let i=e[t];for(let a=t+1;a<n;a++){let t=e[a];i.distanceSqToLine3(t,Hp,Up)<Bp*r&&c(Up)}}let i=[];for(let a=0,o=e.length;a<o;a++){i.length=0;let o=e[a];for(let e=0,n=t.length;e<n;e++){let n=t[e],a=o.closestPointToPointParameter(n,!0);if(o.at(a,Hp),n.distanceToSquared(Hp)<Bp*r){let t=Wp.getInstance();t.param=a,t.index=e,i.push(t)}}i.sort(s);for(let e=0,t=i.length-1;e<t;e++){let t=i[e].index,r=i[e+1].index;t!==r&&n.push([t,r])}}let a=new Set,o=0;for(let e=0,t=n.length;e<t;e++){let t=n[e],r=Math.min(t[0],t[1]),i=Math.max(t[0],t[1]),s=r+`,`+i;a.has(s)||(a.add(s),n[o++]=t)}n.length=o;function s(e,t){return e.param-t.param}function c(e){for(let n=0;n<t.length;n++){let i=t[n];if(e===i||e.distanceToSquared(i)<Vp*r)return n}return t.push(Gp.getInstance().copy(e)),t.length-1}}var qp=class{constructor(){this.trianglePool=new zp(()=>new _d),this.linePool=new zp(()=>new en),this.triangles=[],this.triangleIndices=[],this.constrainedEdges=[],this.triangleConnectivity=[],this.normal=new K,this.projOrigin=new K,this.projU=new K,this.projV=new K,this.baseTri=new _d,this.baseIndices=[,,,]}initialize(e,t=null,n=null,r=null){this.reset();let{normal:i,baseTri:a,projU:o,projV:s,projOrigin:c,constrainedEdges:l,linePool:u,baseIndices:d}=this;e.getNormal(i),a.copy(e),a.update(),d[0]=t,d[1]=n,d[2]=r,l.length=0;let f=u.getInstance();f.start.copy(a.a),f.end.copy(a.b);let p=u.getInstance();p.start.copy(a.b),p.end.copy(a.c);let m=u.getInstance();m.start.copy(a.c),m.end.copy(a.a),l.push(f,p,m),c.copy(a.a),o.subVectors(a.b,a.a).normalize(),s.crossVectors(i,o).normalize()}addConstraintEdge(e){let{constrainedEdges:t,linePool:n}=this,r=n.getInstance().copy(e);t.push(r)}_to2D(e,t){let{projOrigin:n,projU:r,projV:i}=this;return Hp.subVectors(e,n),t.set(Hp.dot(r),Hp.dot(i),0)}_from2D(e,t,n){let{projOrigin:r,projU:i,projV:a}=this;return n.copy(r).addScaledVector(i,e).addScaledVector(a,t),n}triangulate(){let{triangles:e,trianglePool:t,triangleConnectivity:n,triangleIndices:r,linePool:i,baseTri:a,constrainedEdges:o,baseIndices:s}=this;e.length=0,t.clear();let c=[];for(let e=0,t=o.length;e<t;e++){let t=o[e],n=i.getInstance();this._to2D(t.start,n.start),this._to2D(t.end,n.end),c.push(n)}let l=0;for(let e=0;e<3;e++){let t=this._to2D(a.points[e],Hp);l=Math.max(l,Math.abs(t.x),Math.abs(t.y))}let u=[],d=[];Kp(c,u,d,l);let f=[];for(let e=0,t=u.length;e<t;e++){let t=u[e];f.push([t.x,t.y])}let p=Rp(f,d,{exterior:!1}),m=new Map;for(let e=0,t=d.length;e<t;e++){let t=d[e];m.set(`${t[0]}_${t[1]}`,-1),m.set(`${t[1]}_${t[0]}`,-1)}let h=`${s[0]}_${s[1]}_${s[2]}_`;for(let i=0,a=p.length;i<a;i++){let a=p[i],[o,c,l]=a,u=t.getInstance();this._from2D(f[o][0],f[o][1],u.a),this._from2D(f[c][0],f[c][1],u.b),this._from2D(f[l][0],f[l][1],u.c),e.push(u);let d=[];n.push(d);let g=[];r.push(g);for(let e=0;e<3;e++){let t=a[e];g.push(t<3?s[t]:h+t);let r=a[(e+1)%3],o=`${t}_${r}`;if(m.has(o)){let e=m.get(o);e!==-1&&(d.push(e),n[e].push(i))}else{let e=`${r}_${t}`;m.set(e,i)}}}}reset(){this.trianglePool.clear(),this.linePool.clear(),this.triangles.length=0,this.triangleIndices.length=0,this.triangleConnectivity.length=0,this.constrainedEdges.length=0}},Jp=1e-14,Yp=new K,Xp=new K,Zp=new K;function Qp(e,t=Jp){Yp.subVectors(e.b,e.a),Xp.subVectors(e.c,e.a),Zp.subVectors(e.b,e.c);let n=Yp.angleTo(Xp),r=Yp.angleTo(Zp),i=Math.PI-n-r;return Math.abs(n)<t||Math.abs(r)<t||Math.abs(i)<t||e.a.distanceToSquared(e.b)<t||e.a.distanceToSquared(e.c)<t||e.b.distanceToSquared(e.c)<t}var $p=1e-10,em=1e-10,tm=new en,nm=new en,rm=new K,im=new K,am=new K,om=new Se,sm=new _d,cm=class{constructor(){this.trianglePool=new zp(()=>new Tn),this.triangles=[],this.normal=new K}initialize(e){this.reset();let{triangles:t,trianglePool:n,normal:r}=this;if(Array.isArray(e))for(let i=0,a=e.length;i<a;i++){let a=e[i];if(i===0)a.getNormal(r);else if(Math.abs(1-a.getNormal(rm).dot(r))>$p)throw Error(`Triangle Splitter: Cannot initialize with triangles that have different normals.`);let o=n.getInstance();o.copy(a),t.push(o)}else{e.getNormal(r);let i=n.getInstance();i.copy(e),t.push(i)}}splitByTriangle(e,t){let{triangles:n}=this;if(t){for(let e=0,t=n.length;e<t;e++){let t=n[e];t.coplanarCount=0}let t=[e.a,e.b,e.c];for(let n=0;n<3;n++){let r=(n+1)%3,i=t[n],a=t[r];e.getNormal(im).normalize(),rm.subVectors(a,i).normalize(),am.crossVectors(im,rm),om.setFromNormalAndCoplanarPoint(am,i),this.splitByPlane(om,e)}}else e.getPlane(om),this.splitByPlane(om,e)}splitByPlane(e,t){let{triangles:n,trianglePool:r}=this;sm.copy(t),sm.needsUpdate=!0;for(let t=0,i=n.length;t<i;t++){let a=n[t];if(!sm.intersectsTriangle(a,tm,!0))continue;let{a:o,b:s,c}=a,l=0,u=-1,d=!1,f=[],p=[],m=[o,s,c];for(let t=0;t<3;t++){let n=(t+1)%3;tm.start.copy(m[t]),tm.end.copy(m[n]);let r=e.distanceToPoint(tm.start),i=e.distanceToPoint(tm.end);if(Math.abs(r)<em&&Math.abs(i)<em){d=!0;break}if(r>0?f.push(t):p.push(t),Math.abs(r)<em)continue;let a=!!e.intersectLine(tm,rm);!a&&Math.abs(i)<em&&(rm.copy(tm.end),a=!0),a&&!(rm.distanceTo(tm.start)<$p)&&(rm.distanceTo(tm.end)<$p&&(u=t),l===0?nm.start.copy(rm):nm.end.copy(rm),l++)}if(!d&&l===2&&nm.distance()>em)if(u!==-1){u=(u+1)%3;let e=0;e===u&&(e=(e+1)%3);let o=e+1;o===u&&(o=(o+1)%3);let s=r.getInstance();s.a.copy(m[o]),s.b.copy(nm.end),s.c.copy(nm.start),Qp(s)||n.push(s),a.a.copy(m[e]),a.b.copy(nm.start),a.c.copy(nm.end),Qp(a)&&(n.splice(t,1),t--,i--)}else{let e=f.length>=2?p[0]:f[0];if(e===0){let e=nm.start;nm.start=nm.end,nm.end=e}let o=(e+1)%3,s=(e+2)%3,c=r.getInstance(),l=r.getInstance();m[o].distanceToSquared(nm.start)<m[s].distanceToSquared(nm.end)?(c.a.copy(m[o]),c.b.copy(nm.start),c.c.copy(nm.end),l.a.copy(m[o]),l.b.copy(m[s]),l.c.copy(nm.start)):(c.a.copy(m[s]),c.b.copy(nm.start),c.c.copy(nm.end),l.a.copy(m[o]),l.b.copy(m[s]),l.c.copy(nm.end)),a.a.copy(m[e]),a.b.copy(nm.end),a.c.copy(nm.start),Qp(c)||n.push(c),Qp(l)||n.push(l),Qp(a)&&(n.splice(t,1),t--,i--)}else l===3&&console.warn(`TriangleClipper: Coplanar clip not handled`)}}reset(){this.triangles.length=0,this.trianglePool.clear()}},lm=class{constructor(){this.coplanarSet=new Map,this.intersectionSet=new Map,this.edgeSet=new Map,this.ids=[]}add(e,t,n=!1){let{intersectionSet:r,coplanarSet:i,ids:a}=this;r.has(e)||(r.set(e,[]),a.push(e)),r.get(e).push(t),n&&(i.has(e)||i.set(e,new Set),i.get(e).add(t))}addIntersectionEdge(e,t){let{edgeSet:n}=this;n.has(e)||n.set(e,new Set),n.get(e).add(t)}getIntersectionEdges(e){return this.edgeSet.get(e)||null}},um=1e-10,dm=1e-15,fm=1e-10,pm=1e-10,mm=new en,hm=new en,gm=new K,_m=new K,vm=new K,ym=new Se,bm=new K,xm=new K;function Sm(e,t){e.getNormal(bm),t.getNormal(xm);let n=bm.dot(xm);if(Math.abs(1-Math.abs(n))>=fm)return!1;let r=bm.dot(e.a),i=bm.dot(t.a);return Math.abs(r-i)<pm}function Cm(e,t,n,r){let i=0,a=1;e.delta(gm);let o=[t.a,t.b,t.c];for(let t=0;t<3;t++){let r=o[t],s=o[(t+1)%3];_m.subVectors(s,r),vm.crossVectors(n,_m),ym.setFromNormalAndCoplanarPoint(vm,r);let c=ym.distanceToPoint(e.start),l=ym.normal.dot(gm);if(Math.abs(l)<dm){if(c<-1e-10)return null;continue}let u=-c/l;if(l>0?i=Math.max(i,u):a=Math.min(a,u),i>a+um)return null}return a-i<um?null:(e.at(i,r.start),e.at(a,r.end),r)}function wm(e,t,n){let r=0;e.getNormal(bm),t.getNormal(xm);let i=[t.a,t.b,t.c];for(let t=0;t<3;t++){hm.start.copy(i[t]),hm.end.copy(i[(t+1)%3]);let a=Cm(hm,e,bm,mm);a!==null&&(r>=n.length&&n.push(new en),n[r].copy(a),r++)}let a=[e.a,e.b,e.c];for(let e=0;e<3;e++){hm.start.copy(a[e]),hm.end.copy(a[(e+1)%3]);let i=Cm(hm,t,xm,mm);i!==null&&(r>=n.length&&n.push(new en),n[r].copy(i),r++)}return r}var Tm=new Ne,Em=new Pr,Dm=new en,Om=[],km=new zp(()=>new en),Am=null;function jm(e){Am=e}function Mm(e,t,n=null){e.getMidpoint(Tm.origin),e.getNormal(Tm.direction),n&&(Tm.origin.applyMatrix4(n),Tm.direction.transformDirection(n));let r=t.raycastFirst(Tm,2);return r&&Tm.direction.dot(r.face.normal)>0?-1:1}function Nm(e,t){let n=new lm,r=new lm;return km.clear(),Em.copy(e.matrixWorld).invert().multiply(t.matrixWorld),e.geometry.boundsTree.bvhcast(t.geometry.boundsTree,Em,{intersectsTriangles(i,a,o,s){if(!Qp(i)&&!Qp(a)){let c=(Sm(i,a)?wm(i,a,Om):0)>2;if(c||i.intersectsTriangle(a,Dm,!0)){let l=e.geometry.boundsTree.resolveTriangleIndex(o),u=t.geometry.boundsTree.resolveTriangleIndex(s);if(n.add(l,u,c),r.add(u,l,c),c){let e=wm(i,a,Om);for(let t=0;t<e;t++){let e=km.getInstance().copy(Om[t]);n.addIntersectionEdge(l,e),r.addIntersectionEdge(u,e)}}else{let e=km.getInstance().copy(Dm),t=km.getInstance().copy(Dm);n.addIntersectionEdge(l,e),r.addIntersectionEdge(u,t)}Am&&(Am.addEdge(Dm),Am.addIntersectingTriangles(o,i,s,a))}}return!1}}),{aIntersections:n,bIntersections:r}}function Pm(e,t,n=!1){switch(e){case 0:if(t===1||t===2&&!n)return 1;break;case 1:if(n){if(t===-1)return 0}else if(t===1||t===-2)return 1;break;case 2:if(n){if(t===1||t===-2)return 1}else if(t===-1)return 0;break;case 4:if(t===-1)return 0;if(t===1)return 1;break;case 3:if(t===-1||t===2&&!n)return 1;break;case 5:if(!n&&(t===1||t===-2))return 1;break;case 6:if(!n&&(t===-1||t===2))return 1;break;default:throw Error(`Unrecognized CSG operation enum "${e}".`)}return 2}var Fm=class{constructor(e){this.triangle=new Tn().copy(e),this.intersects={}}addTriangle(e,t){this.intersects[e]=new Tn().copy(t)}getIntersectArray(){let e=[],{intersects:t}=this;for(let n in t)e.push(t[n]);return e}},Im=class{constructor(){this.data={}}addTriangleIntersection(e,t,n,r){let{data:i}=this;i[e]||(i[e]=new Fm(t)),i[e].addTriangle(n,r)}getTrianglesAsArray(e=null){let{data:t}=this,n=[];if(e!==null)e in t&&n.push(t[e].triangle);else for(let e in t)n.push(t[e].triangle);return n}getTriangleIndices(){return Object.keys(this.data).map(e=>parseInt(e))}getIntersectionIndices(e){let{data:t}=this;return t[e]?Object.keys(t[e].intersects).map(e=>parseInt(e)):[]}getIntersectionsAsArray(e=null,t=null){let{data:n}=this,r=new Set,i=[],a=e=>{if(n[e])if(t!==null)n[e].intersects[t]&&i.push(n[e].intersects[t]);else{let t=n[e].intersects;for(let e in t)r.has(e)||(r.add(e),i.push(t[e]))}};if(e!==null)a(e);else for(let e in n)a(e);return i}reset(){this.data={}}},Lm=class{constructor(){this.enabled=!1,this.triangleIntersectsA=new Im,this.triangleIntersectsB=new Im,this.intersectionEdges=[]}addIntersectingTriangles(e,t,n,r){let{triangleIntersectsA:i,triangleIntersectsB:a}=this;i.addTriangleIntersection(e,t,n,r),a.addTriangleIntersection(n,r,e,t)}addEdge(e){this.intersectionEdges.push(e.clone())}reset(){this.triangleIntersectsA.reset(),this.triangleIntersectsB.reset(),this.intersectionEdges=[]}init(){this.enabled&&(this.reset(),jm(this))}complete(){this.enabled&&jm(null)}},Rm=new Pr,zm=new Pr,Bm=new Pr,Vm=new Vr,Hm=new Tn,Um=new Tn,Wm=new Tn,Gm=new Tn,Km=[],qm=[],Jm=new Set,Ym=new K,Xm=new K,Zm=new zp(()=>new Tn),Qm=new K,$m=[];function eh(e,t,n,r,i,a={}){let{useGroups:o=!0}=a,{aIntersections:s,bIntersections:c}=Nm(e,t),l=[],u;return u=o?0:-1,nh(e,t,s,n,!1,i,u),th(e,t,s,n,!1,r,i,u),n.findIndex(e=>e!==6&&e!==5)!==-1&&(i.forEach(e=>e.clearIndexMap()),u=o?e.geometry.groups.length||1:-1,nh(t,e,c,n,!0,i,u),th(t,e,c,n,!0,r,i,u)),i.forEach(e=>e.clearIndexMap()),Km.length=0,{groups:l,materials:null}}function th(e,t,n,r,i,a,o,s=0){Rm.copy(t.matrixWorld).invert().multiply(e.matrixWorld),zm.copy(Rm).invert(),i?Bm.copy(Rm):Bm.identity();let c=Bm.determinant()<0;Vm.getNormalMatrix(Bm).multiplyScalar(c?-1:1);let l=e.geometry.groupIndices,u=e.geometry.index,d=e.geometry.attributes.position,f=t.geometry.boundsTree,p=t.geometry.index,m=t.geometry.attributes.position,h=n.ids;for(let t=0,g=h.length;t<g;t++){let g=h[t],_=s===-1?0:l[g]+s,v=3*g,y=v+0,b=v+1,x=v+2;u&&(y=u.getX(y),b=u.getX(b),x=u.getX(x)),Hm.a.fromBufferAttribute(d,y),Hm.b.fromBufferAttribute(d,b),Hm.c.fromBufferAttribute(d,x),i&&(Hm.a.applyMatrix4(Rm),Hm.b.applyMatrix4(Rm),Hm.c.applyMatrix4(Rm)),a.reset(),a.initialize(Hm,y,b,x),$m.length=0,Zm.clear(),Hm.getNormal(Xm);let S=n.coplanarSet.get(g);if(S)for(let e of S){let t=3*e,n=t+0,r=t+1,a=t+2;p&&(n=p.getX(n),r=p.getX(r),a=p.getX(a));let o=Zm.getInstance();o.a.fromBufferAttribute(m,n),o.b.fromBufferAttribute(m,r),o.c.fromBufferAttribute(m,a),i||(o.a.applyMatrix4(zm),o.b.applyMatrix4(zm),o.c.applyMatrix4(zm)),$m.push(o)}if(a.addConstraintEdge){let e=n.getIntersectionEdges(g);if(e)for(let t of e)a.addConstraintEdge(t);a.triangulate()}else{let e=n.intersectionSet.get(g);for(let t=0,n=e.length;t<n;t++){let n=e[t],r=S&&S.has(n),o=3*n,s=o+0,c=o+1,l=o+2;p&&(s=p.getX(s),c=p.getX(c),l=p.getX(l)),Um.a.fromBufferAttribute(m,s),Um.b.fromBufferAttribute(m,c),Um.c.fromBufferAttribute(m,l),i||(Um.a.applyMatrix4(zm),Um.b.applyMatrix4(zm),Um.c.applyMatrix4(zm)),a.splitByTriangle(Um,r)}}let{triangles:C,triangleIndices:w=[],triangleConnectivity:T=[]}=a;for(let t=0,n=o.length;t<n;t++)o[t].initInterpolatedAttributeData(e.geometry,Bm,Vm,y,b,x);Jm.clear();for(let e=0,t=C.length;e<t;e++){if(Jm.has(e))continue;let t=C[e],n=i?null:Rm,a=null;t.getMidpoint(Ym);for(let e=0,t=$m.length;e<t;e++){let t=$m[e];if(t.containsPoint(Ym)){t.getNormal(Qm),a=Xm.dot(Qm)>0?2:-2;break}}a===null&&(a=Mm(t,f,n)),Km.length=0,qm.length=0;for(let e=0,t=r.length;e<t;e++){let t=Pm(r[e],a,i);t!==2&&(Km.push(t),qm.push(o[e]))}if(qm.length!==0){let t=[e];for(;t.length>0;){let e=t.pop();if(Jm.has(e))continue;Jm.add(e);let n=w[e],r=null,i=null,a=null;n&&(r=n[0],i=n[1],a=n[2]);let o=C[e];Hm.getBarycoord(o.a,Gm.a),Hm.getBarycoord(o.b,Gm.b),Hm.getBarycoord(o.c,Gm.c);for(let e=0,t=qm.length;e<t;e++){let t=qm[e],n=c!==(Km[e]===0);t.appendInterpolatedAttributeData(_,Gm.a,r,n),n?(t.appendInterpolatedAttributeData(_,Gm.c,a,n),t.appendInterpolatedAttributeData(_,Gm.b,i,n)):(t.appendInterpolatedAttributeData(_,Gm.b,i,n),t.appendInterpolatedAttributeData(_,Gm.c,a,n))}}}}}return h.length}function nh(e,t,n,r,i,a,o=0){Rm.copy(t.matrixWorld).invert().multiply(e.matrixWorld),i?Bm.copy(Rm):Bm.identity();let s=Bm.determinant()<0;Vm.getNormalMatrix(Bm).multiplyScalar(s?-1:1);let c=t.geometry.boundsTree,l=e.geometry.groupIndices,u=e.geometry.index,d=e.geometry.attributes.position,f=[],p=e.geometry.halfEdges,m=new Set(n.ids),h=rp(e.geometry);for(let t=0;t<h&&m.size!==h;t++){if(m.has(t))continue;m.add(t),f.push(t);let n=3*t,h=n+0,g=n+1,_=n+2;u&&(h=u.getX(h),g=u.getX(g),_=u.getX(_)),Wm.a.fromBufferAttribute(d,h),Wm.b.fromBufferAttribute(d,g),Wm.c.fromBufferAttribute(d,_),i&&(Wm.a.applyMatrix4(Rm),Wm.b.applyMatrix4(Rm),Wm.c.applyMatrix4(Rm));let v=Mm(Wm,c,i?null:Rm);Km.length=0,qm.length=0;for(let e=0,t=r.length;e<t;e++){let t=Pm(r[e],v,i);t!==2&&(Km.push(t),qm.push(a[e]))}for(;f.length>0;){let t=f.pop();for(let e=0;e<3;e++){let n=p.getSiblingTriangleIndex(t,e);n!==-1&&!m.has(n)&&(f.push(n),m.add(n))}if(qm.length!==0){let n=3*t,r=n+0,i=n+1,a=n+2;u&&(r=u.getX(r),i=u.getX(i),a=u.getX(a));let c=o===-1?0:l[t]+o;if(Wm.a.fromBufferAttribute(d,r),Wm.b.fromBufferAttribute(d,i),Wm.c.fromBufferAttribute(d,a),!Qp(Wm))for(let t=0,n=qm.length;t<n;t++){let n=qm[t],o=Km[t]===0!==s;n.appendIndexFromGeometry(e.geometry,Bm,Vm,c,r,o),o?(n.appendIndexFromGeometry(e.geometry,Bm,Vm,c,a,o),n.appendIndexFromGeometry(e.geometry,Bm,Vm,c,i,o)):(n.appendIndexFromGeometry(e.geometry,Bm,Vm,c,i,o),n.appendIndexFromGeometry(e.geometry,Bm,Vm,c,a,o))}}}}}function rh(e){return e=~~e,e+4-e%4}var ih=class{constructor(e,t=500){this.expansionFactor=1.5,this.type=e,this.length=0,this.array=null,this.setSize(t)}setType(e){if(e===this.type)return;if(this.length!==0)throw Error(`TypeBackedArray: Cannot change the type while there is used data in the buffer.`);let t=this.array.buffer;this.array=new e(t),this.type=e}setSize(e){if(this.array&&e===this.array.length)return;let t=this.type,n=new t(new(ep()?SharedArrayBuffer:ArrayBuffer)(rh(e*t.BYTES_PER_ELEMENT)));this.array&&n.set(this.array,0),this.array=n}expand(){let{array:e,expansionFactor:t}=this;this.setSize(e.length*t)}push(...e){let{array:t,length:n}=this;n+e.length>t.length&&(this.expand(),t=this.array);for(let r=0,i=e.length;r<i;r++)t[n+r]=e[r];this.length+=e.length}clear(){this.length=0}},ah=new K,oh=new K,sh=new K,ch=new K,lh=new xi,uh=new xi,dh=new xi,fh=new xi;function ph(e,t,n,r,i,a=!1,o=!1){return i.set(0,0,0,0).addScaledVector(e,r.x).addScaledVector(t,r.y).addScaledVector(n,r.z),a&&i.normalize(),o&&i.multiplyScalar(-1),i}function mh(e,t,n){switch(t){case 1:n.push(e.x);break;case 2:n.push(e.x,e.y);break;case 3:n.push(e.x,e.y,e.z);break;case 4:n.push(e.x,e.y,e.z,e.w);break}}var hh=class extends ih{get count(){return this.length/this.itemSize}constructor(...e){super(...e),this.itemSize=1,this.normalized=!1}},gh=class{constructor(){this.attributeData={},this.groupIndices=[],this.forwardIndexMap=new Map,this.invertedIndexMap=new Map,this.interpolatedFields={}}initFromGeometry(e,t){this.clear();let{attributeData:n}=this,r=e.attributes;for(let e=0,i=t.length;e<i;e++){let i=t[e],a=r[i],o=a.array.constructor;n[i]||(n[i]=new hh(o)),n[i].setType(o),n[i].itemSize=a.itemSize,n[i].normalized=a.normalized}for(let e in n.attributes)t.includes(e)||n.delete(e)}initInterpolatedAttributeData(e,t,n,r,i,a){let{attributeData:o,interpolatedFields:s}=this,{attributes:c}=e;for(let e in o){let o=c[e];if(!o)throw Error(`CSG Operations: Attribute ${e} not available on geometry.`);let l,u,d;if(e===`position`?(l=oh.fromBufferAttribute(o,r).applyMatrix4(t),u=sh.fromBufferAttribute(o,i).applyMatrix4(t),d=ch.fromBufferAttribute(o,a).applyMatrix4(t)):e===`normal`?(l=oh.fromBufferAttribute(o,r).applyNormalMatrix(n),u=sh.fromBufferAttribute(o,i).applyNormalMatrix(n),d=ch.fromBufferAttribute(o,a).applyNormalMatrix(n)):e===`tangent`?(l=oh.fromBufferAttribute(o,r).transformDirection(t),u=sh.fromBufferAttribute(o,i).transformDirection(t),d=ch.fromBufferAttribute(o,a).transformDirection(t)):(l=uh.fromBufferAttribute(o,r),u=dh.fromBufferAttribute(o,i),d=fh.fromBufferAttribute(o,a)),!s[e])s[e]=[l.clone(),u.clone(),d.clone()];else{let t=s[e];t[0].copy(l),t[1].copy(u),t[2].copy(d)}}}appendInterpolatedAttributeData(e,t,n=null,r=!1){let{groupIndices:i,attributeData:a,interpolatedFields:o,forwardIndexMap:s,invertedIndexMap:c}=this;for(;i.length<=e;)i.push(new hh(Uint32Array));let l=r?c:s,u=i[e];if(n!==null&&l.has(n))u.push(l.get(n));else{l.set(n,a.position.count),u.push(a.position.count);for(let e in o){let n=a[e],i=e===`normal`||e===`tangent`,s=r&&i,c=n.itemSize,[l,u,d]=o[e];ph(l,u,d,t,lh,i,s),mh(lh,c,n)}}}appendIndexFromGeometry(e,t,n,r,i,a=!1){let{groupIndices:o,attributeData:s,forwardIndexMap:c,invertedIndexMap:l}=this;for(;o.length<=r;)o.push(new hh(Uint32Array));let u=a?l:c,d=o[r];if(i!==null&&u.has(i))d.push(u.get(i));else{u.set(i,s.position.count),d.push(s.position.count);let{attributes:r}=e;for(let e in s){let o=s[e],c=r[e];if(!c)throw Error(`CSG Operations: Attribute ${e} not available on geometry.`);let l=c.itemSize;e===`position`?(ah.fromBufferAttribute(c,i).applyMatrix4(t),o.push(ah.x,ah.y,ah.z)):e===`normal`?(ah.fromBufferAttribute(c,i).applyNormalMatrix(n),a&&ah.multiplyScalar(-1),o.push(ah.x,ah.y,ah.z)):e===`tangent`?(ah.fromBufferAttribute(c,i).transformDirection(t),a&&ah.multiplyScalar(-1),o.push(ah.x,ah.y,ah.z)):(lh.fromBufferAttribute(c,i),mh(lh,l,o))}}}buildGeometry(e,t){let n=!1,{groupIndices:r,attributeData:i}=this,{attributes:a,index:o}=e;for(let t in i){let r=i[t],{type:o,itemSize:s,normalized:c,length:l,count:u}=r,d=r.array.buffer,f=a[t];(!f||f.count<u||f.array.type!==o)&&(f=new Zt(new o(l),s,c),e.setAttribute(t,f),n=!0),f.array.set(new o(d,0,l),0),f.needsUpdate=!0}let s=r.reduce((e,t)=>t.count+e,0);(!e.index||o.count<s||o.array.type!==Uint32Array)&&(e.setIndex(new Zt(new Uint32Array(s),1)),n=!0),e.clearGroups();let c=0;for(let n=0,i=Math.min(t.length,r.length);n<i;n++){let{index:i,materialIndex:a}=t[n],{count:o}=r[i],s=r[i].array.buffer;o!==0&&(e.index.array.set(new Uint32Array(s,0,o),c),e.addGroup(c,o,a),c+=o)}e.setDrawRange(0,c),e.boundsTree=null,e.boundingBox=null,e.boundingSphere=null,n&&e.dispose()}clearIndexMap(){this.forwardIndexMap.clear(),this.invertedIndexMap.clear()}clear(){let{groupIndices:e,attributeData:t}=this;this.interpolatedFields={};for(let e in t)t[e].clear();e.forEach(e=>{e.clear()}),this.clearIndexMap()}};function _h(e,t){for(let n in e.attributes)t.includes(n)||(e.deleteAttribute(n),e.dispose());return e}function vh(e,t){let n=[];for(let r=0,i=e.length;r<i;r++){let i=e[r],a=t[i.materialIndex];n.push({...i,materialIndex:t.indexOf(a)})}return n}function yh(e,t){let n=[],r=new Map;for(let i=0,a=e.length;i<a;i++){let a=e[i];r.has(a.materialIndex)||(r.set(a.materialIndex,n.length),n.push(t[a.materialIndex])),a.materialIndex=r.get(a.materialIndex)}return n}function bh(e){for(let t=0;t<e.length-1;t++){let n=e[t],r=e[t+1];if(n.materialIndex===r.materialIndex){let i=n.start,a=r.start+r.count;r.start=i,r.count=a-i,e.splice(t,1),t--}}}function xh(e,t){let n=t;return Array.isArray(t)||(n=[],e.forEach(e=>{n[e.materialIndex]=t})),n}var Sh=class{get useCDTClipping(){return this.triangleSplitter instanceof qp}set useCDTClipping(e){e!==this.useCDTClipping&&(this.triangleSplitter=e?new qp:new cm)}constructor(){this.triangleSplitter=new cm,this.geometryBuilders=[],this.attributes=[`position`,`uv`,`normal`],this.useGroups=!0,this.consolidateGroups=!0,this.removeUnusedMaterials=!0,this.debug=new Lm}getGroupRanges(e){return!this.useGroups||e.groups.length===0?[{start:0,count:1/0,materialIndex:0}]:e.groups.map(e=>({...e}))}evaluate(e,t,n,r=new Cp){let i=!0;if(Array.isArray(n)||(n=[n]),Array.isArray(r)||(r=[r],i=!1),r.length!==n.length)throw Error(`Evaluator: operations and target array passed as different sizes.`);e.prepareGeometry(),t.prepareGeometry();let{triangleSplitter:a,geometryBuilders:o,attributes:s,useGroups:c,consolidateGroups:l,removeUnusedMaterials:u,debug:d}=this;for(;o.length<r.length;)o.push(new gh);r.forEach((t,n)=>{o[n].initFromGeometry(e.geometry,s),_h(t.geometry,s)}),d.init(),eh(e,t,n,a,o,{useGroups:c}),d.complete();let f=this.getGroupRanges(e.geometry),p=xh(f,e.material),m=this.getGroupRanges(t.geometry),h=xh(m,t.material);m.forEach(e=>e.materialIndex+=p.length);let g=[...p,...h],_=[...f,...m].map((e,t)=>({...e,index:t}));return c?c&&l&&(_=vh(_,g),_.sort((e,t)=>e.materialIndex-t.materialIndex)):_=[{start:0,count:1/0,index:0,materialIndex:0}],r.forEach((t,n)=>{let r=t.geometry;o[n].buildGeometry(r,_),e.matrixWorld.decompose(t.position,t.quaternion,t.scale),t.updateMatrix(),t.matrixWorld.copy(e.matrixWorld),c?(t.material=g,l&&bh(r.groups),u&&(t.material=yh(r.groups,g))):t.material=g[0]}),i?r:r[0]}evaluateHierarchy(e,t=new Cp){e.updateMatrixWorld(!0);let n=(e,t)=>{let r=e.children;for(let e=0,i=r.length;e<i;e++){let i=r[e];i.isOperationGroup?n(i,t):t(i)}},r=e=>{let t=e.children,i=!1;for(let e=0,n=t.length;e<n;e++){let n=t[e];i=r(n)||i}let a=e.isDirty();if(a&&e.markUpdated(),i&&!e.isOperationGroup){let t;return n(e,n=>{t=t?this.evaluate(t,n,n.operation):this.evaluate(e,n,n.operation)}),e._cachedGeometry=t.geometry,e._cachedMaterials=t.material,!0}else return i||a};return r(e),t.geometry=e._cachedGeometry,t.material=e._cachedMaterials,t}reset(){this.triangleSplitter.reset()}};function Ch(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>{let e=new U(r);e.colorSpace=di,e.magFilter=ci,e.minFilter=ci,e.generateMipmaps=!1,e.flipY=!0,e.needsUpdate=!0,t(e)},r.onerror=()=>n(Error(`Bemalungstextur konnte nicht geladen werden.`)),r.src=e})}async function wh(e){let t=[...new Set(e.map(e=>e.material.paintTexture?.dataUrl).filter(e=>!!e))],n=await Promise.all(t.map(async e=>[e,await Ch(e)]));return new Map(n)}function Th(e,t){let n=e.material.paintTexture?.dataUrl,r=n?t.get(n)??null:null;return new ae({color:r?`#FFFFFF`:e.material.color,map:r,roughness:e.material.roughness,metalness:e.material.metalness,opacity:e.material.opacity,transparent:e.material.opacity<1||!!r,alphaTest:r?.001:0,flatShading:e.material.flatShading})}function Eh(e){return new Pr().compose(new K(...e.position),new Ei().setFromEuler(new _n(...e.rotation)),new K(...e.scale))}function Dh(e,t){let n=Ur(e),r=n;if(t&&n.index&&(r=n.toNonIndexed(),n.dispose()),r.applyMatrix4(Eh(e)),t){for(let e of Object.keys(r.attributes))e!==`position`&&e!==`normal`&&e!==`uv`&&r.deleteAttribute(e);if(r.getAttribute(`normal`)||r.computeVertexNormals(),!r.getAttribute(`uv`)){let e=r.getAttribute(`position`).count;r.setAttribute(`uv`,new Zt(new Float32Array(e*2),2))}let e=r.index?.count??r.getAttribute(`position`).count;r.clearGroups(),r.addGroup(0,e,0),r.setDrawRange(0,e)}return r.computeBoundingBox(),r.computeBoundingSphere(),r}function Oh(e){e.isMesh&&(e=e.geometry);let t=new Sp;return t.matchDisjointEdges=!0,t.updateFrom(e),t.unmatchedEdges===0}function kh(e){return Oh(e)}function Ah(e){let t=new Sp;return t.matchDisjointEdges=!0,t.updateFrom(e),t.unmatchedEdges}function jh(e){let t=e.index?.count??e.getAttribute(`position`).count,n=Math.max(0,Math.min(t,e.drawRange.start)),r=Number.isFinite(e.drawRange.count)?e.drawRange.count:t-n;return{start:n,count:Math.max(0,Math.min(t-n,r))}}function Mh(e){let t=jh(e),n=t.start+t.count,r=(e.groups.length>0?e.groups:[{start:t.start,count:t.count,materialIndex:0}]).map(e=>{let r=Math.max(e.start,t.start),i=Math.min(e.start+e.count,n);return{start:r,count:Math.max(0,i-r),materialIndex:e.materialIndex??0}}).filter(e=>e.count>0);if(r.length===0)return null;let i=e.clone();i.clearGroups(),r.forEach(e=>i.addGroup(e.start,e.count,e.materialIndex));let a=i.index?.count??i.getAttribute(`position`).count;return i.setDrawRange(0,a),i.getAttribute(`normal`)||i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function Nh(e){return Array.isArray(e.material)?e.material:[e.material]}function Ph(e){let t=e.getAttribute(`uv`);if(!t)return null;let n=1/0,r=-1/0;for(let e=0;e<t.count;e+=1)for(let i=0;i<2;i+=1){let a=i===0?t.getX(e):t.getY(e);if(!Number.isFinite(a))return null;n=Math.min(n,a),r=Math.max(r,a)}return{min:n,max:r}}function Fh(e,t){let n=Ph(e.geometry);if(!n)return!1;let r=1/0,i=-1/0;for(let e of t){let t=Ph(e.geometry);t&&(r=Math.min(r,t.min),i=Math.max(i,t.max))}if(!Number.isFinite(r))return!1;let a=.001;return n.min>=r-a&&n.max<=i+a}function Ih(e,t,n){let r=[],i=e=>(r.forEach(e=>e.geometry.dispose()),r.length=0,e),a=e.evaluate(t,n,0);if(a.updateMatrixWorld(!0),kh(a.geometry)&&Fh(a,[t,n]))return a;r.push(a),e.useCDTClipping=!0;try{for(let[a,o]of[[t,n],[n,t]]){let s=e.evaluate(a,o,0);if(s.updateMatrixWorld(!0),kh(s.geometry)&&Fh(s,[t,n]))return i(s);r.push(s)}}finally{e.useCDTClipping=!1}return r.sort((e,r)=>{let i=Ah(e.geometry)-Ah(r.geometry);return i===0?Number(Fh(r,[t,n]))-Number(Fh(e,[t,n])):i}),i(r[0])}function Lh(e,t,n){let r=new Sh;r.attributes=[`position`,`normal`,`uv`],r.useGroups=!0;let i=null;for(let a of e){let e=Dh(a,!0),o=Th(a,t),s=new Cp(e,o);if(s.name=a.name,s.updateMatrixWorld(!0),n?.geometries.add(e),n?.materials.add(o),!i){i=s;continue}let c=Ih(r,i,s);n&&(n.geometries.add(c.geometry),Nh(c).forEach(e=>n.materials.add(e))),i=c}if(!i)throw Error(`Es konnten keine Volumenkörper für die Union vorbereitet werden.`);return i}var Rh={POSITION:[`byte`,`byte normalized`,`unsigned byte`,`unsigned byte normalized`,`short`,`short normalized`,`unsigned short`,`unsigned short normalized`],NORMAL:[`byte normalized`,`short normalized`],TANGENT:[`byte normalized`,`short normalized`],TEXCOORD:[`byte`,`byte normalized`,`unsigned byte`,`short`,`short normalized`,`unsigned short`]},zh=class{constructor(){this.textureUtils=null,this.pluginCallbacks=[],this.register(function(e){return new og(e)}),this.register(function(e){return new sg(e)}),this.register(function(e){return new dg(e)}),this.register(function(e){return new fg(e)}),this.register(function(e){return new pg(e)}),this.register(function(e){return new mg(e)}),this.register(function(e){return new cg(e)}),this.register(function(e){return new lg(e)}),this.register(function(e){return new ug(e)}),this.register(function(e){return new hg(e)}),this.register(function(e){return new gg(e)}),this.register(function(e){return new _g(e)}),this.register(function(e){return new vg(e)}),this.register(function(e){return new yg(e)})}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}setTextureUtils(e){return this.textureUtils=e,this}parse(e,t,n,r){let i=new ag,a=[];for(let e=0,t=this.pluginCallbacks.length;e<t;e++)a.push(this.pluginCallbacks[e](i));i.setPlugins(a),i.setTextureUtils(this.textureUtils),i.writeAsync(e,t,r).catch(n)}parseAsync(e,t){let n=this;return new Promise(function(r,i){n.parse(e,r,i,t)})}},Bh={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,BYTE:5120,UNSIGNED_BYTE:5121,SHORT:5122,UNSIGNED_SHORT:5123,INT:5124,UNSIGNED_INT:5125,FLOAT:5126,ARRAY_BUFFER:34962,ELEMENT_ARRAY_BUFFER:34963,NEAREST:9728,LINEAR:9729,NEAREST_MIPMAP_NEAREST:9984,LINEAR_MIPMAP_NEAREST:9985,NEAREST_MIPMAP_LINEAR:9986,LINEAR_MIPMAP_LINEAR:9987,CLAMP_TO_EDGE:33071,MIRRORED_REPEAT:33648,REPEAT:10497},Vh=`KHR_mesh_quantization`,Hh={};Hh[ci]=Bh.NEAREST,Hh[ct]=Bh.NEAREST_MIPMAP_NEAREST,Hh[tt]=Bh.NEAREST_MIPMAP_LINEAR,Hh[xn]=Bh.LINEAR,Hh[ma]=Bh.LINEAR_MIPMAP_NEAREST,Hh[br]=Bh.LINEAR_MIPMAP_LINEAR,Hh[xr]=Bh.CLAMP_TO_EDGE,Hh[ua]=Bh.REPEAT,Hh[ht]=Bh.MIRRORED_REPEAT;var Uh={scale:`scale`,position:`translation`,quaternion:`rotation`,morphTargetInfluences:`weights`},Wh=new Ai,Gh=12,Kh=1179937895,qh=2,Jh=8,Yh=1313821514,Xh=5130562;function Zh(e,t){return e.length===t.length&&e.every(function(e,n){return e===t[n]})}function Qh(e){return new TextEncoder().encode(e).buffer}function $h(e){return Zh(e.elements,[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])}function eg(e,t,n){let r={min:Array(e.itemSize).fill(1/0),max:Array(e.itemSize).fill(-1/0)};for(let i=t;i<t+n;i++)for(let t=0;t<e.itemSize;t++){let n;e.itemSize>4?n=e.array[i*e.itemSize+t]:(t===0?n=e.getX(i):t===1?n=e.getY(i):t===2?n=e.getZ(i):t===3&&(n=e.getW(i)),e.normalized===!0&&(n=Hi.normalize(n,e.array))),r.min[t]=Math.min(r.min[t],n),r.max[t]=Math.max(r.max[t],n)}return r}function tg(e){return Math.ceil(e/4)*4}function ng(e,t=0){let n=tg(e.byteLength);if(n!==e.byteLength){let r=new Uint8Array(n);if(r.set(new Uint8Array(e)),t!==0)for(let i=e.byteLength;i<n;i++)r[i]=t;return r.buffer}return e}function rg(){return typeof document>`u`&&typeof OffscreenCanvas<`u`?new OffscreenCanvas(1,1):document.createElement(`canvas`)}function ig(e,t){if(typeof OffscreenCanvas<`u`&&e instanceof OffscreenCanvas){let n;return t===`image/jpeg`?n=.92:t===`image/webp`&&(n=.8),e.convertToBlob({type:t,quality:n})}else return new Promise(n=>e.toBlob(n,t))}var ag=class{constructor(){this.plugins=[],this.options={},this.pending=[],this.buffers=[],this.byteOffset=0,this.buffers=[],this.nodeMap=new Map,this.skins=[],this.extensionsUsed={},this.extensionsRequired={},this.uids=new Map,this.uid=0,this.json={asset:{version:`2.0`,generator:`THREE.GLTFExporter r185`}},this.cache={meshes:new Map,attributes:new Map,attributesNormalized:new Map,materials:new Map,textures:new Map,images:new Map},this.textureUtils=null}setPlugins(e){this.plugins=e}setTextureUtils(e){this.textureUtils=e}async writeAsync(e,t,n={}){this.options=Object.assign({binary:!1,trs:!1,onlyVisible:!0,maxTextureSize:1/0,animations:[],includeCustomExtensions:!1},n),this.options.animations.length>0&&(this.options.trs=!0),await this.processInputAsync(e),await Promise.all(this.pending);let r=this,i=r.buffers,a=r.json;n=r.options;let o=r.extensionsUsed,s=r.extensionsRequired,c=new Blob(i,{type:`application/octet-stream`}),l=Object.keys(o),u=Object.keys(s);if(l.length>0&&(a.extensionsUsed=l),u.length>0&&(a.extensionsRequired=u),a.buffers&&a.buffers.length>0&&(a.buffers[0].byteLength=c.size),n.binary===!0){let e=new FileReader;e.readAsArrayBuffer(c),e.onloadend=function(){let n=ng(e.result),r=new DataView(new ArrayBuffer(Jh));r.setUint32(0,n.byteLength,!0),r.setUint32(4,Xh,!0);let i=ng(Qh(JSON.stringify(a)),32),o=new DataView(new ArrayBuffer(Jh));o.setUint32(0,i.byteLength,!0),o.setUint32(4,Yh,!0);let s=new ArrayBuffer(Gh),c=new DataView(s);c.setUint32(0,Kh,!0),c.setUint32(4,qh,!0);let l=Gh+o.byteLength+i.byteLength+r.byteLength+n.byteLength;c.setUint32(8,l,!0);let u=new Blob([s,o,i,r,n],{type:`application/octet-stream`}),d=new FileReader;d.readAsArrayBuffer(u),d.onloadend=function(){t(d.result)}}}else if(a.buffers&&a.buffers.length>0){let e=new FileReader;e.readAsDataURL(c),e.onloadend=function(){let n=e.result;a.buffers[0].uri=n,t(a)}}else t(a)}serializeUserData(e,t){if(Object.keys(e.userData).length===0)return;let n=this.options,r=this.extensionsUsed;try{let i=JSON.parse(JSON.stringify(e.userData));if(n.includeCustomExtensions&&i.gltfExtensions){t.extensions===void 0&&(t.extensions={});for(let e in i.gltfExtensions)t.extensions[e]=i.gltfExtensions[e],r[e]=!0;delete i.gltfExtensions}Object.keys(i).length>0&&(t.extras=i)}catch(t){console.warn(`THREE.GLTFExporter: userData of '`+e.name+`' won't be serialized because of JSON.stringify error - `+t.message)}}getUID(e,t=!1){if(this.uids.has(e)===!1){let t=new Map;t.set(!0,this.uid++),t.set(!1,this.uid++),this.uids.set(e,t)}return this.uids.get(e).get(t)}isNormalizedNormalAttribute(e){if(this.cache.attributesNormalized.has(e))return!1;let t=new K;for(let n=0,r=e.count;n<r;n++)if(Math.abs(t.fromBufferAttribute(e,n).length()-1)>5e-4)return!1;return!0}createNormalizedNormalAttribute(e){let t=this.cache;if(t.attributesNormalized.has(e))return t.attributesNormalized.get(e);let n=e.clone(),r=new K;for(let e=0,t=n.count;e<t;e++)r.fromBufferAttribute(n,e),r.x===0&&r.y===0&&r.z===0?r.setX(1):r.normalize(),n.setXYZ(e,r.x,r.y,r.z);return t.attributesNormalized.set(e,n),n}applyTextureTransform(e,t){let n=!1,r={};(t.offset.x!==0||t.offset.y!==0)&&(r.offset=t.offset.toArray(),n=!0),t.rotation!==0&&(r.rotation=t.rotation,n=!0),(t.repeat.x!==1||t.repeat.y!==1)&&(r.scale=t.repeat.toArray(),n=!0),n&&(e.extensions=e.extensions||{},e.extensions.KHR_texture_transform=r,this.extensionsUsed.KHR_texture_transform=!0)}async buildMetalRoughTextureAsync(e,t){if(e===t)return e;function n(e){return e.colorSpace===`srgb`?function(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}:function(e){return e}}e instanceof cr&&(e=await this.decompressTextureAsync(e)),t instanceof cr&&(t=await this.decompressTextureAsync(t));let r=e?e.image:null,i=t?t.image:null,a=Math.max(r?r.width:0,i?i.width:0),o=Math.max(r?r.height:0,i?i.height:0),s=rg();s.width=a,s.height=o;let c=s.getContext(`2d`,{willReadFrequently:!0});c.fillStyle=`#00ffff`,c.fillRect(0,0,a,o);let l=c.getImageData(0,0,a,o);if(r){c.drawImage(r,0,0,a,o);let t=n(e),i=c.getImageData(0,0,a,o).data;for(let e=2;e<i.length;e+=4)l.data[e]=t(i[e]/256)*256}if(i){c.drawImage(i,0,0,a,o);let e=n(t),r=c.getImageData(0,0,a,o).data;for(let t=1;t<r.length;t+=4)l.data[t]=e(r[t]/256)*256}c.putImageData(l,0,0);let u=(e||t).clone();return u.source=new Rt(s),u.colorSpace=``,u.channel=(e||t).channel,e&&t&&e.channel!==t.channel&&console.warn(`THREE.GLTFExporter: UV channels for metalnessMap and roughnessMap textures must match.`),console.warn(`THREE.GLTFExporter: Merged metalnessMap and roughnessMap textures.`),u}async buildNormalMapTextureAsync(e,t,n){e instanceof cr&&(e=await this.decompressTextureAsync(e));let r=e.image,i=rg();i.width=r.width,i.height=r.height;let a=i.getContext(`2d`,{willReadFrequently:!0});a.drawImage(r,0,0,i.width,i.height);let o=a.getImageData(0,0,i.width,i.height),s=o.data;for(let e=0;e<s.length;e+=4)t&&(s[e+0]=255-s[e+0]),n&&(s[e+1]=255-s[e+1]);a.putImageData(o,0,0);let c=e.clone();return c.source=new Rt(i),c}async decompressTextureAsync(e,t=1/0){if(this.textureUtils===null)throw Error(`THREE.GLTFExporter: setTextureUtils() must be called to process compressed textures.`);return await this.textureUtils.decompress(e,t)}processBuffer(e){let t=this.json,n=this.buffers;return t.buffers||=[{byteLength:0}],n.push(e),0}processBufferView(e,t,n,r,i){let a=this.json;a.bufferViews||=[];let o;switch(t){case Bh.BYTE:case Bh.UNSIGNED_BYTE:o=1;break;case Bh.SHORT:case Bh.UNSIGNED_SHORT:o=2;break;default:o=4}let s=e.itemSize*o;i===Bh.ARRAY_BUFFER&&(s=Math.ceil(s/4)*4);let c=tg(r*s),l=new DataView(new ArrayBuffer(c)),u=0;for(let i=n;i<n+r;i++){for(let n=0;n<e.itemSize;n++){let r;e.itemSize>4?r=e.array[i*e.itemSize+n]:(n===0?r=e.getX(i):n===1?r=e.getY(i):n===2?r=e.getZ(i):n===3&&(r=e.getW(i)),e.normalized===!0&&(r=Hi.normalize(r,e.array))),t===Bh.FLOAT?l.setFloat32(u,r,!0):t===Bh.INT?l.setInt32(u,r,!0):t===Bh.UNSIGNED_INT?l.setUint32(u,r,!0):t===Bh.SHORT?l.setInt16(u,r,!0):t===Bh.UNSIGNED_SHORT?l.setUint16(u,r,!0):t===Bh.BYTE?l.setInt8(u,r):t===Bh.UNSIGNED_BYTE&&l.setUint8(u,r),u+=o}u%s!==0&&(u+=s-u%s)}let d={buffer:this.processBuffer(l.buffer),byteOffset:this.byteOffset,byteLength:c};return i!==void 0&&(d.target=i),i===Bh.ARRAY_BUFFER&&(d.byteStride=s),this.byteOffset+=c,a.bufferViews.push(d),{id:a.bufferViews.length-1,byteLength:0}}processBufferViewImage(e){let t=this,n=t.json;return n.bufferViews||=[],new Promise(function(r){let i=new FileReader;i.readAsArrayBuffer(e),i.onloadend=function(){let e=ng(i.result),a={buffer:t.processBuffer(e),byteOffset:t.byteOffset,byteLength:e.byteLength};t.byteOffset+=e.byteLength,r(n.bufferViews.push(a)-1)}})}processAccessor(e,t,n,r){let i=this.json,a={1:`SCALAR`,2:`VEC2`,3:`VEC3`,4:`VEC4`,9:`MAT3`,16:`MAT4`},o;if(e.array.constructor===Float32Array)o=Bh.FLOAT;else if(e.array.constructor===Int32Array)o=Bh.INT;else if(e.array.constructor===Uint32Array)o=Bh.UNSIGNED_INT;else if(e.array.constructor===Int16Array)o=Bh.SHORT;else if(e.array.constructor===Uint16Array)o=Bh.UNSIGNED_SHORT;else if(e.array.constructor===Int8Array)o=Bh.BYTE;else if(e.array.constructor===Uint8Array)o=Bh.UNSIGNED_BYTE;else throw Error(`THREE.GLTFExporter: Unsupported bufferAttribute component type: `+e.array.constructor.name);if(n===void 0&&(n=0),(r===void 0||r===1/0)&&(r=e.count),r===0)return null;let s=eg(e,n,r),c;t!==void 0&&(c=e===t.index?Bh.ELEMENT_ARRAY_BUFFER:Bh.ARRAY_BUFFER);let l=this.processBufferView(e,o,n,r,c),u={bufferView:l.id,byteOffset:l.byteOffset,componentType:o,count:r,max:s.max,min:s.min,type:a[e.itemSize]};return e.normalized===!0&&(u.normalized=!0),i.accessors||=[],i.accessors.push(u)-1}processImage(e,t,n,r=`image/png`){if(e!==null){let i=this,a=i.cache,o=i.json,s=i.options,c=i.pending;a.images.has(e)||a.images.set(e,{});let l=a.images.get(e),u=r+`:flipY/`+n.toString();if(l[u]!==void 0)return l[u];o.images||=[];let d={mimeType:r},f=rg();f.width=Math.min(e.width,s.maxTextureSize),f.height=Math.min(e.height,s.maxTextureSize);let p=f.getContext(`2d`,{willReadFrequently:!0});if(n===!0&&(p.translate(0,f.height),p.scale(1,-1)),e.data!==void 0){t!==1023&&console.error(`GLTFExporter: Only RGBAFormat is supported.`,t),(e.width>s.maxTextureSize||e.height>s.maxTextureSize)&&console.warn(`GLTFExporter: Image size is bigger than maxTextureSize`,e);let n=new Uint8ClampedArray(e.height*e.width*4);for(let t=0;t<n.length;t+=4)n[t+0]=e.data[t+0],n[t+1]=e.data[t+1],n[t+2]=e.data[t+2],n[t+3]=e.data[t+3];p.putImageData(new ImageData(n,e.width,e.height),0,0)}else if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof OffscreenCanvas<`u`&&e instanceof OffscreenCanvas)p.drawImage(e,0,0,f.width,f.height);else throw Error(`THREE.GLTFExporter: Invalid image type. Use HTMLImageElement, HTMLCanvasElement, ImageBitmap or OffscreenCanvas.`);s.binary===!0?c.push(ig(f,r).then(e=>i.processBufferViewImage(e)).then(e=>{d.bufferView=e})):d.uri=bi.getDataURL(f,r);let m=o.images.push(d)-1;return l[u]=m,m}else throw Error(`THREE.GLTFExporter: No valid image data found. Unable to process texture.`)}processSampler(e){let t=this.json;t.samplers||=[];let n={magFilter:Hh[e.magFilter],minFilter:Hh[e.minFilter],wrapS:Hh[e.wrapS],wrapT:Hh[e.wrapT]};return t.samplers.push(n)-1}async processTextureAsync(e){let t=this.options,n=this.cache,r=this.json;if(n.textures.has(e))return n.textures.get(e);r.textures||=[],e instanceof cr&&(e=await this.decompressTextureAsync(e,t.maxTextureSize));let i=e.userData.mimeType,a=this.processImage(e.image,e.format,e.flipY,i),o={sampler:this.processSampler(e)};i===`image/webp`?(o.extensions=o.extensions||{},o.extensions.EXT_texture_webp={source:a},this.extensionsUsed.EXT_texture_webp=!0,this.extensionsRequired.EXT_texture_webp=!0):o.source=a,e.name&&(o.name=e.name),await this._invokeAllAsync(async function(t){t.writeTexture&&await t.writeTexture(e,o)});let s=r.textures.push(o)-1;return n.textures.set(e,s),s}async processMaterialAsync(e,t){let n=this.cache,r=this.json,i=t!==void 0&&t.hasAttribute(`tangent`),a=e.normalMap?e.uuid+`:`+i:e.uuid;if(n.materials.has(a))return n.materials.get(a);if(e.isShaderMaterial)return console.warn(`GLTFExporter: THREE.ShaderMaterial not supported.`),null;r.materials||=[];let o={pbrMetallicRoughness:{}};e.isMeshStandardMaterial!==!0&&e.isMeshBasicMaterial!==!0&&console.warn(`GLTFExporter: Use MeshStandardMaterial or MeshBasicMaterial for best results.`);let s=e.color.toArray().concat([e.opacity]);if(Zh(s,[1,1,1,1])||(o.pbrMetallicRoughness.baseColorFactor=s),e.isMeshStandardMaterial?(o.pbrMetallicRoughness.metallicFactor=e.metalness,o.pbrMetallicRoughness.roughnessFactor=e.roughness):(o.pbrMetallicRoughness.metallicFactor=0,o.pbrMetallicRoughness.roughnessFactor=1),e.metalnessMap||e.roughnessMap){let t=await this.buildMetalRoughTextureAsync(e.metalnessMap,e.roughnessMap),n={index:await this.processTextureAsync(t),texCoord:t.channel};this.applyTextureTransform(n,t),o.pbrMetallicRoughness.metallicRoughnessTexture=n}if(e.map){let t={index:await this.processTextureAsync(e.map),texCoord:e.map.channel};this.applyTextureTransform(t,e.map),o.pbrMetallicRoughness.baseColorTexture=t}if(e.emissive){let t=e.emissive;if(Math.max(t.r,t.g,t.b)>0&&(o.emissiveFactor=e.emissive.toArray()),e.emissiveMap){let t={index:await this.processTextureAsync(e.emissiveMap),texCoord:e.emissiveMap.channel};this.applyTextureTransform(t,e.emissiveMap),o.emissiveTexture=t}}if(e.normalMap){let t=e.normalScale,n=t.x<0,r=i?t.y<0:t.y>0,a=e.normalMap;(n||r)&&(a=await this.buildNormalMapTextureAsync(e.normalMap,n,r));let s={index:await this.processTextureAsync(a),texCoord:e.normalMap.channel};Math.abs(t.x)!==1&&(s.scale=Math.abs(t.x)),this.applyTextureTransform(s,e.normalMap),o.normalTexture=s}if(e.aoMap){let t={index:await this.processTextureAsync(e.aoMap),texCoord:e.aoMap.channel};e.aoMapIntensity!==1&&(t.strength=e.aoMapIntensity),this.applyTextureTransform(t,e.aoMap),o.occlusionTexture=t}e.transparent?o.alphaMode=`BLEND`:e.alphaTest>0&&(o.alphaMode=`MASK`,o.alphaCutoff=e.alphaTest),e.side===2&&(o.doubleSided=!0),e.name!==``&&(o.name=e.name),this.serializeUserData(e,o),await this._invokeAllAsync(async function(t){t.writeMaterialAsync&&await t.writeMaterialAsync(e,o)});let c=r.materials.push(o)-1;return n.materials.set(a,c),c}async processMeshAsync(e){let t=this.cache,n=this.json,r=[e.geometry.uuid];if(Array.isArray(e.material))for(let t=0,n=e.material.length;t<n;t++)r.push(e.material[t].uuid);else r.push(e.material.uuid);let i=r.join(`:`);if(t.meshes.has(i))return t.meshes.get(i);let a=e.geometry,o;o=e.isLineSegments?Bh.LINES:e.isLineLoop?Bh.LINE_LOOP:e.isLine?Bh.LINE_STRIP:e.isPoints?Bh.POINTS:e.material.wireframe?Bh.LINES:Bh.TRIANGLES;let s={},c={},l=[],u=[],d={uv:`TEXCOORD_0`,uv1:`TEXCOORD_1`,uv2:`TEXCOORD_2`,uv3:`TEXCOORD_3`,color:`COLOR_0`,skinWeight:`WEIGHTS_0`,skinIndex:`JOINTS_0`},f=a.getAttribute(`normal`);f!==void 0&&!this.isNormalizedNormalAttribute(f)&&(console.warn(`THREE.GLTFExporter: Creating normalized normal attribute from the non-normalized one.`),a.setAttribute(`normal`,this.createNormalizedNormalAttribute(f)));let p=null;for(let e in a.attributes){if(e.slice(0,5)===`morph`)continue;let n=a.attributes[e];if(e=d[e]||e.toUpperCase(),!/^(POSITION|NORMAL|TANGENT|TEXCOORD_\d+|COLOR_\d+|JOINTS_\d+|WEIGHTS_\d+)$/.test(e)&&!e.startsWith(`_`)&&(e=`_`+e),t.attributes.has(this.getUID(n))){c[e]=t.attributes.get(this.getUID(n));continue}p=null;let r=n.array;e===`JOINTS_0`&&!(r instanceof Uint16Array)&&!(r instanceof Uint8Array)?(console.warn(`GLTFExporter: Attribute "skinIndex" converted to type UNSIGNED_SHORT.`),p=zh.Utils.toTypedBufferAttribute(n,Uint16Array)):(r instanceof Uint32Array||r instanceof Int32Array)&&!e.startsWith(`_`)&&(console.warn(`GLTFExporter: Attribute "${e}" converted to type FLOAT.`),p=zh.Utils.toTypedBufferAttribute(n,Float32Array));let i=this.processAccessor(p||n,a);i!==null&&(e.startsWith(`_`)||this.detectMeshQuantization(e,n),c[e]=i,t.attributes.set(this.getUID(n),i))}if(f!==void 0&&a.setAttribute(`normal`,f),Object.keys(c).length===0)return null;if(e.morphTargetInfluences!==void 0&&e.morphTargetInfluences.length>0){let n=[],r=[],i={};if(e.morphTargetDictionary!==void 0)for(let t in e.morphTargetDictionary)i[e.morphTargetDictionary[t]]=t;for(let o=0;o<e.morphTargetInfluences.length;++o){let s={},c=!1;for(let e in a.morphAttributes){if(e!==`position`&&e!==`normal`){c||=(console.warn(`GLTFExporter: Only POSITION and NORMAL morph are supported.`),!0);continue}let n=a.morphAttributes[e][o],r=e.toUpperCase(),i=a.attributes[e];if(t.attributes.has(this.getUID(n,!0))){s[r]=t.attributes.get(this.getUID(n,!0));continue}let l=n.clone();if(!a.morphTargetsRelative)for(let e=0,t=n.count;e<t;e++)for(let t=0;t<n.itemSize;t++)t===0&&l.setX(e,n.getX(e)-i.getX(e)),t===1&&l.setY(e,n.getY(e)-i.getY(e)),t===2&&l.setZ(e,n.getZ(e)-i.getZ(e)),t===3&&l.setW(e,n.getW(e)-i.getW(e));s[r]=this.processAccessor(l,a),t.attributes.set(this.getUID(i,!0),s[r])}u.push(s),n.push(e.morphTargetInfluences[o]),e.morphTargetDictionary!==void 0&&r.push(i[o])}s.weights=n,r.length>0&&(s.extras={},s.extras.targetNames=r)}let m=Array.isArray(e.material);if(m&&a.groups.length===0)return null;let h=!1;if(m&&a.index===null){let e=[];for(let t=0,n=a.attributes.position.count;t<n;t++)e[t]=t;a.setIndex(e),h=!0}let g=m?e.material:[e.material],_=m?a.groups:[{materialIndex:0,start:void 0,count:void 0}];for(let e=0,n=_.length;e<n;e++){let n={mode:o,attributes:c};if(this.serializeUserData(a,n),u.length>0&&(n.targets=u),a.index!==null){let r=this.getUID(a.index);(_[e].start!==void 0||_[e].count!==void 0)&&(r+=`:`+_[e].start+`:`+_[e].count),t.attributes.has(r)?n.indices=t.attributes.get(r):(n.indices=this.processAccessor(a.index,a,_[e].start,_[e].count),t.attributes.set(r,n.indices)),n.indices===null&&delete n.indices}let r=await this.processMaterialAsync(g[_[e].materialIndex],a);r!==null&&(n.material=r),l.push(n)}h===!0&&a.setIndex(null),s.primitives=l,n.meshes||=[],await this._invokeAllAsync(function(t){t.writeMesh&&t.writeMesh(e,s)});let v=n.meshes.push(s)-1;return t.meshes.set(i,v),v}detectMeshQuantization(e,t){if(this.extensionsUsed[Vh])return;let n;switch(t.array.constructor){case Int8Array:n=`byte`;break;case Uint8Array:n=`unsigned byte`;break;case Int16Array:n=`short`;break;case Uint16Array:n=`unsigned short`;break;default:return}t.normalized&&(n+=` normalized`);let r=e.split(`_`,1)[0];Rh[r]&&Rh[r].includes(n)&&(this.extensionsUsed[Vh]=!0,this.extensionsRequired[Vh]=!0)}processCamera(e){let t=this.json;t.cameras||=[];let n=e.isOrthographicCamera,r={type:n?`orthographic`:`perspective`};return n?r.orthographic={xmag:e.right*2,ymag:e.top*2,zfar:e.far<=0?.001:e.far,znear:e.near<0?0:e.near}:r.perspective={aspectRatio:e.aspect,yfov:Hi.degToRad(e.fov),zfar:e.far<=0?.001:e.far,znear:e.near<0?0:e.near},e.name!==``&&(r.name=e.type),t.cameras.push(r)-1}processAnimation(e,t){let n=this.json,r=this.nodeMap;n.animations||=[],e=zh.Utils.mergeMorphTargetTracks(e.clone(),t);let i=e.tracks,a=[],o=[];for(let e=0;e<i.length;++e){let n=i[e],s=Ot.parseTrackName(n.name),c=Ot.findNode(t,s.nodeName),l=Uh[s.propertyName];if(s.objectName===`bones`&&(c=c.isSkinnedMesh===!0?c.skeleton.getBoneByName(s.objectIndex):void 0),!c||!l){console.warn(`THREE.GLTFExporter: Could not export animation track "%s".`,n.name);continue}let u=n.values.length/n.times.length;l===Uh.morphTargetInfluences&&(u/=c.morphTargetInfluences.length);let d;n.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline===!0?(d=`CUBICSPLINE`,u/=3):d=n.getInterpolation()===2300?`STEP`:`LINEAR`,o.push({input:this.processAccessor(new Zt(n.times,1)),output:this.processAccessor(new Zt(n.values,u)),interpolation:d}),a.push({sampler:o.length-1,target:{node:r.get(c),path:l}})}let s={name:e.name||`clip_`+n.animations.length,samplers:o,channels:a};return this.serializeUserData(e,s),n.animations.push(s),n.animations.length-1}processSkin(e){let t=this.json,n=this.nodeMap,r=t.nodes[n.get(e)],i=e.skeleton;if(i===void 0)return null;let a=e.skeleton.bones[0];if(a===void 0)return null;let o=[],s=new Float32Array(i.bones.length*16),c=new Pr;for(let t=0;t<i.bones.length;++t)o.push(n.get(i.bones[t])),c.copy(i.boneInverses[t]),c.multiply(e.bindMatrix).toArray(s,t*16);return t.skins===void 0&&(t.skins=[]),t.skins.push({inverseBindMatrices:this.processAccessor(new Zt(s,16)),joints:o,skeleton:n.get(a)}),r.skin=t.skins.length-1}async processNodeAsync(e){let t=this.json,n=this.options,r=this.nodeMap;if(t.nodes||=[],e.pivot!==null)return await this._processNodeWithPivotAsync(e);let i={};if(n.trs){let t=e.quaternion.toArray(),n=e.position.toArray(),r=e.scale.toArray();Zh(t,[0,0,0,1])||(i.rotation=t),Zh(n,[0,0,0])||(i.translation=n),Zh(r,[1,1,1])||(i.scale=r)}else e.matrixAutoUpdate&&e.updateMatrix(),$h(e.matrix)===!1&&(i.matrix=e.matrix.elements);if(e.name!==``&&(i.name=String(e.name)),this.serializeUserData(e,i),e.isMesh||e.isLine||e.isPoints){let t=await this.processMeshAsync(e);t!==null&&(i.mesh=t)}else e.isCamera&&(i.camera=this.processCamera(e));e.isSkinnedMesh&&this.skins.push(e);let a=t.nodes.push(i)-1;if(r.set(e,a),e.children.length>0){let t=[];for(let r=0,i=e.children.length;r<i;r++){let i=e.children[r];if(i.visible||n.onlyVisible===!1){let e=await this.processNodeAsync(i);e!==null&&t.push(e)}}t.length>0&&(i.children=t)}return await this._invokeAllAsync(function(t){t.writeNode&&t.writeNode(e,i)}),a}async _processNodeWithPivotAsync(e){let t=this.json,n=this.options,r=this.nodeMap,i=e.pivot,a={},o=e.quaternion.toArray(),s=[e.position.x+i.x,e.position.y+i.y,e.position.z+i.z],c=e.scale.toArray();Zh(o,[0,0,0,1])||(a.rotation=o),Zh(s,[0,0,0])||(a.translation=s),Zh(c,[1,1,1])||(a.scale=c),a.extras={pivot:i.toArray()},e.name!==``&&(a.name=String(e.name)),this.serializeUserData(e,a);let l=t.nodes.push(a)-1;r.set(e,l);let u={},d=[-i.x,-i.y,-i.z];if(Zh(d,[0,0,0])||(u.translation=d),e.isMesh||e.isLine||e.isPoints){let t=await this.processMeshAsync(e);t!==null&&(u.mesh=t)}else e.isCamera&&(u.camera=this.processCamera(e));e.isSkinnedMesh&&this.skins.push(e);let f=[t.nodes.push(u)-1];if(e.children.length>0){let t=[];for(let r=0,i=e.children.length;r<i;r++){let i=e.children[r];if(i.visible||n.onlyVisible===!1){let e=await this.processNodeAsync(i);e!==null&&t.push(e)}}t.length>0&&(u.children=t)}return a.children=f,await this._invokeAllAsync(function(t){t.writeNode&&t.writeNode(e,a)}),l}async processSceneAsync(e){let t=this.json,n=this.options;t.scenes||(t.scenes=[],t.scene=0);let r={};e.name!==``&&(r.name=e.name),t.scenes.push(r);let i=[];for(let t=0,r=e.children.length;t<r;t++){let r=e.children[t];if(r.visible||n.onlyVisible===!1){let e=await this.processNodeAsync(r);e!==null&&i.push(e)}}i.length>0&&(r.nodes=i),this.serializeUserData(e,r)}async processObjectsAsync(e){let t=new ur;t.name=`AuxScene`;for(let n=0;n<e.length;n++)t.children.push(e[n]);await this.processSceneAsync(t)}async processInputAsync(e){let t=this.options;e=e instanceof Array?e:[e],await this._invokeAllAsync(function(t){t.beforeParse&&t.beforeParse(e)});let n=[];for(let t=0;t<e.length;t++)e[t]instanceof ur?await this.processSceneAsync(e[t]):n.push(e[t]);n.length>0&&await this.processObjectsAsync(n);for(let e=0;e<this.skins.length;++e)this.processSkin(this.skins[e]);if(e.length===1)for(let n=0;n<t.animations.length;++n)this.processAnimation(t.animations[n],e[0]);else for(let n=0;n<e.length;n++){let r=t.animations[n]||[];for(let t=0;t<r.length;++t)this.processAnimation(r[t],e[n])}await this._invokeAllAsync(function(t){t.afterParse&&t.afterParse(e)})}async _invokeAllAsync(e){for(let t=0,n=this.plugins.length;t<n;t++)await e(this.plugins[t])}},og=class{constructor(e){this.writer=e,this.name=`KHR_lights_punctual`}writeNode(e,t){if(!e.isLight)return;if(!e.isDirectionalLight&&!e.isPointLight&&!e.isSpotLight){console.warn(`THREE.GLTFExporter: Only directional, point, and spot lights are supported.`,e);return}let n=this.writer,r=n.json,i=n.extensionsUsed,a={};e.name&&(a.name=e.name),a.color=e.color.toArray(),a.intensity=e.intensity,e.isDirectionalLight?a.type=`directional`:e.isPointLight?(a.type=`point`,e.distance>0&&(a.range=e.distance)):e.isSpotLight&&(a.type=`spot`,e.distance>0&&(a.range=e.distance),a.spot={},a.spot.innerConeAngle=(1-e.penumbra)*e.angle,a.spot.outerConeAngle=e.angle),e.decay!==void 0&&e.decay!==2&&console.warn(`THREE.GLTFExporter: Light decay may be lost. glTF is physically-based, and expects light.decay=2.`),e.target&&(e.target.parent!==e||e.target.position.x!==0||e.target.position.y!==0||e.target.position.z!==-1)&&console.warn(`THREE.GLTFExporter: Light direction may be lost. For best results, make light.target a child of the light with position 0,0,-1.`),i[this.name]||(r.extensions=r.extensions||{},r.extensions[this.name]={lights:[]},i[this.name]=!0);let o=r.extensions[this.name].lights;o.push(a),t.extensions=t.extensions||{},t.extensions[this.name]={light:o.length-1}}},sg=class{constructor(e){this.writer=e,this.name=`KHR_materials_unlit`}async writeMaterialAsync(e,t){if(!e.isMeshBasicMaterial)return;let n=this.writer.extensionsUsed;t.extensions=t.extensions||{},t.extensions[this.name]={},n[this.name]=!0,t.pbrMetallicRoughness.metallicFactor=0,t.pbrMetallicRoughness.roughnessFactor=.9}},cg=class{constructor(e){this.writer=e,this.name=`KHR_materials_clearcoat`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.clearcoat===0)return;let n=this.writer,r=n.extensionsUsed,i={};if(i.clearcoatFactor=e.clearcoat,e.clearcoatMap){let t={index:await n.processTextureAsync(e.clearcoatMap),texCoord:e.clearcoatMap.channel};n.applyTextureTransform(t,e.clearcoatMap),i.clearcoatTexture=t}if(i.clearcoatRoughnessFactor=e.clearcoatRoughness,e.clearcoatRoughnessMap){let t={index:await n.processTextureAsync(e.clearcoatRoughnessMap),texCoord:e.clearcoatRoughnessMap.channel};n.applyTextureTransform(t,e.clearcoatRoughnessMap),i.clearcoatRoughnessTexture=t}if(e.clearcoatNormalMap){let t={index:await n.processTextureAsync(e.clearcoatNormalMap),texCoord:e.clearcoatNormalMap.channel};e.clearcoatNormalScale.x!==1&&(t.scale=e.clearcoatNormalScale.x),n.applyTextureTransform(t,e.clearcoatNormalMap),i.clearcoatNormalTexture=t}t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},lg=class{constructor(e){this.writer=e,this.name=`KHR_materials_dispersion`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.dispersion===0)return;let n=this.writer.extensionsUsed,r={};r.dispersion=e.dispersion,t.extensions=t.extensions||{},t.extensions[this.name]=r,n[this.name]=!0}},ug=class{constructor(e){this.writer=e,this.name=`KHR_materials_iridescence`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.iridescence===0)return;let n=this.writer,r=n.extensionsUsed,i={};if(i.iridescenceFactor=e.iridescence,e.iridescenceMap){let t={index:await n.processTextureAsync(e.iridescenceMap),texCoord:e.iridescenceMap.channel};n.applyTextureTransform(t,e.iridescenceMap),i.iridescenceTexture=t}if(i.iridescenceIor=e.iridescenceIOR,i.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],i.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1],e.iridescenceThicknessMap){let t={index:await n.processTextureAsync(e.iridescenceThicknessMap),texCoord:e.iridescenceThicknessMap.channel};n.applyTextureTransform(t,e.iridescenceThicknessMap),i.iridescenceThicknessTexture=t}t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},dg=class{constructor(e){this.writer=e,this.name=`KHR_materials_transmission`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.transmission===0)return;let n=this.writer,r=n.extensionsUsed,i={};if(i.transmissionFactor=e.transmission,e.transmissionMap){let t={index:await n.processTextureAsync(e.transmissionMap),texCoord:e.transmissionMap.channel};n.applyTextureTransform(t,e.transmissionMap),i.transmissionTexture=t}t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},fg=class{constructor(e){this.writer=e,this.name=`KHR_materials_volume`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.transmission===0)return;let n=this.writer,r=n.extensionsUsed,i={};if(i.thicknessFactor=e.thickness,e.thicknessMap){let t={index:await n.processTextureAsync(e.thicknessMap),texCoord:e.thicknessMap.channel};n.applyTextureTransform(t,e.thicknessMap),i.thicknessTexture=t}e.attenuationDistance!==1/0&&(i.attenuationDistance=e.attenuationDistance),i.attenuationColor=e.attenuationColor.toArray(),t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},pg=class{constructor(e){this.writer=e,this.name=`KHR_materials_ior`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.ior===1.5)return;let n=this.writer.extensionsUsed,r={};r.ior=e.ior,t.extensions=t.extensions||{},t.extensions[this.name]=r,n[this.name]=!0}},mg=class{constructor(e){this.writer=e,this.name=`KHR_materials_specular`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.specularIntensity===1&&e.specularColor.equals(Wh)&&!e.specularIntensityMap&&!e.specularColorMap)return;let n=this.writer,r=n.extensionsUsed,i={};if(e.specularIntensityMap){let t={index:await n.processTextureAsync(e.specularIntensityMap),texCoord:e.specularIntensityMap.channel};n.applyTextureTransform(t,e.specularIntensityMap),i.specularTexture=t}if(e.specularColorMap){let t={index:await n.processTextureAsync(e.specularColorMap),texCoord:e.specularColorMap.channel};n.applyTextureTransform(t,e.specularColorMap),i.specularColorTexture=t}i.specularFactor=e.specularIntensity,i.specularColorFactor=e.specularColor.toArray(),t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},hg=class{constructor(e){this.writer=e,this.name=`KHR_materials_sheen`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.sheen==0)return;let n=this.writer,r=n.extensionsUsed,i={};if(e.sheenRoughnessMap){let t={index:await n.processTextureAsync(e.sheenRoughnessMap),texCoord:e.sheenRoughnessMap.channel};n.applyTextureTransform(t,e.sheenRoughnessMap),i.sheenRoughnessTexture=t}if(e.sheenColorMap){let t={index:await n.processTextureAsync(e.sheenColorMap),texCoord:e.sheenColorMap.channel};n.applyTextureTransform(t,e.sheenColorMap),i.sheenColorTexture=t}i.sheenRoughnessFactor=e.sheenRoughness,i.sheenColorFactor=e.sheenColor.toArray(),t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},gg=class{constructor(e){this.writer=e,this.name=`KHR_materials_anisotropy`}async writeMaterialAsync(e,t){if(!e.isMeshPhysicalMaterial||e.anisotropy==0)return;let n=this.writer,r=n.extensionsUsed,i={};if(e.anisotropyMap){let t={index:await n.processTextureAsync(e.anisotropyMap)};n.applyTextureTransform(t,e.anisotropyMap),i.anisotropyTexture=t}i.anisotropyStrength=e.anisotropy,i.anisotropyRotation=e.anisotropyRotation,t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},_g=class{constructor(e){this.writer=e,this.name=`KHR_materials_emissive_strength`}async writeMaterialAsync(e,t){if(!e.isMeshStandardMaterial||e.emissiveIntensity===1)return;let n=this.writer.extensionsUsed,r={};r.emissiveStrength=e.emissiveIntensity,t.extensions=t.extensions||{},t.extensions[this.name]=r,n[this.name]=!0}},vg=class{constructor(e){this.writer=e,this.name=`EXT_materials_bump`}async writeMaterialAsync(e,t){if(!e.isMeshStandardMaterial||e.bumpScale===1&&!e.bumpMap)return;let n=this.writer,r=n.extensionsUsed,i={};if(e.bumpMap){let t={index:await n.processTextureAsync(e.bumpMap),texCoord:e.bumpMap.channel};n.applyTextureTransform(t,e.bumpMap),i.bumpTexture=t}i.bumpFactor=e.bumpScale,t.extensions=t.extensions||{},t.extensions[this.name]=i,r[this.name]=!0}},yg=class{constructor(e){this.writer=e,this.name=`EXT_mesh_gpu_instancing`}writeNode(e,t){if(!e.isInstancedMesh)return;let n=this.writer,r=e,i=new Float32Array(r.count*3),a=new Float32Array(r.count*4),o=new Float32Array(r.count*3),s=new Pr,c=new K,l=new Ei,u=new K;for(let e=0;e<r.count;e++)r.getMatrixAt(e,s),s.decompose(c,l,u),c.toArray(i,e*3),l.toArray(a,e*4),u.toArray(o,e*3);let d={TRANSLATION:n.processAccessor(new Zt(i,3)),ROTATION:n.processAccessor(new Zt(a,4)),SCALE:n.processAccessor(new Zt(o,3))};r.instanceColor&&(d._COLOR_0=n.processAccessor(r.instanceColor)),t.extensions=t.extensions||{},t.extensions[this.name]={attributes:d},n.extensionsUsed[this.name]=!0,n.extensionsRequired[this.name]=!0}};zh.Utils={insertKeyframe:function(e,t){let n=.001,r=e.getValueSize(),i=new e.TimeBufferType(e.times.length+1),a=new e.ValueBufferType(e.values.length+r),o=e.createInterpolant(new e.ValueBufferType(r)),s;if(e.times.length===0){i[0]=t;for(let e=0;e<r;e++)a[e]=0;s=0}else if(t<e.times[0]){if(Math.abs(e.times[0]-t)<n)return 0;i[0]=t,i.set(e.times,1),a.set(o.evaluate(t),0),a.set(e.values,r),s=0}else if(t>e.times[e.times.length-1]){if(Math.abs(e.times[e.times.length-1]-t)<n)return e.times.length-1;i[i.length-1]=t,i.set(e.times,0),a.set(e.values,0),a.set(o.evaluate(t),e.values.length),s=i.length-1}else for(let c=0;c<e.times.length;c++){if(Math.abs(e.times[c]-t)<n)return c;if(e.times[c]<t&&e.times[c+1]>t){i.set(e.times.slice(0,c+1),0),i[c+1]=t,i.set(e.times.slice(c+1),c+2),a.set(e.values.slice(0,(c+1)*r),0),a.set(o.evaluate(t),(c+1)*r),a.set(e.values.slice((c+1)*r),(c+2)*r),s=c+1;break}}return e.times=i,e.values=a,s},mergeMorphTargetTracks:function(e,t){let n=[],r={},i=e.tracks;for(let e=0;e<i.length;++e){let a=i[e],o=Ot.parseTrackName(a.name),s=Ot.findNode(t,o.nodeName);if(o.propertyName!==`morphTargetInfluences`||o.propertyIndex===void 0){n.push(a);continue}if(a.createInterpolant!==a.InterpolantFactoryMethodDiscrete&&a.createInterpolant!==a.InterpolantFactoryMethodLinear){if(a.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline)throw Error(`THREE.GLTFExporter: Cannot merge tracks with glTF CUBICSPLINE interpolation.`);console.warn(`THREE.GLTFExporter: Morph target interpolation mode not yet supported. Using LINEAR instead.`),a=a.clone(),a.setInterpolation(_)}let c=s.morphTargetInfluences.length,l=s.morphTargetDictionary[o.propertyIndex];if(l===void 0)throw Error(`THREE.GLTFExporter: Morph target name not found: `+o.propertyIndex);let u;if(r[s.uuid]===void 0){u=a.clone();let e=new u.ValueBufferType(c*u.times.length);for(let t=0;t<u.times.length;t++)e[t*c+l]=u.values[t];u.name=(o.nodeName||``)+`.morphTargetInfluences`,u.values=e,r[s.uuid]=u,n.push(u);continue}let d=a.createInterpolant(new a.ValueBufferType(1));u=r[s.uuid];for(let e=0;e<u.times.length;e++)u.values[e*c+l]=d.evaluate(u.times[e]);for(let e=0;e<a.times.length;e++){let t=this.insertKeyframe(u,a.times[e]);u.values[t*c+l]=a.values[e]}}return e.tracks=n,e},toTypedBufferAttribute:function(e,t){let n=new Zt(new t(e.count*e.itemSize),e.itemSize,!1);if(!e.normalized&&!e.isInterleavedBufferAttribute)return n.array.set(e.array),n;for(let t=0,r=e.count;t<r;t++)for(let r=0;r<e.itemSize;r++)n.setComponent(t,r,e.getComponent(t,r));return n}};function bg(e,t,n,r){let i=Dh(t,!1),a=Th(t,r),o=new G(i,a);o.name=t.name,n.geometries.add(i),n.materials.add(a),e.add(o)}function xg(e,t,n){let r=Nh(t);r.forEach(e=>n.materials.add(e));let i=Mh(t.geometry);if(!i)throw Error(`Die Union hat keine exportierbare Geometrie erzeugt.`);n.geometries.add(i);let a=new G(i,r.length===1?r[0]:r);a.name=`Union`,e.add(a)}function Sg(e,t,n,r){let i=t.filter(Gl),a=t.filter(e=>!Gl(e));if(i.length<2){t.forEach(t=>bg(e,t,n,r));return}xg(e,Lh(i,r,n),n),a.forEach(t=>bg(e,t,n,r))}async function Cg(e,t,n=`separate`){let r=new Pi,i={geometries:new Set,materials:new Set,textures:new Set};try{let a=await wh(e);a.forEach(e=>i.textures.add(e)),n===`union`?Sg(r,e,i,a):e.forEach(e=>bg(r,e,i,a));let o=await new zh().parseAsync(r,{binary:!0,onlyVisible:!0});if(!(o instanceof ArrayBuffer))throw Error(`Der binäre GLB-Export hat kein ArrayBuffer erzeugt.`);let s=new Blob([o],{type:`model/gltf-binary`}),c=URL.createObjectURL(s),l=document.createElement(`a`);return l.href=c,l.download=`${Hl(t)}.glb`,l.click(),window.setTimeout(()=>URL.revokeObjectURL(c),0),s}catch(e){if(n===`union`){let t=e instanceof Error?e.message:`unbekannter Geometriefehler`;throw Error(`Union fehlgeschlagen: ${t}`)}throw e}finally{i.geometries.forEach(e=>e.dispose()),i.materials.forEach(e=>e.dispose()),i.textures.forEach(e=>e.dispose())}}var Q=s();function wg({onClose:e}){let t=q(e=>e.objects),i=q(e=>e.selectedId),a=q(e=>e.project.name),o=q(e=>e.setMessage),[s,c]=(0,Y.useState)(!1),[l,u]=(0,Y.useState)(`separate`),[d,f]=(0,Y.useState)(a),[p,m]=(0,Y.useState)(!1),h=(0,Y.useMemo)(()=>ql(t,i,s,l),[l,t,i,s]),g=async()=>{if(h.objects.length===0){o(`Export abgebrochen: keine sichtbaren Objekte`);return}m(!0);try{let t=await Cg(h.objects,d,l),i=`${Hl(d)}.glb`;if(r()){let e=await n(t,i,`model/gltf-binary`);if(!e)return;i=e.name}let a=l===`union`&&h.unionEligible>=2?`Union`:`getrennte Meshes`;o(`GLB gespeichert (${a}): ${i} · ${(t.size/1024).toFixed(1)} KB`),e()}catch(e){o(e instanceof Error?`GLB-Export fehlgeschlagen: ${e.message}`:`GLB-Export fehlgeschlagen`)}finally{m(!1)}};return(0,Q.jsx)(`div`,{className:`modal-backdrop`,onMouseDown:t=>t.target===t.currentTarget&&e(),children:(0,Q.jsxs)(`div`,{className:`modal`,role:`dialog`,"aria-modal":`true`,"aria-label":`GLB exportieren`,children:[(0,Q.jsx)(`h2`,{children:`GLB exportieren`}),(0,Q.jsxs)(`div`,{className:`modal-content`,children:[(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Dateiname`}),(0,Q.jsx)(`input`,{value:d,onChange:e=>f(e.target.value)})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Umfang`}),(0,Q.jsxs)(`select`,{value:s?`selection`:`scene`,onChange:e=>c(e.target.value===`selection`),children:[(0,Q.jsx)(`option`,{value:`scene`,children:`Gesamte sichtbare Szene`}),(0,Q.jsx)(`option`,{value:`selection`,children:`Nur Auswahl`})]})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Aktion`}),(0,Q.jsxs)(`select`,{value:l,onChange:e=>u(e.target.value),children:[(0,Q.jsx)(`option`,{value:`separate`,children:`Getrennte Meshes exportieren`}),(0,Q.jsx)(`option`,{value:`union`,children:`Volumenkörper als Union exportieren`})]})]}),(0,Q.jsxs)(`div`,{className:`export-report`,children:[(0,Q.jsx)(`strong`,{children:h.objects.length}),` Objekte · `,(0,Q.jsx)(`strong`,{children:h.triangles.toLocaleString(`de-DE`)}),` Dreiecke`]}),l===`union`&&(0,Q.jsxs)(`div`,{className:`export-report`,children:[(0,Q.jsx)(`strong`,{children:h.unionEligible}),` geschlossene Volumenkörper für Union · `,(0,Q.jsx)(`strong`,{children:h.unionSeparate}),` separat`]}),h.warnings.length>0&&(0,Q.jsx)(`ul`,{className:`warning-list`,children:h.warnings.map(e=>(0,Q.jsx)(`li`,{children:e},e))}),(0,Q.jsx)(`p`,{children:l===`union`?`Geschlossene Volumenkörper – auch bemalte – werden nur für die exportierte GLB boolesch vereinigt. Die Editor-Szene bleibt unverändert.`:`Transformationen und Materialien werden eingebettet. Raster, Achsen und Editor-Helfer werden nicht exportiert.`})]}),(0,Q.jsxs)(`div`,{className:`modal-actions`,children:[(0,Q.jsx)(`button`,{onClick:e,children:`Abbrechen`}),(0,Q.jsx)(`button`,{disabled:p||h.objects.length===0,onClick:()=>void g(),children:p?`Export läuft…`:`GLB speichern`})]})]})})}async function Tg(e){let t=document.querySelector(`.viewport canvas`);if(!t)return null;let r=await new Promise(e=>{t.toBlob(e,`image/png`)});return r?n(r,`${Hl(e)}-preview.png`,`image/png`):null}function Eg(){document.querySelectorAll(`.menu[open]`).forEach(e=>e.removeAttribute(`open`))}function Dg(){let e=(0,Y.useRef)(null),t=(0,Y.useRef)(null),[i,o]=(0,Y.useState)(!1),s=q(e=>e.project),c=q(e=>e.scene),l=q(e=>e.objects),u=q(e=>e.setProjectName),d=q(e=>e.newProject),f=q(e=>e.loadProject),p=q(e=>e.markSaved),m=q(e=>e.setMessage),h=q(e=>e.undo),g=q(e=>e.redo),_=q(e=>e.duplicateObject),v=q(e=>e.deleteObject),y=q(e=>e.selectedId),b=q(e=>e.past.length),x=q(e=>e.future.length),S=q(e=>e.setScene),C=q(e=>e.requestCameraView),w=()=>{let e=Vl(s,c,l);return zl({project:e.project,scene:e.scene,objects:e.objects})},T=async(e,t)=>{let n=await e.createWritable();await n.write(t),await n.close()},E=async()=>{let e=w(),i=`${Hl(s.name)}.ncae.json`,a=new Blob([e],{type:`application/json`}),o=window;try{if(r()){let e=await n(a,i,`application/json`);if(!e?.uri)return;t.current={kind:`native`,uri:e.uri,name:e.name},p(),m(`Gespeichert unter: ${e.name}`)}else if(o.showSaveFilePicker){let n=await o.showSaveFilePicker({suggestedName:i,excludeAcceptAllOption:!1,types:[{description:`NorthCore Asset Editor Projekt`,accept:{"application/json":[`.json`]}}]});await T(n,e),t.current={kind:`browser`,handle:n},p(),m(`Gespeichert unter: ${n.name}`)}else{let e=await n(a,i,`application/json`);if(!e)return;t.current=null,p(),m(`Heruntergeladen: ${e.name}`)}}catch(e){if(e instanceof DOMException&&e.name===`AbortError`)return;m(e instanceof Error?`Speichern fehlgeschlagen: ${e.message}`:`Speichern fehlgeschlagen`)}finally{Eg()}},D=async()=>{let e=t.current;if(!e){await E();return}try{let t=w();e.kind===`native`?(await a(e.uri,new Blob([t],{type:`application/json`})),m(`Gespeichert: ${e.name}`)):(await T(e.handle,t),m(`Gespeichert: ${e.handle.name}`)),p()}catch(e){m(e instanceof Error?`Speichern fehlgeschlagen: ${e.message}`:`Speichern fehlgeschlagen`)}finally{Eg()}},O=async e=>{try{f(Bl(await e.text())),t.current=null}catch(e){m(e instanceof Error?e.message:`Projektdatei konnte nicht geladen werden.`)}};return(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsxs)(`header`,{className:`topbar`,children:[(0,Q.jsxs)(`details`,{className:`menu`,onMouseLeave:e=>e.currentTarget.removeAttribute(`open`),children:[(0,Q.jsx)(`summary`,{children:`Datei`}),(0,Q.jsxs)(`div`,{className:`menu-popover`,children:[(0,Q.jsx)(`button`,{onClick:()=>{t.current=null,d(),Eg()},children:`Neu`}),(0,Q.jsx)(`button`,{onClick:()=>{e.current?.click(),Eg()},children:`Öffnen…`}),(0,Q.jsx)(`button`,{onClick:()=>{D()},children:`Speichern`}),(0,Q.jsx)(`button`,{onClick:()=>{E()},children:`Speichern unter…`})]})]}),(0,Q.jsxs)(`details`,{className:`menu`,onMouseLeave:e=>e.currentTarget.removeAttribute(`open`),children:[(0,Q.jsx)(`summary`,{children:`Bearbeiten`}),(0,Q.jsxs)(`div`,{className:`menu-popover`,children:[(0,Q.jsx)(`button`,{disabled:b===0,onClick:()=>{h(),Eg()},children:`Rückgängig`}),(0,Q.jsx)(`button`,{disabled:x===0,onClick:()=>{g(),Eg()},children:`Wiederholen`}),(0,Q.jsx)(`button`,{disabled:!y,onClick:()=>{_(),Eg()},children:`Duplizieren`}),(0,Q.jsx)(`button`,{disabled:!y,className:`danger`,onClick:()=>{v(),Eg()},children:`Löschen`})]})]}),(0,Q.jsxs)(`details`,{className:`menu`,onMouseLeave:e=>e.currentTarget.removeAttribute(`open`),children:[(0,Q.jsx)(`summary`,{children:`Ansicht`}),(0,Q.jsxs)(`div`,{className:`menu-popover`,children:[(0,Q.jsx)(`button`,{onClick:()=>{C(`perspective`),Eg()},children:`Perspektive`}),(0,Q.jsx)(`button`,{onClick:()=>{C(`focus`),Eg()},children:`Auswahl fokussieren`}),(0,Q.jsxs)(`button`,{onClick:()=>{S({gridVisible:!c.gridVisible}),Eg()},children:[`Raster `,c.gridVisible?`aus`:`ein`]}),(0,Q.jsxs)(`button`,{onClick:()=>{S({axesVisible:!c.axesVisible}),Eg()},children:[`Achsen `,c.axesVisible?`aus`:`ein`]})]})]}),(0,Q.jsxs)(`details`,{className:`menu`,onMouseLeave:e=>e.currentTarget.removeAttribute(`open`),children:[(0,Q.jsx)(`summary`,{children:`Export`}),(0,Q.jsxs)(`div`,{className:`menu-popover`,children:[(0,Q.jsx)(`button`,{onClick:()=>{o(!0),Eg()},children:`GLB exportieren…`}),(0,Q.jsx)(`button`,{onClick:()=>{Tg(s.name).then(e=>{e&&m(`Screenshot gespeichert: ${e.name}`)}).catch(e=>{m(e instanceof Error?`Screenshot fehlgeschlagen: ${e.message}`:`Screenshot konnte nicht erstellt werden`)}),Eg()},children:`Screenshot als PNG`})]})]}),(0,Q.jsx)(`input`,{className:`project-name`,"aria-label":`Projektname`,value:s.name,onChange:e=>u(e.target.value)}),(0,Q.jsxs)(`div`,{className:`brand`,children:[`NorthCore 3D Asset Editor `,Cl]}),(0,Q.jsx)(`input`,{ref:e,type:`file`,hidden:!0,accept:`.json,.ncae.json,application/json`,onChange:e=>{let t=e.target.files?.[0];t&&O(t),e.currentTarget.value=``}})]}),i&&(0,Q.jsx)(wg,{onClose:()=>o(!1)})]})}function Og(){let e=q(e=>e.objects),t=q(e=>e.selectedId),n=q(e=>e.tool),r=q(e=>e.snap),i=q(e=>e.dirty),a=q(e=>e.message),o=e.find(e=>e.id===t),s=(0,Y.useMemo)(()=>e.filter(e=>e.visible).reduce((e,t)=>e+Sl(t),0),[e]);return(0,Q.jsxs)(`footer`,{className:`statusbar`,children:[(0,Q.jsxs)(`span`,{children:[`Objekte: `,e.length]}),(0,Q.jsxs)(`span`,{children:[`Auswahl: `,o?.name??`–`]}),(0,Q.jsxs)(`span`,{children:[`Dreiecke: `,s.toLocaleString(`de-DE`)]}),(0,Q.jsxs)(`span`,{children:[`Werkzeug: `,n]}),(0,Q.jsxs)(`span`,{children:[`Snapping: `,r.enabled?`an`:`aus`]}),(0,Q.jsx)(`span`,{className:i?`unsaved`:``,children:i?`Ungespeichert`:`Gespeichert`}),(0,Q.jsx)(`span`,{className:`message`,children:a})]})}var kg=[`Alle`,`Formen`,`Gebäude`,`Möbel`,`Natur`,`Infrastruktur`,`Dekoration`,`Importiert`],Ag={box:`■`,cuboid:`▰`,sphere:`●`,hemisphere:`◒`,cylinder:`⬤`,cone:`▲`,pyramid:`◆`,plane:`▱`,torus:`◎`,wedge:`◢`,prism:`⬡`,wall:`▥`,floor:`▬`,flatRoof:`▔`,gableRoof:`⌂`,shedRoof:`◩`,door:`▯`,window:`⊞`,column:`▮`,chimney:`▯`,stairs:`▟`},jg=e=>e===`Grundformen`?`Formen`:`Gebäude`;function Mg({collapsed:e,onToggle:t}){let n=q(e=>e.addObject),r=(0,Y.useRef)(null),[i,a]=(0,Y.useState)(`Alle`),[o,s]=(0,Y.useState)(``),[c,l]=(0,Y.useState)(!1),[u,d]=(0,Y.useState)(!1),f=(0,Y.useCallback)(()=>{let e=r.current;if(!e)return;let t=Math.max(0,e.scrollWidth-e.clientWidth);l(e.scrollLeft>1),d(e.scrollLeft<t-1)},[]);(0,Y.useEffect)(()=>{let e=window.requestAnimationFrame(f);return window.addEventListener(`resize`,f),()=>{window.cancelAnimationFrame(e),window.removeEventListener(`resize`,f)}},[e,f]);let p=e=>{r.current?.scrollBy({left:e*120,behavior:`smooth`})},m=(0,Y.useMemo)(()=>{let e=o.trim().toLocaleLowerCase(`de-DE`);return ln.filter(t=>{let n=jg(t.category),r=i===`Alle`||i===n,a=!e||[t.label,t.type,n].some(t=>t.toLocaleLowerCase(`de-DE`).includes(e));return r&&a})},[i,o]),h=i===`Alle`||i===`Formen`||i===`Gebäude`;return(0,Q.jsxs)(`aside`,{className:`panel left-panel shapes-inventory${e?` panel-collapsed`:``}`,children:[(0,Q.jsxs)(`div`,{className:`panel-header inventory-header`,children:[!e&&(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`span`,{className:`panel-title`,children:`Inventar`}),(0,Q.jsx)(`span`,{className:`inventory-count`,children:m.length})]}),(0,Q.jsx)(`button`,{type:`button`,className:`panel-collapse-button`,onClick:t,"aria-label":e?`Inventar einblenden`:`Inventar ausblenden`,title:e?`Inventar einblenden`:`Inventar ausblenden`,children:e?`›`:`‹`})]}),!e&&(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsxs)(`div`,{className:`inventory-controls`,children:[(0,Q.jsxs)(`label`,{className:`inventory-search`,children:[(0,Q.jsx)(`span`,{"aria-hidden":`true`,children:`⌕`}),(0,Q.jsx)(`input`,{type:`search`,value:o,onChange:e=>s(e.target.value),placeholder:`Assets suchen…`,"aria-label":`Assets suchen`}),o&&(0,Q.jsx)(`button`,{type:`button`,onClick:()=>s(``),"aria-label":`Suche leeren`,children:`×`})]}),(0,Q.jsxs)(`div`,{className:`inventory-category-strip`,children:[(0,Q.jsx)(`button`,{type:`button`,className:`inventory-category-arrow inventory-category-arrow-left`,onClick:()=>p(-1),disabled:!c,"aria-label":`Vorherige Kategorien anzeigen`,children:`‹`}),(0,Q.jsx)(`nav`,{ref:r,className:`inventory-categories`,"aria-label":`Asset-Kategorien`,onScroll:f,children:kg.map(e=>(0,Q.jsx)(`button`,{type:`button`,className:i===e?`active`:void 0,onClick:()=>a(e),children:e},e))}),(0,Q.jsx)(`button`,{type:`button`,className:`inventory-category-arrow inventory-category-arrow-right`,onClick:()=>p(1),disabled:!u,"aria-label":`Weitere Kategorien anzeigen`,children:`›`})]})]}),(0,Q.jsx)(`section`,{className:`inventory-results`,"aria-live":`polite`,children:m.length>0?(0,Q.jsx)(`div`,{className:`inventory-grid`,children:m.map(e=>{let t=jg(e.category);return(0,Q.jsxs)(`button`,{type:`button`,className:`inventory-item`,onClick:()=>n(e.type),title:`${e.label} hinzufügen`,children:[(0,Q.jsx)(`span`,{className:`inventory-preview inventory-preview-${t===`Formen`?`shape`:`building`}`,"aria-hidden":`true`,children:Ag[e.type]??`◆`}),(0,Q.jsx)(`span`,{className:`inventory-item-label`,children:e.label}),(0,Q.jsx)(`span`,{className:`inventory-item-category`,children:t})]},e.type)})}):(0,Q.jsxs)(`div`,{className:`inventory-empty`,children:[(0,Q.jsx)(`strong`,{children:o?`Keine Treffer`:i}),(0,Q.jsx)(`span`,{children:o?`Für „${o}“ wurden keine Assets gefunden.`:h?`In dieser Kategorie sind derzeit keine passenden Assets vorhanden.`:`Diese Kategorie ist für spätere Asset-Pakete vorbereitet.`})]})})]})]})}var Ng={"Holz hell":{color:`#B98555`,roughness:.82,metalness:0,opacity:1,flatShading:!0},"Holz dunkel":{color:`#5B3825`,roughness:.88,metalness:0,opacity:1,flatShading:!0},Metall:{color:`#8E9AA1`,roughness:.28,metalness:.82,opacity:1,flatShading:!1},Kunststoff:{color:`#4F8F68`,roughness:.45,metalness:.05,opacity:1,flatShading:!1},Glas:{color:`#A9D8E6`,roughness:.08,metalness:0,opacity:.32,flatShading:!1},Stein:{color:`#7E807C`,roughness:.94,metalness:0,opacity:1,flatShading:!0},Beton:{color:`#A5A5A0`,roughness:.96,metalness:0,opacity:1,flatShading:!0},Ziegel:{color:`#9A4E3D`,roughness:.92,metalness:0,opacity:1,flatShading:!0},Gras:{color:`#5F8D4E`,roughness:1,metalness:0,opacity:1,flatShading:!0},Erde:{color:`#6F4E37`,roughness:1,metalness:0,opacity:1,flatShading:!0}};function Pg(e,t=255){let n=/^#[0-9a-fA-F]{6}$/.test(e)?e.slice(1):`000000`;return{r:Number.parseInt(n.slice(0,2),16),g:Number.parseInt(n.slice(2,4),16),b:Number.parseInt(n.slice(4,6),16),a:t}}function Fg(e){let t=e=>Math.max(0,Math.min(255,e)).toString(16).padStart(2,`0`);return`#${t(e.r)}${t(e.g)}${t(e.b)}`.toUpperCase()}function Ig(e,t,n){return(n*e.width+t)*4}function Lg(e,t,n){let r=Ig(e,t,n);return{r:e.data[r]??0,g:e.data[r+1]??0,b:e.data[r+2]??0,a:e.data[r+3]??0}}function Rg(e,t,n,r){let i=Ig(e,t,n);e.data[i]=r.r,e.data[i+1]=r.g,e.data[i+2]=r.b,e.data[i+3]=r.a}function zg(e,t,n=0){return e.a===0&&t.a===0||Math.abs(e.r-t.r)<=n&&Math.abs(e.g-t.g)<=n&&Math.abs(e.b-t.b)<=n&&Math.abs(e.a-t.a)<=n}function Bg(e,t,n){return Lg(e,Math.max(0,Math.min(e.width-1,t)),Math.max(0,Math.min(e.height-1,n)))}function Vg(e,t,n,r,i){let a=Math.max(1,Math.round(r)),o=t-Math.floor((a-1)/2),s=n-Math.floor((a-1)/2);for(let t=0;t<a;t+=1)for(let n=0;n<a;n+=1){let r=o+n,a=s+t;r<0||a<0||r>=e.width||a>=e.height||Rg(e,r,a,i)}}function Hg(e,t,n,r,i=0,a){let o=Math.max(0,Math.min(e.width-1,a?.minX??0)),s=Math.max(o,Math.min(e.width-1,a?.maxX??e.width-1)),c=Math.max(0,Math.min(e.height-1,a?.minY??0)),l=Math.max(c,Math.min(e.height-1,a?.maxY??e.height-1));if(t<o||n<c||t>s||n>l)return;let u=Lg(e,t,n);if(zg(u,r,0))return;let d=[[t,n]],f=new Uint8Array(e.width*e.height);for(;d.length>0;){let[t,n]=d.pop();if(n<c||n>l)continue;let a=t;for(;a>=o&&zg(Lg(e,a,n),u,i);)--a;a+=1;let p=!1,m=!1;for(let t=a;t<=s&&zg(Lg(e,t,n),u,i);t+=1){let a=n*e.width+t;if(f[a]||(f[a]=1,Rg(e,t,n,r)),n>c){let r=zg(Lg(e,t,n-1),u,i);r&&!p?(d.push([t,n-1]),p=!0):r||(p=!1)}if(n<l){let r=zg(Lg(e,t,n+1),u,i);r&&!m?(d.push([t,n+1]),m=!0):r||(m=!1)}}}}function Ug(e,t,n){let r=new ImageData(e,t);for(let i=0;i<t;i+=1)for(let t=0;t<e;t+=1)Rg(r,t,i,n);return r}var Wg=!1,Gg=new Set;function Kg(){Gg.forEach(e=>e(Wg))}function qg(e){Wg!==e&&(Wg=e,Kg())}function Jg(e){e.button===0&&qg(!0)}function Yg(){qg(!1)}function Xg(){window.addEventListener(`pointerdown`,Jg,!0),window.addEventListener(`pointerup`,Yg,!0),window.addEventListener(`pointercancel`,Yg,!0),window.addEventListener(`blur`,Yg,!0)}typeof window<`u`&&Xg();function Zg(){return Wg}function Qg(e){return Gg.add(e),e(Wg),()=>Gg.delete(e)}var $g=4;function e_(e,t){return Math.max(1,Math.min(t,Math.round(e)))}function t_(e,t){let n=Math.abs(e),r=Math.abs(t);for(;r!==0;){let e=n%r;n=r,r=e}return Math.max(1,n)}function n_(e,t){let n=Math.max($g,Math.round(t)),r=e.length>0?e.map(e=>e_(e,n)):[1],i=1;for(let e of r){let t=e/t_(i,e);if(i>Math.floor(n/t))return n;i*=t}let a=Math.ceil($g/i)*i;return Math.min(n,Math.max(i,a))}function r_(e,t){let n=Math.max(1,Math.round(e)),r=Math.max(0,Math.min(.49,t)),i=Math.floor(r*n),a=Math.ceil((1-r)*n);return Math.max(1,a-i)}function i_(e,t){let n=Math.max(1,Math.round(e)),r=Math.max(0,Math.min(.49,t));if(r===0)return n;let i=Math.max(.02,1-r*2),a=Math.max(n,Math.ceil((n+2)/i)+16),o=n,s=1/0;for(let e=1;e<=a;e+=1){let t=r_(e,r),i=Math.abs(t-n);if(i<s&&(o=e,s=i),t===n)return e}return o}function a_(e,t){let n=Math.max(1,Math.round(t)),r=Math.max(0,Math.min(1,e));return Math.max(0,Math.min(n-1,Math.floor(r*n)))}function o_(e,t,n,r,i,a){let o=Math.max(1,Math.round(n)),s=Math.max(1,Math.round(a)),c=r+(Math.max(0,Math.min(o-1,Math.round(e)-Math.round(t)))+.5)/o*Math.max(1e-6,i);return Math.max(0,Math.min(s-1,Math.floor(c)))}var s_=384,c_=1e-6,l_=1e-4,u_=new Set([`Vorne`,`Hinten`,`Links`,`Rechts`,`Mantel`,`Rundung`,`Schräge`]),d_=new WeakMap,f_=new Map;Qg(e=>{if(e||f_.size===0)return;let t=[...f_.entries()];f_.clear(),t.forEach(([e,t])=>{let n=x_(e,t.scale,t.atlas);t.target.splice(0,t.target.length,...n),d_.set(e,t.target)})});function p_(e,t){return e.index?.getX(t)??t}function m_(e,t){return new K(e.getX(t),e.getY(t),e.getZ(t))}function h_(e,t){return new Er(e.getX(t),e.getY(t))}function g_(e,t,n){let r=e.islands[t];if(!r)return null;let i=r.uMax-r.uMin,a=r.vMax-r.vMin;return i<=c_||a<=c_?null:new Er((n.x-r.uMin)/i,(n.y-r.vMin)/a)}function __(e,t){return new K(e.x*t.x,e.y*t.y,e.z*t.z)}function v_(e){return e.replace(/\s+\d+$/u,``)}function y_(e,t){switch(v_(e)){case`Vorne`:case`Hinten`:return{width:t.x,height:t.y};case`Links`:case`Rechts`:return{width:t.z,height:t.y};case`Oben`:case`Unten`:return{width:t.x,height:t.z};default:{let e=[t.x,t.y,t.z].sort((e,t)=>t-e);return{width:e[0]??1,height:e[1]??e[0]??1}}}}function b_(e){let t=Math.max(c_,e)*32,n=Math.round(t),r=Math.abs(t-n)<=l_?n:t,i=Math.max(1,Math.ceil(r)),a=Math.min(s_,i);return{pixels:a,coverage:i===a?Hi.clamp(r/a,1/a,1):1}}function x_(e,t,n){let r=e.getAttribute(`position`),i=e.getAttribute(`uv`),a=new K(Math.abs(t[0]),Math.abs(t[1]),Math.abs(t[2]));e.computeBoundingBox();let o=(e.boundingBox?.clone()??new Xa(new K(-.5,-.5,-.5),new K(.5,.5,.5))).getSize(new K),s=new K(Math.abs(o.x*a.x),Math.abs(o.y*a.y),Math.abs(o.z*a.z)),c=n.islands.map(()=>({width:0,height:0,weight:0}));if(r&&i&&r.count>=3&&i.count>=3){let t=e.index?.count??r.count;for(let o=0;o+2<t;o+=3){let t=p_(e,o),s=p_(e,o+1),l=p_(e,o+2),u=m_(r,t),d=m_(r,s),f=m_(r,l),p=h_(i,t),m=h_(i,s),h=h_(i,l),g=ra(n,p.clone().add(m).add(h).multiplyScalar(1/3)),_=c[g];if(!_)continue;let v=g_(n,g,p),y=g_(n,g,m),b=g_(n,g,h);if(!v||!y||!b)continue;let x=d.clone().sub(u),S=f.clone().sub(u),C=y.clone().sub(v),w=b.clone().sub(v),T=C.x*w.y-C.y*w.x;if(Math.abs(T)<=c_)continue;let E=1/T,D=x.clone().multiplyScalar(w.y).sub(S.clone().multiplyScalar(C.y)).multiplyScalar(E),O=S.clone().multiplyScalar(C.x).sub(x.clone().multiplyScalar(w.x)).multiplyScalar(E),k=__(D,a).length(),A=__(O,a).length(),j=__(x,a).cross(__(S,a)).length()*.5,M=Math.max(c_,j);_.width+=k*M,_.height+=A*M,_.weight+=M}}return n.islands.map((e,t)=>{let n=c[t],r=y_(e.label,s),i=n&&n.weight>c_?n.width/n.weight:r.width,a=n&&n.weight>c_?n.height/n.weight:r.height,o=b_(i),l=b_(a);return{label:e.label,width:o.pixels,height:l.pixels,coverageU:o.coverage,coverageV:l.coverage,worldWidth:i,worldHeight:a}})}function S_(e,t,n){let r=d_.get(e);if(r&&Zg())return f_.set(e,{scale:[t[0],t[1],t[2]],atlas:n,target:r}),r;let i=x_(e,t,n);return d_.set(e,i),i}function C_(e){return u_.has(v_(e))}function w_(e,t){return Math.max(0,Math.floor(e/2)-Math.floor(t/2))}function T_(e){let t=Hi.clamp(e.coverageU,c_,1),n=Hi.clamp(e.coverageV,c_,1);return{offsetU:(1-t)*.5,offsetV:C_(e.label)?0:(1-n)*.5,scaleU:t,scaleV:n}}function E_(e){let t=e.getContext(`2d`,{willReadFrequently:!0});if(!t)throw Error(`2D-Kontext für Flächenraster nicht verfügbar.`);return t.imageSmoothingEnabled=!1,t}function D_(e,t,n,r){let i=Pg(t),a=Pg(n);for(let t=0;t<e.data.length;t+=4){let n=e.data[t]??0,o=e.data[t+1]??0,s=e.data[t+2]??0,c=e.data[t+3]??0;(r===2?c===254:c>0&&Math.abs(n-i.r)<=3&&Math.abs(o-i.g)<=3&&Math.abs(s-i.b)<=3)&&(e.data[t]=a.r,e.data[t+1]=a.g,e.data[t+2]=a.b,e.data[t+3]=254)}}function O_(e,t,n,r){let i=E_(e),a=i.getImageData(0,0,e.width,e.height);D_(a,t,n,r),i.putImageData(a,0,0)}function k_(e){let t=E_(e),n=t.getImageData(0,0,e.width,e.height),r=!1;for(let e=3;e<n.data.length;e+=4)n.data[e]===254&&(n.data[e]=255,r=!0);r&&t.putImageData(n,0,0)}function A_(e,t,n){let r=document.createElement(`canvas`);return r.width=Math.max(1,e),r.height=Math.max(1,t),E_(r).putImageData(Ug(r.width,r.height,Pg(n,254)),0,0),r}function j_(e){let t=document.createElement(`canvas`);return t.width=e.width,t.height=e.height,E_(t).drawImage(e,0,0),t}function M_(e,t){let n=Math.max(1,Math.min(t.width,e.width)),r=Math.max(1,Math.min(t.height,e.height));return{x:w_(e.width,n),y:C_(t.label)?Math.max(0,e.height-r):w_(e.height,r),width:n,height:r}}function N_(e,t){let n=M_(e,t),r=document.createElement(`canvas`);return r.width=Math.max(1,t.width),r.height=Math.max(1,t.height),E_(r).drawImage(e,n.x,n.y,n.width,n.height,0,0,r.width,r.height),k_(r),r}function P_(e,t,n){let r=Math.max(e.width,t.width),i=Math.max(e.height,t.height);if(e.width===r&&e.height===i)return j_(e);let a=A_(r,i,n),o=E_(e),s=E_(a),c=o.getImageData(0,0,e.width,e.height),l=s.getImageData(0,0,a.width,a.height),u=w_(a.width,e.width),d=C_(t.label)?a.height-e.height:w_(a.height,e.height);for(let t=0;t<e.height;t+=1){let n=t+d;if(!(n<0||n>=a.height))for(let r=0;r<e.width;r+=1){let i=r+u;if(i<0||i>=a.width)continue;let o=(t*e.width+r)*4,s=(n*a.width+i)*4;l.data[s]=c.data[o]??0,l.data[s+1]=c.data[o+1]??0,l.data[s+2]=c.data[o+2]??0,l.data[s+3]=c.data[o+3]??0}}return s.putImageData(l,0,0),a}function F_(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>t(r),r.onerror=()=>n(Error(`Bemalung konnte nicht geladen werden.`)),r.src=e})}async function I_(e,t,n,r){if(!e)return n.map(e=>A_(e.width,e.height,r));let i=e.surfaceGrid,a=(i?.version===1||i?.version===2)&&i.atlasSignature===t.signature&&i.surfaces.length===t.islands.length,o=a&&!!i.sourceDataUrl&&!!i.sourceWidth&&!!i.sourceHeight,s=o&&i.sourceDataUrl?i.sourceDataUrl:e.dataUrl,c=o&&i.sourceWidth?i.sourceWidth:e.width,l=o&&i.sourceHeight?i.sourceHeight:e.height,u=await F_(s);return n.map((e,n)=>{let o=nr(t,n,c,l),s=Math.max(1,o.maxX-o.minX+1),d=Math.max(1,o.maxY-o.minY+1),f=a?i.surfaces[n]:void 0,p=Math.max(1,f?.sourceWidth??f?.width??e.width),m=Math.max(1,f?.sourceHeight??f?.height??e.height),h=document.createElement(`canvas`);return h.width=p,h.height=m,E_(h).drawImage(u,o.minX,o.minY,s,d,0,0,p,m),O_(h,i?.baseColor??r,r,i?.version??1),P_(h,e,r)})}function L_(e,t,n){return t.map((t,r)=>P_(e[r]??A_(t.width,t.height,n),t,n))}function R_(e,t){let n=n_(e.map(e=>e.width),s_),r=n_(e.map(e=>e.height),s_),i=i_(n,t.padding),a=i_(r,t.padding);return{cellWidth:i,cellHeight:a,canvasWidth:Math.max(1,t.columns*i),canvasHeight:Math.max(1,t.rows*a)}}function z_(e,t,n,r,i=!1){let a=R_(n,t),o=document.createElement(`canvas`);o.width=a.canvasWidth,o.height=a.canvasHeight;let s=E_(o);return s.clearRect(0,0,o.width,o.height),t.islands.forEach((i,a)=>{let c=n[a];if(!c)return;let l=e[a]??A_(c.width,c.height,r),u=nr(t,a,o.width,o.height),d=Math.max(1,u.maxX-u.minX+1),f=Math.max(1,u.maxY-u.minY+1),p=M_(l,c),m=T_(c),h=p.x+m.offsetU*p.width,g=p.y+(1-m.offsetV-m.scaleV)*p.height,_=Math.max(c_,m.scaleU*p.width),v=Math.max(c_,m.scaleV*p.height);s.drawImage(l,h,g,_,v,u.minX,u.minY,d,f)}),i||k_(o),o}function B_(e,t,n,r){let i=z_(e,t,n,r),a=z_(e,t,n.map((t,n)=>({...t,width:e[n]?.width??t.width,height:e[n]?.height??t.height,coverageU:1,coverageV:1})),r,!0),o={version:2,atlasSignature:t.signature,pixelsPerWorldUnit:32,baseColor:r.toUpperCase(),surfaces:n.map(({label:t,width:n,height:r,coverageU:i,coverageV:a},o)=>({label:t,width:n,height:r,coverageU:i,coverageV:a,sourceWidth:e[o]?.width??n,sourceHeight:e[o]?.height??r})),sourceDataUrl:a.toDataURL(`image/png`),sourceWidth:a.width,sourceHeight:a.height};return{dataUrl:i.toDataURL(`image/png`),width:i.width,height:i.height,pixelated:!0,surfaceGrid:o}}function V_(e,t,n){let r=document.createElement(`canvas`);r.width=t.width,r.height=t.height;let i=E_(r),a=n?M_(e,n):{x:0,y:0,width:e.width,height:e.height};return i.drawImage(e,a.x,a.y,a.width,a.height,0,0,r.width,r.height),r}function H_(e,t,n,r){let i=ra(e,n),a=t[i];if(!e.islands[i]||!a)return null;let o=R_(t,e),s=nr(e,i,o.canvasWidth,o.canvasHeight),c=Math.max(1,s.maxX-s.minX+1),l=Math.max(1,s.maxY-s.minY+1),u=a_(n.x,o.canvasWidth),d=a_(1-n.y,o.canvasHeight),f=r?.[i],p=f?M_(f,a):{x:0,y:0,width:a.width,height:a.height},m=T_(a),h=p.x+m.offsetU*p.width,g=p.y+(1-m.offsetV-m.scaleV)*p.height,_=Math.max(c_,m.scaleU*p.width),v=Math.max(c_,m.scaleV*p.height),y=f?.width??a.width,b=f?.height??a.height;return{islandIndex:i,point:[o_(u,s.minX,c,h,_,y),o_(d,s.minY,l,g,v,b)]}}function U_(e){return e.map(e=>[e.label,e.width,e.height,e.coverageU.toFixed(6),e.coverageV.toFixed(6)].join(`:`)).join(`|`)}function W_(e){return e.map(e=>`${e.width}x${e.height}`).join(`|`)}var G_=1,K_=8,q_=-1,J_={enabled:!1,tool:`brush`,color:`#AEB8BE`,brushSize:G_,eraseAll:!1,islandIndex:q_,cameraView:null,cameraRequestId:0},Y_=new Set;function X_(e,t,n){let r=Math.round(e);return n===void 0?Math.max(t,r):Math.max(t,Math.min(n,r))}function Z_(e,t){return{...e,...t,brushSize:t.brushSize===void 0?e.brushSize:X_(t.brushSize,G_,K_),islandIndex:t.islandIndex===void 0?e.islandIndex:X_(t.islandIndex,q_)}}function Q_(){Y_.forEach(e=>e(J_))}function $_(){return J_}function ev(e){J_=Z_(J_,e),Q_()}function tv(e){ev({cameraView:e,cameraRequestId:J_.cameraRequestId+1})}function nv(e){return Y_.add(e),e(J_),()=>Y_.delete(e)}function rv(e,t){return e?.surfaceGrid?{...e,surfaceGrid:{...e.surfaceGrid,baseColor:t.toUpperCase()}}:e}function iv(e,t,n,r){return rv(B_(e,t,n,r),r)}function av(e,t,n,r){if(!e)return!1;let i=e.surfaceGrid;return!i||i.version!==2||i.atlasSignature!==t.signature||i.baseColor?.toUpperCase()!==r.toUpperCase()||!i.sourceDataUrl||!i.sourceWidth||!i.sourceHeight||i.surfaces.length!==n.length||i.surfaces.some((e,t)=>{let r=n[t];return!r||!e.sourceWidth||!e.sourceHeight||e.width!==r.width||e.height!==r.height||Math.abs(e.coverageU-r.coverageU)>1e-6||Math.abs(e.coverageV-r.coverageV)>1e-6})}async function ov(e,t,n,r){return iv(await I_(e,t,n,r),t,n,r)}var sv=`Dunkelviolett.Dämmerungsblau.Tiefblau.Kräftiges Blau.Königsblau.Lavendelblau.Helles Lavendel.Marineblau-Violett.Aubergine.Traube.Violett.Lila.Zartes Violett.Helles Lila.Dunkle Pflaume.Tiefes Violett.Samtig Lila.Kräftiges Lila.Amethyst.Malve.Helllila.Dunkles Rubin.Pflaume.Helles Lila.Strahlendes Violett.Magenta.Blassviolett.Flieder.Tiefes Amethyst.Karminrot.Maulbeere.Helles Pink.Pink.Nelkenrosa.Zuckerwatte Pink.Tiefes Purpurrot.Kirschholz.Kirschrot.Tomatenrot.Erdbeerrosa.Helle Koralle.Rosenwasser.Kastanienbraun.Dunkelrot.Kirschrot.Knallrot.Korallenrot.Koralle.Pastellrosa.Rotbraun.Rostbraun.Korallenorange.Lachsfarben.Orange.Apricot.Pfirsich.Sattes Braun.Mittleres Braun.Dunkelorange.Warmes Orange.Pfirsich.Elfenbein.Vanille.Goldbraun.Sonnenscheingold.Sonnengelb.Helle Zitrone.Gelb.Löwenzahn.Hellgelb.Tiefes Moos.Moosgrün.Helles Khaki.Helles Grün.Limette.Helle Limette.Pastell-Limette.Tiefgrün.Waldgrün.Spritzige Limette.Grasgrün.Elektrogrün.Pastellgrün.Frühlingsnebel.Smaragdgrüne Nacht.Grüner Nebel.Grün.Meerschaum.Meeresbrise.Eiskalt.Eisiges Blaugrün.Tiefes Smaragdgrün.Tiefsee.Bergwiese.Zartes Blaugrün.Helle Jade.Gletscherblau.Hellblau.Evergreen.Tiefes Indigo.Tropisches Blaugrün.Kristall-Lagune.Türkisblau.Frostige Minze.Heller Himmel.Mitternachtsblaugrün.Tiefes Blaugrün.Dunkeltürkis.Aquablau.Strahlender Himmel.Aquamarinblau.Weißes Eis.Dunkles Ozeanblau.Dunkles Blaugrün.Helles Blau.Hellblau.Kristallblau.Puderblau.Mattierte Minze.Tiefsee.Meeresblau.Kobaltblau.Saphirblau.Zartblau.Eisblau.Blassblau`.split(`.`),cv=`#000B3D.#00167A.#0025CC.#1F48FF.#5271FF.#99ACFF.#C2CDFF.#020C45.#2C0A71.#4910BC.#5E17EB.#8C52FF.#BEA1F7.#D8C7FA.#200934.#401268.#6B1FAD.#9440DD.#B174E7.#CEA8F0.#E2CBF6.#2B0934.#561269.#8F1EAE.#BC3FDE.#CB6CE6.#E1A8F0.#EDCBF6.#3D0026.#7A004B.#CC007E.#FF1FA9.#FF66C4.#FF99D8.#FFC2E8.#330A0A.#661414.#FF2828.#FF3A3A.#FF5050.#FFADAD.#FFD6D6.#3D0000.#7A0000.#CC0000.#FF3131.#FF5757.#FF9999.#FFC2C2.#3D1700.#7A2F00.#CC4E00.#FF751F.#FF914D.#FFC099.#FFD9C2.#3D2500.#7A4900.#CC7A00.#FFA51F.#FFBD59.#FFD699.#FFE7C2.#3D3100.#7A6200.#CCA300.#FFD21F.#FFDE59.#FFEB99.#FFF3C2.#233D00.#457A00.#74CC00.#9EFF1F.#C1FF72.#D3FF99.#E4FFC2.#17320B.#2E6417.#4CA626.#7ED957.#99E17A.#BFECAC.#D9F4CD.#003D20.#007A3F.#00BF63.#1FFF93.#5CFFB0.#99FFCE.#C2FFE1.#053827.#0A714E.#10BB82.#31EDAE.#69F2C4.#A1F7DA.#C7FAE9.#083335.#11676A.#1CABB0.#3DDBE1.#5CE1E6.#A7EFF1.#CAF5F7.#00343D.#00687A.#0097B2.#0CC0DF.#5CE7FF.#99F0FF.#C2F6FF.#00273D.#004E7A.#0081CC.#38B6FF.#70CBFF.#99DAFF.#C2E9FF.#001B3D.#00357A.#004AAD.#1F80FF.#5CA3FF.#99C5FF.#C2DCFF`.split(`.`).map((e,t)=>({hex:e,name:sv[t]??e})),lv=[{name:`Weiß`,hex:`#FFFFFF`},{name:`Schwarz`,hex:`#11161A`},{name:`Knallrot`,hex:`#FF3131`},{name:`Lachsfarben`,hex:`#FF751F`},{name:`Sonnengelb`,hex:`#FFD21F`},{name:`Grün`,hex:`#00BF63`},{name:`Aquablau`,hex:`#0CC0DF`},{name:`Kräftiges Blau`,hex:`#1F48FF`},{name:`Lila`,hex:`#8C52FF`},{name:`Helles Pink`,hex:`#FF1FA9`}];function uv(e){return e.toUpperCase()}function dv({entry:e,selected:t,className:n,onSelect:r}){return(0,Q.jsx)(`button`,{type:`button`,className:`${n}${t?` selected`:``}`,style:{backgroundColor:e.hex},title:`${e.name} · ${e.hex}`,"aria-label":`${e.name}, ${e.hex}`,"aria-pressed":t,onClick:()=>r(e.hex)})}function fv({value:e,onChange:t}){let[n,r]=(0,Y.useState)(!1),[i,a]=(0,Y.useState)(`grid`),o=uv(e);return(0,Q.jsxs)(`div`,{className:`standard-color-picker`,children:[(0,Q.jsxs)(`div`,{className:`standard-color-row-heading`,children:[(0,Q.jsx)(`span`,{children:`Grundfarben`}),(0,Q.jsx)(`button`,{type:`button`,className:`standard-color-all-button`,onClick:()=>r(!0),children:`Alle ansehen`})]}),(0,Q.jsx)(`div`,{className:`standard-color-preview`,"aria-label":`Grundfarben`,children:lv.map(e=>(0,Q.jsx)(dv,{entry:e,selected:o===e.hex,className:`standard-color-preview-swatch`,onSelect:t},e.hex))}),n&&(0,Q.jsxs)(`div`,{className:`standard-color-overlay`,role:`dialog`,"aria-modal":`true`,"aria-label":`Standard-Vollfarben`,children:[(0,Q.jsxs)(`div`,{className:`standard-color-overlay-header`,children:[(0,Q.jsx)(`button`,{type:`button`,className:`standard-color-header-button standard-color-back-button`,"aria-label":`Zurück`,title:`Zurück`,onClick:()=>r(!1),children:`←`}),(0,Q.jsx)(`strong`,{children:`Standard-Vollfarben`}),(0,Q.jsxs)(`div`,{className:`standard-color-header-actions`,children:[(0,Q.jsx)(`button`,{type:`button`,className:`standard-color-header-button standard-color-view-button`,"aria-label":i===`grid`?`Listenansicht`:`Rasteransicht`,title:i===`grid`?`Listenansicht`:`Rasteransicht`,onClick:()=>a(e=>e===`grid`?`list`:`grid`),children:i===`grid`?`☷`:`▦`}),(0,Q.jsx)(`button`,{type:`button`,className:`standard-color-header-button standard-color-close-button`,"aria-label":`Schließen`,title:`Schließen`,onClick:()=>r(!1),children:`×`})]})]}),(0,Q.jsx)(`div`,{className:`standard-color-overlay-scroll`,children:i===`grid`?(0,Q.jsx)(`div`,{className:`standard-color-grid`,style:{gridTemplateColumns:`repeat(7, minmax(0, 1fr))`},children:cv.map(e=>(0,Q.jsx)(dv,{entry:e,selected:o===e.hex,className:`standard-color-grid-swatch`,onSelect:t},e.hex))}):(0,Q.jsx)(`div`,{className:`standard-color-list`,children:cv.map(e=>(0,Q.jsxs)(`button`,{type:`button`,className:o===e.hex?`standard-color-list-entry selected`:`standard-color-list-entry`,"aria-pressed":o===e.hex,onClick:()=>t(e.hex),children:[(0,Q.jsx)(`span`,{className:`standard-color-list-swatch`,style:{backgroundColor:e.hex}}),(0,Q.jsx)(`span`,{className:`standard-color-list-name`,children:e.name}),(0,Q.jsx)(`span`,{className:`standard-color-list-hex`,children:e.hex})]},`${e.name}:${e.hex}`))})})]})]})}function pv(e,t){let n=[],[r,i]=e,[a,o]=t,s=Math.abs(a-r),c=r<a?1:-1,l=-Math.abs(o-i),u=i<o?1:-1,d=s+l;for(;n.push([r,i]),!(r===a&&i===o);){let e=d*2;e>=l&&(d+=l,r+=c),e<=s&&(d+=s,i+=u)}return n}function mv(e){let t=e.replace(/\s+\d+$/u,``);return t===`Vorne`?`front`:t===`Hinten`?`back`:t===`Links`?`left`:t===`Rechts`?`right`:t===`Oben`?`top`:t===`Unten`?`bottom`:null}function hv(e,t,n){let r=new K(0,1,0);switch(e){case`perspective`:return{position:t.clone().add(new K(6,5,7)),up:r};case`focus`:return{position:t.clone().add(new K(n,n*.65,n)),up:r};case`front`:return{position:t.clone().add(new K(0,0,n)),up:r};case`back`:return{position:t.clone().add(new K(0,0,-n)),up:r};case`left`:return{position:t.clone().add(new K(-n,0,0)),up:r};case`right`:return{position:t.clone().add(new K(n,0,0)),up:r};case`top`:return{position:t.clone().add(new K(0,n,.001)),up:new K(0,0,-1)};case`bottom`:return{position:t.clone().add(new K(0,-n,.001)),up:new K(0,0,1)}}}var gv=[{tool:`brush`,label:`Pinsel`},{tool:`eraser`,label:`Radierer`},{tool:`fill`,label:`Füllen`},{tool:`eyedropper`,label:`Pipette`}];function _v(e,t){let n=`Fläche ${e+1}`;return/^Fläche\s+\d+$/i.test(t)?n:`${n} · ${t}`}function vv(e){e.closest(`details`)?.removeAttribute(`open`)}function yv(e,t,n){let r=e.getBoundingClientRect();return[Math.max(0,Math.min(e.width-1,Math.floor((t-r.left)/r.width*e.width))),Math.max(0,Math.min(e.height-1,Math.floor((n-r.top)/r.height*e.height)))]}function bv(e,t,n){let r=e.getBoundingClientRect();return t>=r.left&&t<=r.right&&n>=r.top&&n<=r.bottom}function xv(e){return e.map(e=>{let t=e.getContext(`2d`,{willReadFrequently:!0});return t?t.getImageData(0,0,e.width,e.height):new ImageData(e.width,e.height)})}function Sv(e){return e.map(e=>{let t=document.createElement(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`,{willReadFrequently:!0});return n&&(n.imageSmoothingEnabled=!1,n.putImageData(e,0,0)),t})}function Cv({objectId:e,baseColor:t,texture:n,atlas:r,metrics:i,onCommit:a,onPaintModeChange:o}){let s=(0,Y.useRef)(null),c=(0,Y.useRef)([]),l=(0,Y.useRef)(!1),u=(0,Y.useRef)(null),d=(0,Y.useRef)(null),f=(0,Y.useRef)([]),p=(0,Y.useRef)([]),m=(0,Y.useRef)(``),h=(0,Y.useRef)(0),[g,_]=(0,Y.useState)(`brush`),[v,y]=(0,Y.useState)(t),[b,x]=(0,Y.useState)(1),[S,C]=(0,Y.useState)(!1),[w,T]=(0,Y.useState)(!1),[E,D]=(0,Y.useState)(-1),[O,k]=(0,Y.useState)(-1),[A,j]=(0,Y.useState)(0),[M,N]=(0,Y.useState)(0),P=W_(i),F=U_(i),I=(e=E)=>{let n=s.current,a=n?.getContext(`2d`,{willReadFrequently:!0});if(!n||!a||c.current.length===0)return;if(a.imageSmoothingEnabled=!1,e<0){let e=z_(c.current,r,i,t);n.width=e.width,n.height=e.height,a.clearRect(0,0,n.width,n.height),a.drawImage(e,0,0);return}let o=c.current[e],l=i[e];if(!o||!l)return;let u=N_(o,l);n.width=u.width,n.height=u.height,a.clearRect(0,0,n.width,n.height),a.drawImage(u,0,0)},L=()=>{if(c.current.length===0)return;let n=iv(c.current,r,i,t);m.current=`${e}:${n.dataUrl}:${r.signature}:${P}`,a(n)},ee=()=>{c.current.length!==0&&(f.current=[...f.current.slice(-29),xv(c.current)],p.current=[],j(f.current.length),N(p.current.length))};(0,Y.useEffect)(()=>nv(e=>{T(e.enabled),_(e.tool),y(e.color),x(e.brushSize),C(e.eraseAll),D(Math.min(Math.max(-1,e.islandIndex),Math.max(0,r.islands.length-1)))}),[r.islands.length]),(0,Y.useEffect)(()=>()=>{h.current+=1,ev({enabled:!1})},[]),(0,Y.useEffect)(()=>{let e=Math.min(Math.max(-1,E),Math.max(0,r.islands.length-1));if(e!==E){let t=window.setTimeout(()=>{D(e),ev({islandIndex:e})},0);return()=>window.clearTimeout(t)}I(e)},[r.signature,E,F]);let te=O>=r.islands.length?-1:O,ne=e=>{_(e),ev({tool:e})},R=e=>{let t=e.toUpperCase();y(t),ev({color:t})},z=e=>{x(e),ev({brushSize:e})},B=e=>{C(e),ev({eraseAll:e})},V=e=>{let t=Math.max(-1,Math.min(r.islands.length-1,e));if(D(t),ev({islandIndex:t}),t>=0){let e=mv(r.islands[t]?.label??``);e&&tv(e)}},re=(e,t)=>{V(e),vv(t)},ie=()=>{let e=!w;o?.(e),ev({enabled:e})};(0,Y.useEffect)(()=>{let a=`${e}:${n?.dataUrl??t}:${r.signature}:${P}`;if(m.current===a)return;let o=++h.current;I_(n,r,i,t).then(e=>{h.current===o&&(c.current=e,m.current=a,f.current=[],p.current=[],I(),j(f.current.length),N(p.current.length),av(n,r,i,t)&&L())}).catch(()=>void 0)},[r.signature,t,P,e,n?.dataUrl,n?.height,n?.width]),(0,Y.useEffect)(()=>{c.current.length!==0&&(c.current=L_(c.current,i,t),I(),n&&L())},[F]);let ae=e=>{let t=e.currentTarget;if(!bv(t,e.clientX,e.clientY))return null;let[n,a]=yv(t,e.clientX,e.clientY);if(E>=0){let e=c.current[E],t=i[E];if(!e||!t)return null;let r=M_(e,t);return{islandIndex:E,point:[r.x+Math.max(0,Math.min(r.width-1,n)),r.y+Math.max(0,Math.min(r.height-1,a))]}}let o=ji(r,t.width,t.height,n,a),s=c.current[o],l=i[o];if(!s||!l)return null;let u=nr(r,o,t.width,t.height);if(n<u.minX||n>u.maxX||a<u.minY||a>u.maxY)return null;let d=Math.max(1,u.maxX-u.minX+1),f=Math.max(1,u.maxY-u.minY+1),p=Math.max(0,Math.min(.999999,(n-u.minX+.5)/d)),m=Math.max(0,Math.min(.999999,(a-u.minY+.5)/f)),h=T_(l),g=M_(s,l),_=g.x+(h.offsetU+p*h.scaleU)*g.width,v=g.y+(1-h.offsetV-h.scaleV+m*h.scaleV)*g.height;return{islandIndex:o,point:[Math.max(0,Math.min(s.width-1,Math.floor(_))),Math.max(0,Math.min(s.height-1,Math.floor(v)))]}},oe=(e,n,r)=>{let i=c.current[e],a=i?.getContext(`2d`,{willReadFrequently:!0});if(!i||!a)return;let o=a.getImageData(0,0,i.width,i.height);if(g===`eyedropper`){let e=Bg(o,n[0],n[1]);e.a>0&&R(Fg(e));return}if(g===`fill`)Hg(o,n[0],n[1],Pg(v));else{let e=g===`eraser`?S?Pg(`#000000`,0):Pg(t,254):Pg(v);pv(r??n,n).forEach(([t,n])=>Vg(o,t,n,b,e))}a.putImageData(o,0,0),I()},se=e=>{e.preventDefault();let t=ae(e);if(t){if(g===`eyedropper`){oe(t.islandIndex,t.point);return}if(ee(),oe(t.islandIndex,t.point),g===`fill`){L();return}l.current=!0,u.current=t.islandIndex,d.current=t.point,e.currentTarget.setPointerCapture(e.pointerId)}},ce=e=>{if(!l.current||g!==`brush`&&g!==`eraser`)return;let t=ae(e);if(!t){u.current=null,d.current=null;return}let n=u.current===t.islandIndex;oe(t.islandIndex,t.point,n?d.current??t.point:t.point),u.current=t.islandIndex,d.current=t.point},le=e=>{l.current&&(l.current=!1,u.current=null,d.current=null,e.currentTarget.hasPointerCapture(e.pointerId)&&e.currentTarget.releasePointerCapture(e.pointerId),L())},ue=()=>{let e=c.current[E],t=i[E];if(!e||!t||E<0)return;let n=te<0?r.islands.map((e,t)=>t).filter(e=>e!==E):[te];if(n.length===0||n.includes(E))return;ee();let a=c.current.map(j_);n.forEach(n=>{let r=i[n];r&&(a[n]=V_(e,r,t))}),c.current=a,I(),L()},de=()=>{let e=f.current.at(-1);!e||c.current.length===0||(f.current=f.current.slice(0,-1),p.current=[xv(c.current),...p.current].slice(0,30),c.current=Sv(e),I(),L(),j(f.current.length),N(p.current.length))},fe=()=>{let e=p.current[0];!e||c.current.length===0||(f.current=[...f.current.slice(-29),xv(c.current)],p.current=p.current.slice(1),c.current=Sv(e),I(),L(),j(f.current.length),N(p.current.length))},pe=()=>{f.current=[],p.current=[],m.current=``,c.current=[],a(void 0),j(f.current.length),N(p.current.length)},me=E>=0?r.islands[E]:void 0,he=E<0?`Fläche X · Gesamtübersicht`:_v(E,me?.label??`Oberfläche`),ge=r.islands.length<2||E<0||te===E;return(0,Q.jsxs)(`div`,{className:`paint-editor`,children:[(0,Q.jsx)(`button`,{type:`button`,className:w?`paint-mode-button active`:`paint-mode-button`,"aria-pressed":w,onClick:ie,children:`Auf Form malen`}),(0,Q.jsx)(`div`,{className:`paint-tool-grid`,children:gv.map(e=>(0,Q.jsx)(`button`,{type:`button`,className:g===e.tool?`paint-tool-button active`:`paint-tool-button`,"aria-pressed":g===e.tool,onClick:()=>ne(e.tool),children:e.label},e.tool))}),(g===`brush`||g===`eraser`)&&(0,Q.jsxs)(`div`,{className:`range-row paint-brush-size`,children:[(0,Q.jsx)(`label`,{children:`Pinselgröße`}),(0,Q.jsx)(`input`,{type:`range`,min:1,max:8,step:1,value:b,onChange:e=>z(Number(e.target.value))}),(0,Q.jsxs)(`span`,{children:[b,`px`]})]}),g===`eraser`&&(0,Q.jsxs)(`label`,{className:`paint-eraser-all`,title:`Vollständig transparent radieren`,children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:S,onChange:e=>B(e.target.checked)}),(0,Q.jsx)(`span`,{children:`Alles`})]}),(0,Q.jsxs)(`div`,{className:`paint-surface-block`,children:[(0,Q.jsxs)(`div`,{className:`field-row paint-surface-field`,children:[(0,Q.jsx)(`label`,{children:`Fläche`}),(0,Q.jsxs)(`details`,{className:`paint-surface-picker`,children:[(0,Q.jsx)(`summary`,{children:he}),(0,Q.jsxs)(`div`,{className:`paint-surface-options`,children:[(0,Q.jsx)(`button`,{type:`button`,className:E===-1?`active`:``,onClick:e=>re(-1,e.currentTarget),children:`Fläche X · Gesamtübersicht`}),r.islands.map((e,t)=>(0,Q.jsx)(`button`,{type:`button`,className:E===t?`active`:``,onClick:e=>re(t,e.currentTarget),children:_v(t,e.label)},`${e.label}:${t}`))]})]})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Kopieren nach`}),(0,Q.jsxs)(`select`,{value:te,onChange:e=>k(Number(e.target.value)),children:[(0,Q.jsx)(`option`,{value:-1,children:`Alle Flächen`}),r.islands.map((e,t)=>(0,Q.jsx)(`option`,{value:t,children:_v(t,e.label)},`copy:${e.label}:${t}`))]})]}),(0,Q.jsx)(`button`,{type:`button`,className:`paint-copy-button`,disabled:ge,onClick:ue,children:`Kopieren`})]}),(0,Q.jsx)(`div`,{className:`paint-surface-preview-title`,children:he}),(0,Q.jsx)(`div`,{className:`paint-canvas-shell paint-canvas-switch`,children:(0,Q.jsx)(`canvas`,{ref:s,onPointerDown:se,onPointerMove:ce,onPointerUp:le,onPointerCancel:le})},E),(0,Q.jsxs)(`div`,{className:`paint-history-actions`,children:[(0,Q.jsx)(`button`,{type:`button`,disabled:A===0,onClick:de,children:`Rückgängig`}),(0,Q.jsx)(`button`,{type:`button`,disabled:M===0,onClick:fe,children:`Wiederholen`}),(0,Q.jsx)(`button`,{type:`button`,className:`danger`,disabled:!n,onClick:pe,children:`Entfernen`})]})]})}var wv=e=>Number(e.toFixed(3));function Tv({label:e,value:t,unit:n,onChange:r}){let i=t.map(e=>wv(n===`deg`?e*180/Math.PI:e));return(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:e}),(0,Q.jsx)(`div`,{className:`vector-grid`,children:[`X`,`Y`,`Z`].map((e,t)=>(0,Q.jsxs)(`label`,{children:[e,(0,Q.jsx)(`input`,{type:`number`,step:.001,value:i[t],onChange:e=>{let a=[...i];a[t]=wv(Number(e.target.value)),r(n===`deg`?a.map(e=>e*Math.PI/180):a.map(wv))}})]},e))})]})}function Ev({label:e,value:t,min:n,max:r,step:i,decimals:a=2,className:o,title:s,onChange:c}){let l=q(e=>e.beginTransaction),u=q(e=>e.endTransaction);return(0,Q.jsxs)(`div`,{className:`range-row${o?` ${o}`:``}`,title:s,children:[(0,Q.jsx)(`label`,{children:e}),(0,Q.jsx)(`input`,{type:`range`,min:n,max:r,step:i,value:t,onPointerDown:l,onPointerUp:u,onPointerCancel:u,onChange:e=>c(Number(e.target.value),!1)}),(0,Q.jsx)(`span`,{children:t.toFixed(a)})]})}function Dv({collapsed:e,onToggle:t}){return(0,Q.jsxs)(`div`,{className:`panel-header`,children:[!e&&(0,Q.jsx)(`span`,{className:`panel-title`,children:`Eigenschaften`}),(0,Q.jsx)(`button`,{type:`button`,className:`panel-collapse-button`,onClick:t,"aria-label":e?`Eigenschaften einblenden`:`Eigenschaften ausblenden`,title:e?`Eigenschaften einblenden`:`Eigenschaften ausblenden`,children:e?`‹`:`›`})]})}function Ov({collapsed:e,onToggle:t}){let n=q(e=>e.selectedId),r=q(e=>e.objects.find(e=>e.id===n)),i=q(e=>e.updateObject),a=q(e=>e.updateTransform),o=q(e=>e.updateMaterial),s=q(e=>e.duplicateObject),c=q(e=>e.deleteObject),[l,u]=(0,Y.useState)(`base`),[d,f]=(0,Y.useState)(`#AEB8BE`),p=(0,Y.useRef)(0);(0,Y.useEffect)(()=>nv(e=>{f(e.color)}),[]);let m=(0,Y.useMemo)(()=>{if(!r)return{atlas:Hn,metrics:[{label:`Oberfläche`,width:32,height:32,coverageU:1,coverageV:1,worldWidth:1,worldHeight:1}]};let e=Ur({type:r.type,geometry:r.geometry}),t=ui(e),n=S_(e,r.scale,t);return e.dispose(),{atlas:t,metrics:n}},[r?.geometry,r?.type,r?.scale[0],r?.scale[1],r?.scale[2]]);if(e)return(0,Q.jsx)(`aside`,{className:`panel right-panel panel-collapsed`,children:(0,Q.jsx)(Dv,{collapsed:!0,onToggle:t})});if(!r)return(0,Q.jsxs)(`aside`,{className:`panel right-panel`,children:[(0,Q.jsx)(Dv,{collapsed:!1,onToggle:t}),(0,Q.jsx)(`div`,{className:`properties-scroll-content`,children:(0,Q.jsx)(`div`,{className:`empty-state`,children:`Kein Objekt ausgewählt`})}),(0,Q.jsx)(`div`,{className:`panel-end-space`,"aria-hidden":`true`})]});let h=(e,t=!0)=>o(r.id,e,t),g=(e,t=!0)=>i(r.id,{geometry:{...r.geometry,...e}},t),_=l===`base`?r.material.color:d,v=e=>{let t=r.material.color,n=r.material.paintTexture,i=n?.dataUrl,a=++p.current;if(!n||t.toUpperCase()===e){h({color:e});return}let{atlas:s,metrics:c}=m;ov(n,s,c,e).then(t=>{let n=q.getState().objects.find(e=>e.id===r.id)?.material.paintTexture?.dataUrl;p.current!==a||n!==i||o(r.id,{color:e,paintTexture:t})}).catch(()=>void 0)};return(0,Q.jsxs)(`aside`,{className:`panel right-panel`,children:[(0,Q.jsx)(Dv,{collapsed:!1,onToggle:t}),(0,Q.jsxs)(`div`,{className:`properties-scroll-content`,children:[(0,Q.jsxs)(`section`,{className:`panel-section`,children:[(0,Q.jsx)(`h3`,{children:`Objekt`}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Name`}),(0,Q.jsx)(`input`,{value:r.name,onChange:e=>i(r.id,{name:e.target.value})})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Typ`}),(0,Q.jsx)(`input`,{value:r.type,readOnly:!0})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Sichtbar`}),(0,Q.jsx)(`input`,{type:`checkbox`,checked:r.visible,onChange:e=>i(r.id,{visible:e.target.checked})})]}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Gesperrt`}),(0,Q.jsx)(`input`,{type:`checkbox`,checked:r.locked,onChange:e=>i(r.id,{locked:e.target.checked})})]}),(0,Q.jsxs)(`div`,{className:`inline-actions`,children:[(0,Q.jsx)(`button`,{onClick:()=>s(r.id),children:`Duplizieren`}),(0,Q.jsx)(`button`,{className:`danger`,onClick:()=>c(r.id),children:`Löschen`})]})]}),(0,Q.jsxs)(`section`,{className:`panel-section`,children:[(0,Q.jsx)(`h3`,{children:`Transformation`}),(0,Q.jsx)(Tv,{label:`Position`,value:r.position,onChange:e=>a(r.id,`position`,e)}),(0,Q.jsx)(Tv,{label:`Rotation`,value:r.rotation,unit:`deg`,onChange:e=>a(r.id,`rotation`,e)}),(0,Q.jsx)(Tv,{label:`Skalierung`,value:r.scale,onChange:e=>a(r.id,`scale`,e)}),Sr(r.type)&&(0,Q.jsxs)(`div`,{className:`rounding-controls`,children:[(0,Q.jsx)(Ev,{className:`rounding-range-row`,label:`Ecken abrunden`,value:ga(r.geometry),min:0,max:100,step:1,decimals:0,title:`Bestimmt die Größe des Abrundungsradius.`,onChange:(e,t)=>g({cornerRoundness:e},t)}),(0,Q.jsx)(Ev,{className:`rounding-range-row`,label:`Eckkanten abrunden`,value:lr(r.geometry),min:0,max:100,step:1,decimals:0,title:`Bestimmt, wie weich die abgerundeten Kanten aufgebaut werden.`,onChange:(e,t)=>g({edgeRoundness:e},t)})]})]}),(0,Q.jsxs)(`section`,{className:`panel-section`,children:[(0,Q.jsx)(`h3`,{children:`Material & Farben`}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Vorlage`}),(0,Q.jsxs)(`select`,{defaultValue:``,onChange:e=>{let t=Ng[e.target.value];t&&h(t)},children:[(0,Q.jsx)(`option`,{value:``,children:`– auswählen –`}),Object.keys(Ng).map(e=>(0,Q.jsx)(`option`,{children:e},e))]})]}),(0,Q.jsxs)(`div`,{className:`merged-color-block`,children:[(0,Q.jsxs)(`div`,{className:`color-target-toggle`,children:[(0,Q.jsx)(`button`,{type:`button`,className:l===`base`?`color-target-button active`:`color-target-button`,onClick:()=>u(`base`),children:`Grundfarbe`}),(0,Q.jsx)(`button`,{type:`button`,className:l===`paint`?`color-target-button active`:`color-target-button`,onClick:()=>u(`paint`),children:`Malfarbe`})]}),(0,Q.jsx)(fv,{value:_,onChange:e=>{let t=e.toUpperCase();l===`base`?v(t):ev({color:t})}})]}),(0,Q.jsx)(Ev,{label:`Rauheit`,value:r.material.roughness,min:0,max:1,step:.01,onChange:(e,t)=>h({roughness:e},t)}),(0,Q.jsx)(Ev,{label:`Metallisch`,value:r.material.metalness,min:0,max:1,step:.01,onChange:(e,t)=>h({metalness:e},t)}),(0,Q.jsx)(Ev,{label:`Transparenz`,value:r.material.opacity,min:0,max:1,step:.01,onChange:(e,t)=>h({opacity:e},t)}),(0,Q.jsxs)(`div`,{className:`field-row`,children:[(0,Q.jsx)(`label`,{children:`Flat Shading`}),(0,Q.jsx)(`input`,{type:`checkbox`,checked:r.material.flatShading,onChange:e=>h({flatShading:e.target.checked})})]})]}),(0,Q.jsxs)(`section`,{className:`panel-section`,children:[(0,Q.jsx)(`h3`,{children:`Bemalung`}),(0,Q.jsx)(Cv,{objectId:r.id,baseColor:r.material.color,texture:r.material.paintTexture,atlas:m.atlas,metrics:m.metrics,onCommit:e=>{p.current+=1,h({paintTexture:rv(e,r.material.color)})},onPaintModeChange:e=>{e&&u(`paint`)}})]})]}),(0,Q.jsx)(`div`,{className:`panel-end-space`,"aria-hidden":`true`})]})}function kv({collapsed:e,onToggle:t}){let n=q(e=>e.objects),r=q(e=>e.selectedIds),i=q(e=>e.select),a=q(e=>e.updateObject),o=q(e=>e.duplicateObject),s=q(e=>e.deleteObject),c=q(e=>e.groupSelection),l=q(e=>e.ungroupSelection),u=n.filter(e=>r.includes(e.id)).some(e=>!!e.parentId);return(0,Q.jsxs)(`section`,{className:`panel hierarchy${e?` panel-collapsed`:``}`,children:[(0,Q.jsxs)(`div`,{className:`panel-header hierarchy-header`,children:[(0,Q.jsx)(`span`,{className:`panel-title`,children:`Objektliste`}),(0,Q.jsxs)(`div`,{className:`hierarchy-actions`,children:[!e&&(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`button`,{disabled:r.length<2,onClick:c,children:`Gruppieren`}),(0,Q.jsx)(`button`,{disabled:!u,onClick:l,children:`Aufheben`}),(0,Q.jsxs)(`span`,{children:[n.length,` Objekte`]})]}),(0,Q.jsx)(`button`,{type:`button`,className:`panel-collapse-button`,onClick:t,"aria-label":e?`Objektliste einblenden`:`Objektliste ausblenden`,title:e?`Objektliste einblenden`:`Objektliste ausblenden`,children:e?`⌃`:`⌄`})]})]}),!e&&(n.length===0?(0,Q.jsx)(`div`,{className:`empty-state`,children:`Füge links eine Form hinzu.`}):(0,Q.jsxs)(`table`,{className:`object-list`,children:[(0,Q.jsx)(`thead`,{children:(0,Q.jsxs)(`tr`,{children:[(0,Q.jsx)(`th`,{children:`S`}),(0,Q.jsx)(`th`,{children:`L`}),(0,Q.jsx)(`th`,{children:`Name`}),(0,Q.jsx)(`th`,{children:`Typ`}),(0,Q.jsx)(`th`,{children:`Aktionen`})]})}),(0,Q.jsx)(`tbody`,{children:n.map(e=>(0,Q.jsxs)(`tr`,{className:r.includes(e.id)?`selected`:``,onClick:t=>i(e.id,t.shiftKey),children:[(0,Q.jsx)(`td`,{children:(0,Q.jsx)(`button`,{className:`icon-button`,title:`Sichtbarkeit`,onClick:t=>{t.stopPropagation(),a(e.id,{visible:!e.visible})},children:e.visible?`●`:`○`})}),(0,Q.jsx)(`td`,{children:(0,Q.jsx)(`button`,{className:`icon-button`,title:`Sperren`,onClick:t=>{t.stopPropagation(),a(e.id,{locked:!e.locked})},children:e.locked?`◆`:`◇`})}),(0,Q.jsx)(`td`,{children:(0,Q.jsx)(`input`,{value:e.name,onClick:e=>e.stopPropagation(),onChange:t=>a(e.id,{name:t.target.value})})}),(0,Q.jsx)(`td`,{children:e.parentId?`${e.type} · Gruppe`:e.type}),(0,Q.jsxs)(`td`,{children:[(0,Q.jsx)(`button`,{className:`icon-button`,title:`Duplizieren`,onClick:t=>{t.stopPropagation(),o(e.id)},children:`⧉`}),(0,Q.jsx)(`button`,{className:`icon-button danger`,title:`Löschen`,onClick:t=>{t.stopPropagation(),s(e.id)},children:`×`})]})]},e.id))})]}))]})}var Av=ro(),jv=!1,Mv=new Set;function Nv(e){jv!==e&&(jv=e,Mv.forEach(e=>e()))}function Pv(e){return Mv.add(e),()=>Mv.delete(e)}function Fv(){return(0,Y.useSyncExternalStore)(Pv,()=>jv,()=>!1)}var Iv=[{mode:`translate`,label:`Verschieben`,key:`W/G`},{mode:`rotate`,label:`Drehen`,key:`E/R`},{mode:`scale`,label:`Skalieren`,key:`S`}],Lv=[{view:`perspective`,label:`Persp.`},{view:`front`,label:`Vorne`},{view:`back`,label:`Hinten`},{view:`left`,label:`Links`},{view:`right`,label:`Rechts`},{view:`top`,label:`Oben`},{view:`bottom`,label:`Unten`},{view:`focus`,label:`Fokus`}];function Rv(){let e=q(e=>e.tool),t=q(e=>e.setTool),n=q(e=>e.selectedIds),r=q(e=>e.snap),i=q(e=>e.setSnap),a=q(e=>e.scene),o=q(e=>e.setScene),s=q(e=>e.requestCameraView),c=Fv(),[l,u]=(0,Y.useState)(!1),[d,f]=(0,Y.useState)(null),p=(0,Y.useRef)(null),m=(0,Y.useRef)(null);(0,Y.useEffect)(()=>{if(!l)return;let e=e=>{let t=e.target;p.current?.contains(t)||m.current?.contains(t)||u(!1)};return document.addEventListener(`pointerdown`,e,!0),()=>document.removeEventListener(`pointerdown`,e,!0)},[l]);let h=e=>{ev({enabled:!1,cameraView:null}),t(e)},g=e=>{if(n.length===1){tv(e);return}s(e)};return(0,Q.jsxs)(`div`,{className:`toolbar`,children:[(0,Q.jsx)(`div`,{className:`group`,children:Iv.map(t=>(0,Q.jsx)(`button`,{className:e===t.mode?`active`:``,title:t.key,onClick:()=>h(t.mode),children:t.label},t.mode))}),(0,Q.jsx)(`div`,{className:`group`,children:(0,Q.jsxs)(`div`,{className:`view-menu`,ref:p,children:[(0,Q.jsxs)(`button`,{type:`button`,className:l?`active`:``,"aria-haspopup":`menu`,"aria-expanded":l,onClick:e=>{if(!l){let t=e.currentTarget.getBoundingClientRect();f({left:t.left,top:t.bottom+4})}u(e=>!e)},children:[`Ansicht\xA0`,l?`▴`:`▾`]}),l&&d&&(0,Av.createPortal)((0,Q.jsx)(`div`,{className:`view-menu-popover`,role:`menu`,ref:m,style:{left:d.left,top:d.top},children:Lv.map(e=>(0,Q.jsx)(`button`,{type:`button`,role:`menuitem`,onClick:()=>{g(e.view),u(!1)},children:e.label},e.view))}),document.body)]})}),(0,Q.jsxs)(`div`,{className:`group`,children:[(0,Q.jsxs)(`label`,{children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:a.gridVisible,onChange:e=>o({gridVisible:e.target.checked})}),` Raster`]}),(0,Q.jsxs)(`label`,{children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:a.axesVisible,onChange:e=>o({axesVisible:e.target.checked})}),` Achsen`]})]}),(0,Q.jsxs)(`div`,{className:`group`,children:[(0,Q.jsxs)(`label`,{children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:r.enabled,onChange:e=>i({enabled:e.target.checked,scale:r.position})}),` Snapping`]}),(0,Q.jsxs)(`label`,{className:`disabled`,title:`Grundformen an den Fangflächen anderer Grundformen einrasten (vorerst deaktiviert)`,children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:r.surface,disabled:!0,onChange:e=>i({surface:e.target.checked})}),` Formen-Snap`]}),(0,Q.jsxs)(`label`,{title:`Länge, Höhe und Tiefe aller sichtbaren Formen anzeigen`,children:[(0,Q.jsx)(`input`,{type:`checkbox`,checked:c,onChange:e=>Nv(e.target.checked)}),` Maße`]}),(0,Q.jsxs)(`label`,{children:[`Pos./Skala `,(0,Q.jsx)(`input`,{type:`number`,min:`0.01`,step:`0.05`,value:r.position,onChange:e=>{let t=Number(e.target.value);i({position:t,scale:t})}})]}),(0,Q.jsxs)(`label`,{children:[`Grad `,(0,Q.jsx)(`input`,{type:`number`,min:`1`,step:`1`,value:r.rotation,onChange:e=>i({rotation:Number(e.target.value)})})]})]})]})}function zv({onRestore:e,onDiscard:t}){return(0,Q.jsx)(`div`,{className:`modal-backdrop`,children:(0,Q.jsxs)(`div`,{className:`modal`,role:`dialog`,"aria-modal":`true`,"aria-label":`Letzte Sitzung wiederherstellen`,children:[(0,Q.jsx)(`h2`,{children:`Letzte Sitzung wiederherstellen`}),(0,Q.jsx)(`div`,{className:`modal-content`,children:`Es wurde ein lokal gespeicherter Arbeitsstand gefunden. Er befindet sich ausschließlich in diesem Browser.`}),(0,Q.jsxs)(`div`,{className:`modal-actions`,children:[(0,Q.jsx)(`button`,{onClick:t,children:`Verwerfen`}),(0,Q.jsx)(`button`,{onClick:e,children:`Wiederherstellen`})]})]})})}var Bv=i((t=>{var n=e();function r(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var i=typeof Object.is==`function`?Object.is:r,a=n.useState,o=n.useEffect,s=n.useLayoutEffect,c=n.useDebugValue;function l(e,t){var n=t(),r=a({inst:{value:n,getSnapshot:t}}),i=r[0].inst,l=r[1];return s(function(){i.value=n,i.getSnapshot=t,u(i)&&l({inst:i})},[e,n,t]),o(function(){return u(i)&&l({inst:i}),e(function(){u(i)&&l({inst:i})})},[e]),c(n),n}function u(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!i(e,n)}catch{return!0}}function d(e,t){return t()}var f=typeof window>`u`||window.document===void 0||window.document.createElement===void 0?d:l;t.useSyncExternalStore=n.useSyncExternalStore===void 0?f:n.useSyncExternalStore})),Vv=i(((e,t)=>{t.exports=Bv()})),Hv=i((t=>{var n=e(),r=Vv();function i(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var a=typeof Object.is==`function`?Object.is:i,o=r.useSyncExternalStore,s=n.useRef,c=n.useEffect,l=n.useMemo,u=n.useDebugValue;t.useSyncExternalStoreWithSelector=function(e,t,n,r,i){var d=s(null);if(d.current===null){var f={hasValue:!1,value:null};d.current=f}else f=d.current;d=l(function(){function e(e){if(!o){if(o=!0,s=e,e=r(e),i!==void 0&&f.hasValue){var t=f.value;if(i(t,e))return c=t}return c=e}if(t=c,a(s,e))return t;var n=r(e);return i!==void 0&&i(t,n)?(s=e,t):(s=e,c=n)}var o=!1,s,c,l=n===void 0?null:n;return[function(){return e(t())},l===null?void 0:function(){return e(l())}]},[t,n,r,i]);var p=o(e,d[0],d[1]);return c(function(){f.hasValue=!0,f.value=p},[p]),u(p),p}})),{useSyncExternalStoreWithSelector:Uv}=t(i(((e,t)=>{t.exports=Hv()}))(),1).default,Wv=e=>e;function Gv(e,t=Wv,n){let r=Uv(e.subscribe,e.getState,e.getInitialState,t,n);return Y.useDebugValue(r),r}var Kv=(e,t)=>{let n=xe(e),r=(e,r=t)=>Gv(n,e,r);return Object.assign(r,n),r},qv=((e,t)=>e?Kv(e,t):Kv),Jv=e=>typeof e==`object`&&typeof e.then==`function`,Yv=[];function Xv(e,t,n=(e,t)=>e===t){if(e===t)return!0;if(!e||!t)return!1;let r=e.length;if(t.length!==r)return!1;for(let i=0;i<r;i++)if(!n(e[i],t[i]))return!1;return!0}function Zv(e,t=null,n=!1,r={}){t===null&&(t=[e]);for(let e of Yv)if(Xv(t,e.keys,e.equal)){if(n)return;if(Object.prototype.hasOwnProperty.call(e,`error`))throw e.error;if(Object.prototype.hasOwnProperty.call(e,`response`))return r.lifespan&&r.lifespan>0&&(e.timeout&&clearTimeout(e.timeout),e.timeout=setTimeout(e.remove,r.lifespan)),e.response;if(!n)throw e.promise}let i={keys:t,equal:r.equal,remove:()=>{let e=Yv.indexOf(i);e!==-1&&Yv.splice(e,1)},promise:(Jv(e)?e:e(...t)).then(e=>{i.response=e,r.lifespan&&r.lifespan>0&&(i.timeout=setTimeout(i.remove,r.lifespan))}).catch(e=>i.error=e)};if(Yv.push(i),!n)throw i.promise}var Qv=(e,t,n)=>Zv(e,t,!1,n),$v=(e,t,n)=>void Zv(e,t,!0,n),ey=e=>{if(e===void 0||e.length===0)Yv.splice(0,Yv.length);else{let t=Yv.find(t=>Xv(e,t.keys,t.equal));t&&t.remove()}},ty=t(tn());typeof window<`u`&&(window.document?.createElement||window.navigator?.product===`ReactNative`)?Y.useLayoutEffect:Y.useEffect;function ny(e,t,n){if(!e)return;if(n(e)===!0)return e;let r=t?e.return:e.child;for(;r;){let e=ny(r,t,n);if(e)return e;r=t?null:r.sibling}}function ry(e){try{return Object.defineProperties(e,{_currentRenderer:{get(){return null},set(){}},_currentRenderer2:{get(){return null},set(){}}})}catch{return e}}var iy=ry(Y.createContext(null)),ay=class extends Y.Component{render(){return Y.createElement(iy.Provider,{value:this._reactInternals},this.props.children)}};function oy(){let e=Y.useContext(iy);if(e===null)throw Error(`its-fine: useFiber must be called within a <FiberProvider />!`);let t=Y.useId();return Y.useMemo(()=>{for(let n of[e,e?.alternate]){if(!n)continue;let e=ny(n,!1,e=>{let n=e.memoizedState;for(;n;){if(n.memoizedState===t)return!0;n=n.next}});if(e)return e}},[e,t])}var sy=Symbol.for(`react.context`),cy=e=>typeof e==`object`&&!!e&&`$$typeof`in e&&e.$$typeof===sy;function ly(){let e=oy(),[t]=Y.useState(()=>new Map);t.clear();let n=e;for(;n;){let e=n.type;cy(e)&&e!==iy&&!t.has(e)&&t.set(e,Y.use(ry(e))),n=n.return}return t}function uy(){let e=ly();return Y.useMemo(()=>Array.from(e.keys()).reduce((t,n)=>r=>Y.createElement(t,null,Y.createElement(n.Provider,{...r,value:e.get(n)})),e=>Y.createElement(ay,{...e})),[e])}function dy(e){let t=e.root;for(;t.getState().previousRoot;)t=t.getState().previousRoot;return t}var fy=e=>e&&e.isOrthographicCamera,py=e=>e&&e.hasOwnProperty(`current`),my=e=>e!=null&&(typeof e==`string`||typeof e==`number`||e.isColor),hy=((e,t)=>typeof window<`u`&&((e=window.document)?.createElement||(t=window.navigator)?.product===`ReactNative`))()?Y.useLayoutEffect:Y.useEffect;function gy(e){let t=Y.useRef(e);return hy(()=>void(t.current=e),[e]),t}function _y(){let e=oy(),t=uy();return Y.useMemo(()=>({children:n})=>(0,Q.jsx)(ny(e,!0,e=>e.type===Y.StrictMode)?Y.StrictMode:Y.Fragment,{children:(0,Q.jsx)(t,{children:n})}),[e,t])}function vy({set:e}){return hy(()=>(e(new Promise(()=>null)),()=>e(!1)),[e]),null}var yy=(e=>(e=class extends Y.Component{constructor(...e){super(...e),this.state={error:!1}}componentDidCatch(e){this.props.set(e)}render(){return this.state.error?null:this.props.children}},e.getDerivedStateFromError=()=>({error:!0}),e))();function by(e){let t=typeof window<`u`?window.devicePixelRatio??2:1;return Array.isArray(e)?Math.min(Math.max(e[0],t),e[1]):e}function xy(e){return e.__r3f?.root.getState()}var Sy={obj:e=>e===Object(e)&&!Sy.arr(e)&&typeof e!=`function`,fun:e=>typeof e==`function`,str:e=>typeof e==`string`,num:e=>typeof e==`number`,boo:e=>typeof e==`boolean`,und:e=>e===void 0,nul:e=>e===null,arr:e=>Array.isArray(e),equ(e,t,{arrays:n=`shallow`,objects:r=`reference`,strict:i=!0}={}){if(typeof e!=typeof t||!!e!=!!t)return!1;if(Sy.str(e)||Sy.num(e)||Sy.boo(e))return e===t;let a=Sy.obj(e);if(a&&r===`reference`)return e===t;let o=Sy.arr(e);if(o&&n===`reference`)return e===t;if((o||a)&&e===t)return!0;let s;for(s in e)if(!(s in t))return!1;if(a&&n===`shallow`&&r===`shallow`){for(s in i?t:e)if(!Sy.equ(e[s],t[s],{strict:i,objects:`reference`}))return!1}else for(s in i?t:e)if(e[s]!==t[s])return!1;if(Sy.und(s)){if(o&&e.length===0&&t.length===0||a&&Object.keys(e).length===0&&Object.keys(t).length===0)return!0;if(e!==t)return!1}return!0}};function Cy(e){let t={nodes:{},materials:{},meshes:{}};return e&&e.traverse(e=>{e.name&&(t.nodes[e.name]=e),e.material&&!t.materials[e.material.name]&&(t.materials[e.material.name]=e.material),e.isMesh&&!t.meshes[e.name]&&(t.meshes[e.name]=e)}),t}function wy(e){e.type!==`Scene`&&(e.dispose==null||e.dispose());for(let t in e){let n=e[t];n?.type!==`Scene`&&(n==null||n.dispose==null||n.dispose())}}var Ty=[`children`,`key`,`ref`];function Ey(e){let t={};for(let n in e)Ty.includes(n)||(t[n]=e[n]);return t}function Dy(e,t,n,r){let i=e,a=i?.__r3f;return a||(a={root:t,type:n,parent:null,children:[],props:Ey(r),object:i,eventCount:0,handlers:{},isHidden:!1},i&&(i.__r3f=a)),a}function Oy(e,t){if(!t.includes(`-`)||t in e)return{root:e,key:t,target:e[t]};let n=e,r=t.split(`-`);for(let i of r){if(typeof n!=`object`||!n){if(n!==void 0){let e=r.slice(r.indexOf(i)).join(`-`);return{root:n,key:e,target:void 0}}return{root:e,key:t,target:void 0}}t=i,e=n,n=n[t]}return{root:e,key:t,target:n}}var ky=/-\d+$/;function Ay(e,t){if(Sy.str(t.props.attach)){if(ky.test(t.props.attach)){let n=t.props.attach.replace(ky,``),{root:r,key:i}=Oy(e.object,n);Array.isArray(r[i])||(r[i]=[])}let{root:n,key:r}=Oy(e.object,t.props.attach);t.previousAttach=n[r],n[r]=t.object}else Sy.fun(t.props.attach)&&(t.previousAttach=t.props.attach(e.object,t.object))}function jy(e,t){if(Sy.str(t.props.attach)){let{root:n,key:r}=Oy(e.object,t.props.attach),i=t.previousAttach;i===void 0?delete n[r]:n[r]=i}else t.previousAttach==null||t.previousAttach(e.object,t.object);delete t.previousAttach}var My=[...Ty,`args`,`dispose`,`attach`,`object`,`onUpdate`,`dispose`],Ny=new Map;function Py(e){let t=Ny.get(e.constructor);try{t||(t=new e.constructor,Ny.set(e.constructor,t))}catch{}return t}function Fy(e,t){let n={};for(let r in t)if(!My.includes(r)&&!Sy.equ(t[r],e.props[r])){n[r]=t[r];for(let e in t)e.startsWith(`${r}-`)&&(n[e]=t[e])}for(let r in e.props){if(My.includes(r)||t.hasOwnProperty(r))continue;let{root:i,key:a}=Oy(e.object,r);if(i.constructor&&i.constructor.length===0){let e=Py(i);Sy.und(e)||(n[a]=e[a])}else n[a]=0}return n}var Iy=[`map`,`emissiveMap`,`sheenColorMap`,`specularColorMap`,`envMap`],Ly=/^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/;function Ry(e,t){var n;let r=e.__r3f,i=r&&dy(r).getState(),a=r?.eventCount;for(let n in t){let a=t[n];if(My.includes(n))continue;if(r&&Ly.test(n)){typeof a==`function`?r.handlers[n]=a:delete r.handlers[n],r.eventCount=Object.keys(r.handlers).length;continue}if(a===void 0)continue;let{root:s,key:c,target:l}=Oy(e,n);if(l===void 0&&(typeof s!=`object`||!s))throw Error(`R3F: Cannot set "${n}". Ensure it is an object before setting "${c}".`);if(l instanceof $a&&a instanceof $a)l.mask=a.mask;else if(l instanceof Ai&&my(a))l.set(a);else if(typeof l==`object`&&l&&typeof l.set==`function`&&typeof l.copy==`function`&&a!=null&&a.constructor&&l.constructor===a.constructor)l.copy(a);else if(typeof l==`object`&&l&&typeof l.set==`function`&&Array.isArray(a))typeof l.fromArray==`function`?l.fromArray(a):l.set(...a);else if(typeof l==`object`&&l&&typeof l.set==`function`&&typeof a==`number`)typeof l.setScalar==`function`?l.setScalar(a):l.set(a);else if(s instanceof Cr&&c===`uniforms`&&Sy.obj(a)){Sy.obj(s.uniforms)||(s.uniforms={});let e=s.uniforms,t=a;for(let n in t){let r=t[n],i=e[n];i?Object.assign(i,r):e[n]={...r}}}else{var o;s[c]=a,i&&!i.linear&&Iy.includes(c)&&(o=s[c])!=null&&o.isTexture&&s[c].format===1023&&s[c].type===1009&&(s[c].colorSpace=di)}}if(r!=null&&r.parent&&i!=null&&i.internal&&(n=r.object)!=null&&n.isObject3D&&a!==r.eventCount){let e=r.object,t=i.internal.interaction.indexOf(e);t>-1&&i.internal.interaction.splice(t,1),r.eventCount&&e.raycast!==null&&i.internal.interaction.push(e)}return r&&r.props.attach===void 0&&(r.object.isBufferGeometry?r.props.attach=`geometry`:r.object.isMaterial&&(r.props.attach=`material`)),r&&zy(r),e}function zy(e){var t;if(!e.parent)return;e.props.onUpdate==null||e.props.onUpdate(e.object);let n=(t=e.root)==null||t.getState==null?void 0:t.getState();n&&n.internal.frames===0&&n.invalidate()}function By(e,t){e.manual||(fy(e)?(e.left=t.width/-2,e.right=t.width/2,e.top=t.height/2,e.bottom=t.height/-2):e.aspect=t.width/t.height,e.updateProjectionMatrix())}var Vy=e=>e?.isObject3D;function Hy(e){return(e.eventObject||e.object).uuid+`/`+e.index+e.instanceId}function Uy(e,t,n,r){let i=n.get(t);i&&(n.delete(t),n.size===0&&(e.delete(r),i.target.releasePointerCapture(r)))}function Wy(e,t,n){let{internal:r}=e.getState();for(let e=0;e<r.interaction.length;e++)r.interaction[e]===t&&(r.interaction[e]=n);for(let e=0;e<r.initialHits.length;e++)r.initialHits[e]===t&&(r.initialHits[e]=n);r.hovered.forEach((e,i)=>{if(e.eventObject===t||e.object===t){r.hovered.delete(i);let a={...e,eventObject:e.eventObject===t?n:e.eventObject,object:e.object===t?n:e.object};r.hovered.set(Hy(a),a)}}),r.capturedMap.forEach(e=>{let r=e.get(t);r&&(e.delete(t),e.set(n,r))})}function Gy(e,t){let{internal:n}=e.getState();n.interaction=n.interaction.filter(e=>e!==t),n.initialHits=n.initialHits.filter(e=>e!==t),n.hovered.forEach((e,r)=>{(e.eventObject===t||e.object===t)&&n.hovered.delete(r)}),n.capturedMap.forEach((e,r)=>{Uy(n.capturedMap,t,e,r)})}function Ky(e){function t(t){let{internal:n}=e.getState(),r=t.offsetX-n.initialClick[0],i=t.offsetY-n.initialClick[1];return Math.round(Math.sqrt(r*r+i*i))}function n(e){return e.filter(e=>[`Move`,`Over`,`Enter`,`Out`,`Leave`].some(t=>e.__r3f?.handlers[`onPointer`+t]))}function r(t,n){let r=e.getState(),i=new Set,a=[],o=n?n(r.internal.interaction):r.internal.interaction;for(let e=0;e<o.length;e++){let t=xy(o[e]);t&&(t.raycaster.camera=void 0)}r.previousRoot||r.events.compute==null||r.events.compute(t,r);function s(e){let n=xy(e);return!n||!n.events.enabled||n.raycaster.camera===null?[]:(n.raycaster.camera===void 0&&(n.events.compute==null||n.events.compute(t,n,n.previousRoot?.getState()),n.raycaster.camera===void 0&&(n.raycaster.camera=null)),n.raycaster.camera?n.raycaster.intersectObject(e,!0):[])}let c=o.flatMap(s).sort((e,t)=>{let n=xy(e.object),r=xy(t.object);return!n||!r?e.distance-t.distance:r.events.priority-n.events.priority||e.distance-t.distance}).filter(e=>{let t=Hy(e);return i.has(t)?!1:(i.add(t),!0)});r.events.filter&&(c=r.events.filter(c,r));for(let e of c){let t=e.object;for(;t;){var l;(l=t.__r3f)!=null&&l.eventCount&&a.push({...e,eventObject:t}),t=t.parent}}if(`pointerId`in t&&r.internal.capturedMap.has(t.pointerId))for(let e of r.internal.capturedMap.get(t.pointerId).values())i.has(Hy(e.intersection))||a.push(e.intersection);return a}function i(e,t,n,r){if(e.length){let i={stopped:!1};for(let o of e){let s=xy(o.object);if(s||o.object.traverseAncestors(e=>{let t=xy(e);if(t)return s=t,!1}),s){let{raycaster:c,pointer:l,camera:u,internal:d}=s,f=new K(l.x,l.y,0).unproject(u),p=e=>d.capturedMap.get(e)?.has(o.eventObject)??!1,m=e=>{let n={intersection:o,target:t.target};d.capturedMap.has(e)?d.capturedMap.get(e).set(o.eventObject,n):d.capturedMap.set(e,new Map([[o.eventObject,n]])),t.target.setPointerCapture(e)},h=e=>{let t=d.capturedMap.get(e);t&&Uy(d.capturedMap,o.eventObject,t,e)},g={};for(let e in t){let n=t[e];typeof n!=`function`&&(g[e]=n)}let _={...o,...g,pointer:l,intersections:e,stopped:i.stopped,delta:n,unprojectedPoint:f,ray:c.ray,camera:u,stopPropagation(){let n=`pointerId`in t&&d.capturedMap.get(t.pointerId);(!n||n.has(o.eventObject))&&(_.stopped=i.stopped=!0,d.hovered.size&&Array.from(d.hovered.values()).find(e=>e.eventObject===o.eventObject)&&a([...e.slice(0,e.indexOf(o)),o]))},target:{hasPointerCapture:p,setPointerCapture:m,releasePointerCapture:h},currentTarget:{hasPointerCapture:p,setPointerCapture:m,releasePointerCapture:h},nativeEvent:t};if(r(_),i.stopped===!0)break}}}return e}function a(t){let{internal:n}=e.getState();for(let e of n.hovered.values())if(!t.length||!t.find(t=>t.object===e.object&&t.index===e.index&&t.instanceId===e.instanceId)){let r=e.eventObject.__r3f;if(n.hovered.delete(Hy(e)),r!=null&&r.eventCount){let n=r.handlers,i={...e,intersections:t};n.onPointerOut==null||n.onPointerOut(i),n.onPointerLeave==null||n.onPointerLeave(i)}}}function o(e,t){for(let n=0;n<t.length;n++){let r=t[n].__r3f;r==null||r.handlers.onPointerMissed==null||r.handlers.onPointerMissed(e)}}function s(s){switch(s){case`onPointerLeave`:case`onPointerCancel`:return()=>a([]);case`onLostPointerCapture`:return t=>{let{internal:n}=e.getState();`pointerId`in t&&n.capturedMap.has(t.pointerId)&&requestAnimationFrame(()=>{n.capturedMap.has(t.pointerId)&&(n.capturedMap.delete(t.pointerId),a([]))})}}return function(c){let{onPointerMissed:l,internal:u}=e.getState();u.lastEvent.current=c;let d=s===`onPointerMove`,f=s===`onClick`||s===`onContextMenu`||s===`onDoubleClick`,p=r(c,d?n:void 0),m=f?t(c):0;s===`onPointerDown`&&(u.initialClick=[c.offsetX,c.offsetY],u.initialHits=p.map(e=>e.eventObject)),f&&!p.length&&m<=2&&(o(c,u.interaction),l&&l(c)),d&&a(p);function h(e){let t=e.eventObject,n=t.__r3f;if(!(n!=null&&n.eventCount))return;let r=n.handlers;if(d){if(r.onPointerOver||r.onPointerEnter||r.onPointerOut||r.onPointerLeave){let t=Hy(e),n=u.hovered.get(t);n?n.stopped&&e.stopPropagation():(u.hovered.set(t,e),r.onPointerOver==null||r.onPointerOver(e),r.onPointerEnter==null||r.onPointerEnter(e))}r.onPointerMove==null||r.onPointerMove(e)}else{let n=r[s];n?(!f||u.initialHits.includes(t))&&(o(c,u.interaction.filter(e=>!u.initialHits.includes(e))),n(e)):f&&u.initialHits.includes(t)&&o(c,u.interaction.filter(e=>!u.initialHits.includes(e)))}}i(p,c,m,h)}}return{handlePointer:s}}var qy=e=>!!(e!=null&&e.render),Jy=Y.createContext(null),Yy=(e,t)=>{let n=qv((n,r)=>{let i=new K,a=new K,o=new K;function s(e=r().camera,t=a,n=r().size){let{width:s,height:c,top:l,left:u}=n,d=s/c;t.isVector3?o.copy(t):o.set(...t);let f=e.getWorldPosition(i).distanceTo(o);if(fy(e))return{width:s/e.zoom,height:c/e.zoom,top:l,left:u,factor:1,distance:f,aspect:d};{let t=e.fov*Math.PI/180,n=2*Math.tan(t/2)*f,r=s/c*n;return{width:r,height:n,top:l,left:u,factor:s/r,distance:f,aspect:d}}}let c,l=e=>n(t=>({performance:{...t.performance,current:e}})),u=new Er;return{set:n,get:r,gl:null,camera:null,raycaster:null,events:{priority:1,enabled:!0,connected:!1},scene:null,xr:null,invalidate:(t=1)=>e(r(),t),advance:(e,n)=>t(e,n,r()),legacy:!1,linear:!1,flat:!1,controls:null,clock:new ha,pointer:u,mouse:u,frameloop:`always`,onPointerMissed:void 0,performance:{current:1,min:.5,max:1,debounce:200,regress:()=>{let e=r();c&&clearTimeout(c),e.performance.current!==e.performance.min&&l(e.performance.min),c=setTimeout(()=>l(r().performance.max),e.performance.debounce)}},size:{width:0,height:0,top:0,left:0},viewport:{initialDpr:0,dpr:0,width:0,height:0,top:0,left:0,aspect:0,distance:0,factor:0,getCurrentViewport:s},setEvents:e=>n(t=>({...t,events:{...t.events,...e}})),setSize:(e,t,i=0,o=0)=>{let c=r().camera,l={width:e,height:t,top:i,left:o};n(e=>({size:l,viewport:{...e.viewport,...s(c,a,l)}}))},setDpr:e=>n(t=>{let n=by(e);return{viewport:{...t.viewport,dpr:n,initialDpr:t.viewport.initialDpr||n}}}),setFrameloop:(e=`always`)=>{let t=r().clock;t.stop(),t.elapsedTime=0,e!==`never`&&(t.start(),t.elapsedTime=0),n(()=>({frameloop:e}))},previousRoot:void 0,internal:{interaction:[],hovered:new Map,subscribers:[],initialClick:[0,0],initialHits:[],capturedMap:new Map,lastEvent:Y.createRef(),active:!1,frames:0,priority:0,subscribe:(e,t,n)=>{let i=r().internal;return i.priority+=+(t>0),i.subscribers.push({ref:e,priority:t,store:n}),i.subscribers=i.subscribers.sort((e,t)=>e.priority-t.priority),()=>{let n=r().internal;n!=null&&n.subscribers&&(n.priority-=+(t>0),n.subscribers=n.subscribers.filter(t=>t.ref!==e))}}}}}),r=n.getState(),i=r.size,a=r.viewport.dpr,o=r.camera;return n.subscribe(()=>{let{camera:e,size:t,viewport:r,gl:s,set:c}=n.getState();if(t.width!==i.width||t.height!==i.height||r.dpr!==a){i=t,a=r.dpr,By(e,t),r.dpr>0&&s.setPixelRatio(r.dpr);let n=typeof HTMLCanvasElement<`u`&&s.domElement instanceof HTMLCanvasElement;s.setSize(t.width,t.height,n)}e!==o&&(o=e,c(t=>({viewport:{...t.viewport,...t.viewport.getCurrentViewport(e)}})))}),n.subscribe(t=>e(t)),n};function Xy(){let e=Y.useContext(Jy);if(!e)throw Error(`R3F: Hooks can only be used within the Canvas component!`);return e}function Zy(e=e=>e,t){return Xy()(e,t)}function Qy(e,t=0){let n=Xy(),r=n.getState().internal.subscribe,i=gy(e);return hy(()=>r(i,t,n),[t,r,n]),null}var $y=new WeakMap,eb=e=>typeof e==`function`&&e?.prototype?.constructor===e;function tb(e,t){return function(n,...r){let i;return eb(n)?(i=$y.get(n),i||(i=new n,$y.set(n,i))):i=n,e&&e(i),Promise.all(r.map(e=>new Promise((n,r)=>i.load(e,e=>{Vy(e?.scene)&&Object.assign(e,Cy(e.scene)),n(e)},t,t=>r(Error(`Could not load ${e}: ${t?.message}`))))))}}function nb(e,t,n,r){let i=Array.isArray(t)?t:[t],a=Qv(tb(n,r),[e,...i],{equal:Sy.equ});return Array.isArray(t)?a:a[0]}nb.preload=function(e,t,n){let r=Array.isArray(t)?t:[t];return $v(tb(n),[e,...r])},nb.clear=function(e,t){return ey([e,...Array.isArray(t)?t:[t]])};var rb=1,ib=8,ab=32,ob=2,sb={name:`@react-three/fiber`,version:`9.6.1`,description:`A React renderer for Threejs`,keywords:[`react`,`renderer`,`fiber`,`three`,`threejs`],author:`Paul Henschel (https://github.com/drcmda)`,license:`MIT`,maintainers:[`Josh Ellis (https://github.com/joshuaellis)`,`Cody Bennett (https://github.com/codyjasonbennett)`,`Kris Baumgarter (https://github.com/krispya)`],bugs:{url:`https://github.com/pmndrs/react-three-fiber/issues`},homepage:`https://github.com/pmndrs/react-three-fiber#readme`,repository:{type:`git`,url:`git+https://github.com/pmndrs/react-three-fiber.git`},collective:{type:`opencollective`,url:`https://opencollective.com/react-three-fiber`},main:`dist/react-three-fiber.cjs.js`,module:`dist/react-three-fiber.esm.js`,types:`dist/react-three-fiber.cjs.d.ts`,"react-native":`native/dist/react-three-fiber-native.cjs.js`,sideEffects:!1,preconstruct:{entrypoints:[`index.tsx`,`native.tsx`]},scripts:{prebuild:`cp ../../readme.md readme.md`},devDependencies:{"@types/react-reconciler":`^0.32.3`,"react-reconciler":`^0.33.0`},dependencies:{"@babel/runtime":`^7.17.8`,"@types/webxr":`*`,"base64-js":`^1.5.1`,buffer:`^6.0.3`,"its-fine":`^2.0.0`,"react-use-measure":`^2.1.7`,scheduler:`^0.27.0`,"suspend-react":`^0.1.3`,"use-sync-external-store":`^1.4.0`,zustand:`^5.0.3`},peerDependencies:{expo:`>=43.0`,"expo-asset":`>=8.4`,"expo-file-system":`>=11.0`,"expo-gl":`>=11.0`,react:`>=19 <19.3`,"react-dom":`>=19 <19.3`,"react-native":`>=0.78`,three:`>=0.156`},peerDependenciesMeta:{"react-dom":{optional:!0},"react-native":{optional:!0},expo:{optional:!0},"expo-asset":{optional:!0},"expo-file-system":{optional:!0},"expo-gl":{optional:!0}}};function cb(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,`default`)?e.default:e}var lb={exports:{}},ub={exports:{}};ub.exports;var db;function fb(){return db||(db=1,function(e){e.exports=function(e){function t(e,t,n,r){return new sa(e,t,n,r)}function n(){}function r(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function i(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function a(e){if(i(e)!==e)throw Error(r(188))}function o(e){var t=e.alternate;if(!t){if(t=i(e),t===null)throw Error(r(188));return t===e?e:null}for(var n=e,o=t;;){var s=n.return;if(s===null)break;var c=s.alternate;if(c===null){if(o=s.return,o!==null){n=o;continue}break}if(s.child===c.child){for(c=s.child;c;){if(c===n)return a(s),e;if(c===o)return a(s),t;c=c.sibling}throw Error(r(188))}if(n.return!==o.return)n=s,o=c;else{for(var l=!1,u=s.child;u;){if(u===n){l=!0,n=s,o=c;break}if(u===o){l=!0,o=s,n=c;break}u=u.sibling}if(!l){for(u=c.child;u;){if(u===n){l=!0,n=c,o=s;break}if(u===o){l=!0,o=c,n=s;break}u=u.sibling}if(!l)throw Error(r(189))}}if(n.alternate!==o)throw Error(r(190))}if(n.tag!==3)throw Error(r(188));return n.stateNode.current===n?e:t}function s(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=s(e),t!==null)return t;e=e.sibling}return null}function c(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(e.tag!==4&&(t=c(e),t!==null))return t;e=e.sibling}return null}function l(e){return typeof e!=`object`||!e?null:(e=Va&&e[Va]||e[`@@iterator`],typeof e==`function`?e:null)}function u(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===Ha?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case ka:return`Fragment`;case ja:return`Profiler`;case Aa:return`StrictMode`;case Fa:return`Suspense`;case Ia:return`SuspenseList`;case za:return`Activity`}if(typeof e==`object`)switch(e.$$typeof){case Oa:return`Portal`;case Na:return e.displayName||`Context`;case Ma:return(e._context.displayName||`Context`)+`.Consumer`;case Pa:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case La:return t=e.displayName||null,t===null?u(e.type)||`Memo`:t;case Ra:t=e._payload,e=e._init;try{return u(e(t))}catch{}}return null}function d(e){return{current:e}}function f(e){0>sc||(e.current=oc[sc],oc[sc]=null,sc--)}function p(e,t){sc++,oc[sc]=e.current,e.current=t}function m(e){return e>>>=0,e===0?32:31-(uc(e)/dc|0)|0}function h(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function g(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=h(n))):i=h(o):i=h(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=h(n))):i=h(o)):i=h(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function _(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function v(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function y(){var e=mc;return mc<<=1,!(mc&62914560)&&(mc=4194304),e}function b(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function x(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function S(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-lc(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&C(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function C(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-lc(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function w(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-lc(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function T(e,t){var n=t&-t;return n=n&42?1:E(n),(n&(e.suspendedLanes|t))===0?n:0}function E(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function D(e){return e&=-e,2<e?8<e?e&134217727?32:268435456:8:2}function O(e){if(typeof wc==`function`&&Tc(e),Dc&&typeof Dc.setStrictMode==`function`)try{Dc.setStrictMode(Ec,e)}catch{}}function k(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}function A(e){if(jc===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);jc=t&&t[1]||``,Mc=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+jc+e+Mc}function j(e,t){if(!e||Nc)return``;Nc=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}e.call(n.prototype)}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,`name`);i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:`DetermineComponentFrameRoot`});var a=r.DetermineComponentFrameRoot(),o=a[0],s=a[1];if(o&&s){var c=o.split(`
`),l=s.split(`
`);for(i=r=0;r<c.length&&!c[r].includes(`DetermineComponentFrameRoot`);)r++;for(;i<l.length&&!l[i].includes(`DetermineComponentFrameRoot`);)i++;if(r===c.length||i===l.length)for(r=c.length-1,i=l.length-1;1<=r&&0<=i&&c[r]!==l[i];)i--;for(;1<=r&&0<=i;r--,i--)if(c[r]!==l[i]){if(r!==1||i!==1)do if(r--,i--,0>i||c[r]!==l[i]){var u=`
`+c[r].replace(` at new `,` at `);return e.displayName&&u.includes(`<anonymous>`)&&(u=u.replace(`<anonymous>`,e.displayName)),u}while(1<=r&&0<=i);break}}}finally{Nc=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:``)?A(n):``}function M(e,t){switch(e.tag){case 26:case 27:case 5:return A(e.type);case 16:return A(`Lazy`);case 13:return e.child!==t&&t!==null?A(`Suspense Fallback`):A(`Suspense`);case 19:return A(`SuspenseList`);case 0:case 15:return j(e.type,!1);case 11:return j(e.type.render,!1);case 1:return j(e.type,!0);case 31:return A(`Activity`);default:return``}}function N(e){try{var t=``,n=null;do t+=M(e,n),n=e,e=e.return;while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}function P(e,t){if(typeof e==`object`&&e){var n=Pc.get(e);return n===void 0?(t={value:e,source:t,stack:N(t)},Pc.set(e,t),t):n}return{value:e,source:t,stack:N(t)}}function F(e,t){Fc[Ic++]=Rc,Fc[Ic++]=Lc,Lc=e,Rc=t}function I(e,t,n){zc[Bc++]=Hc,zc[Bc++]=Uc,zc[Bc++]=Vc,Vc=e;var r=Hc;e=Uc;var i=32-lc(r)-1;r&=~(1<<i),n+=1;var a=32-lc(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,Hc=1<<32-lc(t)+i|n<<i|r,Uc=a+e}else Hc=1<<a|n<<i|r,Uc=e}function L(e){e.return!==null&&(F(e,1),I(e,1,0))}function ee(e){for(;e===Lc;)Lc=Fc[--Ic],Fc[Ic]=null,Rc=Fc[--Ic],Fc[Ic]=null;for(;e===Vc;)Vc=zc[--Bc],zc[Bc]=null,Uc=zc[--Bc],zc[Bc]=null,Hc=zc[--Bc],zc[Bc]=null}function te(e,t){zc[Bc++]=Hc,zc[Bc++]=Uc,zc[Bc++]=Vc,Hc=t.id,Uc=t.overflow,Vc=e}function ne(e,t){p(Kc,t),p(Gc,e),p(Wc,null),e=Ja(t),f(Wc),p(Wc,e)}function R(){f(Wc),f(Gc),f(Kc)}function z(e){e.memoizedState!==null&&p(qc,e);var t=Wc.current,n=Ya(t,e.type);t!==n&&(p(Gc,e),p(Wc,n))}function B(e){Gc.current===e&&(f(Wc),f(Gc)),qc.current===e&&(f(qc),oo?wo._currentValue=Co:wo._currentValue2=Co)}function V(e){throw ce(P(Error(r(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?`text`:`HTML`,``)),e)),$c}function re(e,t){if(!so)throw Error(r(175));xs(e.stateNode,e.type,e.memoizedProps,t,e)||V(e,!0)}function ie(e){for(Jc=e.return;Jc;)switch(Jc.tag){case 5:case 31:case 13:Qc=!1;return;case 27:case 3:Qc=!0;return;default:Jc=Jc.return}}function ae(e){if(!so||e!==Jc)return!1;if(!Xc)return ie(e),Xc=!0,!1;var t=e.tag;if(ec?t!==3&&t!==27&&(t!==5||Ls(e.type)&&!to(e.type,e.memoizedProps))&&Yc&&V(e):t!==3&&(t!==5||Ls(e.type)&&!to(e.type,e.memoizedProps))&&Yc&&V(e),ie(e),t===13){if(!so)throw Error(r(316));if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(r(317));Yc=Es(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(r(317));Yc=Ts(e)}else Yc=ec&&t===27?ds(e.type,Yc):Jc?us(e.stateNode):null;return!0}function oe(){so&&(Yc=Jc=null,Xc=!1)}function se(){var e=Zc;return e!==null&&(Lu===null?Lu=e:Lu.push.apply(Lu,e),Zc=null),e}function ce(e){Zc===null?Zc=[e]:Zc.push(e)}function le(e,t,n){oo?(p(el,t._currentValue),t._currentValue=n):(p(el,t._currentValue2),t._currentValue2=n)}function ue(e){var t=el.current;oo?e._currentValue=t:e._currentValue2=t,f(el)}function de(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function fe(e,t,n,i){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var s=a.child;o=o.firstContext;e:for(;o!==null;){var c=o;o=a;for(var l=0;l<t.length;l++)if(c.context===t[l]){o.lanes|=n,c=o.alternate,c!==null&&(c.lanes|=n),de(o.return,n,e),i||(s=null);break e}o=c.next}}else if(a.tag===18){if(s=a.return,s===null)throw Error(r(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),de(s,n,e),s=null}else s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}}function pe(e,t,n,i){e=null;for(var a=t,o=!1;a!==null;){if(!o){if(a.flags&524288)o=!0;else if(a.flags&262144)break}if(a.tag===10){var s=a.alternate;if(s===null)throw Error(r(387));if(s=s.memoizedProps,s!==null){var c=a.type;Oc(a.pendingProps.value,s.value)||(e===null?e=[c]:e.push(c))}}else if(a===qc.current){if(s=a.alternate,s===null)throw Error(r(387));s.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e===null?e=[wo]:e.push(wo))}a=a.return}e!==null&&fe(t,e,n,i),t.flags|=262144}function me(e){for(e=e.firstContext;e!==null;){var t=e.context;if(!Oc(oo?t._currentValue:t._currentValue2,e.memoizedValue))return!0;e=e.next}return!1}function he(e){tl=e,nl=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ge(e){return _e(tl,e)}function H(e,t){return tl===null&&he(e),_e(e,t)}function _e(e,t){var n=oo?t._currentValue:t._currentValue2;if(t={context:t,memoizedValue:n,next:null},nl===null){if(e===null)throw Error(r(308));nl=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else nl=nl.next=t;return n}function ve(){return{controller:new rl,data:new Map,refCount:0}}function ye(e){e.refCount--,e.refCount===0&&il(al,function(){e.controller.abort()})}function U(){}function be(e){e!==cl&&e.next===null&&(cl===null?sl=cl=e:cl=cl.next=e),ul=!0,ll||(ll=!0,Ee())}function W(e,t){if(!dl&&ul){dl=!0;do for(var n=!1,r=sl;r!==null;){if(!t)if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-lc(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,Te(r,a))}else a=Cu,a=g(r,r===xu?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==ao),!(a&3)||_(r,a)||(n=!0,Te(r,a));r=r.next}while(n);dl=!1}}function xe(){Se()}function Se(){ul=ll=!1;var e=0;fl!==0&&mo()&&(e=fl);for(var t=yc(),n=null,r=sl;r!==null;){var i=r.next,a=Ce(r,t);a===0?(r.next=null,n===null?sl=i:n.next=i,i===null&&(cl=n)):(n=r,(e!==0||a&3)&&(ul=!0)),r=i}Wu!==0&&Wu!==5||W(e,!1),fl!==0&&(fl=0)}function Ce(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-lc(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=v(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=xu,n=Cu,n=g(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==ao),r=e.callbackNode,n===0||e===t&&(wu===2||wu===9)||e.cancelPendingCommit!==null)return r!==null&&r!==null&&gc(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||_(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(r!==null&&gc(r),D(n)){case 2:case 8:n=xc;break;case 32:n=Sc;break;case 268435456:n=Cc;break;default:n=Sc}return r=we.bind(null,e),n=hc(n,r),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&r!==null&&gc(r),e.callbackPriority=2,e.callbackNode=null,2}function we(e,t){if(Wu!==0&&Wu!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(Zi()&&e.callbackNode!==n)return null;var r=Cu;return r=g(e,e===xu?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==ao),r===0?null:(Ei(e,r,t),Ce(e,yc()),e.callbackNode!=null&&e.callbackNode===n?we.bind(null,e):null)}function Te(e,t){if(Zi())return null;Ei(e,t,!0)}function Ee(){Eo?Do(function(){bu&6?hc(bc,xe):Se()}):hc(bc,xe)}function De(){if(fl===0){var e=hl;e===0&&(e=fc,fc<<=1,!(fc&261888)&&(fc=256)),fl=e}return fl}function Oe(e,t){if(pl===null){var n=pl=[];ml=0,hl=De(),gl={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return ml++,t.then(ke,ke),t}function ke(){if(--ml===0&&pl!==null){gl!==null&&(gl.status=`fulfilled`);var e=pl;pl=null,hl=0,gl=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Ae(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}function je(){var e=vl.current;return e===null?xu.pooledCache:e}function Me(e,t){t===null?p(vl,vl.current):p(vl,t.pool)}function Ne(){var e=je();return e===null?null:{parent:oo?ol._currentValue:ol._currentValue2,pool:e}}function Pe(e,t){if(Oc(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Ac.call(t,i)||!Oc(e[i],t[i]))return!1}return!0}function Fe(e){return e=e.status,e===`fulfilled`||e===`rejected`}function Ie(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(U,U),t=n),t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,ze(e),e;default:if(typeof t.status==`string`)t.then(U,U);else{if(e=xu,e!==null&&100<e.shellSuspendCounter)throw Error(r(482));e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,ze(e),e}throw Cl=t,yl}}function Le(e){try{var t=e._init;return t(e._payload)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(Cl=e,yl):e}}function Re(){if(Cl===null)throw Error(r(459));var e=Cl;return Cl=null,e}function ze(e){if(e===yl||e===xl)throw Error(r(483))}function Be(e){var t=Tl;return Tl+=1,wl===null&&(wl=[]),Ie(wl,e,t)}function Ve(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function He(e,t){throw t.$$typeof===Ea?Error(r(525)):(e=Object.prototype.toString.call(t),Error(r(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)))}function Ue(e){function n(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function i(t,r){if(!e)return null;for(;r!==null;)n(t,r),r=r.sibling;return null}function a(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function o(e,t){return e=la(e,t),e.index=0,e.sibling=null,e}function s(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=67108866,n):(r=r.index,r<n?(t.flags|=67108866,n):r)):(t.flags|=1048576,n)}function c(t){return e&&t.alternate===null&&(t.flags|=67108866),t}function u(e,t,n,r){return t===null||t.tag!==6?(t=fa(n,e.mode,r),t.return=e,t):(t=o(t,n),t.return=e,t)}function d(e,t,n,r){var i=n.type;return i===ka?p(e,t,n.props.children,r,n.key):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===Ra&&Le(i)===t.type)?(t=o(t,n.props),Ve(t,n),t.return=e,t):(t=ua(n.type,n.key,n.props,null,e.mode,r),Ve(t,n),t.return=e,t)}function f(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=ma(n,e.mode,r),t.return=e,t):(t=o(t,n.children||[]),t.return=e,t)}function p(e,t,n,r,i){return t===null||t.tag!==7?(t=da(n,e.mode,r,i),t.return=e,t):(t=o(t,n),t.return=e,t)}function m(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=fa(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case Da:return n=ua(t.type,t.key,t.props,null,e.mode,n),Ve(n,t),n.return=e,n;case Oa:return t=ma(t,e.mode,n),t.return=e,t;case Ra:return t=Le(t),m(e,t,n)}if(Ua(t)||l(t))return t=da(t,e.mode,n,null),t.return=e,t;if(typeof t.then==`function`)return m(e,Be(t),n);if(t.$$typeof===Na)return m(e,H(e,t),n);He(e,t)}return null}function h(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?u(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case Da:return n.key===i?d(e,t,n,r):null;case Oa:return n.key===i?f(e,t,n,r):null;case Ra:return n=Le(n),h(e,t,n,r)}if(Ua(n)||l(n))return i===null?p(e,t,n,r,null):null;if(typeof n.then==`function`)return h(e,t,Be(n),r);if(n.$$typeof===Na)return h(e,t,H(e,n),r);He(e,n)}return null}function g(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,u(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case Da:return e=e.get(r.key===null?n:r.key)||null,d(t,e,r,i);case Oa:return e=e.get(r.key===null?n:r.key)||null,f(t,e,r,i);case Ra:return r=Le(r),g(e,t,n,r,i)}if(Ua(r)||l(r))return e=e.get(n)||null,p(t,e,r,i,null);if(typeof r.then==`function`)return g(e,t,n,Be(r),i);if(r.$$typeof===Na)return g(e,t,n,H(t,r),i);He(t,r)}return null}function _(t,r,o,c){for(var l=null,u=null,d=r,f=r=0,p=null;d!==null&&f<o.length;f++){d.index>f?(p=d,d=null):p=d.sibling;var _=h(t,d,o[f],c);if(_===null){d===null&&(d=p);break}e&&d&&_.alternate===null&&n(t,d),r=s(_,r,f),u===null?l=_:u.sibling=_,u=_,d=p}if(f===o.length)return i(t,d),Xc&&F(t,f),l;if(d===null){for(;f<o.length;f++)d=m(t,o[f],c),d!==null&&(r=s(d,r,f),u===null?l=d:u.sibling=d,u=d);return Xc&&F(t,f),l}for(d=a(d);f<o.length;f++)p=g(d,t,f,o[f],c),p!==null&&(e&&p.alternate!==null&&d.delete(p.key===null?f:p.key),r=s(p,r,f),u===null?l=p:u.sibling=p,u=p);return e&&d.forEach(function(e){return n(t,e)}),Xc&&F(t,f),l}function v(t,o,c,l){if(c==null)throw Error(r(151));for(var u=null,d=null,f=o,p=o=0,_=null,v=c.next();f!==null&&!v.done;p++,v=c.next()){f.index>p?(_=f,f=null):_=f.sibling;var y=h(t,f,v.value,l);if(y===null){f===null&&(f=_);break}e&&f&&y.alternate===null&&n(t,f),o=s(y,o,p),d===null?u=y:d.sibling=y,d=y,f=_}if(v.done)return i(t,f),Xc&&F(t,p),u;if(f===null){for(;!v.done;p++,v=c.next())v=m(t,v.value,l),v!==null&&(o=s(v,o,p),d===null?u=v:d.sibling=v,d=v);return Xc&&F(t,p),u}for(f=a(f);!v.done;p++,v=c.next())v=g(f,t,p,v.value,l),v!==null&&(e&&v.alternate!==null&&f.delete(v.key===null?p:v.key),o=s(v,o,p),d===null?u=v:d.sibling=v,d=v);return e&&f.forEach(function(e){return n(t,e)}),Xc&&F(t,p),u}function y(e,t,a,s){if(typeof a==`object`&&a&&a.type===ka&&a.key===null&&(a=a.props.children),typeof a==`object`&&a){switch(a.$$typeof){case Da:e:{for(var u=a.key;t!==null;){if(t.key===u){if(u=a.type,u===ka){if(t.tag===7){i(e,t.sibling),s=o(t,a.props.children),s.return=e,e=s;break e}}else if(t.elementType===u||typeof u==`object`&&u&&u.$$typeof===Ra&&Le(u)===t.type){i(e,t.sibling),s=o(t,a.props),Ve(s,a),s.return=e,e=s;break e}i(e,t);break}else n(e,t);t=t.sibling}a.type===ka?(s=da(a.props.children,e.mode,s,a.key),s.return=e,e=s):(s=ua(a.type,a.key,a.props,null,e.mode,s),Ve(s,a),s.return=e,e=s)}return c(e);case Oa:e:{for(u=a.key;t!==null;){if(t.key===u)if(t.tag===4&&t.stateNode.containerInfo===a.containerInfo&&t.stateNode.implementation===a.implementation){i(e,t.sibling),s=o(t,a.children||[]),s.return=e,e=s;break e}else{i(e,t);break}else n(e,t);t=t.sibling}s=ma(a,e.mode,s),s.return=e,e=s}return c(e);case Ra:return a=Le(a),y(e,t,a,s)}if(Ua(a))return _(e,t,a,s);if(l(a)){if(u=l(a),typeof u!=`function`)throw Error(r(150));return a=u.call(a),v(e,t,a,s)}if(typeof a.then==`function`)return y(e,t,Be(a),s);if(a.$$typeof===Na)return y(e,t,H(e,a),s);He(e,a)}return typeof a==`string`&&a!==``||typeof a==`number`||typeof a==`bigint`?(a=``+a,t!==null&&t.tag===6?(i(e,t.sibling),s=o(t,a),s.return=e,e=s):(i(e,t),s=fa(a,e.mode,s),s.return=e,e=s),c(e)):i(e,t)}return function(e,n,r,i){try{Tl=0;var a=y(e,n,r,i);return wl=null,a}catch(n){if(n===yl||n===xl)throw n;var o=t(29,n,null,e.mode);return o.lanes=i,o.return=e,o}}}function We(){for(var e=kl,t=Al=kl=0;t<e;){var n=Ol[t];Ol[t++]=null;var r=Ol[t];Ol[t++]=null;var i=Ol[t];Ol[t++]=null;var a=Ol[t];if(Ol[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&Je(n,i,a)}}function Ge(e,t,n,r){Ol[kl++]=e,Ol[kl++]=t,Ol[kl++]=n,Ol[kl++]=r,Al|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function Ke(e,t,n,r){return Ge(e,t,n,r),Ye(e)}function qe(e,t){return Ge(e,null,null,t),Ye(e)}function Je(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-lc(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function Ye(e){if(50<Zu)throw Zu=0,Qu=null,Error(r(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}function Xe(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Ze(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Qe(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function $e(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,bu&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=Ye(e),Je(e,null,n),t}return Ge(e,r,t,n),Ye(e)}function et(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,w(e,n)}}function tt(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function nt(){if(Ml){var e=gl;if(e!==null)throw e}}function rt(e,t,n,r){Ml=!1;var i=e.updateQueue;jl=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(Cu&f)===f:(r&f)===f){f!==0&&f===hl&&(Ml=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});e:{var m=e,h=s;f=t;var g=n;switch(h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(g,d,f);break e}d=m;break e;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(g,d,f):m,f==null)break e;d=Ta({},d,f);break e;case 2:jl=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(!0);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),ju|=o,e.lanes=o,e.memoizedState=d}}function it(e,t){if(typeof e!=`function`)throw Error(r(191,e));e.call(t)}function at(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)it(n[e],t)}function ot(e,t){e=ku,p(Pl,e),p(Nl,t),ku=e|t.baseLanes}function st(){p(Pl,ku),p(Nl,Nl.current)}function ct(){ku=Pl.current,f(Nl),f(Pl)}function lt(e){var t=e.alternate;p(Ll,Ll.current&1),p(Fl,e),Il===null&&(t===null||Nl.current!==null||t.memoizedState!==null)&&(Il=e)}function ut(e){p(Ll,Ll.current),p(Fl,e),Il===null&&(Il=e)}function dt(e){e.tag===22?(p(Ll,Ll.current),p(Fl,e),Il===null&&(Il=e)):ft()}function ft(){p(Ll,Ll.current),p(Fl,Fl.current)}function pt(e){f(Fl),Il===e&&(Il=null),f(Ll)}function mt(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||is(n)||as(n)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder===`forwards`||t.memoizedProps.revealOrder===`backwards`||t.memoizedProps.revealOrder===`unstable_legacy-backwards`||t.memoizedProps.revealOrder===`together`)){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}function ht(){throw Error(r(321))}function gt(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Oc(e[n],t[n]))return!1;return!0}function _t(e,t,n,r,i,a){return Rl=a,zl=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,J.H=e===null||e.memoizedState===null?Xl:Zl,Wl=!1,a=n(r,i),Wl=!1,Ul&&(a=yt(t,n,r,i)),vt(e),a}function vt(e){J.H=Yl;var t=Bl!==null&&Bl.next!==null;if(Rl=0,Vl=Bl=zl=null,Hl=!1,Kl=0,ql=null,t)throw Error(r(300));e===null||tu||(e=e.dependencies,e!==null&&me(e)&&(tu=!0))}function yt(e,t,n,i){zl=e;var a=0;do{if(Ul&&(ql=null),Kl=0,Ul=!1,25<=a)throw Error(r(301));if(a+=1,Vl=Bl=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}J.H=Ql,o=t(n,i)}while(Ul);return o}function bt(){var e=J.H,t=e.useState()[0];return t=typeof t.then==`function`?Dt(t):t,e=e.useState()[0],(Bl===null?null:Bl.memoizedState)!==e&&(zl.flags|=1024),t}function xt(){var e=Gl!==0;return Gl=0,e}function St(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Ct(e){if(Hl){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Hl=!1}Rl=0,Vl=Bl=zl=null,Ul=!1,Kl=Gl=0,ql=null}function wt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Vl===null?zl.memoizedState=Vl=e:Vl=Vl.next=e,Vl}function Tt(){if(Bl===null){var e=zl.alternate;e=e===null?null:e.memoizedState}else e=Bl.next;var t=Vl===null?zl.memoizedState:Vl.next;if(t!==null)Vl=t,Bl=e;else{if(e===null)throw zl.alternate===null?Error(r(467)):Error(r(310));Bl=e,e={memoizedState:Bl.memoizedState,baseState:Bl.baseState,baseQueue:Bl.baseQueue,queue:Bl.queue,next:null},Vl===null?zl.memoizedState=Vl=e:Vl=Vl.next=e}return Vl}function Et(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Dt(e){var t=Kl;return Kl+=1,ql===null&&(ql=[]),e=Ie(ql,e,t),t=zl,(Vl===null?t.memoizedState:Vl.next)===null&&(t=t.alternate,J.H=t===null||t.memoizedState===null?Xl:Zl),e}function Ot(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return Dt(e);if(e.$$typeof===Na)return ge(e)}throw Error(r(438,String(e)))}function kt(e){var t=null,n=zl.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=zl.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=Et(),zl.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=Ba;return t.index++,n}function At(e,t){return typeof t==`function`?t(e):t}function jt(e){return Mt(Tt(),Bl,e)}function Mt(e,t,n){var i=e.queue;if(i===null)throw Error(r(311));i.lastRenderedReducer=n;var a=e.baseQueue,o=i.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}t.baseQueue=a=o,i.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var c=s=null,l=null,u=t,d=!1;do{var f=u.lane&-536870913;if(f===u.lane?(Rl&f)===f:(Cu&f)===f){var p=u.revertLane;if(p===0)l!==null&&(l=l.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===hl&&(d=!0);else if((Rl&p)===p){u=u.next,p===hl&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=f,s=o):l=l.next=f,zl.lanes|=p,ju|=p;f=u.action,Wl&&n(o,f),o=u.hasEagerState?u.eagerState:n(o,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=p,s=o):l=l.next=p,zl.lanes|=f,ju|=f;u=u.next}while(u!==null&&u!==t);if(l===null?s=o:l.next=c,!Oc(o,e.memoizedState)&&(tu=!0,d&&(n=gl,n!==null)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=l,i.lastRenderedState=o}return a===null&&(i.lanes=0),[e.memoizedState,i.dispatch]}function Nt(e){var t=Tt(),n=t.queue;if(n===null)throw Error(r(311));n.lastRenderedReducer=e;var i=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);Oc(o,t.memoizedState)||(tu=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,i]}function Pt(e,t,n){var i=zl,a=Tt(),o=Xc;if(o){if(n===void 0)throw Error(r(407));n=n()}else n=t();var s=!Oc((Bl||a).memoizedState,n);if(s&&(a.memoizedState=n,tu=!0),a=a.queue,on(Lt.bind(null,i,a,e),[e]),a.getSnapshot!==t||s||Vl!==null&&Vl.memoizedState.tag&1){if(i.flags|=2048,en(9,{destroy:void 0},It.bind(null,i,a,n,t),null),xu===null)throw Error(r(349));o||Rl&127||Ft(i,t,n)}return n}function Ft(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=zl.updateQueue,t===null?(t=Et(),zl.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function It(e,t,n,r){t.value=n,t.getSnapshot=r,Rt(t)&&zt(e)}function Lt(e,t,n){return n(function(){Rt(t)&&zt(e)})}function Rt(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Oc(e,n)}catch{return!0}}function zt(e){var t=qe(e,2);t!==null&&Ti(t,e,2)}function Bt(e){var t=wt();if(typeof e==`function`){var n=e;if(e=n(),Wl){O(!0);try{n()}finally{O(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:At,lastRenderedState:e},t}function Vt(e,t,n,r){return e.baseState=n,Mt(e,Bl,typeof r==`function`?r:At)}function Ht(e,t,n,i,a){if(On(e))throw Error(r(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};J.T===null?o.isTransition=!1:n(!0),i(o),n=t.pending,n===null?(o.next=t.pending=o,Ut(t,o)):(o.next=n.next,t.pending=n.next=o)}}function Ut(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=J.T,o={};J.T=o;try{var s=n(i,r),c=J.S;c!==null&&c(o,s),Wt(e,t,s)}catch(n){Kt(e,t,n)}finally{a!==null&&o.types!==null&&(a.types=o.types),J.T=a}}else try{a=n(i,r),Wt(e,t,a)}catch(n){Kt(e,t,n)}}function Wt(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?n.then(function(n){Gt(e,t,n)},function(n){return Kt(e,t,n)}):Gt(e,t,n)}function Gt(e,t,n){t.status=`fulfilled`,t.value=n,qt(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Ut(e,n)))}function Kt(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,qt(t),t=t.next;while(t!==r)}e.action=null}function qt(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Jt(e,t){return t}function Yt(e,t){if(Xc){var n=xu.formState;if(n!==null){e:{var r=zl;if(Xc){if(Yc){var i=cs(Yc,Qc);if(i){Yc=us(i),r=ls(i);break e}}V(r)}r=!1}r&&(t=n[0])}}n=wt(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Jt,lastRenderedState:t},n.queue=r,n=Tn.bind(null,zl,r),r.dispatch=n,r=Bt(!1);var a=Dn.bind(null,zl,!1,r.queue);return r=wt(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=Ht.bind(null,zl,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function Xt(e){return Zt(Tt(),Bl,e)}function Zt(e,t,n){if(t=Mt(e,t,Jt)[0],e=jt(At)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=Dt(t)}catch(e){throw e===yl?xl:e}else r=t;t=Tt();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(zl.flags|=2048,en(9,{destroy:void 0},Qt.bind(null,i,n),null)),[r,a,e]}function Qt(e,t){e.action=t}function $t(e){var t=Tt(),n=Bl;if(n!==null)return Zt(t,n,e);Tt(),t=t.memoizedState,n=Tt();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function en(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=zl.updateQueue,t===null&&(t=Et(),zl.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function tn(){return Tt().memoizedState}function nn(e,t,n,r){var i=wt();zl.flags|=e,i.memoizedState=en(1|t,{destroy:void 0},n,r===void 0?null:r)}function rn(e,t,n,r){var i=Tt();r=r===void 0?null:r;var a=i.memoizedState.inst;Bl!==null&&r!==null&&gt(r,Bl.memoizedState.deps)?i.memoizedState=en(t,a,n,r):(zl.flags|=e,i.memoizedState=en(1|t,a,n,r))}function an(e,t){nn(8390656,8,e,t)}function on(e,t){rn(2048,8,e,t)}function sn(e){zl.flags|=4;var t=zl.updateQueue;if(t===null)t=Et(),zl.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function cn(e){var t=Tt().memoizedState;return sn({ref:t,nextImpl:e}),function(){if(bu&2)throw Error(r(440));return t.impl.apply(void 0,arguments)}}function ln(e,t){return rn(4,2,e,t)}function un(e,t){return rn(4,4,e,t)}function dn(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function fn(e,t,n){n=n==null?null:n.concat([e]),rn(4,4,dn.bind(null,t,e),n)}function pn(){}function mn(e,t){var n=Tt();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&gt(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function hn(e,t){var n=Tt();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&gt(t,r[1]))return r[0];if(r=e(),Wl){O(!0);try{e()}finally{O(!1)}}return n.memoizedState=[r,t],r}function gn(e,t,n){return n===void 0||Rl&1073741824&&!(Cu&261930)?e.memoizedState=t:(e.memoizedState=n,e=wi(),zl.lanes|=e,ju|=e,n)}function _n(e,t,n,r){return Oc(n,t)?n:Nl.current===null?!(Rl&42)||Rl&1073741824&&!(Cu&261930)?(tu=!0,e.memoizedState=n):(e=wi(),zl.lanes|=e,ju|=e,t):(e=gn(e,n,r),Oc(e,t)||(tu=!0),e)}function vn(e,t,n,r,i){var a=fo();uo(a!==0&&8>a?a:8);var o=J.T,s={};J.T=s,Dn(e,!1,t,n);try{var c=i(),l=J.S;l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`?En(e,t,Ae(c,r),Ci(e)):En(e,t,r,Ci(e))}catch(n){En(e,t,{then:function(){},status:`rejected`,reason:n},Ci())}finally{uo(a),o!==null&&s.types!==null&&(o.types=s.types),J.T=o}}function yn(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Co,baseState:Co,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:At,lastRenderedState:Co},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:At,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function bn(){return ge(wo)}function xn(){return Tt().memoizedState}function Sn(){return Tt().memoizedState}function Cn(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=Ci();e=Qe(n);var r=$e(t,e,n);r!==null&&(Ti(r,t,n),et(r,t,n)),t={cache:ve()},e.payload=t;return}t=t.return}}function wn(e,t,n){var r=Ci();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},On(e)?kn(t,n):(n=Ke(e,t,n,r),n!==null&&(Ti(n,e,r),An(n,t,r)))}function Tn(e,t,n){En(e,t,n,Ci())}function En(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(On(e))kn(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,Oc(s,o))return Ge(e,t,i,0),xu===null&&We(),!1}catch{}if(n=Ke(e,t,i,r),n!==null)return Ti(n,e,r),An(n,t,r),!0}return!1}function Dn(e,t,n,i){if(i={lane:2,revertLane:De(),gesture:null,action:i,hasEagerState:!1,eagerState:null,next:null},On(e)){if(t)throw Error(r(479))}else t=Ke(e,n,i,2),t!==null&&Ti(t,e,2)}function On(e){var t=e.alternate;return e===zl||t!==null&&t===zl}function kn(e,t){Ul=Hl=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function An(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,w(e,n)}}function jn(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:Ta({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}function Mn(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Pe(n,r)||!Pe(i,a):!0}function Nn(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&$l.enqueueReplaceState(t,t.state,null)}function Pn(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=Ta({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function Fn(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function In(e,t,n){try{var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function Ln(e,t,n){return n=Qe(n),n.tag=3,n.payload={element:null},n.callback=function(){Fn(e,t)},n}function Rn(e){return e=Qe(e),e.tag=3,e}function zn(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){In(t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){In(t,n,r),typeof i!=`function`&&(Uu===null?Uu=new Set([this]):Uu.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:e===null?``:e})})}function Bn(e,t,n,i,a){if(n.flags|=32768,typeof i==`object`&&i&&typeof i.then==`function`){if(t=n.alternate,t!==null&&pe(t,n,a,!0),n=Fl.current,n!==null){switch(n.tag){case 31:case 13:return Il===null?Li():n.alternate===null&&Au===0&&(Au=3),n.flags&=-257,n.flags|=65536,n.lanes=a,i===Sl?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([i]):t.add(i),ta(e,i,a)),!1;case 22:return n.flags|=65536,i===Sl?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([i])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([i]):n.add(i)),ta(e,i,a)),!1}throw Error(r(435,n.tag))}return ta(e,i,a),Li(),!1}if(Xc)return t=Fl.current,t===null?(i!==$c&&(t=Error(r(423),{cause:i}),ce(P(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,i=P(i,n),a=Ln(e.stateNode,i,a),tt(e,a),Au!==4&&(Au=2)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=a,i!==$c&&(e=Error(r(422),{cause:i}),ce(P(e,n)))),!1;var o=Error(r(520),{cause:i});if(o=P(o,n),Iu===null?Iu=[o]:Iu.push(o),Au!==4&&(Au=2),t===null)return!0;i=P(i,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=Ln(n.stateNode,i,e),tt(n,e),!1;case 1:if(t=n.type,o=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||o!==null&&typeof o.componentDidCatch==`function`&&(Uu===null||!Uu.has(o))))return n.flags|=65536,a&=-a,n.lanes|=a,a=Rn(a),zn(a,e,n,i),tt(n,a),!1}n=n.return}while(n!==null);return!1}function G(e,t,n,r){t.child=e===null?Dl(t,null,n,r):El(t,e.child,n,r)}function Vn(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return he(t),r=_t(e,t,n,o,a,i),s=xt(),e!==null&&!tu?(St(e,t,i),ur(e,t,i)):(Xc&&s&&L(t),t.flags|=1,G(e,t,r,i),t.child)}function Hn(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!ca(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,Un(e,t,a,r,i)):(e=ua(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!dr(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Pe:n,n(o,r)&&e.ref===t.ref)return ur(e,t,i)}return t.flags|=1,e=la(a,r),e.ref=t.ref,e.return=t,t.child=e}function Un(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Pe(a,r)&&e.ref===t.ref)if(tu=!1,t.pendingProps=r=a,dr(e,i))e.flags&131072&&(tu=!0);else return t.lanes=e.lanes,ur(e,t,i)}return Zn(e,t,n,r,i)}function Wn(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return Kn(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Me(t,a===null?null:a.cachePool),a===null?st():ot(t,a),dt(t);else return r=t.lanes=536870912,Kn(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&Me(t,null),st(),ft()):(Me(t,a.cachePool),ot(t,a),ft(),t.memoizedState=null);return G(e,t,i,n),t.child}function Gn(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Kn(e,t,n,r,i){var a=je();return a=a===null?null:{parent:oo?ol._currentValue:ol._currentValue2,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&Me(t,null),st(),dt(t),e!==null&&pe(e,t,r,!0),t.childLanes=i,null}function qn(e,t){return t=ar({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Jn(e,t,n){return El(t,e.child,null,n),e=qn(t,t.pendingProps),e.flags|=2,pt(t),t.memoizedState=null,e}function Yn(e,t,n){var i=t.pendingProps,a=(t.flags&128)!=0;if(t.flags&=-129,e===null){if(Xc){if(i.mode===`hidden`)return e=qn(t,i),t.lanes=536870912,Gn(null,e);if(ut(t),(e=Yc)?(e=ys(e,Qc),e!==null&&(t.memoizedState={dehydrated:e,treeContext:Vc===null?null:{id:Hc,overflow:Uc},retryLane:536870912,hydrationErrors:null},n=pa(e),n.return=t,t.child=n,Jc=t,Yc=null)):e=null,e===null)throw V(t);return t.lanes=536870912,null}return qn(t,i)}var o=e.memoizedState;if(o!==null){var s=o.dehydrated;if(ut(t),a)if(t.flags&256)t.flags&=-257,t=Jn(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(r(558));else if(tu||pe(e,t,n,!1),a=(n&e.childLanes)!==0,tu||a){if(i=xu,i!==null&&(s=T(i,n),s!==0&&s!==o.retryLane))throw o.retryLane=s,qe(e,s),Ti(i,e,s),eu;Li(),t=Jn(e,t,n)}else e=o.treeContext,so&&(Yc=ms(s),Jc=t,Xc=!0,Zc=null,Qc=!1,e!==null&&te(t,e)),t=qn(t,i),t.flags|=4096;return t}return e=la(e.child,{mode:i.mode,children:i.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Xn(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(r(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Zn(e,t,n,r,i){return he(t),n=_t(e,t,n,r,void 0,i),r=xt(),e!==null&&!tu?(St(e,t,i),ur(e,t,i)):(Xc&&r&&L(t),t.flags|=1,G(e,t,n,i),t.child)}function Qn(e,t,n,r,i,a){return he(t),t.updateQueue=null,n=yt(t,r,n,i),vt(e),r=xt(),e!==null&&!tu?(St(e,t,a),ur(e,t,a)):(Xc&&r&&L(t),t.flags|=1,G(e,t,n,a),t.child)}function $n(e,t,n,r,i){if(he(t),t.stateNode===null){var a=cc,o=n.contextType;typeof o==`object`&&o&&(a=ge(o)),a=new n(r,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=$l,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},Xe(t),o=n.contextType,a.context=typeof o==`object`&&o?ge(o):cc,a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(jn(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&$l.enqueueReplaceState(a,a.state,null),rt(t,r,a,i),nt(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!0}else if(e===null){a=t.stateNode;var s=t.memoizedProps,c=Pn(n,s);a.props=c;var l=a.context,u=n.contextType;o=cc,typeof u==`object`&&u&&(o=ge(u));var d=n.getDerivedStateFromProps;u=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`,s=t.pendingProps!==s,u||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(s||l!==o)&&Nn(t,a,r,o),jl=!1;var f=t.memoizedState;a.state=f,rt(t,r,a,i),nt(),l=t.memoizedState,s||f!==l||jl?(typeof d==`function`&&(jn(t,n,d,r),l=t.memoizedState),(c=jl||Mn(t,n,c,r,f,l,o))?(u||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=l),a.props=r,a.state=l,a.context=o,r=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,Ze(e,t),o=t.memoizedProps,u=Pn(n,o),a.props=u,d=t.pendingProps,f=a.context,l=n.contextType,c=cc,typeof l==`object`&&l&&(c=ge(l)),s=n.getDerivedStateFromProps,(l=typeof s==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==d||f!==c)&&Nn(t,a,r,c),jl=!1,f=t.memoizedState,a.state=f,rt(t,r,a,i),nt();var p=t.memoizedState;o!==d||f!==p||jl||e!==null&&e.dependencies!==null&&me(e.dependencies)?(typeof s==`function`&&(jn(t,n,s,r),p=t.memoizedState),(u=jl||Mn(t,n,u,r,f,p,c)||e!==null&&e.dependencies!==null&&me(e.dependencies))?(l||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,p,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,p,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=c,r=u):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,Xn(e,t),r=(t.flags&128)!=0,a||r?(a=t.stateNode,n=r&&typeof n.getDerivedStateFromError!=`function`?null:a.render(),t.flags|=1,e!==null&&r?(t.child=El(t,e.child,null,i),t.child=El(t,null,n,i)):G(e,t,n,i),t.memoizedState=a.state,e=t.child):e=ur(e,t,i),e}function er(e,t,n,r){return oe(),t.flags|=256,G(e,t,n,r),t.child}function tr(e){return{baseLanes:e,cachePool:Ne()}}function nr(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=Pu),e}function rr(e,t,n){var i=t.pendingProps,a=!1,o=(t.flags&128)!=0,s;if((s=o)||(s=e!==null&&e.memoizedState===null?!1:(Ll.current&2)!=0),s&&(a=!0,t.flags&=-129),s=(t.flags&32)!=0,t.flags&=-33,e===null){if(Xc){if(a?lt(t):ft(),(e=Yc)?(e=bs(e,Qc),e!==null&&(t.memoizedState={dehydrated:e,treeContext:Vc===null?null:{id:Hc,overflow:Uc},retryLane:536870912,hydrationErrors:null},n=pa(e),n.return=t,t.child=n,Jc=t,Yc=null)):e=null,e===null)throw V(t);return as(e)?t.lanes=32:t.lanes=536870912,null}var c=i.children;return i=i.fallback,a?(ft(),a=t.mode,c=ar({mode:`hidden`,children:c},a),i=da(i,a,n,null),c.return=t,i.return=t,c.sibling=i,t.child=c,i=t.child,i.memoizedState=tr(n),i.childLanes=nr(e,s,n),t.memoizedState=nu,Gn(null,i)):(lt(t),ir(t,c))}var l=e.memoizedState;if(l!==null&&(c=l.dehydrated,c!==null)){if(o)t.flags&256?(lt(t),t.flags&=-257,t=or(e,t,n)):t.memoizedState===null?(ft(),c=i.fallback,a=t.mode,i=ar({mode:`visible`,children:i.children},a),c=da(c,a,n,null),c.flags|=2,i.return=t,c.return=t,i.sibling=c,t.child=i,El(t,e.child,null,n),i=t.child,i.memoizedState=tr(n),i.childLanes=nr(e,s,n),t.memoizedState=nu,t=Gn(null,i)):(ft(),t.child=e.child,t.flags|=128,t=null);else if(lt(t),as(c))s=os(c).digest,i=Error(r(419)),i.stack=``,i.digest=s,ce({value:i,source:null,stack:null}),t=or(e,t,n);else if(tu||pe(e,t,n,!1),s=(n&e.childLanes)!==0,tu||s){if(s=xu,s!==null&&(i=T(s,n),i!==0&&i!==l.retryLane))throw l.retryLane=i,qe(e,i),Ti(s,e,i),eu;is(c)||Li(),t=or(e,t,n)}else is(c)?(t.flags|=192,t.child=e.child,t=null):(e=l.treeContext,so&&(Yc=hs(c),Jc=t,Xc=!0,Zc=null,Qc=!1,e!==null&&te(t,e)),t=ir(t,i.children),t.flags|=4096);return t}return a?(ft(),c=i.fallback,a=t.mode,l=e.child,o=l.sibling,i=la(l,{mode:`hidden`,children:i.children}),i.subtreeFlags=l.subtreeFlags&65011712,o===null?(c=da(c,a,n,null),c.flags|=2):c=la(o,c),c.return=t,i.return=t,i.sibling=c,t.child=i,Gn(null,i),i=t.child,c=e.child.memoizedState,c===null?c=tr(n):(a=c.cachePool,a===null?a=Ne():(l=oo?ol._currentValue:ol._currentValue2,a=a.parent===l?a:{parent:l,pool:l}),c={baseLanes:c.baseLanes|n,cachePool:a}),i.memoizedState=c,i.childLanes=nr(e,s,n),t.memoizedState=nu,Gn(e.child,i)):(lt(t),n=e.child,e=n.sibling,n=la(n,{mode:`visible`,children:i.children}),n.return=t,n.sibling=null,e!==null&&(s=t.deletions,s===null?(t.deletions=[e],t.flags|=16):s.push(e)),t.child=n,t.memoizedState=null,n)}function ir(e,t){return t=ar({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function ar(e,n){return e=t(22,e,null,n),e.lanes=0,e}function or(e,t,n){return El(t,e.child,null,n),e=ir(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function sr(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),de(e.return,t,n)}function cr(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function lr(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;r=r.children;var o=Ll.current,s=(o&2)!=0;if(s?(o=o&1|2,t.flags|=128):o&=1,p(Ll,o),G(e,t,r,n),r=Xc?Rc:0,!s&&e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&sr(e,n,t);else if(e.tag===19)sr(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`forwards`:for(n=t.child,i=null;n!==null;)e=n.alternate,e!==null&&mt(e)===null&&(i=n),n=n.sibling;n=i,n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),cr(t,!1,i,n,a,r);break;case`backwards`:case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&mt(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}cr(t,!0,n,null,a,r);break;case`together`:cr(t,!1,null,null,void 0,r);break;default:t.memoizedState=null}return t.child}function ur(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),ju|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(pe(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(r(153));if(t.child!==null){for(e=t.child,n=la(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=la(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function dr(e,t){return(e.lanes&t)===0?(e=e.dependencies,!!(e!==null&&me(e))):!0}function fr(e,t,n){switch(t.tag){case 3:ne(t,t.stateNode.containerInfo),le(t,ol,e.memoizedState.cache),oe();break;case 27:case 5:z(t);break;case 4:ne(t,t.stateNode.containerInfo);break;case 10:le(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,ut(t),null;break;case 13:var r=t.memoizedState;if(r!==null)return r.dehydrated===null?(n&t.child.childLanes)===0?(lt(t),e=ur(e,t,n),e===null?null:e.sibling):rr(e,t,n):(lt(t),t.flags|=128,null);lt(t);break;case 19:var i=(e.flags&128)!=0;if(r=(n&t.childLanes)!==0,r||=(pe(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return lr(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),p(Ll,Ll.current),r)break;return null;case 22:return t.lanes=0,Wn(e,t,n,t.pendingProps);case 24:le(t,ol,e.memoizedState.cache)}return ur(e,t,n)}function pr(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)tu=!0;else{if(!dr(e,n)&&!(t.flags&128))return tu=!1,fr(e,t,n);tu=(e.flags&131072)!=0}else tu=!1,Xc&&t.flags&1048576&&I(t,Rc,t.index);switch(t.lanes=0,t.tag){case 16:e:{var i=t.pendingProps;if(e=Le(t.elementType),t.type=e,typeof e==`function`)ca(e)?(i=Pn(e,i),t.tag=1,t=$n(null,t,e,i,n)):(t.tag=0,t=Zn(null,t,e,i,n));else{if(e!=null){var a=e.$$typeof;if(a===Pa){t.tag=11,t=Vn(null,t,e,i,n);break e}else if(a===La){t.tag=14,t=Hn(null,t,e,i,n);break e}}throw t=u(e)||e,Error(r(306,t,``))}}return t;case 0:return Zn(e,t,t.type,t.pendingProps,n);case 1:return i=t.type,a=Pn(i,t.pendingProps),$n(e,t,i,a,n);case 3:e:{if(ne(t,t.stateNode.containerInfo),e===null)throw Error(r(387));var o=t.pendingProps;a=t.memoizedState,i=a.element,Ze(e,t),rt(t,o,null,n);var s=t.memoizedState;if(o=s.cache,le(t,ol,o),o!==a.cache&&fe(t,[ol],n,!0),nt(),o=s.element,so&&a.isDehydrated)if(a={element:o,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=a,t.memoizedState=a,t.flags&256){t=er(e,t,o,n);break e}else if(o!==i){i=P(Error(r(424)),t),ce(i),t=er(e,t,o,n);break e}else for(so&&(Yc=ps(t.stateNode.containerInfo),Jc=t,Xc=!0,Zc=null,Qc=!0),n=Dl(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(oe(),o===i){t=ur(e,t,n);break e}G(e,t,o,n)}t=t.child}return t;case 26:if(Bs)return Xn(e,t),e===null?(n=Us(t.type,null,t.pendingProps,null))?t.memoizedState=n:Xc||(t.stateNode=Ys(t.type,t.pendingProps,Kc.current,t)):t.memoizedState=Us(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:if(ec)return z(t),e===null&&ec&&Xc&&(i=t.stateNode=tc(t.type,t.pendingProps,Kc.current,Wc.current,!1),Jc=t,Qc=!0,Yc=gs(t.type,i,Yc)),G(e,t,t.pendingProps.children,n),Xn(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&Xc&&(Rs(t.type,t.pendingProps,Wc.current),(a=i=Yc)&&(i=_s(i,t.type,t.pendingProps,Qc),i===null?a=!1:(t.stateNode=i,Jc=t,Yc=fs(i),Qc=!1,a=!0)),a||V(t)),z(t),a=t.type,o=t.pendingProps,s=e===null?null:e.memoizedProps,i=o.children,to(a,o)?i=null:s!==null&&to(a,s)&&(t.flags|=32),t.memoizedState!==null&&(a=_t(e,t,bt,null,null,n),oo?wo._currentValue=a:wo._currentValue2=a),Xn(e,t),G(e,t,i,n),t.child;case 6:return e===null&&Xc&&(zs(t.pendingProps,Wc.current),(e=n=Yc)&&(n=vs(n,t.pendingProps,Qc),n===null?e=!1:(t.stateNode=n,Jc=t,Yc=null,e=!0)),e||V(t)),null;case 13:return rr(e,t,n);case 4:return ne(t,t.stateNode.containerInfo),i=t.pendingProps,e===null?t.child=El(t,null,i,n):G(e,t,i,n),t.child;case 11:return Vn(e,t,t.type,t.pendingProps,n);case 7:return G(e,t,t.pendingProps,n),t.child;case 8:return G(e,t,t.pendingProps.children,n),t.child;case 12:return G(e,t,t.pendingProps.children,n),t.child;case 10:return i=t.pendingProps,le(t,t.type,i.value),G(e,t,i.children,n),t.child;case 9:return a=t.type._context,i=t.pendingProps.children,he(t),a=ge(a),i=i(a),t.flags|=1,G(e,t,i,n),t.child;case 14:return Hn(e,t,t.type,t.pendingProps,n);case 15:return Un(e,t,t.type,t.pendingProps,n);case 19:return lr(e,t,n);case 31:return Yn(e,t,n);case 22:return Wn(e,t,n,t.pendingProps);case 24:return he(t),i=ge(ol),e===null?(a=je(),a===null&&(a=xu,o=ve(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=n),a=o),t.memoizedState={parent:i,cache:a},Xe(t),le(t,ol,a)):((e.lanes&n)!==0&&(Ze(e,t),rt(t,null,null,n),nt()),a=e.memoizedState,o=t.memoizedState,a.parent===i?(i=o.cache,le(t,ol,i),i!==a.cache&&fe(t,[ol],n,!0)):(a={parent:i,cache:i},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),le(t,ol,i))),G(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(r(156,t.tag))}function mr(e){e.flags|=4}function hr(e){Z&&(e.flags|=8)}function gr(e,t){if(e!==null&&e.child===t.child)return!1;if(t.flags&16)return!0;for(e=t.child;e!==null;){if(e.flags&8218||e.subtreeFlags&8218)return!0;e=e.sibling}return!1}function _r(e,t,n,r){if(X)for(n=t.child;n!==null;){if(n.tag===5||n.tag===6)$a(e,n.stateNode);else if(!(n.tag===4||ec&&n.tag===27)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}else if(Z)for(var i=t.child;i!==null;){if(i.tag===5){var a=i.stateNode;n&&r&&(a=ns(a,i.type,i.memoizedProps)),$a(e,a)}else if(i.tag===6)a=i.stateNode,n&&r&&(a=rs(a,i.memoizedProps)),$a(e,a);else if(i.tag!==4){if(i.tag===22&&i.memoizedState!==null)a=i.child,a!==null&&(a.return=i),_r(e,i,!0,!0);else if(i.child!==null){i.child.return=i,i=i.child;continue}}if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return;i=i.return}i.sibling.return=i.return,i=i.sibling}}function vr(e,t,n,r){var i=!1;if(Z)for(var a=t.child;a!==null;){if(a.tag===5){var o=a.stateNode;n&&r&&(o=ns(o,a.type,a.memoizedProps)),$o(e,o)}else if(a.tag===6)o=a.stateNode,n&&r&&(o=rs(o,a.memoizedProps)),$o(e,o);else if(a.tag!==4){if(a.tag===22&&a.memoizedState!==null)i=a.child,i!==null&&(i.return=a),vr(e,a,!0,!0),i=!0;else if(a.child!==null){a.child.return=a,a=a.child;continue}}if(a===t)break;for(;a.sibling===null;){if(a.return===null||a.return===t)return i;a=a.return}a.sibling.return=a.return,a=a.sibling}return i}function yr(e,t){if(Z&&gr(e,t)){e=t.stateNode;var n=e.containerInfo,r=Qo();vr(r,t,!1,!1),e.pendingChildren=r,mr(t),es(n,r)}}function br(e,t,n,r){if(X)e.memoizedProps!==r&&mr(t);else if(Z){var i=e.stateNode,a=e.memoizedProps;if((e=gr(e,t))||a!==r){var o=Wc.current;a=Zo(i,n,a,r,!e,null),a===i?t.stateNode=i:(hr(t),eo(a,n,r,o)&&mr(t),t.stateNode=a,e&&_r(a,t,!1,!1))}else t.stateNode=i}}function xr(e,t,n,r,i){if(e.mode&32&&(n===null?go(t,r):_o(t,n,r))){if(e.flags|=16777216,(i&335544128)===i||vo(t,r))if(yo(e.stateNode,t,r))e.flags|=8192;else if(Pi())e.flags|=8192;else throw Cl=Sl,bl}else e.flags&=-16777217}function Sr(e,t){if(Zs(t)){if(e.flags|=16777216,!Qs(t))if(Pi())e.flags|=8192;else throw Cl=Sl,bl}else e.flags&=-16777217}function Cr(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:y(),e.lanes|=t,Fu|=t)}function wr(e,t){if(!Xc)switch(e.tailMode){case`hidden`:t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case`collapsed`:n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function Tr(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&65011712,r|=i.flags&65011712,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function Er(e,t,n){var i=t.pendingProps;switch(ee(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Tr(t),null;case 1:return Tr(t),null;case 3:return n=t.stateNode,i=null,e!==null&&(i=e.memoizedState.cache),t.memoizedState.cache!==i&&(t.flags|=2048),ue(ol),R(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(ae(t)?mr(t):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,se())),yr(e,t),Tr(t),null;case 26:if(Bs){var a=t.type,o=t.memoizedState;return e===null?(mr(t),o===null?(Tr(t),xr(t,a,null,i,n)):(Tr(t),Sr(t,o))):o?o===e.memoizedState?(Tr(t),t.flags&=-16777217):(mr(t),Tr(t),Sr(t,o)):(o=e.memoizedProps,X?o!==i&&mr(t):br(e,t,a,i),Tr(t),xr(t,a,o,i,n)),null}case 27:if(ec){if(B(t),n=Kc.current,a=t.type,e!==null&&t.stateNode!=null)X?e.memoizedProps!==i&&mr(t):br(e,t,a,i);else{if(!i){if(t.stateNode===null)throw Error(r(166));return Tr(t),null}e=Wc.current,ae(t)?re(t,e):(e=tc(a,i,n,e,!0),t.stateNode=e,mr(t))}return Tr(t),null}case 5:if(B(t),a=t.type,e!==null&&t.stateNode!=null)br(e,t,a,i);else{if(!i){if(t.stateNode===null)throw Error(r(166));return Tr(t),null}if(o=Wc.current,ae(t))re(t,o),js(t.stateNode,a,i,o)&&(t.flags|=64);else{var s=Qa(a,i,Kc.current,o,t);hr(t),_r(s,t,!1,!1),t.stateNode=s,eo(s,a,i,o)&&mr(t)}}return Tr(t),xr(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)n=e.memoizedProps,X?n!==i&&mr(t):Z&&(n===i?t.stateNode=e.stateNode:(e=Kc.current,n=Wc.current,hr(t),t.stateNode=no(i,e,n,t)));else{if(typeof i!=`string`&&t.stateNode===null)throw Error(r(166));if(e=Kc.current,n=Wc.current,ae(t)){if(!so)throw Error(r(176));if(e=t.stateNode,n=t.memoizedProps,i=null,a=Jc,a!==null)switch(a.tag){case 27:case 5:i=a.memoizedProps}Ss(e,n,t,i)||V(t,!0)}else hr(t),t.stateNode=no(i,e,n,t)}return Tr(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(i=ae(t),n!==null){if(e===null){if(!i)throw Error(r(318));if(!so)throw Error(r(556));if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(r(557));Cs(e,t)}else oe(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;Tr(t),e=!1}else n=se(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(pt(t),t):(pt(t),null);if(t.flags&128)throw Error(r(558))}return Tr(t),null;case 13:if(i=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=ae(t),i!==null&&i.dehydrated!==null){if(e===null){if(!a)throw Error(r(318));if(!so)throw Error(r(344));if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(r(317));ws(a,t)}else oe(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;Tr(t),a=!1}else a=se(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(pt(t),t):(pt(t),null)}return pt(t),t.flags&128?(t.lanes=n,t):(n=i!==null,e=e!==null&&e.memoizedState!==null,n&&(i=t.child,a=null,i.alternate!==null&&i.alternate.memoizedState!==null&&i.alternate.memoizedState.cachePool!==null&&(a=i.alternate.memoizedState.cachePool.pool),o=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(o=i.memoizedState.cachePool.pool),o!==a&&(i.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Cr(t,t.updateQueue),Tr(t),null);case 4:return R(),yr(e,t),e===null&&lo(t.stateNode.containerInfo),Tr(t),null;case 10:return ue(t.type),Tr(t),null;case 19:if(f(Ll),i=t.memoizedState,i===null)return Tr(t),null;if(a=(t.flags&128)!=0,o=i.rendering,o===null)if(a)wr(i,!1);else{if(Au!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=mt(e),o!==null){for(t.flags|=128,wr(i,!1),e=o.updateQueue,t.updateQueue=e,Cr(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)q(n,e),n=n.sibling;return p(Ll,Ll.current&1|2),Xc&&F(t,i.treeForkCount),t.child}e=e.sibling}i.tail!==null&&yc()>Vu&&(t.flags|=128,a=!0,wr(i,!1),t.lanes=4194304)}else{if(!a)if(e=mt(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,Cr(t,e),wr(i,!0),i.tail===null&&i.tailMode===`hidden`&&!o.alternate&&!Xc)return Tr(t),null}else 2*yc()-i.renderingStartTime>Vu&&n!==536870912&&(t.flags|=128,a=!0,wr(i,!1),t.lanes=4194304);i.isBackwards?(o.sibling=t.child,t.child=o):(e=i.last,e===null?t.child=o:e.sibling=o,i.last=o)}return i.tail===null?(Tr(t),null):(e=i.tail,i.rendering=e,i.tail=e.sibling,i.renderingStartTime=yc(),e.sibling=null,n=Ll.current,p(Ll,a?n&1|2:n&1),Xc&&F(t,i.treeForkCount),e);case 22:case 23:return pt(t),ct(),i=t.memoizedState!==null,e===null?i&&(t.flags|=8192):e.memoizedState!==null!==i&&(t.flags|=8192),i?n&536870912&&!(t.flags&128)&&(Tr(t),t.subtreeFlags&6&&(t.flags|=8192)):Tr(t),n=t.updateQueue,n!==null&&Cr(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),i=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),i!==n&&(t.flags|=2048),e!==null&&f(vl),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ue(ol),Tr(t),null;case 25:return null;case 30:return null}throw Error(r(156,t.tag))}function Dr(e,t){switch(ee(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ue(ol),R(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return B(t),null;case 31:if(t.memoizedState!==null){if(pt(t),t.alternate===null)throw Error(r(340));oe()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(pt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(r(340));oe()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return f(Ll),null;case 4:return R(),null;case 10:return ue(t.type),null;case 22:case 23:return pt(t),ct(),e!==null&&f(vl),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return ue(ol),null;case 25:return null;default:return null}}function Or(e,t){switch(ee(t),t.tag){case 3:ue(ol),R();break;case 26:case 27:case 5:B(t);break;case 4:R();break;case 31:t.memoizedState!==null&&pt(t);break;case 13:pt(t);break;case 19:f(Ll);break;case 10:ue(t.type);break;case 22:case 23:pt(t),ct(),e!==null&&f(vl);break;case 24:ue(ol)}}function kr(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var a=n.create,o=n.inst;r=a(),o.destroy=r}n=n.next}while(n!==i)}}catch(e){ea(t,t.return,e)}}function Ar(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;if(s!==void 0){o.destroy=void 0,i=t;var c=n,l=s;try{l()}catch(e){ea(i,c,e)}}}r=r.next}while(r!==a)}}catch(e){ea(t,t.return,e)}}function jr(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{at(t,n)}catch(t){ea(e,e.return,t)}}}function Mr(e,t,n){n.props=Pn(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){ea(e,t,n)}}function Nr(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var r=qa(e.stateNode);break;case 30:r=e.stateNode;break;default:r=e.stateNode}typeof n==`function`?e.refCleanup=n(r):n.current=r}}catch(n){ea(e,t,n)}}function Pr(e,t){var n=e.ref,r=e.refCleanup;if(n!==null)if(typeof r==`function`)try{r()}catch(n){ea(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{n(null)}catch(n){ea(e,t,n)}else n.current=null}function Fr(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{zo(r,t,n,e)}catch(t){ea(e,e.return,t)}}function Ir(e,t,n){try{Bo(e.stateNode,e.type,n,t,e)}catch(t){ea(e,e.return,t)}}function Lr(e){return e.tag===5||e.tag===3||(Bs?e.tag===26:!1)||(ec?e.tag===27&&ac(e.type):!1)||e.tag===4}function Rr(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Lr(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(ec&&e.tag===27&&ac(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function zr(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?Ho(n,e,t):Lo(n,e);else if(r!==4&&(ec&&r===27&&ac(e.type)&&(n=e.stateNode,t=null),e=e.child,e!==null))for(zr(e,t,n),e=e.sibling;e!==null;)zr(e,t,n),e=e.sibling}function Br(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?Vo(n,e,t):Io(n,e);else if(r!==4&&(ec&&r===27&&ac(e.type)&&(n=e.stateNode),e=e.child,e!==null))for(Br(e,t,n),e=e.sibling;e!==null;)Br(e,t,n),e=e.sibling}function Vr(e,t,n){e=e.containerInfo;try{ts(e,n)}catch(e){ea(t,t.return,e)}}function Hr(e){var t=e.stateNode,n=e.memoizedProps;try{nc(e.type,n,t,e)}catch(t){ea(e,e.return,t)}}function Ur(e,t){for(Xa(e.containerInfo),su=t;su!==null;)if(e=su,t=e.child,e.subtreeFlags&1028&&t!==null)t.return=e,su=t;else for(;su!==null;){e=su;var n=e.alternate;switch(t=e.flags,e.tag){case 0:if(t&4&&(t=e.updateQueue,t=t===null?null:t.events,t!==null))for(var i=0;i<t.length;i++){var a=t[i];a.ref.impl=a.nextImpl}break;case 11:case 15:break;case 1:if(t&1024&&n!==null){t=void 0,i=e,a=n.memoizedProps,n=n.memoizedState;var o=i.stateNode;try{var s=Pn(i.type,a);t=o.getSnapshotBeforeUpdate(s,n),o.__reactInternalSnapshotBeforeUpdate=t}catch(e){ea(i,i.return,e)}}break;case 3:t&1024&&X&&Xo(e.stateNode.containerInfo);break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if(t&1024)throw Error(r(163))}if(t=e.sibling,t!==null){t.return=e.return,su=t;break}su=e.return}}function Wr(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:ni(e,n),r&4&&kr(5,n);break;case 1:if(ni(e,n),r&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(e){ea(n,n.return,e)}else{var i=Pn(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){ea(n,n.return,e)}}r&64&&jr(n),r&512&&Nr(n,n.return);break;case 3:if(ni(e,n),r&64&&(r=n.updateQueue,r!==null)){if(e=null,n.child!==null)switch(n.child.tag){case 27:case 5:e=qa(n.child.stateNode);break;case 1:e=n.child.stateNode}try{at(r,e)}catch(e){ea(n,n.return,e)}}break;case 27:ec&&t===null&&r&4&&Hr(n);case 26:case 5:if(ni(e,n),t===null){if(r&4)Fr(n);else if(r&64){e=n.type,t=n.memoizedProps,i=n.stateNode;try{Ds(i,e,t,n)}catch(e){ea(n,n.return,e)}}}r&512&&Nr(n,n.return);break;case 12:ni(e,n);break;case 31:ni(e,n),r&4&&Jr(e,n);break;case 13:ni(e,n),r&4&&Yr(e,n),r&64&&(r=n.memoizedState,r!==null&&(r=r.dehydrated,r!==null&&(n=ia.bind(null,n),ss(r,n))));break;case 22:if(r=n.memoizedState!==null||ru,!r){t=t!==null&&t.memoizedState!==null||iu,i=ru;var a=iu;ru=r,(iu=t)&&!a?ii(e,n,(n.subtreeFlags&8772)!=0):ni(e,n),ru=i,iu=a}break;case 30:break;default:ni(e,n)}}function Gr(e){var t=e.alternate;t!==null&&(e.alternate=null,Gr(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&ho(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Kr(e,t,n){for(n=n.child;n!==null;)qr(e,t,n),n=n.sibling}function qr(e,t,n){if(Dc&&typeof Dc.onCommitFiberUnmount==`function`)try{Dc.onCommitFiberUnmount(Ec,n)}catch{}switch(n.tag){case 26:if(Bs){iu||Pr(n,t),Kr(e,t,n),n.memoizedState?Gs(n.memoizedState):n.stateNode&&Js(n.stateNode);break}case 27:if(ec){iu||Pr(n,t);var r=cu,i=lu;ac(n.type)&&(cu=n.stateNode,lu=!1),Kr(e,t,n),rc(n.stateNode),cu=r,lu=i;break}case 5:iu||Pr(n,t);case 6:if(X){if(r=cu,i=lu,cu=null,Kr(e,t,n),cu=r,lu=i,cu!==null)if(lu)try{Wo(cu,n.stateNode)}catch(e){ea(n,t,e)}else try{Uo(cu,n.stateNode)}catch(e){ea(n,t,e)}}else Kr(e,t,n);break;case 18:X&&cu!==null&&(lu?Ps(cu,n.stateNode):Ns(cu,n.stateNode));break;case 4:X?(r=cu,i=lu,cu=n.stateNode.containerInfo,lu=!0,Kr(e,t,n),cu=r,lu=i):(Z&&Vr(n.stateNode,n,Qo()),Kr(e,t,n));break;case 0:case 11:case 14:case 15:Ar(2,n,t),iu||Ar(4,n,t),Kr(e,t,n);break;case 1:iu||(Pr(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`&&Mr(n,t,r)),Kr(e,t,n);break;case 21:Kr(e,t,n);break;case 22:iu=(r=iu)||n.memoizedState!==null,Kr(e,t,n),iu=r;break;default:Kr(e,t,n)}}function Jr(e,t){if(so&&t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ks(e)}catch(e){ea(t,t.return,e)}}}function Yr(e,t){if(so&&t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{As(e)}catch(e){ea(t,t.return,e)}}function Xr(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new ou),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new ou),t;default:throw Error(r(435,e.tag))}}function Zr(e,t){var n=Xr(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=aa.bind(null,e,t);t.then(r,r)}})}function Qr(e,t){var n=t.deletions;if(n!==null)for(var i=0;i<n.length;i++){var a=n[i],o=e,s=t;if(X){var c=s;e:for(;c!==null;){switch(c.tag){case 27:if(ec){if(ac(c.type)){cu=c.stateNode,lu=!1;break e}break}case 5:cu=c.stateNode,lu=!1;break e;case 3:case 4:cu=c.stateNode.containerInfo,lu=!0;break e}c=c.return}if(cu===null)throw Error(r(160));qr(o,s,a),cu=null,lu=!1}else qr(o,s,a);o=a.alternate,o!==null&&(o.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)$r(t,e),t=t.sibling}function $r(e,t){var n=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Qr(t,e),ei(e),i&4&&(Ar(3,e,e.return),kr(3,e),Ar(5,e,e.return));break;case 1:Qr(t,e),ei(e),i&512&&(iu||n===null||Pr(n,n.return)),i&64&&ru&&(e=e.updateQueue,e!==null&&(i=e.callbacks,i!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?i:n.concat(i))));break;case 26:if(Bs){var a=uu;if(Qr(t,e),ei(e),i&512&&(iu||n===null||Pr(n,n.return)),i&4){i=n===null?null:n.memoizedState;var o=e.memoizedState;n===null?o===null?e.stateNode===null?e.stateNode=Ks(a,e.type,e.memoizedProps,e):qs(a,e.type,e.stateNode):e.stateNode=Ws(a,o,e.memoizedProps):i===o?o===null&&e.stateNode!==null&&Ir(e,e.memoizedProps,n.memoizedProps):(i===null?n.stateNode!==null&&Js(n.stateNode):Gs(i),o===null?qs(a,e.type,e.stateNode):Ws(a,o,e.memoizedProps))}break}case 27:if(ec){Qr(t,e),ei(e),i&512&&(iu||n===null||Pr(n,n.return)),n!==null&&i&4&&Ir(e,e.memoizedProps,n.memoizedProps);break}case 5:if(Qr(t,e),ei(e),i&512&&(iu||n===null||Pr(n,n.return)),X){if(e.flags&32){a=e.stateNode;try{Go(a)}catch(t){ea(e,e.return,t)}}i&4&&e.stateNode!=null&&(a=e.memoizedProps,Ir(e,a,n===null?a:n.memoizedProps)),i&1024&&(au=!0)}else Z&&e.alternate!==null&&(e.alternate.stateNode=e.stateNode);break;case 6:if(Qr(t,e),ei(e),i&4&&X){if(e.stateNode===null)throw Error(r(162));i=e.memoizedProps,n=n===null?i:n.memoizedProps,a=e.stateNode;try{Ro(a,n,i)}catch(t){ea(e,e.return,t)}}break;case 3:if(Bs?(Xs(),a=uu,uu=Hs(t.containerInfo),Qr(t,e),uu=a):Qr(t,e),ei(e),i&4){if(X&&so&&n!==null&&n.memoizedState.isDehydrated)try{Os(t.containerInfo)}catch(t){ea(e,e.return,t)}if(Z){i=t.containerInfo,n=t.pendingChildren;try{ts(i,n)}catch(t){ea(e,e.return,t)}}}au&&(au=!1,ti(e));break;case 4:Bs?(n=uu,uu=Hs(e.stateNode.containerInfo),Qr(t,e),ei(e),uu=n):(Qr(t,e),ei(e)),i&4&&Z&&Vr(e.stateNode,e,e.stateNode.pendingChildren);break;case 12:Qr(t,e),ei(e);break;case 31:Qr(t,e),ei(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Zr(e,i)));break;case 13:Qr(t,e),ei(e),e.child.flags&8192&&e.memoizedState!==null!=(n!==null&&n.memoizedState!==null)&&(zu=yc()),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Zr(e,i)));break;case 22:a=e.memoizedState!==null;var s=n!==null&&n.memoizedState!==null,c=ru,l=iu;if(ru=c||a,iu=l||s,Qr(t,e),iu=l,ru=c,ei(e),i&8192&&(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,a&&(n===null||s||ru||iu||ri(e)),X)){e:if(n=null,X)for(t=e;;){if(t.tag===5||Bs&&t.tag===26){if(n===null){s=n=t;try{o=s.stateNode,a?Ko(o):Jo(s.stateNode,s.memoizedProps)}catch(e){ea(s,s.return,e)}}}else if(t.tag===6){if(n===null){s=t;try{var u=s.stateNode;a?qo(u):Yo(u,s.memoizedProps)}catch(e){ea(s,s.return,e)}}}else if(t.tag===18){if(n===null){s=t;try{var d=s.stateNode;a?Fs(d):Is(s.stateNode)}catch(e){ea(s,s.return,e)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;n===t&&(n=null),t=t.return}n===t&&(n=null),t.sibling.return=t.return,t=t.sibling}}i&4&&(i=e.updateQueue,i!==null&&(n=i.retryQueue,n!==null&&(i.retryQueue=null,Zr(e,n))));break;case 19:Qr(t,e),ei(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Zr(e,i)));break;case 30:break;case 21:break;default:Qr(t,e),ei(e)}}function ei(e){var t=e.flags;if(t&2){try{for(var n,i=e.return;i!==null;){if(Lr(i)){n=i;break}i=i.return}if(X){if(n==null)throw Error(r(160));switch(n.tag){case 27:if(ec){var a=n.stateNode;Br(e,Rr(e),a);break}case 5:var o=n.stateNode;n.flags&32&&(Go(o),n.flags&=-33),Br(e,Rr(e),o);break;case 3:case 4:var s=n.stateNode.containerInfo;zr(e,Rr(e),s);break;default:throw Error(r(161))}}}catch(t){ea(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function ti(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;ti(t),t.tag===5&&t.flags&1024&&To(t.stateNode),e=e.sibling}}function ni(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Wr(e,t.alternate,t),t=t.sibling}function ri(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Ar(4,t,t.return),ri(t);break;case 1:Pr(t,t.return);var n=t.stateNode;typeof n.componentWillUnmount==`function`&&Mr(t,t.return,n),ri(t);break;case 27:ec&&rc(t.stateNode);case 26:case 5:Pr(t,t.return),ri(t);break;case 22:t.memoizedState===null&&ri(t);break;case 30:ri(t);break;default:ri(t)}e=e.sibling}}function ii(e,t,n){for(n&&=(t.subtreeFlags&8772)!=0,t=t.child;t!==null;){var r=t.alternate,i=e,a=t,o=a.flags;switch(a.tag){case 0:case 11:case 15:ii(i,a,n),kr(4,a);break;case 1:if(ii(i,a,n),r=a,i=r.stateNode,typeof i.componentDidMount==`function`)try{i.componentDidMount()}catch(e){ea(r,r.return,e)}if(r=a,i=r.updateQueue,i!==null){var s=r.stateNode;try{var c=i.shared.hiddenCallbacks;if(c!==null)for(i.shared.hiddenCallbacks=null,i=0;i<c.length;i++)it(c[i],s)}catch(e){ea(r,r.return,e)}}n&&o&64&&jr(a),Nr(a,a.return);break;case 27:ec&&Hr(a);case 26:case 5:ii(i,a,n),n&&r===null&&o&4&&Fr(a),Nr(a,a.return);break;case 12:ii(i,a,n);break;case 31:ii(i,a,n),n&&o&4&&Jr(i,a);break;case 13:ii(i,a,n),n&&o&4&&Yr(i,a);break;case 22:a.memoizedState===null&&ii(i,a,n),Nr(a,a.return);break;case 30:break;default:ii(i,a,n)}t=t.sibling}}function ai(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&ye(n))}function oi(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ye(e))}function si(e,t,n,r){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)ci(e,t,n,r),t=t.sibling}function ci(e,t,n,r){var i=t.flags;switch(t.tag){case 0:case 11:case 15:si(e,t,n,r),i&2048&&kr(9,t);break;case 1:si(e,t,n,r);break;case 3:si(e,t,n,r),i&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ye(e)));break;case 12:if(i&2048){si(e,t,n,r),e=t.stateNode;try{var a=t.memoizedProps,o=a.id,s=a.onPostCommit;typeof s==`function`&&s(o,t.alternate===null?`mount`:`update`,e.passiveEffectDuration,-0)}catch(e){ea(t,t.return,e)}}else si(e,t,n,r);break;case 31:si(e,t,n,r);break;case 13:si(e,t,n,r);break;case 23:break;case 22:a=t.stateNode,o=t.alternate,t.memoizedState===null?a._visibility&2?si(e,t,n,r):(a._visibility|=2,li(e,t,n,r,(t.subtreeFlags&10256)!=0||!1)):a._visibility&2?si(e,t,n,r):ui(e,t),i&2048&&ai(o,t);break;case 24:si(e,t,n,r),i&2048&&oi(t.alternate,t);break;default:si(e,t,n,r)}}function li(e,t,n,r,i){for(i&&=(t.subtreeFlags&10256)!=0||!1,t=t.child;t!==null;){var a=e,o=t,s=n,c=r,l=o.flags;switch(o.tag){case 0:case 11:case 15:li(a,o,s,c,i),kr(8,o);break;case 23:break;case 22:var u=o.stateNode;o.memoizedState===null?(u._visibility|=2,li(a,o,s,c,i)):u._visibility&2?li(a,o,s,c,i):ui(a,o),i&&l&2048&&ai(o.alternate,o);break;case 24:li(a,o,s,c,i),i&&l&2048&&oi(o.alternate,o);break;default:li(a,o,s,c,i)}t=t.sibling}}function ui(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:ui(n,r),i&2048&&ai(r.alternate,r);break;case 24:ui(n,r),i&2048&&oi(r.alternate,r);break;default:ui(n,r)}t=t.sibling}}function di(e,t,n){if(e.subtreeFlags&du)for(e=e.child;e!==null;)fi(e,t,n),e=e.sibling}function fi(e,t,n){switch(e.tag){case 26:if(di(e,t,n),e.flags&du)if(e.memoizedState!==null)$s(n,uu,e.memoizedState,e.memoizedProps);else{var r=e.stateNode,i=e.type;e=e.memoizedProps,((t&335544128)===t||vo(i,e))&&xo(n,r,i,e)}break;case 5:di(e,t,n),e.flags&du&&(r=e.stateNode,i=e.type,e=e.memoizedProps,((t&335544128)===t||vo(i,e))&&xo(n,r,i,e));break;case 3:case 4:Bs?(r=uu,uu=Hs(e.stateNode.containerInfo),di(e,t,n),uu=r):di(e,t,n);break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=du,du=16777216,di(e,t,n),du=r):di(e,t,n));break;default:di(e,t,n)}}function pi(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function mi(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];su=r,_i(r,e)}pi(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)hi(e),e=e.sibling}function hi(e){switch(e.tag){case 0:case 11:case 15:mi(e),e.flags&2048&&Ar(9,e,e.return);break;case 3:mi(e);break;case 12:mi(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,gi(e)):mi(e);break;default:mi(e)}}function gi(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];su=r,_i(r,e)}pi(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ar(8,t,t.return),gi(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,gi(t));break;default:gi(t)}e=e.sibling}}function _i(e,t){for(;su!==null;){var n=su;switch(n.tag){case 0:case 11:case 15:Ar(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var r=n.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:ye(n.memoizedState.cache)}if(r=n.child,r!==null)r.return=n,su=r;else e:for(n=e;su!==null;){r=su;var i=r.sibling,a=r.return;if(Gr(r),r===n){su=null;break e}if(i!==null){i.return=a,su=i;break e}su=a}}}function vi(e){var t=co(e);if(t!=null){if(typeof t.memoizedProps[`data-testname`]!=`string`)throw Error(r(364));return t}if(e=ko(e),e===null)throw Error(r(362));return e.stateNode.current}function yi(e,t){var n=e.tag;switch(t.$$typeof){case pu:if(e.type===t.value)return!0;break;case mu:e:{for(t=t.value,e=[e,0],n=0;n<e.length;){var i=e[n++],a=i.tag,o=e[n++],s=t[o];if(a!==5&&a!==26&&a!==27||!Mo(i)){for(;s!=null&&yi(i,s);)o++,s=t[o];if(o===t.length){t=!0;break e}else for(i=i.child;i!==null;)e.push(i,o),i=i.sibling}}t=!1}return t;case hu:if((n===5||n===26||n===27)&&No(e.stateNode,t.value))return!0;break;case _u:if((n===5||n===6||n===26||n===27)&&(e=jo(e),e!==null&&0<=e.indexOf(t.value)))return!0;break;case gu:if((n===5||n===26||n===27)&&(e=e.memoizedProps[`data-testname`],typeof e==`string`&&e.toLowerCase()===t.value.toLowerCase()))return!0;break;default:throw Error(r(365))}return!1}function bi(e){switch(e.$$typeof){case pu:return`<`+(u(e.value)||`Unknown`)+`>`;case mu:return`:has(`+(bi(e)||``)+`)`;case hu:return`[role="`+e.value+`"]`;case _u:return`"`+e.value+`"`;case gu:return`[data-testname="`+e.value+`"]`;default:throw Error(r(365))}}function xi(e,t){var n=[];e=[e,0];for(var r=0;r<e.length;){var i=e[r++],a=i.tag,o=e[r++],s=t[o];if(a!==5&&a!==26&&a!==27||!Mo(i)){for(;s!=null&&yi(i,s);)o++,s=t[o];if(o===t.length)n.push(i);else for(i=i.child;i!==null;)e.push(i,o),i=i.sibling}}return n}function Si(e,t){if(!Oo)throw Error(r(363));e=vi(e),e=xi(e,t),t=[],e=Array.from(e);for(var n=0;n<e.length;){var i=e[n++],a=i.tag;if(a===5||a===26||a===27)Mo(i)||t.push(i.stateNode);else for(i=i.child;i!==null;)e.push(i),i=i.sibling}return t}function Ci(){return bu&2&&Cu!==0?Cu&-Cu:J.T===null?po():De()}function wi(){if(Pu===0)if(!(Cu&536870912)||Xc){var e=pc;pc<<=1,!(pc&3932160)&&(pc=262144),Pu=e}else Pu=536870912;return e=Fl.current,e!==null&&(e.flags|=32),Pu}function Ti(e,t,n){(e===xu&&(wu===2||wu===9)||e.cancelPendingCommit!==null)&&(Mi(e,0),ki(e,Cu,Pu,!1)),x(e,n),(!(bu&2)||e!==xu)&&(e===xu&&(!(bu&2)&&(Mu|=n),Au===4&&ki(e,Cu,Pu,!1)),be(e))}function Ei(e,t,n){if(bu&6)throw Error(r(327));var i=!n&&(t&127)==0&&(t&e.expiredLanes)===0||_(e,t),a=i?Bi(e,t):Ri(e,t,!0),o=i;do{if(a===0){Du&&!i&&ki(e,t,0,!1);break}else{if(n=e.current.alternate,o&&!Oi(n)){a=Ri(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){t=s;e:{var c=e;a=Iu;var l=so&&c.current.memoizedState.isDehydrated;if(l&&(Mi(c,s).flags|=256),s=Ri(c,s,!1),s!==2){if(Ou&&!l){c.errorRecoveryDisabledLanes|=o,Mu|=o,a=4;break e}o=Lu,Lu=a,o!==null&&(Lu===null?Lu=o:Lu.push.apply(Lu,o))}a=s}if(o=!1,a!==2)continue}}if(a===1){Mi(e,0),ki(e,t,0,!0);break}e:{switch(i=e,o=a,o){case 0:case 1:throw Error(r(345));case 4:if((t&4194048)!==t)break;case 6:ki(i,t,Pu,!Eu);break e;case 2:Lu=null;break;case 3:case 5:break;default:throw Error(r(329))}if((t&62914560)===t&&(a=zu+300-yc(),10<a)){if(ki(i,t,Pu,!Eu),g(i,0,!0)!==0)break e;qu=t,i.timeoutHandle=ro(Di.bind(null,i,n,Lu,Hu,Ru,t,Pu,Mu,Fu,Eu,o,`Throttled`,-0,0),a);break e}Di(i,n,Lu,Hu,Ru,t,Pu,Mu,Fu,Eu,o,null,-0,0)}}break}while(!0);be(e)}function Di(e,t,n,r,i,a,o,s,c,l,u,d,f,p){if(e.timeoutHandle=ao,d=t.subtreeFlags,d&8192||(d&16785408)==16785408){d=bo(),fi(t,a,d);var m=(a&62914560)===a?zu-yc():(a&4194048)===a?Bu-yc():0;if(m=So(d,m),m!==null){qu=a,e.cancelPendingCommit=m(Ki.bind(null,e,t,a,n,r,i,o,s,c,u,d,null,f,p)),ki(e,a,o,!l);return}}Ki(e,t,a,n,r,i,o,s,c)}function Oi(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Oc(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function ki(e,t,n,r){t&=~Nu,t&=~Mu,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-lc(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&C(e,n,t)}function Ai(){return bu&6?!0:(W(0,!1),!1)}function ji(){if(Su!==null){if(wu===0)var e=Su.return;else e=Su,nl=tl=null,Ct(e),wl=null,Tl=0,e=Su;for(;e!==null;)Or(e.alternate,e),e=e.return;Su=null}}function Mi(e,t){var n=e.timeoutHandle;n!==ao&&(e.timeoutHandle=ao,io(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),qu=0,ji(),xu=e,Su=n=la(e.current,null),Cu=t,wu=0,Tu=null,Eu=!1,Du=_(e,t),Ou=!1,Fu=Pu=Nu=Mu=ju=Au=0,Lu=Iu=null,Ru=!1,t&8&&(t|=t&32);var r=e.entangledLanes;if(r!==0)for(e=e.entanglements,r&=t;0<r;){var i=31-lc(r),a=1<<i;t|=e[i],r&=~a}return ku=t,We(),n}function Ni(e,t){zl=null,J.H=Yl,t===yl||t===xl?(t=Re(),wu=3):t===bl?(t=Re(),wu=4):wu=t===eu?8:typeof t==`object`&&t&&typeof t.then==`function`?6:1,Tu=t,Su===null&&(Au=1,Fn(e,P(t,e.current)))}function Pi(){var e=Fl.current;return e===null?!0:(Cu&4194048)===Cu?Il===null:(Cu&62914560)===Cu||Cu&536870912?e===Il:!1}function Fi(){var e=J.H;return J.H=Yl,e===null?Yl:e}function Ii(){var e=J.A;return J.A=fu,e}function Li(){Au=4,Eu||(Cu&4194048)!==Cu&&Fl.current!==null||(Du=!0),!(ju&134217727)&&!(Mu&134217727)||xu===null||ki(xu,Cu,Pu,!1)}function Ri(e,t,n){var r=bu;bu|=2;var i=Fi(),a=Ii();(xu!==e||Cu!==t)&&(Hu=null,Mi(e,t)),t=!1;var o=Au;e:do try{if(wu!==0&&Su!==null){var s=Su,c=Tu;switch(wu){case 8:ji(),o=6;break e;case 3:case 2:case 9:case 6:Fl.current===null&&(t=!0);var l=wu;if(wu=0,Tu=null,Ui(e,s,c,l),n&&Du){o=0;break e}break;default:l=wu,wu=0,Tu=null,Ui(e,s,c,l)}}zi(),o=Au;break}catch(t){Ni(e,t)}while(!0);return t&&e.shellSuspendCounter++,nl=tl=null,bu=r,J.H=i,J.A=a,Su===null&&(xu=null,Cu=0,We()),o}function zi(){for(;Su!==null;)K(Su)}function Bi(e,t){var n=bu;bu|=2;var i=Fi(),a=Ii();xu!==e||Cu!==t?(Hu=null,Vu=yc()+500,Mi(e,t)):Du=_(e,t);e:do try{if(wu!==0&&Su!==null){t=Su;var o=Tu;n:switch(wu){case 1:wu=0,Tu=null,Ui(e,t,o,1);break;case 2:case 9:if(Fe(o)){wu=0,Tu=null,Hi(t);break}t=function(){wu!==2&&wu!==9||xu!==e||(wu=7),be(e)},o.then(t,t);break e;case 3:wu=7;break e;case 4:wu=5;break e;case 7:Fe(o)?(wu=0,Tu=null,Hi(t)):(wu=0,Tu=null,Ui(e,t,o,7));break;case 5:var s=null;switch(Su.tag){case 26:s=Su.memoizedState;case 5:case 27:var c=Su,l=c.type,u=c.pendingProps;if(s?Qs(s):yo(c.stateNode,l,u)){wu=0,Tu=null;var d=c.sibling;if(d!==null)Su=d;else{var f=c.return;f===null?Su=null:(Su=f,Wi(f))}break n}}wu=0,Tu=null,Ui(e,t,o,5);break;case 6:wu=0,Tu=null,Ui(e,t,o,6);break;case 8:ji(),Au=6;break e;default:throw Error(r(462))}}Vi();break}catch(t){Ni(e,t)}while(!0);return nl=tl=null,J.H=i,J.A=a,bu=n,Su===null?(xu=null,Cu=0,We(),Au):0}function Vi(){for(;Su!==null&&!_c();)K(Su)}function K(e){var t=pr(e.alternate,e,ku);e.memoizedProps=e.pendingProps,t===null?Wi(e):Su=t}function Hi(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Qn(n,t,t.pendingProps,t.type,void 0,Cu);break;case 11:t=Qn(n,t,t.pendingProps,t.type.render,t.ref,Cu);break;case 5:Ct(t);default:Or(n,t),t=Su=q(t,ku),t=pr(n,t,ku)}e.memoizedProps=e.pendingProps,t===null?Wi(e):Su=t}function Ui(e,t,n,r){nl=tl=null,Ct(t),wl=null,Tl=0;var i=t.return;try{if(Bn(e,i,t,n,Cu)){Au=1,Fn(e,P(n,e.current)),Su=null;return}}catch(t){if(i!==null)throw Su=i,t;Au=1,Fn(e,P(n,e.current)),Su=null;return}t.flags&32768?(Xc||r===1?e=!0:Du||Cu&536870912?e=!1:(Eu=e=!0,(r===2||r===9||r===3||r===6)&&(r=Fl.current,r!==null&&r.tag===13&&(r.flags|=16384))),Gi(t,e)):Wi(t)}function Wi(e){var t=e;do{if(t.flags&32768){Gi(t,Eu);return}e=t.return;var n=Er(t.alternate,t,ku);if(n!==null){Su=n;return}if(t=t.sibling,t!==null){Su=t;return}Su=t=e}while(t!==null);Au===0&&(Au=5)}function Gi(e,t){do{var n=Dr(e.alternate,e);if(n!==null){n.flags&=32767,Su=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){Su=e;return}Su=e=n}while(e!==null);Au=6,Su=null}function Ki(e,t,n,i,a,o,s,c,l){e.cancelPendingCommit=null;do Zi();while(Wu!==0);if(bu&6)throw Error(r(327));if(t!==null){if(t===e.current)throw Error(r(177));if(o=t.lanes|t.childLanes,o|=Al,S(e,n,o,s,c,l),e===xu&&(Su=xu=null,Cu=0),Ku=t,Gu=e,qu=n,Ju=o,Yu=a,Xu=i,t.subtreeFlags&10256||t.flags&10256?(e.callbackNode=null,e.callbackPriority=0,oa(Sc,function(){return Qi(),null})):(e.callbackNode=null,e.callbackPriority=0),i=(t.flags&13878)!=0,t.subtreeFlags&13878||i){i=J.T,J.T=null,a=fo(),uo(2),s=bu,bu|=4;try{Ur(e,t,n)}finally{bu=s,uo(a),J.T=i}}Wu=1,qi(),Ji(),Yi()}}function qi(){if(Wu===1){Wu=0;var e=Gu,t=Ku,n=(t.flags&13878)!=0;if(t.subtreeFlags&13878||n){n=J.T,J.T=null;var r=fo();uo(2);var i=bu;bu|=4;try{$r(t,e),Za(e.containerInfo)}finally{bu=i,uo(r),J.T=n}}e.current=t,Wu=2}}function Ji(){if(Wu===2){Wu=0;var e=Gu,t=Ku,n=(t.flags&8772)!=0;if(t.subtreeFlags&8772||n){n=J.T,J.T=null;var r=fo();uo(2);var i=bu;bu|=4;try{Wr(e,t.alternate,t)}finally{bu=i,uo(r),J.T=n}}Wu=3}}function Yi(){if(Wu===4||Wu===3){Wu=0,vc();var e=Gu,t=Ku,n=qu,r=Xu;t.subtreeFlags&10256||t.flags&10256?Wu=5:(Wu=0,Ku=Gu=null,Xi(e,e.pendingLanes));var i=e.pendingLanes;if(i===0&&(Uu=null),D(n),t=t.stateNode,Dc&&typeof Dc.onCommitFiberRoot==`function`)try{Dc.onCommitFiberRoot(Ec,t,void 0,(t.current.flags&128)==128)}catch{}if(r!==null){t=J.T,i=fo(),uo(2),J.T=null;try{for(var a=e.onRecoverableError,o=0;o<r.length;o++){var s=r[o];a(s.value,{componentStack:s.stack})}}finally{J.T=t,uo(i)}}qu&3&&Zi(),be(e),i=e.pendingLanes,n&261930&&i&42?e===Qu?Zu++:(Zu=0,Qu=e):Zu=0,so&&Ms(),W(0,!1)}}function Xi(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,ye(t)))}function Zi(){return qi(),Ji(),Yi(),Qi()}function Qi(){if(Wu!==5)return!1;var e=Gu,t=Ju;Ju=0;var n=D(qu),i=32>n?32:n;n=J.T;var a=fo();try{uo(i),J.T=null,i=Yu,Yu=null;var o=Gu,s=qu;if(Wu=0,Ku=Gu=null,qu=0,bu&6)throw Error(r(331));var c=bu;if(bu|=4,hi(o.current),ci(o,o.current,s,i),bu=c,W(0,!1),Dc&&typeof Dc.onPostCommitFiberRoot==`function`)try{Dc.onPostCommitFiberRoot(Ec,o)}catch{}return!0}finally{uo(a),J.T=n,Xi(e,t)}}function $i(e,t,n){t=P(n,t),t=Ln(e.stateNode,t,2),e=$e(e,t,2),e!==null&&(x(e,2),be(e))}function ea(e,t,n){if(e.tag===3)$i(e,e,n);else for(;t!==null;){if(t.tag===3){$i(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(Uu===null||!Uu.has(r))){e=P(n,e),n=Rn(2),r=$e(t,n,2),r!==null&&(zn(n,r,t,e),x(r,2),be(r));break}}t=t.return}}function ta(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new yu;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(Ou=!0,i.add(n),e=na.bind(null,e,t,n),t.then(e,e))}function na(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,xu===e&&(Cu&n)===n&&(Au===4||Au===3&&(Cu&62914560)===Cu&&300>yc()-zu?!(bu&2)&&Mi(e,0):Nu|=n,Fu===Cu&&(Fu=0)),be(e)}function ra(e,t){t===0&&(t=y()),e=qe(e,t),e!==null&&(x(e,t),be(e))}function ia(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),ra(e,n)}function aa(e,t){var n=0;switch(e.tag){case 31:case 13:var i=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:i=e.stateNode;break;case 22:i=e.stateNode._retryCache;break;default:throw Error(r(314))}i!==null&&i.delete(t),ra(e,n)}function oa(e,t){return hc(e,t)}function sa(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ca(e){return e=e.prototype,!(!e||!e.isReactComponent)}function la(e,n){var r=e.alternate;return r===null?(r=t(e.tag,n,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=n,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&65011712,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,n=e.dependencies,r.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r}function q(e,t){e.flags&=65011714;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function ua(e,n,i,a,o,s){var c=0;if(a=e,typeof e==`function`)ca(e)&&(c=1);else if(typeof e==`string`)c=Bs&&ec?Vs(e,i,Wc.current)?26:ic(e)?27:5:Bs?Vs(e,i,Wc.current)?26:5:ec&&ic(e)?27:5;else e:switch(e){case za:return e=t(31,i,n,o),e.elementType=za,e.lanes=s,e;case ka:return da(i.children,o,s,n);case Aa:c=8,o|=24;break;case ja:return e=t(12,i,n,o|2),e.elementType=ja,e.lanes=s,e;case Fa:return e=t(13,i,n,o),e.elementType=Fa,e.lanes=s,e;case Ia:return e=t(19,i,n,o),e.elementType=Ia,e.lanes=s,e;default:if(typeof e==`object`&&e)switch(e.$$typeof){case Na:c=10;break e;case Ma:c=9;break e;case Pa:c=11;break e;case La:c=14;break e;case Ra:c=16,a=null;break e}c=29,i=Error(r(130,e===null?`null`:typeof e,``)),a=null}return n=t(c,i,n,o),n.elementType=e,n.type=a,n.lanes=s,n}function da(e,n,r,i){return e=t(7,e,i,n),e.lanes=r,e}function fa(e,n,r){return e=t(6,e,null,n),e.lanes=r,e}function pa(e){var n=t(18,null,null,0);return n.stateNode=e,n}function ma(e,n,r){return n=t(4,e.children===null?[]:e.children,e.key,n),n.lanes=r,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}function ha(e,t,n,r,i,a,o,s,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=ao,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=b(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=b(0),this.hiddenUpdates=b(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.incompleteTransitions=new Map}function ga(e,n,r,i,a,o,s,c,l,u,d,f){return e=new ha(e,n,r,s,l,u,d,f,c),n=1,o===!0&&(n|=24),o=t(3,null,null,n),e.current=o,o.stateNode=e,n=ve(),n.refCount++,e.pooledCache=n,n.refCount++,o.memoizedState={element:i,isDehydrated:r,cache:n},Xe(o),e}function _a(e){return e?(e=cc,e):cc}function va(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(r(188)):(e=Object.keys(e).join(`,`),Error(r(268,e)));return e=o(t),e=e===null?null:s(e),e===null?null:qa(e.stateNode)}function ya(e,t,n,r,i,a){i=_a(i),r.context===null?r.context=i:r.pendingContext=i,r=Qe(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(r.callback=a),n=$e(e,r,t),n!==null&&(Ti(n,e,t),et(n,e,t))}function ba(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function xa(e,t){ba(e,t),(e=e.alternate)&&ba(e,t)}var Sa={},Ca=Y.default,wa=ty.default,Ta=Object.assign,Ea=Symbol.for(`react.element`),Da=Symbol.for(`react.transitional.element`),Oa=Symbol.for(`react.portal`),ka=Symbol.for(`react.fragment`),Aa=Symbol.for(`react.strict_mode`),ja=Symbol.for(`react.profiler`),Ma=Symbol.for(`react.consumer`),Na=Symbol.for(`react.context`),Pa=Symbol.for(`react.forward_ref`),Fa=Symbol.for(`react.suspense`),Ia=Symbol.for(`react.suspense_list`),La=Symbol.for(`react.memo`),Ra=Symbol.for(`react.lazy`),za=Symbol.for(`react.activity`),Ba=Symbol.for(`react.memo_cache_sentinel`),Va=Symbol.iterator,Ha=Symbol.for(`react.client.reference`),Ua=Array.isArray,J=Ca.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Wa=e.rendererVersion,Ga=e.rendererPackageName,Ka=e.extraDevToolsConfig,qa=e.getPublicInstance,Ja=e.getRootHostContext,Ya=e.getChildHostContext,Xa=e.prepareForCommit,Za=e.resetAfterCommit,Qa=e.createInstance;e.cloneMutableInstance;var $a=e.appendInitialChild,eo=e.finalizeInitialChildren,to=e.shouldSetTextContent,no=e.createTextInstance;e.cloneMutableTextInstance;var ro=e.scheduleTimeout,io=e.cancelTimeout,ao=e.noTimeout,oo=e.isPrimaryRenderer;e.warnsIfNotActing;var X=e.supportsMutation,Z=e.supportsPersistence,so=e.supportsHydration,co=e.getInstanceFromNode;e.beforeActiveInstanceBlur;var lo=e.preparePortalMount;e.prepareScopeUpdate,e.getInstanceFromScope;var uo=e.setCurrentUpdatePriority,fo=e.getCurrentUpdatePriority,po=e.resolveUpdatePriority;e.trackSchedulerEvent,e.resolveEventType,e.resolveEventTimeStamp;var mo=e.shouldAttemptEagerTransition,ho=e.detachDeletedInstance;e.requestPostPaintCallback;var go=e.maySuspendCommit,_o=e.maySuspendCommitOnUpdate,vo=e.maySuspendCommitInSyncRender,yo=e.preloadInstance,bo=e.startSuspendingCommit,xo=e.suspendInstance;e.suspendOnActiveViewTransition;var So=e.waitForCommitToBeReady;e.getSuspendedCommitReason;var Co=e.NotPendingTransition,wo=e.HostTransitionContext,To=e.resetFormInstance;e.bindToConsole;var Eo=e.supportsMicrotasks,Do=e.scheduleMicrotask,Oo=e.supportsTestSelectors,ko=e.findFiberRoot,Ao=e.getBoundingRect,jo=e.getTextContent,Mo=e.isHiddenSubtree,No=e.matchAccessibilityRole,Po=e.setFocusIfFocusable,Fo=e.setupIntersectionObserver,Io=e.appendChild,Lo=e.appendChildToContainer,Ro=e.commitTextUpdate,zo=e.commitMount,Bo=e.commitUpdate,Vo=e.insertBefore,Ho=e.insertInContainerBefore,Uo=e.removeChild,Wo=e.removeChildFromContainer,Go=e.resetTextContent,Ko=e.hideInstance,qo=e.hideTextInstance,Jo=e.unhideInstance,Yo=e.unhideTextInstance;e.cancelViewTransitionName,e.cancelRootViewTransitionName,e.restoreRootViewTransitionName,e.cloneRootViewTransitionContainer,e.removeRootViewTransitionClone,e.measureClonedInstance,e.hasInstanceChanged,e.hasInstanceAffectedParent,e.startViewTransition,e.startGestureTransition,e.stopViewTransition,e.getCurrentGestureOffset,e.createViewTransitionInstance;var Xo=e.clearContainer;e.createFragmentInstance,e.updateFragmentInstanceFiber,e.commitNewChildToFragmentInstance,e.deleteChildFromFragmentInstance;var Zo=e.cloneInstance,Qo=e.createContainerChildSet,$o=e.appendChildToContainerChildSet,es=e.finalizeContainerChildren,ts=e.replaceContainerChildren,ns=e.cloneHiddenInstance,rs=e.cloneHiddenTextInstance,is=e.isSuspenseInstancePending,as=e.isSuspenseInstanceFallback,os=e.getSuspenseInstanceFallbackErrorDetails,ss=e.registerSuspenseInstanceRetry,cs=e.canHydrateFormStateMarker,ls=e.isFormStateMarkerMatching,us=e.getNextHydratableSibling,ds=e.getNextHydratableSiblingAfterSingleton,fs=e.getFirstHydratableChild,ps=e.getFirstHydratableChildWithinContainer,ms=e.getFirstHydratableChildWithinActivityInstance,hs=e.getFirstHydratableChildWithinSuspenseInstance,gs=e.getFirstHydratableChildWithinSingleton,_s=e.canHydrateInstance,vs=e.canHydrateTextInstance,ys=e.canHydrateActivityInstance,bs=e.canHydrateSuspenseInstance,xs=e.hydrateInstance,Ss=e.hydrateTextInstance,Cs=e.hydrateActivityInstance,ws=e.hydrateSuspenseInstance,Ts=e.getNextHydratableInstanceAfterActivityInstance,Es=e.getNextHydratableInstanceAfterSuspenseInstance,Ds=e.commitHydratedInstance,Os=e.commitHydratedContainer,ks=e.commitHydratedActivityInstance,As=e.commitHydratedSuspenseInstance,js=e.finalizeHydratedChildren,Ms=e.flushHydrationEvents;e.clearActivityBoundary;var Ns=e.clearSuspenseBoundary;e.clearActivityBoundaryFromContainer;var Ps=e.clearSuspenseBoundaryFromContainer,Fs=e.hideDehydratedBoundary,Is=e.unhideDehydratedBoundary,Ls=e.shouldDeleteUnhydratedTailInstances;e.diffHydratedPropsForDevWarnings,e.diffHydratedTextForDevWarnings,e.describeHydratableInstanceForDevWarnings;var Rs=e.validateHydratableInstance,zs=e.validateHydratableTextInstance,Bs=e.supportsResources,Vs=e.isHostHoistableType,Hs=e.getHoistableRoot,Us=e.getResource,Ws=e.acquireResource,Gs=e.releaseResource,Ks=e.hydrateHoistable,qs=e.mountHoistable,Js=e.unmountHoistable,Ys=e.createHoistableInstance,Xs=e.prepareToCommitHoistables,Zs=e.mayResourceSuspendCommit,Qs=e.preloadResource,$s=e.suspendResource,ec=e.supportsSingletons,tc=e.resolveSingletonInstance,nc=e.acquireSingletonInstance,rc=e.releaseSingletonInstance,ic=e.isHostSingletonType,ac=e.isSingletonScope,oc=[],sc=-1,cc={},lc=Math.clz32?Math.clz32:m,uc=Math.log,dc=Math.LN2,fc=256,pc=262144,mc=4194304,hc=wa.unstable_scheduleCallback,gc=wa.unstable_cancelCallback,_c=wa.unstable_shouldYield,vc=wa.unstable_requestPaint,yc=wa.unstable_now,bc=wa.unstable_ImmediatePriority,xc=wa.unstable_UserBlockingPriority,Sc=wa.unstable_NormalPriority,Cc=wa.unstable_IdlePriority,wc=wa.log,Tc=wa.unstable_setDisableYieldValue,Ec=null,Dc=null,Oc=typeof Object.is==`function`?Object.is:k,kc=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},Ac=Object.prototype.hasOwnProperty,jc,Mc,Nc=!1,Pc=new WeakMap,Fc=[],Ic=0,Lc=null,Rc=0,zc=[],Bc=0,Vc=null,Hc=1,Uc=``,Wc=d(null),Gc=d(null),Kc=d(null),qc=d(null),Jc=null,Yc=null,Xc=!1,Zc=null,Qc=!1,$c=Error(r(519)),el=d(null),tl=null,nl=null,rl=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},il=wa.unstable_scheduleCallback,al=wa.unstable_NormalPriority,ol={$$typeof:Na,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0},sl=null,cl=null,ll=!1,ul=!1,dl=!1,fl=0,pl=null,ml=0,hl=0,gl=null,_l=J.S;J.S=function(e,t){Bu=yc(),typeof t==`object`&&t&&typeof t.then==`function`&&Oe(e,t),_l!==null&&_l(e,t)};var vl=d(null),yl=Error(r(460)),bl=Error(r(474)),xl=Error(r(542)),Sl={then:function(){}},Cl=null,wl=null,Tl=0,El=Ue(!0),Dl=Ue(!1),Ol=[],kl=0,Al=0,jl=!1,Ml=!1,Nl=d(null),Pl=d(0),Fl=d(null),Il=null,Ll=d(0),Rl=0,zl=null,Bl=null,Vl=null,Hl=!1,Ul=!1,Wl=!1,Gl=0,Kl=0,ql=null,Jl=0,Yl={readContext:ge,use:Ot,useCallback:ht,useContext:ht,useEffect:ht,useImperativeHandle:ht,useLayoutEffect:ht,useInsertionEffect:ht,useMemo:ht,useReducer:ht,useRef:ht,useState:ht,useDebugValue:ht,useDeferredValue:ht,useTransition:ht,useSyncExternalStore:ht,useId:ht,useHostTransitionStatus:ht,useFormState:ht,useActionState:ht,useOptimistic:ht,useMemoCache:ht,useCacheRefresh:ht};Yl.useEffectEvent=ht;var Xl={readContext:ge,use:Ot,useCallback:function(e,t){return wt().memoizedState=[e,t===void 0?null:t],e},useContext:ge,useEffect:an,useImperativeHandle:function(e,t,n){n=n==null?null:n.concat([e]),nn(4194308,4,dn.bind(null,t,e),n)},useLayoutEffect:function(e,t){return nn(4194308,4,e,t)},useInsertionEffect:function(e,t){nn(4,2,e,t)},useMemo:function(e,t){var n=wt();t=t===void 0?null:t;var r=e();if(Wl){O(!0);try{e()}finally{O(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=wt();if(n!==void 0){var i=n(t);if(Wl){O(!0);try{n(t)}finally{O(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=wn.bind(null,zl,e),[r.memoizedState,e]},useRef:function(e){var t=wt();return e={current:e},t.memoizedState=e},useState:function(e){e=Bt(e);var t=e.queue,n=Tn.bind(null,zl,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:pn,useDeferredValue:function(e,t){return gn(wt(),e,t)},useTransition:function(){var e=Bt(!1);return e=vn.bind(null,zl,e.queue,!0,!1),wt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var i=zl,a=wt();if(Xc){if(n===void 0)throw Error(r(407));n=n()}else{if(n=t(),xu===null)throw Error(r(349));Cu&127||Ft(i,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,an(Lt.bind(null,i,o,e),[e]),i.flags|=2048,en(9,{destroy:void 0},It.bind(null,i,o,n,t),null),n},useId:function(){var e=wt(),t=xu.identifierPrefix;if(Xc){var n=Uc,r=Hc;n=(r&~(1<<32-lc(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=Gl++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=Jl++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t},useHostTransitionStatus:bn,useFormState:Yt,useActionState:Yt,useOptimistic:function(e){var t=wt();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Dn.bind(null,zl,!0,n),n.dispatch=t,[e,t]},useMemoCache:kt,useCacheRefresh:function(){return wt().memoizedState=Cn.bind(null,zl)},useEffectEvent:function(e){var t=wt(),n={impl:e};return t.memoizedState=n,function(){if(bu&2)throw Error(r(440));return n.impl.apply(void 0,arguments)}}},Zl={readContext:ge,use:Ot,useCallback:mn,useContext:ge,useEffect:on,useImperativeHandle:fn,useInsertionEffect:ln,useLayoutEffect:un,useMemo:hn,useReducer:jt,useRef:tn,useState:function(){return jt(At)},useDebugValue:pn,useDeferredValue:function(e,t){return _n(Tt(),Bl.memoizedState,e,t)},useTransition:function(){var e=jt(At)[0],t=Tt().memoizedState;return[typeof e==`boolean`?e:Dt(e),t]},useSyncExternalStore:Pt,useId:xn,useHostTransitionStatus:bn,useFormState:Xt,useActionState:Xt,useOptimistic:function(e,t){return Vt(Tt(),Bl,e,t)},useMemoCache:kt,useCacheRefresh:Sn};Zl.useEffectEvent=cn;var Ql={readContext:ge,use:Ot,useCallback:mn,useContext:ge,useEffect:on,useImperativeHandle:fn,useInsertionEffect:ln,useLayoutEffect:un,useMemo:hn,useReducer:Nt,useRef:tn,useState:function(){return Nt(At)},useDebugValue:pn,useDeferredValue:function(e,t){var n=Tt();return Bl===null?gn(n,e,t):_n(n,Bl.memoizedState,e,t)},useTransition:function(){var e=Nt(At)[0],t=Tt().memoizedState;return[typeof e==`boolean`?e:Dt(e),t]},useSyncExternalStore:Pt,useId:xn,useHostTransitionStatus:bn,useFormState:$t,useActionState:$t,useOptimistic:function(e,t){var n=Tt();return Bl===null?(n.baseState=e,[e,n.queue.dispatch]):Vt(n,Bl,e,t)},useMemoCache:kt,useCacheRefresh:Sn};Ql.useEffectEvent=cn;var $l={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=Ci(),i=Qe(r);i.payload=t,n!=null&&(i.callback=n),t=$e(e,i,r),t!==null&&(Ti(t,e,r),et(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=Ci(),i=Qe(r);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=$e(e,i,r),t!==null&&(Ti(t,e,r),et(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Ci(),r=Qe(n);r.tag=2,t!=null&&(r.callback=t),t=$e(e,r,n),t!==null&&(Ti(t,e,n),et(t,e,n))}},eu=Error(r(461)),tu=!1,nu={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null},ru=!1,iu=!1,au=!1,ou=typeof WeakSet==`function`?WeakSet:Set,su=null,cu=null,lu=!1,uu=null,du=8192,fu={getCacheForType:function(e){var t=ge(ol),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ge(ol).controller.signal}},pu=0,mu=1,hu=2,gu=3,_u=4;if(typeof Symbol==`function`&&Symbol.for){var vu=Symbol.for;pu=vu(`selector.component`),mu=vu(`selector.has_pseudo_class`),hu=vu(`selector.role`),gu=vu(`selector.test_id`),_u=vu(`selector.text`)}var yu=typeof WeakMap==`function`?WeakMap:Map,bu=0,xu=null,Su=null,Cu=0,wu=0,Tu=null,Eu=!1,Du=!1,Ou=!1,ku=0,Au=0,ju=0,Mu=0,Nu=0,Pu=0,Fu=0,Iu=null,Lu=null,Ru=!1,zu=0,Bu=0,Vu=1/0,Hu=null,Uu=null,Wu=0,Gu=null,Ku=null,qu=0,Ju=0,Yu=null,Xu=null,Zu=0,Qu=null;return Sa.attemptContinuousHydration=function(e){if(e.tag===13||e.tag===31){var t=qe(e,67108864);t!==null&&Ti(t,e,67108864),xa(e,67108864)}},Sa.attemptHydrationAtCurrentPriority=function(e){if(e.tag===13||e.tag===31){var t=Ci();t=E(t);var n=qe(e,t);n!==null&&Ti(n,e,t),xa(e,t)}},Sa.attemptSynchronousHydration=function(e){switch(e.tag){case 3:if(e=e.stateNode,e.current.memoizedState.isDehydrated){var t=h(e.pendingLanes);if(t!==0){for(e.pendingLanes|=2,e.entangledLanes|=2;t;){var n=1<<31-lc(t);e.entanglements[1]|=n,t&=~n}be(e),!(bu&6)&&(Vu=yc()+500,W(0,!1))}}break;case 31:case 13:t=qe(e,2),t!==null&&Ti(t,e,2),Ai(),xa(e,2)}},Sa.batchedUpdates=function(e,t){return e(t)},Sa.createComponentSelector=function(e){return{$$typeof:pu,value:e}},Sa.createContainer=function(e,t,n,r,i,a,o,s,c,l){return ga(e,t,!1,null,n,r,a,null,o,s,c,l)},Sa.createHasPseudoClassSelector=function(e){return{$$typeof:mu,value:e}},Sa.createHydrationContainer=function(e,t,n,r,i,a,o,s,c,l,u,d,f,p){return e=ga(n,r,!0,e,i,a,s,p,c,l,u,d),e.context=_a(null),n=e.current,r=Ci(),r=E(r),i=Qe(r),i.callback=t??null,$e(n,i,r),t=r,e.current.lanes=t,x(e,t),be(e),e},Sa.createPortal=function(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Oa,key:r==null?null:``+r,children:e,containerInfo:t,implementation:n}},Sa.createRoleSelector=function(e){return{$$typeof:hu,value:e}},Sa.createTestNameSelector=function(e){return{$$typeof:gu,value:e}},Sa.createTextSelector=function(e){return{$$typeof:_u,value:e}},Sa.defaultOnCaughtError=function(e){console.error(e)},Sa.defaultOnRecoverableError=function(e){kc(e)},Sa.defaultOnUncaughtError=function(e){kc(e)},Sa.deferredUpdates=function(e){var t=J.T,n=fo();try{return uo(32),J.T=null,e()}finally{uo(n),J.T=t}},Sa.discreteUpdates=function(e,t,n,r,i){var a=J.T,o=fo();try{return uo(2),J.T=null,e(t,n,r,i)}finally{uo(o),J.T=a,bu===0&&(Vu=yc()+500)}},Sa.findAllNodes=Si,Sa.findBoundingRects=function(e,t){if(!Oo)throw Error(r(363));t=Si(e,t),e=[];for(var n=0;n<t.length;n++)e.push(Ao(t[n]));for(t=e.length-1;0<t;t--){n=e[t];for(var i=n.x,a=i+n.width,o=n.y,s=o+n.height,c=t-1;0<=c;c--)if(t!==c){var l=e[c],u=l.x,d=u+l.width,f=l.y,p=f+l.height;if(i>=u&&o>=f&&a<=d&&s<=p){e.splice(t,1);break}else if(i!==u||n.width!==l.width||p<o||f>s){if(!(o!==f||n.height!==l.height||d<i||u>a)){u>i&&(l.width+=u-i,l.x=i),d<a&&(l.width=a-u),e.splice(t,1);break}}else{f>o&&(l.height+=f-o,l.y=o),p<s&&(l.height=s-f),e.splice(t,1);break}}}return e},Sa.findHostInstance=va,Sa.findHostInstanceWithNoPortals=function(e){return e=o(e),e=e===null?null:c(e),e===null?null:qa(e.stateNode)},Sa.findHostInstanceWithWarning=function(e){return va(e)},Sa.flushPassiveEffects=Zi,Sa.flushSyncFromReconciler=function(e){var t=bu;bu|=1;var n=J.T,r=fo();try{if(uo(2),J.T=null,e)return e()}finally{uo(r),J.T=n,bu=t,!(bu&6)&&W(0,!1)}},Sa.flushSyncWork=Ai,Sa.focusWithin=function(e,t){if(!Oo)throw Error(r(363));for(e=vi(e),t=xi(e,t),t=Array.from(t),e=0;e<t.length;){var n=t[e++],i=n.tag;if(!Mo(n)){if((i===5||i===26||i===27)&&Po(n.stateNode))return!0;for(n=n.child;n!==null;)t.push(n),n=n.sibling}}return!1},Sa.getFindAllNodesFailureDescription=function(e,t){if(!Oo)throw Error(r(363));var n=0,i=[];e=[vi(e),0];for(var a=0;a<e.length;){var o=e[a++],s=o.tag,c=e[a++],l=t[c];if((s!==5&&s!==26&&s!==27||!Mo(o))&&(yi(o,l)&&(i.push(bi(l)),c++,c>n&&(n=c)),c<t.length))for(o=o.child;o!==null;)e.push(o,c),o=o.sibling}if(n<t.length){for(e=[];n<t.length;n++)e.push(bi(t[n]));return`findAllNodes was able to match part of the selector:
  `+(i.join(` > `)+`

No matching component was found for:
  `)+e.join(` > `)}return null},Sa.getPublicRootInstance=function(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 27:case 5:return qa(e.child.stateNode);default:return e.child.stateNode}},Sa.injectIntoDevTools=function(){var e={bundleType:0,version:Wa,rendererPackageName:Ga,currentDispatcherRef:J,reconcilerVersion:`19.2.0`};if(Ka!==null&&(e.rendererConfig=Ka),typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>`u`)e=!1;else{var t=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(t.isDisabled||!t.supportsFiber)e=!0;else{try{Ec=t.inject(e),Dc=t}catch{}e=!!t.checkDCE}}return e},Sa.isAlreadyRendering=function(){return(bu&6)!=0},Sa.observeVisibleRects=function(e,t,n,i){if(!Oo)throw Error(r(363));e=Si(e,t);var a=Fo(e,n,i).disconnect;return{disconnect:function(){a()}}},Sa.shouldError=function(){return null},Sa.shouldSuspend=function(){return!1},Sa.startHostTransition=function(e,t,i,a){if(e.tag!==5)throw Error(r(476));var o=yn(e).queue;vn(e,o,t,Co,i===null?n:function(){var t=yn(e);return t.next===null&&(t=e.alternate.memoizedState),En(e,t.next.queue,{},Ci()),i(a)})},Sa.updateContainer=function(e,t,n,r){var i=t.current,a=Ci();return ya(i,a,e,t,n,r),a},Sa.updateContainerSync=function(e,t,n,r){return ya(t.current,2,e,t,n,r),2},Sa},e.exports.default=e.exports,Object.defineProperty(e.exports,"__esModule",{value:!0})}(ub)),ub.exports}({exports:{}}).exports;var pb;function mb(){return pb||(pb=1,lb.exports=fb()),lb.exports}var hb=cb(mb());function gb(e){let t=hb(e);return t.injectIntoDevTools(),t}var _b=0,vb={},yb=/^three(?=[A-Z])/,bb=e=>`${e[0].toUpperCase()}${e.slice(1)}`,xb=0,Sb=e=>typeof e==`function`;function Cb(e){if(Sb(e)){let t=`${xb++}`;return vb[t]=e,t}else Object.assign(vb,e)}function wb(e,t){let n=bb(e),r=vb[n];if(e!==`primitive`&&!r)throw Error(`R3F: ${n} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);if(e===`primitive`&&!t.object)throw Error(`R3F: Primitives without 'object' are invalid!`);if(t.args!==void 0&&!Array.isArray(t.args))throw Error(`R3F: The args prop must be an array!`)}function Tb(e,t,n){var r;return e=bb(e)in vb?e:e.replace(yb,``),wb(e,t),e===`primitive`&&(r=t.object)!=null&&r.__r3f&&delete t.object.__r3f,Dy(t.object,n,e,t)}function Eb(e){if(!e.isHidden){var t;e.props.attach&&(t=e.parent)!=null&&t.object?jy(e.parent,e):Vy(e.object)&&(e.object.visible=!1),e.isHidden=!0,zy(e)}}function Db(e){if(e.isHidden){var t;e.props.attach&&(t=e.parent)!=null&&t.object?Ay(e.parent,e):Vy(e.object)&&e.props.visible!==!1&&(e.object.visible=!0),e.isHidden=!1,zy(e)}}function Ob(e,t,n){let r=t.root.getState();if(!(!e.parent&&e.object!==r.scene)){if(!t.object){let e=vb[bb(t.type)];t.object=t.props.object??new e(...t.props.args??[]),t.object.__r3f=t}if(Ry(t.object,t.props),t.props.attach)Ay(e,t);else if(Vy(t.object)&&Vy(e.object)){let r=e.object.children.indexOf(n?.object);if(n&&r!==-1){let n=e.object.children.indexOf(t.object);if(n!==-1){e.object.children.splice(n,1);let i=n<r?r-1:r;e.object.children.splice(i,0,t.object)}else t.object.parent=e.object,e.object.children.splice(r,0,t.object),t.object.dispatchEvent({type:`added`}),e.object.dispatchEvent({type:`childadded`,child:t.object})}else e.object.add(t.object)}for(let e of t.children)Ob(t,e);zy(t)}}function kb(e,t){t&&(t.parent=e,e.children.push(t),Ob(e,t))}function Ab(e,t,n){if(!t||!n)return;t.parent=e;let r=e.children.indexOf(n);r===-1?e.children.push(t):e.children.splice(r,0,t),Ob(e,t,n)}function jb(e){if(typeof e.dispose==`function`){let t=()=>{try{e.dispose()}catch{}};typeof IS_REACT_ACT_ENVIRONMENT<`u`?t():(0,ty.unstable_scheduleCallback)(ty.unstable_IdlePriority,t)}}function Mb(e,t,n){if(!t)return;t.parent=null;let r=e.children.indexOf(t);r!==-1&&e.children.splice(r,1),t.props.attach?jy(e,t):Vy(t.object)&&Vy(e.object)&&(e.object.remove(t.object),Gy(dy(t),t.object));let i=t.props.dispose!==null&&n!==!1;for(let e=t.children.length-1;e>=0;e--){let n=t.children[e];Mb(t,n,i)}t.children.length=0,delete t.object.__r3f,i&&t.type!==`primitive`&&t.object.type!==`Scene`&&jb(t.object),n===void 0&&zy(t)}function Nb(e,t){for(let n of[e,e.alternate])if(n!==null)if(typeof n.ref==`function`){n.refCleanup==null||n.refCleanup();let e=n.ref(t);typeof e==`function`&&(n.refCleanup=e)}else n.ref&&(n.ref.current=t)}var Pb=[];function Fb(){for(let[e]of Pb){let t=e.parent;if(t){e.props.attach?jy(t,e):Vy(e.object)&&Vy(t.object)&&t.object.remove(e.object);for(let t of e.children)t.props.attach?jy(e,t):Vy(t.object)&&Vy(e.object)&&e.object.remove(t.object)}e.isHidden&&Db(e),e.object.__r3f&&delete e.object.__r3f,e.type!==`primitive`&&jb(e.object)}for(let[e,t,n]of Pb){e.props=t;let r=e.parent;if(r){let t=vb[bb(e.type)],i=e.object;e.object=e.props.object??new t(...e.props.args??[]),e.object.__r3f=e,Nb(n,e.object),Wy(dy(e),i,e.object),Ry(e.object,e.props),e.props.attach?Ay(r,e):Vy(e.object)&&Vy(r.object)&&r.object.add(e.object);for(let t of e.children)t.props.attach?Ay(e,t):Vy(t.object)&&Vy(e.object)&&e.object.add(t.object);zy(e)}}Pb.length=0}var Ib=()=>{},Lb={},Rb=_b,zb=0,Bb=4,Vb=gb({isPrimaryRenderer:!1,warnsIfNotActing:!1,supportsMutation:!0,supportsPersistence:!1,supportsHydration:!1,createInstance:Tb,removeChild:Mb,appendChild:kb,appendInitialChild:kb,insertBefore:Ab,appendChildToContainer(e,t){let n=e.getState().scene.__r3f;!t||!n||kb(n,t)},removeChildFromContainer(e,t){let n=e.getState().scene.__r3f;!t||!n||Mb(n,t)},insertInContainerBefore(e,t,n){let r=e.getState().scene.__r3f;!t||!n||!r||Ab(r,t,n)},getRootHostContext:()=>Lb,getChildHostContext:()=>Lb,commitUpdate(e,t,n,r,i){var a;wb(t,r);let o=!1;if(e.type===`primitive`&&n.object!==r.object?o=!0:r.args?.length===n.args?.length?(a=r.args)!=null&&a.some((e,t)=>e!==n.args?.[t])&&(o=!0):o=!0,o)Pb.push([e,{...r},i]);else{let t=Fy(e,r);Object.keys(t).length&&(Object.assign(e.props,t),Ry(e.object,t))}(i.sibling===null||(i.flags&Bb)===zb)&&Fb()},finalizeInitialChildren:()=>!1,commitMount(){},getPublicInstance:e=>e?.object,prepareForCommit:()=>null,preparePortalMount:e=>Dy(e.getState().scene,e,``,{}),resetAfterCommit:()=>{},shouldSetTextContent:()=>!1,clearContainer:()=>!1,hideInstance:Eb,unhideInstance:Db,createTextInstance:Ib,hideTextInstance:Ib,unhideTextInstance:Ib,scheduleTimeout:typeof setTimeout==`function`?setTimeout:void 0,cancelTimeout:typeof clearTimeout==`function`?clearTimeout:void 0,noTimeout:-1,getInstanceFromNode:()=>null,beforeActiveInstanceBlur(){},afterActiveInstanceBlur(){},detachDeletedInstance(){},prepareScopeUpdate(){},getInstanceFromScope:()=>null,shouldAttemptEagerTransition:()=>!1,trackSchedulerEvent:()=>{},resolveEventType:()=>null,resolveEventTimeStamp:()=>-1.1,requestPostPaintCallback(){},maySuspendCommit:()=>!1,preloadInstance:()=>!0,suspendInstance(){},waitForCommitToBeReady:()=>null,NotPendingTransition:null,HostTransitionContext:Y.createContext(null),setCurrentUpdatePriority(e){Rb=e},getCurrentUpdatePriority(){return Rb},resolveUpdatePriority(){if(Rb!==_b)return Rb;switch(typeof window<`u`&&window.event?.type){case`click`:case`contextmenu`:case`dblclick`:case`pointercancel`:case`pointerdown`:case`pointerup`:return ob;case`pointermove`:case`pointerout`:case`pointerover`:case`pointerenter`:case`pointerleave`:case`wheel`:return ib;default:return ab}},resetFormInstance(){},rendererPackageName:`@react-three/fiber`,rendererVersion:sb.version,applyViewTransitionName(e,t,n){},restoreViewTransitionName(e,t){},cancelViewTransitionName(e,t,n){},cancelRootViewTransitionName(e){},restoreRootViewTransitionName(e){},InstanceMeasurement:null,measureInstance:e=>null,wasInstanceInViewport:e=>!0,hasInstanceChanged:(e,t)=>!1,hasInstanceAffectedParent:(e,t)=>!1,suspendOnActiveViewTransition(e,t){},startGestureTransition:()=>null,startViewTransition:()=>null,stopViewTransition(e){},createViewTransitionInstance:e=>null,getCurrentGestureOffset(e){throw Error(`startGestureTransition is not yet supported in react-three-fiber.`)},cloneMutableInstance(e,t){return e},cloneMutableTextInstance(e){return e},cloneRootViewTransitionContainer(e){throw Error(`Not implemented.`)},removeRootViewTransitionClone(e,t){throw Error(`Not implemented.`)},createFragmentInstance:e=>null,updateFragmentInstanceFiber(e,t){},commitNewChildToFragmentInstance(e,t){},deleteChildFromFragmentInstance(e,t){},measureClonedInstance:e=>null,maySuspendCommitOnUpdate:(e,t,n)=>!1,maySuspendCommitInSyncRender:(e,t)=>!1,startSuspendingCommit:()=>null,getSuspendedCommitReason:(e,t)=>null}),Hb=new Map,Ub={objects:`shallow`,strict:!1};function Wb(e,t){if(!t&&typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement&&e.parentElement){let{width:t,height:n,top:r,left:i}=e.parentElement.getBoundingClientRect();return{width:t,height:n,top:r,left:i}}else if(!t&&typeof OffscreenCanvas<`u`&&e instanceof OffscreenCanvas)return{width:e.width,height:e.height,top:0,left:0};return{width:0,height:0,top:0,left:0,...t}}function Gb(e){let t=Hb.get(e),n=t?.fiber,r=t?.store;t&&console.warn(`R3F.createRoot should only be called once!`);let i=typeof reportError==`function`?reportError:console.error,a=r||Yy(cx,lx),o=n||Vb.createContainer(a,rb,null,!1,null,``,i,i,i,null);t||Hb.set(e,{fiber:o,store:a});let s,c,l=!1,u=null;return{async configure(t={}){let n;u=new Promise(e=>n=e);let{gl:r,size:i,scene:o,events:d,onCreated:f,shadows:p=!1,linear:m=!1,flat:h=!1,legacy:g=!1,orthographic:_=!1,frameloop:v=`always`,dpr:y=[1,2],performance:b,raycaster:x,camera:S,onPointerMissed:C}=t,w=a.getState(),T=w.gl;if(!w.gl){let t={canvas:e,powerPreference:`high-performance`,antialias:!0,alpha:!0},n=typeof r==`function`?await r(t):r;T=qy(n)?n:new xl({...t,...r}),w.set({gl:T})}let E=w.raycaster;E||w.set({raycaster:E=new En});let{params:D,...O}=x||{};if(Sy.equ(O,E,Ub)||Ry(E,{...O}),Sy.equ(D,E.params,Ub)||Ry(E,{params:{...E.params,...D}}),!w.camera||w.camera===c&&!Sy.equ(c,S,Ub)){c=S;let e=S?.isCamera,t=e?S:_?new to(0,0,0,0,.1,1e3):new un(75,0,.1,1e3);e||(t.position.z=5,S&&(Ry(t,S),t.manual||(`aspect`in S||`left`in S||`right`in S||`bottom`in S||`top`in S)&&(t.manual=!0,t.updateProjectionMatrix())),!w.camera&&!(S!=null&&S.rotation)&&t.lookAt(0,0,0)),w.set({camera:t}),E.camera=t}if(!w.scene){let e;o!=null&&o.isScene?(e=o,Dy(e,a,``,{})):(e=new ur,Dy(e,a,``,{}),o&&Ry(e,o)),w.set({scene:e})}d&&!w.events.handlers&&w.set({events:d(a)});let k=Wb(e,i);if(Sy.equ(k,w.size,Ub)||w.setSize(k.width,k.height,k.top,k.left),y&&w.viewport.dpr!==by(y)&&w.setDpr(y),w.frameloop!==v&&w.setFrameloop(v),w.onPointerMissed||w.set({onPointerMissed:C}),b&&!Sy.equ(b,w.performance,Ub)&&w.set(e=>({performance:{...e.performance,...b}})),!w.xr){let e=(e,t)=>{let n=a.getState();n.frameloop!==`never`&&lx(e,!0,n,t)},t=()=>{let t=a.getState();t.gl.xr.enabled=t.gl.xr.isPresenting,t.gl.xr.setAnimationLoop(t.gl.xr.isPresenting?e:null),t.gl.xr.isPresenting||cx(t)},n={connect(){let e=a.getState().gl;e.xr.addEventListener(`sessionstart`,t),e.xr.addEventListener(`sessionend`,t)},disconnect(){let e=a.getState().gl;e.xr.removeEventListener(`sessionstart`,t),e.xr.removeEventListener(`sessionend`,t)}};typeof T.xr?.addEventListener==`function`&&n.connect(),w.set({xr:n})}if(T.shadowMap){let e=T.shadowMap.enabled,t=T.shadowMap.type;if(T.shadowMap.enabled=!!p,Sy.boo(p))T.shadowMap.type=2;else if(Sy.str(p)){let e={basic:0,percentage:1,soft:2,variance:3};T.shadowMap.type=e[p]??2}else Sy.obj(p)&&Object.assign(T.shadowMap,p);(e!==T.shadowMap.enabled||t!==T.shadowMap.type)&&(T.shadowMap.needsUpdate=!0)}return Yr.enabled=!g,l||(T.outputColorSpace=m?ki:di,T.toneMapping=h?0:4),w.legacy!==g&&w.set(()=>({legacy:g})),w.linear!==m&&w.set(()=>({linear:m})),w.flat!==h&&w.set(()=>({flat:h})),r&&!Sy.fun(r)&&!qy(r)&&!Sy.equ(r,T,Ub)&&Ry(T,r),s=f,l=!0,n(),this},render(t){return!l&&!u&&this.configure(),u.then(()=>{Vb.updateContainer((0,Q.jsx)(Kb,{store:a,children:t,onCreated:s,rootElement:e}),o,null,()=>void 0)}),a},unmount(){qb(e)}}}function Kb({store:e,children:t,onCreated:n,rootElement:r}){return hy(()=>{let t=e.getState();t.set(e=>({internal:{...e.internal,active:!0}})),n&&n(t),e.getState().events.connected||t.events.connect==null||t.events.connect(r)},[]),(0,Q.jsx)(Jy.Provider,{value:e,children:t})}function qb(e,t){let n=Hb.get(e),r=n?.fiber;if(r){let i=n?.store.getState();i&&(i.internal.active=!1),Vb.updateContainer(null,r,null,()=>{i&&setTimeout(()=>{try{var n,r,a,o;i.events.disconnect==null||i.events.disconnect(),(n=i.gl)==null||(r=n.renderLists)==null||r.dispose==null||r.dispose(),(a=i.gl)==null||a.forceContextLoss==null||a.forceContextLoss(),(o=i.gl)!=null&&o.xr&&i.xr.disconnect(),wy(i.scene),Hb.delete(e),t&&t(e)}catch{}},500)})}}var Jb=new Set,Yb=new Set,Xb=new Set;function Zb(e,t){if(e.size)for(let{callback:n}of e.values())n(t)}function Qb(e,t){switch(e){case`before`:return Zb(Jb,t);case`after`:return Zb(Yb,t);case`tail`:return Zb(Xb,t)}}var $b,ex;function tx(e,t,n){let r=t.clock.getDelta();t.frameloop===`never`&&typeof e==`number`&&(r=e-t.clock.elapsedTime,t.clock.oldTime=t.clock.elapsedTime,t.clock.elapsedTime=e),$b=t.internal.subscribers;for(let e=0;e<$b.length;e++)ex=$b[e],ex.ref.current(ex.store.getState(),r,n);return!t.internal.priority&&t.gl.render&&t.gl.render(t.scene,t.camera),t.internal.frames=Math.max(0,t.internal.frames-1),t.frameloop===`always`?1:t.internal.frames}var nx=!1,rx=!1,ix,ax,ox;function sx(e){ax=requestAnimationFrame(sx),nx=!0,ix=0,Qb(`before`,e),rx=!0;for(let n of Hb.values()){var t;ox=n.store.getState(),ox.internal.active&&(ox.frameloop===`always`||ox.internal.frames>0)&&!((t=ox.gl.xr)!=null&&t.isPresenting)&&(ix+=tx(e,ox))}if(rx=!1,Qb(`after`,e),ix===0)return Qb(`tail`,e),nx=!1,cancelAnimationFrame(ax)}function cx(e,t=1){var n;if(!e)return Hb.forEach(e=>cx(e.store.getState(),t));(n=e.gl.xr)!=null&&n.isPresenting||!e.internal.active||e.frameloop===`never`||(t>1?e.internal.frames=Math.min(60,e.internal.frames+t):rx?e.internal.frames=2:e.internal.frames=1,nx||(nx=!0,requestAnimationFrame(sx)))}function lx(e,t=!0,n,r){if(t&&Qb(`before`,e),n)tx(e,n,r);else for(let t of Hb.values())tx(e,t.store.getState());t&&Qb(`after`,e)}var ux={onClick:[`click`,!1],onContextMenu:[`contextmenu`,!1],onDoubleClick:[`dblclick`,!1],onWheel:[`wheel`,!0],onPointerDown:[`pointerdown`,!0],onPointerUp:[`pointerup`,!0],onPointerLeave:[`pointerleave`,!0],onPointerMove:[`pointermove`,!0],onPointerCancel:[`pointercancel`,!0],onLostPointerCapture:[`lostpointercapture`,!0]};function dx(e){let{handlePointer:t}=Ky(e);return{priority:1,enabled:!0,compute(e,t,n){t.pointer.set(e.offsetX/t.size.width*2-1,-(e.offsetY/t.size.height)*2+1),t.raycaster.setFromCamera(t.pointer,t.camera)},connected:void 0,handlers:Object.keys(ux).reduce((e,n)=>({...e,[n]:t(n)}),{}),update:()=>{var t;let{events:n,internal:r}=e.getState();(t=r.lastEvent)!=null&&t.current&&n.handlers&&n.handlers.onPointerMove(r.lastEvent.current)},connect:t=>{let{set:n,events:r}=e.getState();if(r.disconnect==null||r.disconnect(),n(e=>({events:{...e.events,connected:t}})),r.handlers)for(let e in r.handlers){let n=r.handlers[e],[i,a]=ux[e];t.addEventListener(i,n,{passive:a})}},disconnect:()=>{let{set:t,events:n}=e.getState();if(n.connected){if(n.handlers)for(let e in n.handlers){let t=n.handlers[e],[r]=ux[e];n.connected.removeEventListener(r,t)}t(e=>({events:{...e.events,connected:void 0}}))}}}}function fx(e,t){let n;return(...r)=>{window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)}}function px({debounce:e,scroll:t,polyfill:n,offsetSize:r}={debounce:0,scroll:!1,offsetSize:!1}){let i=n||(typeof window>`u`?class{}:window.ResizeObserver);if(!i)throw Error(`This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills`);let[a,o]=(0,Y.useState)({left:0,top:0,width:0,height:0,bottom:0,right:0,x:0,y:0}),s=(0,Y.useRef)({element:null,scrollContainers:null,resizeObserver:null,lastBounds:a,orientationHandler:null}),c=e?typeof e==`number`?e:e.scroll:null,l=e?typeof e==`number`?e:e.resize:null,u=(0,Y.useRef)(!1);(0,Y.useEffect)(()=>(u.current=!0,()=>void(u.current=!1)));let[d,f,p]=(0,Y.useMemo)(()=>{let e=()=>{if(!s.current.element)return;let{left:e,top:t,width:n,height:i,bottom:a,right:c,x:l,y:d}=s.current.element.getBoundingClientRect(),f={left:e,top:t,width:n,height:i,bottom:a,right:c,x:l,y:d};s.current.element instanceof HTMLElement&&r&&(f.height=s.current.element.offsetHeight,f.width=s.current.element.offsetWidth),Object.freeze(f),u.current&&!vx(s.current.lastBounds,f)&&o(s.current.lastBounds=f)};return[e,l?fx(e,l):e,c?fx(e,c):e]},[o,r,c,l]);function m(){s.current.scrollContainers&&(s.current.scrollContainers.forEach(e=>e.removeEventListener(`scroll`,p,!0)),s.current.scrollContainers=null),s.current.resizeObserver&&(s.current.resizeObserver.disconnect(),s.current.resizeObserver=null),s.current.orientationHandler&&(`orientation`in screen&&`removeEventListener`in screen.orientation?screen.orientation.removeEventListener(`change`,s.current.orientationHandler):`onorientationchange`in window&&window.removeEventListener(`orientationchange`,s.current.orientationHandler))}function h(){s.current.element&&(s.current.resizeObserver=new i(p),s.current.resizeObserver.observe(s.current.element),t&&s.current.scrollContainers&&s.current.scrollContainers.forEach(e=>e.addEventListener(`scroll`,p,{capture:!0,passive:!0})),s.current.orientationHandler=()=>{p()},`orientation`in screen&&`addEventListener`in screen.orientation?screen.orientation.addEventListener(`change`,s.current.orientationHandler):`onorientationchange`in window&&window.addEventListener(`orientationchange`,s.current.orientationHandler))}return hx(p,!!t),mx(f),(0,Y.useEffect)(()=>{m(),h()},[t,p,f]),(0,Y.useEffect)(()=>m,[]),[e=>{!e||e===s.current.element||(m(),s.current.element=e,s.current.scrollContainers=gx(e),h())},a,d]}function mx(e){(0,Y.useEffect)(()=>{let t=e;return window.addEventListener(`resize`,t),()=>void window.removeEventListener(`resize`,t)},[e])}function hx(e,t){(0,Y.useEffect)(()=>{if(t){let t=e;return window.addEventListener(`scroll`,t,{capture:!0,passive:!0}),()=>void window.removeEventListener(`scroll`,t,!0)}},[e,t])}function gx(e){let t=[];if(!e||e===document.body)return t;let{overflow:n,overflowX:r,overflowY:i}=window.getComputedStyle(e);return[n,r,i].some(e=>e===`auto`||e===`scroll`)&&t.push(e),[...t,...gx(e.parentElement)]}var _x=[`x`,`y`,`top`,`bottom`,`left`,`right`,`width`,`height`],vx=(e,t)=>_x.every(n=>e[n]===t[n]);function yx({ref:e,children:t,fallback:n,resize:r,style:i,gl:a,events:o=dx,eventSource:s,eventPrefix:c,shadows:l,linear:u,flat:d,legacy:f,orthographic:p,frameloop:m,dpr:h,performance:g,raycaster:_,camera:v,scene:y,onPointerMissed:b,onCreated:x,...S}){Y.useMemo(()=>Cb(io),[]);let C=_y(),[w,T]=px({scroll:!0,debounce:{scroll:50,resize:0},...r}),E=Y.useRef(null),D=Y.useRef(null);Y.useImperativeHandle(e,()=>E.current);let O=gy(b),[k,A]=Y.useState(!1),[j,M]=Y.useState(!1);if(k)throw k;if(j)throw j;let N=Y.useRef(null);return hy(()=>{let e=E.current;if(T.width>0&&T.height>0&&e){N.current||=Gb(e);async function n(){await N.current.configure({gl:a,scene:y,events:o,shadows:l,linear:u,flat:d,legacy:f,orthographic:p,frameloop:m,dpr:h,performance:g,raycaster:_,camera:v,size:T,onPointerMissed:(...e)=>O.current==null?void 0:O.current(...e),onCreated:e=>{e.events.connect==null||e.events.connect(s?py(s)?s.current:s:D.current),c&&e.setEvents({compute:(e,t)=>{let n=e[c+`X`],r=e[c+`Y`];t.pointer.set(n/t.size.width*2-1,-(r/t.size.height)*2+1),t.raycaster.setFromCamera(t.pointer,t.camera)}}),x?.(e)}}),N.current.render((0,Q.jsx)(C,{children:(0,Q.jsx)(yy,{set:M,children:(0,Q.jsx)(Y.Suspense,{fallback:(0,Q.jsx)(vy,{set:A}),children:t??null})})}))}n()}}),Y.useEffect(()=>{let e=E.current;if(e)return()=>qb(e)},[]),(0,Q.jsx)(`div`,{ref:D,style:{position:`relative`,width:`100%`,height:`100%`,overflow:`hidden`,pointerEvents:s?`none`:`auto`,...i},...S,children:(0,Q.jsx)(`div`,{ref:w,style:{width:`100%`,height:`100%`},children:(0,Q.jsx)(`canvas`,{ref:E,style:{display:`block`},children:n})})})}function bx(e){return(0,Q.jsx)(ay,{children:(0,Q.jsx)(yx,{...e})})}var xx=.45,Sx=16,Cx=4,wx=4;function Tx(e,t){return Math.hypot(t[0]-e[0],t[1]-e[1])}function Ex(e,t){let n=Math.max(Cx,Math.round(t)*2);return Math.max(n,Math.max(1,e)*xx)}function Dx(e,t,n,r,i){if(!e)return!1;let a=Math.abs(t.pixel[0]-e.pixel[0]),o=Math.abs(t.pixel[1]-e.pixel[1]);if(a>Ex(n,i)||o>Ex(r,i))return!1;let s=Math.max(Cx,Math.round(i)*2),c=Tx(e.client,t.client),l=Math.max(s+wx,c*Sx+s);return Tx(e.pixel,t.pixel)<=l}var Ox=110;function kx(e){e.colorSpace=di,e.magFilter=ci,e.minFilter=ci,e.generateMipmaps=!1,e.wrapS=xr,e.wrapT=xr,e.flipY=!0,e.needsUpdate=!0}function Ax(e){let t=new vn(e);return kx(t),t}function jx(){let e=document.createElement(`canvas`);e.width=1,e.height=1;let t=e.getContext(`2d`,{willReadFrequently:!0});if(!t)throw Error(`2D-Kontext für Oberflächenbemalung nicht verfügbar.`);return t.imageSmoothingEnabled=!1,{canvas:e,context:t,texture:Ax(e),layers:[]}}function Mx(e,t,n,r){let i=z_(e.layers,t,n,r),a=e.canvas.width!==i.width||e.canvas.height!==i.height;if(a&&(e.canvas.width=i.width,e.canvas.height=i.height,e.context.imageSmoothingEnabled=!1),e.context.clearRect(0,0,e.canvas.width,e.canvas.height),e.context.drawImage(i,0,0),a){let t=e.texture;return e.texture=Ax(e.canvas),t.dispose(),!0}return e.texture.needsUpdate=!0,!1}function Nx(e){e.stopPropagation(),e.nativeEvent.preventDefault(),e.nativeEvent.stopImmediatePropagation()}function Px(e){return e*e*(3-2*e)}function Fx(){let[e,t]=(0,Y.useState)(()=>$_());return(0,Y.useEffect)(()=>nv(t),[]),e}function Ix(e,t,n,r){let i=Zy(e=>e.camera),a=Zy(e=>e.controls),o=q(e=>e.updateMaterial),s=q(e=>e.setMessage),c=q(e=>e.beginTransaction),l=q(e=>e.endTransaction),[u]=(0,Y.useState)(jx),[d,f]=(0,Y.useState)(null),p=(0,Y.useMemo)(()=>ui(r),[r]),m=(0,Y.useMemo)(()=>S_(r,e.scale,p),[p,r,e.scale[0],e.scale[1],e.scale[2]]),h=(0,Y.useRef)(m);(0,Y.useEffect)(()=>{h.current=m},[m]);let g=U_(m),_=(0,Y.useRef)(void 0),v=(0,Y.useRef)(void 0),y=(0,Y.useRef)(void 0),b=(0,Y.useRef)(0),x=(0,Y.useRef)(null),S=(0,Y.useRef)(null),C=(0,Y.useRef)(null),w=(0,Y.useRef)(0),T=(0,Y.useRef)(null),E=(0,Y.useRef)(null),D=(0,Y.useRef)(null),O=(0,Y.useRef)(null),k=(0,Y.useRef)(!1),A=(0,Y.useRef)(!1),j=(0,Y.useRef)(n.cameraRequestId),M=(0,Y.useRef)(null),N=e.material.paintTexture,P=n.enabled&&t&&e.visible&&!e.locked,F=P||!!N,I=()=>{Mx(u,p,h.current,e.material.color),f(u.texture)},L=()=>{let t=h.current;return S.current!==null&&(window.clearTimeout(S.current),S.current=null),u.layers.length===0?N?!1:(u.layers=L_([],t,e.material.color),I(),!0):((u.layers.length!==t.length||t.some((e,t)=>{let n=u.layers[t];return!n||n.width<e.width||n.height<e.height}))&&(u.layers=L_(u.layers,t,e.material.color),I()),!0)},ee=()=>{if(!L())return;let t=iv(u.layers,p,h.current,e.material.color);_.current=t.dataUrl,v.current=e.material.color.toUpperCase(),y.current=void 0,o(e.id,{paintTexture:t},!1)};(0,Y.useEffect)(()=>{if(n.cameraRequestId===j.current||!a||(j.current=n.cameraRequestId,!t||!n.cameraView))return;let r=new K(...e.position),o=Math.max(3.5,Math.max(Math.abs(e.scale[0]),Math.abs(e.scale[1]),Math.abs(e.scale[2]))*4),s=hv(n.cameraView,r,o),c=i.up.clone().normalize(),l=s.up.clone().normalize();M.current={startedAt:performance.now(),duration:420,startPosition:i.position.clone(),endPosition:s.position,startTarget:a.target.clone(),endTarget:r,startUp:c,upRotation:new Ei().setFromUnitVectors(c,l)}},[i,a,e.position[0],e.position[1],e.position[2],e.scale[0],e.scale[1],e.scale[2],t,n.cameraRequestId,n.cameraView]),Qy(()=>{P&&a&&(a.enabled=!0,a.enablePan=!1,a.enableRotate=!0);let e=M.current;if(!e||!a||!t)return;let n=Hi.clamp((performance.now()-e.startedAt)/e.duration,0,1),r=Px(n),o=new Ei().identity().slerp(e.upRotation,r);i.position.lerpVectors(e.startPosition,e.endPosition,r),a.target.lerpVectors(e.startTarget,e.endTarget,r),i.up.copy(e.startUp).applyQuaternion(o).normalize(),i.lookAt(a.target),i.updateMatrixWorld(!0),a.update(),n>=1&&(M.current=null)}),(0,Y.useEffect)(()=>{if(P){A.current=!0;return}!A.current||!a||(A.current=!1,a.enabled=!0,a.enablePan=!0,a.enableRotate=!0,i.up.set(0,1,0),a.update(),i.updateMatrixWorld(!0))},[P,i,a]),(0,Y.useEffect)(()=>(C.current!==null&&(window.clearTimeout(C.current),C.current=null),()=>{b.current+=1,y.current=void 0,x.current!==null&&window.clearTimeout(x.current),S.current!==null&&window.clearTimeout(S.current),O.current=null,T.current!==null&&(T.current=null,E.current=null,l());let e=u.texture;C.current=window.setTimeout(()=>{e.dispose(),C.current=null},0)}),[l,u]),(0,Y.useEffect)(()=>{let t=N?.dataUrl??null,n=e.material.color.toUpperCase(),r=_.current!==void 0&&_.current!==t;if(r&&x.current!==null&&(window.clearTimeout(x.current),x.current=null),r&&S.current!==null&&(window.clearTimeout(S.current),S.current=null),u.layers.length>0&&_.current===t&&v.current===n||y.current===t)return;let i=++b.current,a=w.current,o=!1;return y.current=t,I_(N,p,h.current,e.material.color).then(r=>{if(!(o||b.current!==i)){if(w.current!==a){y.current===t&&(y.current=void 0);return}u.layers=r,I(),y.current=void 0,_.current=t,v.current=n,av(N,p,h.current,e.material.color)&&ee()}}).catch(e=>{o||b.current!==i||(y.current===t&&(y.current=void 0),s(e instanceof Error?`Bemalung konnte nicht geladen werden: ${e.message}`:`Bemalung konnte nicht geladen werden.`))}),()=>{o=!0,b.current===i&&(b.current+=1),y.current===t&&(y.current=void 0)}},[p,e.material.color,N?.dataUrl,N?.height,N?.width,s,u]),(0,Y.useEffect)(()=>{if(u.layers.length===0)return;S.current!==null&&window.clearTimeout(S.current);let t=N?.dataUrl??null;return S.current=window.setTimeout(()=>{S.current=null,u.layers=L_(u.layers,h.current,e.material.color),I(),t&&q.getState().objects.find(t=>t.id===e.id)?.material.paintTexture?.dataUrl===t&&ee()},Ox),()=>{S.current!==null&&(window.clearTimeout(S.current),S.current=null)}},[p,g,e.id,e.material.color,N?.dataUrl,u]);let te=(t,r,i)=>{if(!L())return!1;let a=u.layers[t],o=a?.getContext(`2d`,{willReadFrequently:!0});if(!a||!o)return!1;let s=[Math.max(0,Math.min(a.width-1,r[0])),Math.max(0,Math.min(a.height-1,r[1]))],c=i?[Math.max(0,Math.min(a.width-1,i[0])),Math.max(0,Math.min(a.height-1,i[1]))]:null,l=o.getImageData(0,0,a.width,a.height);if(n.tool===`eyedropper`){let e=Bg(l,s[0],s[1]);return e.a>0&&ev({color:Fg(e)}),!1}if(n.tool===`fill`)Hg(l,s[0],s[1],Pg(n.color));else{let t=n.tool===`eraser`?n.eraseAll?Pg(`#000000`,0):Pg(e.material.color,254):Pg(n.color);(c?pv(c,s):[s]).forEach(([e,r])=>Vg(l,e,r,n.brushSize,t))}return o.putImageData(l,0,0),I(),!0},ne=e=>!e.uv||!(e.object instanceof G)?null:H_(p,h.current,e.uv,u.layers),R=e=>{e.target.releasePointerCapture?.(e.pointerId)},z=e=>{T.current===e.pointerId&&(Nx(e),T.current=null,E.current=null,D.current=null,O.current=null,k.current&&ee(),k.current=!1,R(e),l())};return{active:P,texture:F?d:null,onPointerDown:e=>{if(!P||e.button!==0)return;Nx(e);let t=ne(e);if(!t||(x.current!==null&&(window.clearTimeout(x.current),x.current=null),!L()))return;if(ev({islandIndex:t.islandIndex}),n.tool===`eyedropper`){te(t.islandIndex,t.point,null);return}w.current+=1,c();let r=te(t.islandIndex,t.point,null);if(n.tool===`fill`){r&&ee(),l();return}T.current=e.pointerId,E.current=t.islandIndex,D.current=t.point,O.current=[e.clientX,e.clientY],k.current=r,e.target.setPointerCapture?.(e.pointerId)},onPointerMove:e=>{if(T.current!==e.pointerId)return;if(!(e.buttons&1)){z(e);return}Nx(e);let t=ne(e);if(!t){E.current=null,D.current=null,O.current=null;return}let r=E.current===t.islandIndex,i=[e.clientX,e.clientY],a=h.current[t.islandIndex],o=r&&D.current&&O.current?{pixel:D.current,client:O.current}:null,s=a?Dx(o,{pixel:t.point,client:i},a.width,a.height,n.brushSize):!1;r||ev({islandIndex:t.islandIndex}),k.current=te(t.islandIndex,t.point,s?D.current:null)||k.current,E.current=t.islandIndex,D.current=t.point,O.current=i},onPointerUp:z,onPointerCancel:z}}function Lx(e){let t=e.trim().replace(/^#/,``);return/^[0-9a-f]{3}$/i.test(t)?t.split(``).map(e=>`${e}${e}`).join(``):/^[0-9a-f]{6}$/i.test(t)?t:null}function Rx(e){let t=Lx(e);return t?`#${[0,2,4].map(e=>255-Number.parseInt(t.slice(e,e+2),16)).map(e=>e.toString(16).padStart(2,`0`)).join(``).toUpperCase()}`:`#000000`}function zx(e,t,n,r){let i=Ix(e,t,n,r),a=e.material.paintTexture?i.texture:null;return{...i,texture:a}}function Bx({active:e,disabled:t,onToggle:n}){let r=(0,Y.useRef)(e),i=(0,Y.useRef)(!1),a=(0,Y.useRef)(n);(0,Y.useEffect)(()=>{a.current=n},[n]),(0,Y.useEffect)(()=>{let n=r.current;if(r.current=e,t){i.current=!1;return}n&&!e&&!i.current&&queueMicrotask(()=>a.current())},[e,t]);let o=()=>{i.current=e,a.current()};return(0,Q.jsxs)(`button`,{type:`button`,"data-android-marquee-button":`true`,className:`android-marquee-button${e?` active`:``}`,"aria-label":`Bereich auswählen`,"aria-pressed":e,disabled:t,onPointerDown:e=>{e.preventDefault(),e.stopPropagation(),o()},onClick:e=>{e.preventDefault(),e.stopPropagation()},children:[(0,Q.jsxs)(`svg`,{"aria-hidden":`true`,viewBox:`0 0 24 24`,children:[(0,Q.jsx)(`rect`,{x:`3.5`,y:`4.5`,width:`17`,height:`13`,rx:`1.5`}),(0,Q.jsx)(`path`,{d:`M8 20.5h8`})]}),(0,Q.jsx)(`span`,{children:`Bereich`})]})}function Vx(e,t,n){return e&&t&&(n===`touch`||n===`pen`)}function Hx(){return Hx=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},Hx.apply(null,arguments)}var Ux=Object.defineProperty,Wx=(e,t,n)=>t in e?Ux(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,Gx=(e,t,n)=>(Wx(e,typeof t==`symbol`?t:t+``,n),n),Kx=class{constructor(){Gx(this,`_listeners`)}addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let n=this._listeners[e];if(n!==void 0){let e=n.indexOf(t);e!==-1&&n.splice(e,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let n=t.slice(0);for(let t=0,r=n.length;t<r;t++)n[t].call(this,e);e.target=null}}},qx=Object.defineProperty,Jx=(e,t,n)=>t in e?qx(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,$=(e,t,n)=>(Jx(e,typeof t==`symbol`?t:t+``,n),n),Yx=class extends ke{constructor(e,t){super(),$(this,`isTransformControls`,!0),$(this,`visible`,!1),$(this,`domElement`),$(this,`raycaster`,new En),$(this,`gizmo`),$(this,`plane`),$(this,`tempVector`,new K),$(this,`tempVector2`,new K),$(this,`tempQuaternion`,new Ei),$(this,`unit`,{X:new K(1,0,0),Y:new K(0,1,0),Z:new K(0,0,1)}),$(this,`pointStart`,new K),$(this,`pointEnd`,new K),$(this,`offset`,new K),$(this,`rotationAxis`,new K),$(this,`startNorm`,new K),$(this,`endNorm`,new K),$(this,`rotationAngle`,0),$(this,`cameraPosition`,new K),$(this,`cameraQuaternion`,new Ei),$(this,`cameraScale`,new K),$(this,`parentPosition`,new K),$(this,`parentQuaternion`,new Ei),$(this,`parentQuaternionInv`,new Ei),$(this,`parentScale`,new K),$(this,`worldPositionStart`,new K),$(this,`worldQuaternionStart`,new Ei),$(this,`worldScaleStart`,new K),$(this,`worldPosition`,new K),$(this,`worldQuaternion`,new Ei),$(this,`worldQuaternionInv`,new Ei),$(this,`worldScale`,new K),$(this,`eye`,new K),$(this,`positionStart`,new K),$(this,`quaternionStart`,new Ei),$(this,`scaleStart`,new K),$(this,`camera`),$(this,`object`),$(this,`enabled`,!0),$(this,`axis`,null),$(this,`mode`,`translate`),$(this,`translationSnap`,null),$(this,`rotationSnap`,null),$(this,`scaleSnap`,null),$(this,`space`,`world`),$(this,`size`,1),$(this,`dragging`,!1),$(this,`showX`,!0),$(this,`showY`,!0),$(this,`showZ`,!0),$(this,`changeEvent`,{type:`change`}),$(this,`mouseDownEvent`,{type:`mouseDown`,mode:this.mode}),$(this,`mouseUpEvent`,{type:`mouseUp`,mode:this.mode}),$(this,`objectChangeEvent`,{type:`objectChange`}),$(this,`intersectObjectWithRay`,(e,t,n)=>{let r=t.intersectObject(e,!0);for(let e=0;e<r.length;e++)if(r[e].object.visible||n)return r[e];return!1}),$(this,`attach`,e=>(this.object=e,this.visible=!0,this)),$(this,`detach`,()=>(this.object=void 0,this.visible=!1,this.axis=null,this)),$(this,`reset`,()=>(this.enabled&&this.dragging&&this.object!==void 0&&(this.object.position.copy(this.positionStart),this.object.quaternion.copy(this.quaternionStart),this.object.scale.copy(this.scaleStart),this.dispatchEvent(this.changeEvent),this.dispatchEvent(this.objectChangeEvent),this.pointStart.copy(this.pointEnd)),this)),$(this,`updateMatrixWorld`,()=>{this.object!==void 0&&(this.object.updateMatrixWorld(),this.object.parent===null?console.error(`TransformControls: The attached 3D object must be a part of the scene graph.`):this.object.parent.matrixWorld.decompose(this.parentPosition,this.parentQuaternion,this.parentScale),this.object.matrixWorld.decompose(this.worldPosition,this.worldQuaternion,this.worldScale),this.parentQuaternionInv.copy(this.parentQuaternion).invert(),this.worldQuaternionInv.copy(this.worldQuaternion).invert()),this.camera.updateMatrixWorld(),this.camera.matrixWorld.decompose(this.cameraPosition,this.cameraQuaternion,this.cameraScale),this.eye.copy(this.cameraPosition).sub(this.worldPosition).normalize(),super.updateMatrixWorld()}),$(this,`pointerHover`,e=>{if(this.object===void 0||this.dragging===!0)return;this.raycaster.setFromCamera(e,this.camera);let t=this.intersectObjectWithRay(this.gizmo.picker[this.mode],this.raycaster);t?this.axis=t.object.name:this.axis=null}),$(this,`pointerDown`,e=>{if(!(this.object===void 0||this.dragging===!0||e.button!==0)&&this.axis!==null){this.raycaster.setFromCamera(e,this.camera);let t=this.intersectObjectWithRay(this.plane,this.raycaster,!0);if(t){let e=this.space;if(this.mode===`scale`?e=`local`:(this.axis===`E`||this.axis===`XYZE`||this.axis===`XYZ`)&&(e=`world`),e===`local`&&this.mode===`rotate`){let e=this.rotationSnap;this.axis===`X`&&e&&(this.object.rotation.x=Math.round(this.object.rotation.x/e)*e),this.axis===`Y`&&e&&(this.object.rotation.y=Math.round(this.object.rotation.y/e)*e),this.axis===`Z`&&e&&(this.object.rotation.z=Math.round(this.object.rotation.z/e)*e)}this.object.updateMatrixWorld(),this.object.parent&&this.object.parent.updateMatrixWorld(),this.positionStart.copy(this.object.position),this.quaternionStart.copy(this.object.quaternion),this.scaleStart.copy(this.object.scale),this.object.matrixWorld.decompose(this.worldPositionStart,this.worldQuaternionStart,this.worldScaleStart),this.pointStart.copy(t.point).sub(this.worldPositionStart)}this.dragging=!0,this.mouseDownEvent.mode=this.mode,this.dispatchEvent(this.mouseDownEvent)}}),$(this,`pointerMove`,e=>{let t=this.axis,n=this.mode,r=this.object,i=this.space;if(n===`scale`?i=`local`:(t===`E`||t===`XYZE`||t===`XYZ`)&&(i=`world`),r===void 0||t===null||this.dragging===!1||e.button!==-1)return;this.raycaster.setFromCamera(e,this.camera);let a=this.intersectObjectWithRay(this.plane,this.raycaster,!0);if(a){if(this.pointEnd.copy(a.point).sub(this.worldPositionStart),n===`translate`)this.offset.copy(this.pointEnd).sub(this.pointStart),i===`local`&&t!==`XYZ`&&this.offset.applyQuaternion(this.worldQuaternionInv),t.indexOf(`X`)===-1&&(this.offset.x=0),t.indexOf(`Y`)===-1&&(this.offset.y=0),t.indexOf(`Z`)===-1&&(this.offset.z=0),i===`local`&&t!==`XYZ`?this.offset.applyQuaternion(this.quaternionStart).divide(this.parentScale):this.offset.applyQuaternion(this.parentQuaternionInv).divide(this.parentScale),r.position.copy(this.offset).add(this.positionStart),this.translationSnap&&(i===`local`&&(r.position.applyQuaternion(this.tempQuaternion.copy(this.quaternionStart).invert()),t.search(`X`)!==-1&&(r.position.x=Math.round(r.position.x/this.translationSnap)*this.translationSnap),t.search(`Y`)!==-1&&(r.position.y=Math.round(r.position.y/this.translationSnap)*this.translationSnap),t.search(`Z`)!==-1&&(r.position.z=Math.round(r.position.z/this.translationSnap)*this.translationSnap),r.position.applyQuaternion(this.quaternionStart)),i===`world`&&(r.parent&&r.position.add(this.tempVector.setFromMatrixPosition(r.parent.matrixWorld)),t.search(`X`)!==-1&&(r.position.x=Math.round(r.position.x/this.translationSnap)*this.translationSnap),t.search(`Y`)!==-1&&(r.position.y=Math.round(r.position.y/this.translationSnap)*this.translationSnap),t.search(`Z`)!==-1&&(r.position.z=Math.round(r.position.z/this.translationSnap)*this.translationSnap),r.parent&&r.position.sub(this.tempVector.setFromMatrixPosition(r.parent.matrixWorld))));else if(n===`scale`){if(t.search(`XYZ`)!==-1){let e=this.pointEnd.length()/this.pointStart.length();this.pointEnd.dot(this.pointStart)<0&&(e*=-1),this.tempVector2.set(e,e,e)}else this.tempVector.copy(this.pointStart),this.tempVector2.copy(this.pointEnd),this.tempVector.applyQuaternion(this.worldQuaternionInv),this.tempVector2.applyQuaternion(this.worldQuaternionInv),this.tempVector2.divide(this.tempVector),t.search(`X`)===-1&&(this.tempVector2.x=1),t.search(`Y`)===-1&&(this.tempVector2.y=1),t.search(`Z`)===-1&&(this.tempVector2.z=1);r.scale.copy(this.scaleStart).multiply(this.tempVector2),this.scaleSnap&&this.object&&(t.search(`X`)!==-1&&(this.object.scale.x=Math.round(r.scale.x/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search(`Y`)!==-1&&(r.scale.y=Math.round(r.scale.y/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search(`Z`)!==-1&&(r.scale.z=Math.round(r.scale.z/this.scaleSnap)*this.scaleSnap||this.scaleSnap))}else if(n===`rotate`){this.offset.copy(this.pointEnd).sub(this.pointStart);let e=20/this.worldPosition.distanceTo(this.tempVector.setFromMatrixPosition(this.camera.matrixWorld));t===`E`?(this.rotationAxis.copy(this.eye),this.rotationAngle=this.pointEnd.angleTo(this.pointStart),this.startNorm.copy(this.pointStart).normalize(),this.endNorm.copy(this.pointEnd).normalize(),this.rotationAngle*=this.endNorm.cross(this.startNorm).dot(this.eye)<0?1:-1):t===`XYZE`?(this.rotationAxis.copy(this.offset).cross(this.eye).normalize(),this.rotationAngle=this.offset.dot(this.tempVector.copy(this.rotationAxis).cross(this.eye))*e):(t===`X`||t===`Y`||t===`Z`)&&(this.rotationAxis.copy(this.unit[t]),this.tempVector.copy(this.unit[t]),i===`local`&&this.tempVector.applyQuaternion(this.worldQuaternion),this.rotationAngle=this.offset.dot(this.tempVector.cross(this.eye).normalize())*e),this.rotationSnap&&(this.rotationAngle=Math.round(this.rotationAngle/this.rotationSnap)*this.rotationSnap),i===`local`&&t!==`E`&&t!==`XYZE`?(r.quaternion.copy(this.quaternionStart),r.quaternion.multiply(this.tempQuaternion.setFromAxisAngle(this.rotationAxis,this.rotationAngle)).normalize()):(this.rotationAxis.applyQuaternion(this.parentQuaternionInv),r.quaternion.copy(this.tempQuaternion.setFromAxisAngle(this.rotationAxis,this.rotationAngle)),r.quaternion.multiply(this.quaternionStart).normalize())}this.dispatchEvent(this.changeEvent),this.dispatchEvent(this.objectChangeEvent)}}),$(this,`pointerUp`,e=>{e.button===0&&(this.dragging&&this.axis!==null&&(this.mouseUpEvent.mode=this.mode,this.dispatchEvent(this.mouseUpEvent)),this.dragging=!1,this.axis=null)}),$(this,`getPointer`,e=>{if(this.domElement&&this.domElement.ownerDocument?.pointerLockElement)return{x:0,y:0,button:e.button};{let t=e.changedTouches?e.changedTouches[0]:e,n=this.domElement.getBoundingClientRect();return{x:(t.clientX-n.left)/n.width*2-1,y:-(t.clientY-n.top)/n.height*2+1,button:e.button}}}),$(this,`onPointerHover`,e=>{if(this.enabled)switch(e.pointerType){case`mouse`:case`pen`:this.pointerHover(this.getPointer(e));break}}),$(this,`onPointerDown`,e=>{!this.enabled||!this.domElement||(this.domElement.style.touchAction=`none`,this.domElement.ownerDocument.addEventListener(`pointermove`,this.onPointerMove),this.pointerHover(this.getPointer(e)),this.pointerDown(this.getPointer(e)))}),$(this,`onPointerMove`,e=>{this.enabled&&this.pointerMove(this.getPointer(e))}),$(this,`onPointerUp`,e=>{!this.enabled||!this.domElement||(this.domElement.style.touchAction=``,this.domElement.ownerDocument.removeEventListener(`pointermove`,this.onPointerMove),this.pointerUp(this.getPointer(e)))}),$(this,`getMode`,()=>this.mode),$(this,`setMode`,e=>{this.mode=e}),$(this,`setTranslationSnap`,e=>{this.translationSnap=e}),$(this,`setRotationSnap`,e=>{this.rotationSnap=e}),$(this,`setScaleSnap`,e=>{this.scaleSnap=e}),$(this,`setSize`,e=>{this.size=e}),$(this,`setSpace`,e=>{this.space=e}),$(this,`update`,()=>{console.warn(`THREE.TransformControls: update function has no more functionality and therefore has been deprecated.`)}),$(this,`connect`,e=>{e===document&&console.error(`THREE.OrbitControls: "document" should not be used as the target "domElement". Please use "renderer.domElement" instead.`),this.domElement=e,this.domElement.addEventListener(`pointerdown`,this.onPointerDown),this.domElement.addEventListener(`pointermove`,this.onPointerHover),this.domElement.ownerDocument.addEventListener(`pointerup`,this.onPointerUp)}),$(this,`dispose`,()=>{var e,t,n,r;(e=this.domElement)==null||e.removeEventListener(`pointerdown`,this.onPointerDown),(t=this.domElement)==null||t.removeEventListener(`pointermove`,this.onPointerHover),(n=this.domElement?.ownerDocument)==null||n.removeEventListener(`pointermove`,this.onPointerMove),(r=this.domElement?.ownerDocument)==null||r.removeEventListener(`pointerup`,this.onPointerUp),this.traverse(e=>{let t=e;t.geometry&&t.geometry.dispose(),t.material&&t.material.dispose()})}),this.domElement=t,this.camera=e,this.gizmo=new Xx,this.add(this.gizmo),this.plane=new Zx,this.add(this.plane);let n=(e,t)=>{let n=t;Object.defineProperty(this,e,{get:function(){return n===void 0?t:n},set:function(t){n!==t&&(n=t,this.plane[e]=t,this.gizmo[e]=t,this.dispatchEvent({type:e+`-changed`,value:t}),this.dispatchEvent(this.changeEvent))}}),this[e]=t,this.plane[e]=t,this.gizmo[e]=t};n(`camera`,this.camera),n(`object`,this.object),n(`enabled`,this.enabled),n(`axis`,this.axis),n(`mode`,this.mode),n(`translationSnap`,this.translationSnap),n(`rotationSnap`,this.rotationSnap),n(`scaleSnap`,this.scaleSnap),n(`space`,this.space),n(`size`,this.size),n(`dragging`,this.dragging),n(`showX`,this.showX),n(`showY`,this.showY),n(`showZ`,this.showZ),n(`worldPosition`,this.worldPosition),n(`worldPositionStart`,this.worldPositionStart),n(`worldQuaternion`,this.worldQuaternion),n(`worldQuaternionStart`,this.worldQuaternionStart),n(`cameraPosition`,this.cameraPosition),n(`cameraQuaternion`,this.cameraQuaternion),n(`pointStart`,this.pointStart),n(`pointEnd`,this.pointEnd),n(`rotationAxis`,this.rotationAxis),n(`rotationAngle`,this.rotationAngle),n(`eye`,this.eye),t!==void 0&&this.connect(t)}},Xx=class extends ke{constructor(){super(),$(this,`isTransformControlsGizmo`,!0),$(this,`type`,`TransformControlsGizmo`),$(this,`tempVector`,new K(0,0,0)),$(this,`tempEuler`,new _n),$(this,`alignVector`,new K(0,1,0)),$(this,`zeroVector`,new K(0,0,0)),$(this,`lookAtMatrix`,new Pr),$(this,`tempQuaternion`,new Ei),$(this,`tempQuaternion2`,new Ei),$(this,`identityQuaternion`,new Ei),$(this,`unitX`,new K(1,0,0)),$(this,`unitY`,new K(0,1,0)),$(this,`unitZ`,new K(0,0,1)),$(this,`gizmo`),$(this,`picker`),$(this,`helper`),$(this,`rotationAxis`,new K),$(this,`cameraPosition`,new K),$(this,`worldPositionStart`,new K),$(this,`worldQuaternionStart`,new Ei),$(this,`worldPosition`,new K),$(this,`worldQuaternion`,new Ei),$(this,`eye`,new K),$(this,`camera`,null),$(this,`enabled`,!0),$(this,`axis`,null),$(this,`mode`,`translate`),$(this,`space`,`world`),$(this,`size`,1),$(this,`dragging`,!1),$(this,`showX`,!0),$(this,`showY`,!0),$(this,`showZ`,!0),$(this,`updateMatrixWorld`,()=>{let e=this.space;this.mode===`scale`&&(e=`local`);let t=e===`local`?this.worldQuaternion:this.identityQuaternion;this.gizmo.translate.visible=this.mode===`translate`,this.gizmo.rotate.visible=this.mode===`rotate`,this.gizmo.scale.visible=this.mode===`scale`,this.helper.translate.visible=this.mode===`translate`,this.helper.rotate.visible=this.mode===`rotate`,this.helper.scale.visible=this.mode===`scale`;let n=[];n=n.concat(this.picker[this.mode].children),n=n.concat(this.gizmo[this.mode].children),n=n.concat(this.helper[this.mode].children);for(let e=0;e<n.length;e++){let r=n[e];r.visible=!0,r.rotation.set(0,0,0),r.position.copy(this.worldPosition);let i;if(i=this.camera.isOrthographicCamera?(this.camera.top-this.camera.bottom)/this.camera.zoom:this.worldPosition.distanceTo(this.cameraPosition)*Math.min(1.9*Math.tan(Math.PI*this.camera.fov/360)/this.camera.zoom,7),r.scale.set(1,1,1).multiplyScalar(i*this.size/7),r.tag===`helper`){r.visible=!1,r.name===`AXIS`?(r.position.copy(this.worldPositionStart),r.visible=!!this.axis,this.axis===`X`&&(this.tempQuaternion.setFromEuler(this.tempEuler.set(0,0,0)),r.quaternion.copy(t).multiply(this.tempQuaternion),Math.abs(this.alignVector.copy(this.unitX).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),this.axis===`Y`&&(this.tempQuaternion.setFromEuler(this.tempEuler.set(0,0,Math.PI/2)),r.quaternion.copy(t).multiply(this.tempQuaternion),Math.abs(this.alignVector.copy(this.unitY).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),this.axis===`Z`&&(this.tempQuaternion.setFromEuler(this.tempEuler.set(0,Math.PI/2,0)),r.quaternion.copy(t).multiply(this.tempQuaternion),Math.abs(this.alignVector.copy(this.unitZ).applyQuaternion(t).dot(this.eye))>.9&&(r.visible=!1)),this.axis===`XYZE`&&(this.tempQuaternion.setFromEuler(this.tempEuler.set(0,Math.PI/2,0)),this.alignVector.copy(this.rotationAxis),r.quaternion.setFromRotationMatrix(this.lookAtMatrix.lookAt(this.zeroVector,this.alignVector,this.unitY)),r.quaternion.multiply(this.tempQuaternion),r.visible=this.dragging),this.axis===`E`&&(r.visible=!1)):r.name===`START`?(r.position.copy(this.worldPositionStart),r.visible=this.dragging):r.name===`END`?(r.position.copy(this.worldPosition),r.visible=this.dragging):r.name===`DELTA`?(r.position.copy(this.worldPositionStart),r.quaternion.copy(this.worldQuaternionStart),this.tempVector.set(1e-10,1e-10,1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1),this.tempVector.applyQuaternion(this.worldQuaternionStart.clone().invert()),r.scale.copy(this.tempVector),r.visible=this.dragging):(r.quaternion.copy(t),this.dragging?r.position.copy(this.worldPositionStart):r.position.copy(this.worldPosition),this.axis&&(r.visible=this.axis.search(r.name)!==-1));continue}if(r.quaternion.copy(t),this.mode===`translate`||this.mode===`scale`){let e=.99,n=.2;(r.name===`X`||r.name===`XYZX`)&&Math.abs(this.alignVector.copy(this.unitX).applyQuaternion(t).dot(this.eye))>e&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),(r.name===`Y`||r.name===`XYZY`)&&Math.abs(this.alignVector.copy(this.unitY).applyQuaternion(t).dot(this.eye))>e&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),(r.name===`Z`||r.name===`XYZZ`)&&Math.abs(this.alignVector.copy(this.unitZ).applyQuaternion(t).dot(this.eye))>e&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),r.name===`XY`&&Math.abs(this.alignVector.copy(this.unitZ).applyQuaternion(t).dot(this.eye))<n&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),r.name===`YZ`&&Math.abs(this.alignVector.copy(this.unitX).applyQuaternion(t).dot(this.eye))<n&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),r.name===`XZ`&&Math.abs(this.alignVector.copy(this.unitY).applyQuaternion(t).dot(this.eye))<n&&(r.scale.set(1e-10,1e-10,1e-10),r.visible=!1),r.name.search(`X`)!==-1&&(this.alignVector.copy(this.unitX).applyQuaternion(t).dot(this.eye)<0?r.tag===`fwd`?r.visible=!1:r.scale.x*=-1:r.tag===`bwd`&&(r.visible=!1)),r.name.search(`Y`)!==-1&&(this.alignVector.copy(this.unitY).applyQuaternion(t).dot(this.eye)<0?r.tag===`fwd`?r.visible=!1:r.scale.y*=-1:r.tag===`bwd`&&(r.visible=!1)),r.name.search(`Z`)!==-1&&(this.alignVector.copy(this.unitZ).applyQuaternion(t).dot(this.eye)<0?r.tag===`fwd`?r.visible=!1:r.scale.z*=-1:r.tag===`bwd`&&(r.visible=!1))}else this.mode===`rotate`&&(this.tempQuaternion2.copy(t),this.alignVector.copy(this.eye).applyQuaternion(this.tempQuaternion.copy(t).invert()),r.name.search(`E`)!==-1&&r.quaternion.setFromRotationMatrix(this.lookAtMatrix.lookAt(this.eye,this.zeroVector,this.unitY)),r.name===`X`&&(this.tempQuaternion.setFromAxisAngle(this.unitX,Math.atan2(-this.alignVector.y,this.alignVector.z)),this.tempQuaternion.multiplyQuaternions(this.tempQuaternion2,this.tempQuaternion),r.quaternion.copy(this.tempQuaternion)),r.name===`Y`&&(this.tempQuaternion.setFromAxisAngle(this.unitY,Math.atan2(this.alignVector.x,this.alignVector.z)),this.tempQuaternion.multiplyQuaternions(this.tempQuaternion2,this.tempQuaternion),r.quaternion.copy(this.tempQuaternion)),r.name===`Z`&&(this.tempQuaternion.setFromAxisAngle(this.unitZ,Math.atan2(this.alignVector.y,this.alignVector.x)),this.tempQuaternion.multiplyQuaternions(this.tempQuaternion2,this.tempQuaternion),r.quaternion.copy(this.tempQuaternion)));r.visible=r.visible&&(r.name.indexOf(`X`)===-1||this.showX),r.visible=r.visible&&(r.name.indexOf(`Y`)===-1||this.showY),r.visible=r.visible&&(r.name.indexOf(`Z`)===-1||this.showZ),r.visible=r.visible&&(r.name.indexOf(`E`)===-1||this.showX&&this.showY&&this.showZ),r.material.tempOpacity=r.material.tempOpacity||r.material.opacity,r.material.tempColor=r.material.tempColor||r.material.color.clone(),r.material.color.copy(r.material.tempColor),r.material.opacity=r.material.tempOpacity,this.enabled?this.axis&&(r.name===this.axis||this.axis.split(``).some(function(e){return r.name===e})?(r.material.opacity=1,r.material.color.lerp(new Ai(1,1,1),.5)):(r.material.opacity*=.25,r.material.color.lerp(new Ai(1,1,1),.5))):(r.material.opacity*=.5,r.material.color.lerp(new Ai(1,1,1),.5))}super.updateMatrixWorld()});let e=new Oa({depthTest:!1,depthWrite:!1,transparent:!0,side:2,fog:!1,toneMapped:!1}),t=new hn({depthTest:!1,depthWrite:!1,transparent:!0,linewidth:1,fog:!1,toneMapped:!1}),n=e.clone();n.opacity=.15;let r=e.clone();r.opacity=.33;let i=e.clone();i.color.set(16711680);let a=e.clone();a.color.set(65280);let o=e.clone();o.color.set(255);let s=e.clone();s.opacity=.25;let c=s.clone();c.color.set(16776960);let l=s.clone();l.color.set(65535);let u=s.clone();u.color.set(16711935),e.clone().color.set(16776960);let d=t.clone();d.color.set(16711680);let f=t.clone();f.color.set(65280);let p=t.clone();p.color.set(255);let m=t.clone();m.color.set(65535);let h=t.clone();h.color.set(16711935);let g=t.clone();g.color.set(16776960);let _=t.clone();_.color.set(7895160);let v=g.clone();v.opacity=.25;let y=new Ua(0,.05,.2,12,1,!1),b=new an(.125,.125,.125),x=new fn;x.setAttribute(`position`,new Cn([0,0,0,1,0,0],3));let S=(e,t)=>{let n=new fn,r=[];for(let n=0;n<=64*t;++n)r.push(0,Math.cos(n/32*Math.PI)*e,Math.sin(n/32*Math.PI)*e);return n.setAttribute(`position`,new Cn(r,3)),n},C=()=>{let e=new fn;return e.setAttribute(`position`,new Cn([0,0,0,1,1,1],3)),e},w={X:[[new G(y,i),[1,0,0],[0,0,-Math.PI/2],null,`fwd`],[new G(y,i),[1,0,0],[0,0,Math.PI/2],null,`bwd`],[new W(x,d)]],Y:[[new G(y,a),[0,1,0],null,null,`fwd`],[new G(y,a),[0,1,0],[Math.PI,0,0],null,`bwd`],[new W(x,f),null,[0,0,Math.PI/2]]],Z:[[new G(y,o),[0,0,1],[Math.PI/2,0,0],null,`fwd`],[new G(y,o),[0,0,1],[-Math.PI/2,0,0],null,`bwd`],[new W(x,p),null,[0,-Math.PI/2,0]]],XYZ:[[new G(new Ft(.1,0),s.clone()),[0,0,0],[0,0,0]]],XY:[[new G(new nn(.295,.295),c.clone()),[.15,.15,0]],[new W(x,g),[.18,.3,0],null,[.125,1,1]],[new W(x,g),[.3,.18,0],[0,0,Math.PI/2],[.125,1,1]]],YZ:[[new G(new nn(.295,.295),l.clone()),[0,.15,.15],[0,Math.PI/2,0]],[new W(x,m),[0,.18,.3],[0,0,Math.PI/2],[.125,1,1]],[new W(x,m),[0,.3,.18],[0,-Math.PI/2,0],[.125,1,1]]],XZ:[[new G(new nn(.295,.295),u.clone()),[.15,0,.15],[-Math.PI/2,0,0]],[new W(x,h),[.18,0,.3],null,[.125,1,1]],[new W(x,h),[.3,0,.18],[0,-Math.PI/2,0],[.125,1,1]]]},T={X:[[new G(new Ua(.2,0,1,4,1,!1),n),[.6,0,0],[0,0,-Math.PI/2]]],Y:[[new G(new Ua(.2,0,1,4,1,!1),n),[0,.6,0]]],Z:[[new G(new Ua(.2,0,1,4,1,!1),n),[0,0,.6],[Math.PI/2,0,0]]],XYZ:[[new G(new Ft(.2,0),n)]],XY:[[new G(new nn(.4,.4),n),[.2,.2,0]]],YZ:[[new G(new nn(.4,.4),n),[0,.2,.2],[0,Math.PI/2,0]]],XZ:[[new G(new nn(.4,.4),n),[.2,0,.2],[-Math.PI/2,0,0]]]},E={START:[[new G(new Ft(.01,2),r),null,null,null,`helper`]],END:[[new G(new Ft(.01,2),r),null,null,null,`helper`]],DELTA:[[new W(C(),r),null,null,null,`helper`]],X:[[new W(x,r.clone()),[-1e3,0,0],null,[1e6,1,1],`helper`]],Y:[[new W(x,r.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],`helper`]],Z:[[new W(x,r.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],`helper`]]},D={X:[[new W(S(1,.5),d)],[new G(new Ft(.04,0),i),[0,0,.99],null,[1,3,1]]],Y:[[new W(S(1,.5),f),null,[0,0,-Math.PI/2]],[new G(new Ft(.04,0),a),[0,0,.99],null,[3,1,1]]],Z:[[new W(S(1,.5),p),null,[0,Math.PI/2,0]],[new G(new Ft(.04,0),o),[.99,0,0],null,[1,3,1]]],E:[[new W(S(1.25,1),v),null,[0,Math.PI/2,0]],[new G(new Ua(.03,0,.15,4,1,!1),v),[1.17,0,0],[0,0,-Math.PI/2],[1,1,.001]],[new G(new Ua(.03,0,.15,4,1,!1),v),[-1.17,0,0],[0,0,Math.PI/2],[1,1,.001]],[new G(new Ua(.03,0,.15,4,1,!1),v),[0,-1.17,0],[Math.PI,0,0],[1,1,.001]],[new G(new Ua(.03,0,.15,4,1,!1),v),[0,1.17,0],[0,0,0],[1,1,.001]]],XYZE:[[new W(S(1,1),_),null,[0,Math.PI/2,0]]]},O={AXIS:[[new W(x,r.clone()),[-1e3,0,0],null,[1e6,1,1],`helper`]]},k={X:[[new G(new Gi(1,.1,4,24),n),[0,0,0],[0,-Math.PI/2,-Math.PI/2]]],Y:[[new G(new Gi(1,.1,4,24),n),[0,0,0],[Math.PI/2,0,0]]],Z:[[new G(new Gi(1,.1,4,24),n),[0,0,0],[0,0,-Math.PI/2]]],E:[[new G(new Gi(1.25,.1,2,24),n)]],XYZE:[[new G(new ja(.7,10,8),n)]]},A={X:[[new G(b,i),[.8,0,0],[0,0,-Math.PI/2]],[new W(x,d),null,null,[.8,1,1]]],Y:[[new G(b,a),[0,.8,0]],[new W(x,f),null,[0,0,Math.PI/2],[.8,1,1]]],Z:[[new G(b,o),[0,0,.8],[Math.PI/2,0,0]],[new W(x,p),null,[0,-Math.PI/2,0],[.8,1,1]]],XY:[[new G(b,c),[.85,.85,0],null,[2,2,.2]],[new W(x,g),[.855,.98,0],null,[.125,1,1]],[new W(x,g),[.98,.855,0],[0,0,Math.PI/2],[.125,1,1]]],YZ:[[new G(b,l),[0,.85,.85],null,[.2,2,2]],[new W(x,m),[0,.855,.98],[0,0,Math.PI/2],[.125,1,1]],[new W(x,m),[0,.98,.855],[0,-Math.PI/2,0],[.125,1,1]]],XZ:[[new G(b,u),[.85,0,.85],null,[2,.2,2]],[new W(x,h),[.855,0,.98],null,[.125,1,1]],[new W(x,h),[.98,0,.855],[0,-Math.PI/2,0],[.125,1,1]]],XYZX:[[new G(new an(.125,.125,.125),s.clone()),[1.1,0,0]]],XYZY:[[new G(new an(.125,.125,.125),s.clone()),[0,1.1,0]]],XYZZ:[[new G(new an(.125,.125,.125),s.clone()),[0,0,1.1]]]},j={X:[[new G(new Ua(.2,0,.8,4,1,!1),n),[.5,0,0],[0,0,-Math.PI/2]]],Y:[[new G(new Ua(.2,0,.8,4,1,!1),n),[0,.5,0]]],Z:[[new G(new Ua(.2,0,.8,4,1,!1),n),[0,0,.5],[Math.PI/2,0,0]]],XY:[[new G(b,n),[.85,.85,0],null,[3,3,.2]]],YZ:[[new G(b,n),[0,.85,.85],null,[.2,3,3]]],XZ:[[new G(b,n),[.85,0,.85],null,[3,.2,3]]],XYZX:[[new G(new an(.2,.2,.2),n),[1.1,0,0]]],XYZY:[[new G(new an(.2,.2,.2),n),[0,1.1,0]]],XYZZ:[[new G(new an(.2,.2,.2),n),[0,0,1.1]]]},M={X:[[new W(x,r.clone()),[-1e3,0,0],null,[1e6,1,1],`helper`]],Y:[[new W(x,r.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],`helper`]],Z:[[new W(x,r.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],`helper`]]},N=e=>{let t=new ke;for(let n in e)for(let r=e[n].length;r--;){let i=e[n][r][0].clone(),a=e[n][r][1],o=e[n][r][2],s=e[n][r][3],c=e[n][r][4];i.name=n,i.tag=c,a&&i.position.set(a[0],a[1],a[2]),o&&i.rotation.set(o[0],o[1],o[2]),s&&i.scale.set(s[0],s[1],s[2]),i.updateMatrix();let l=i.geometry.clone();l.applyMatrix4(i.matrix),i.geometry=l,i.renderOrder=1/0,i.position.set(0,0,0),i.rotation.set(0,0,0),i.scale.set(1,1,1),t.add(i)}return t};this.gizmo={},this.picker={},this.helper={},this.add(this.gizmo.translate=N(w)),this.add(this.gizmo.rotate=N(D)),this.add(this.gizmo.scale=N(A)),this.add(this.picker.translate=N(T)),this.add(this.picker.rotate=N(k)),this.add(this.picker.scale=N(j)),this.add(this.helper.translate=N(E)),this.add(this.helper.rotate=N(O)),this.add(this.helper.scale=N(M)),this.picker.translate.visible=!1,this.picker.rotate.visible=!1,this.picker.scale.visible=!1}},Zx=class extends G{constructor(){super(new nn(1e5,1e5,2,2),new Oa({visible:!1,wireframe:!0,side:2,transparent:!0,opacity:.1,toneMapped:!1})),$(this,`isTransformControlsPlane`,!0),$(this,`type`,`TransformControlsPlane`),$(this,`unitX`,new K(1,0,0)),$(this,`unitY`,new K(0,1,0)),$(this,`unitZ`,new K(0,0,1)),$(this,`tempVector`,new K),$(this,`dirVector`,new K),$(this,`alignVector`,new K),$(this,`tempMatrix`,new Pr),$(this,`identityQuaternion`,new Ei),$(this,`cameraQuaternion`,new Ei),$(this,`worldPosition`,new K),$(this,`worldQuaternion`,new Ei),$(this,`eye`,new K),$(this,`axis`,null),$(this,`mode`,`translate`),$(this,`space`,`world`),$(this,`updateMatrixWorld`,()=>{let e=this.space;switch(this.position.copy(this.worldPosition),this.mode===`scale`&&(e=`local`),this.unitX.set(1,0,0).applyQuaternion(e===`local`?this.worldQuaternion:this.identityQuaternion),this.unitY.set(0,1,0).applyQuaternion(e===`local`?this.worldQuaternion:this.identityQuaternion),this.unitZ.set(0,0,1).applyQuaternion(e===`local`?this.worldQuaternion:this.identityQuaternion),this.alignVector.copy(this.unitY),this.mode){case`translate`:case`scale`:switch(this.axis){case`X`:this.alignVector.copy(this.eye).cross(this.unitX),this.dirVector.copy(this.unitX).cross(this.alignVector);break;case`Y`:this.alignVector.copy(this.eye).cross(this.unitY),this.dirVector.copy(this.unitY).cross(this.alignVector);break;case`Z`:this.alignVector.copy(this.eye).cross(this.unitZ),this.dirVector.copy(this.unitZ).cross(this.alignVector);break;case`XY`:this.dirVector.copy(this.unitZ);break;case`YZ`:this.dirVector.copy(this.unitX);break;case`XZ`:this.alignVector.copy(this.unitZ),this.dirVector.copy(this.unitY);break;case`XYZ`:case`E`:this.dirVector.set(0,0,0);break}break;default:this.dirVector.set(0,0,0)}this.dirVector.length()===0?this.quaternion.copy(this.cameraQuaternion):(this.tempMatrix.lookAt(this.tempVector.set(0,0,0),this.dirVector,this.alignVector),this.quaternion.setFromRotationMatrix(this.tempMatrix)),super.updateMatrixWorld()})}},Qx=Object.defineProperty,$x=(e,t,n)=>t in e?Qx(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,eS=(e,t,n)=>($x(e,typeof t==`symbol`?t:t+``,n),n),tS=new Ne,nS=new Se,rS=Math.cos(Math.PI/180*70),iS=(e,t)=>(e%t+t)%t,aS=class extends Kx{constructor(e,t){super(),eS(this,`object`),eS(this,`domElement`),eS(this,`enabled`,!0),eS(this,`target`,new K),eS(this,`minDistance`,0),eS(this,`maxDistance`,1/0),eS(this,`minZoom`,0),eS(this,`maxZoom`,1/0),eS(this,`minPolarAngle`,0),eS(this,`maxPolarAngle`,Math.PI),eS(this,`minAzimuthAngle`,-1/0),eS(this,`maxAzimuthAngle`,1/0),eS(this,`enableDamping`,!1),eS(this,`dampingFactor`,.05),eS(this,`enableZoom`,!0),eS(this,`zoomSpeed`,1),eS(this,`enableRotate`,!0),eS(this,`rotateSpeed`,1),eS(this,`enablePan`,!0),eS(this,`panSpeed`,1),eS(this,`screenSpacePanning`,!0),eS(this,`keyPanSpeed`,7),eS(this,`zoomToCursor`,!1),eS(this,`autoRotate`,!1),eS(this,`autoRotateSpeed`,2),eS(this,`reverseOrbit`,!1),eS(this,`reverseHorizontalOrbit`,!1),eS(this,`reverseVerticalOrbit`,!1),eS(this,`keys`,{LEFT:`ArrowLeft`,UP:`ArrowUp`,RIGHT:`ArrowRight`,BOTTOM:`ArrowDown`}),eS(this,`mouseButtons`,{LEFT:xa.ROTATE,MIDDLE:xa.DOLLY,RIGHT:xa.PAN}),eS(this,`touches`,{ONE:S.ROTATE,TWO:S.DOLLY_PAN}),eS(this,`target0`),eS(this,`position0`),eS(this,`zoom0`),eS(this,`_domElementKeyEvents`,null),eS(this,`getPolarAngle`),eS(this,`getAzimuthalAngle`),eS(this,`setPolarAngle`),eS(this,`setAzimuthalAngle`),eS(this,`getDistance`),eS(this,`getZoomScale`),eS(this,`listenToKeyEvents`),eS(this,`stopListenToKeyEvents`),eS(this,`saveState`),eS(this,`reset`),eS(this,`update`),eS(this,`connect`),eS(this,`dispose`),eS(this,`dollyIn`),eS(this,`dollyOut`),eS(this,`getScale`),eS(this,`setScale`),this.object=e,this.domElement=t,this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this.getPolarAngle=()=>l.phi,this.getAzimuthalAngle=()=>l.theta,this.setPolarAngle=e=>{let t=iS(e,2*Math.PI),r=l.phi;r<0&&(r+=2*Math.PI),t<0&&(t+=2*Math.PI);let i=Math.abs(t-r);2*Math.PI-i<i&&(t<r?t+=2*Math.PI:r+=2*Math.PI),u.phi=t-r,n.update()},this.setAzimuthalAngle=e=>{let t=iS(e,2*Math.PI),r=l.theta;r<0&&(r+=2*Math.PI),t<0&&(t+=2*Math.PI);let i=Math.abs(t-r);2*Math.PI-i<i&&(t<r?t+=2*Math.PI:r+=2*Math.PI),u.theta=t-r,n.update()},this.getDistance=()=>n.object.position.distanceTo(n.target),this.listenToKeyEvents=e=>{e.addEventListener(`keydown`,be),this._domElementKeyEvents=e},this.stopListenToKeyEvents=()=>{this._domElementKeyEvents.removeEventListener(`keydown`,be),this._domElementKeyEvents=null},this.saveState=()=>{n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=()=>{n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(r),n.update(),s=o.NONE},this.update=(()=>{let t=new K,i=new K(0,1,0),a=new Ei().setFromUnitVectors(e.up,i),p=a.clone().invert(),m=new K,h=new Ei,g=2*Math.PI;return function(){let _=n.object.position;a.setFromUnitVectors(e.up,i),p.copy(a).invert(),t.copy(_).sub(n.target),t.applyQuaternion(a),l.setFromVector3(t),n.autoRotate&&s===o.NONE&&A(O()),n.enableDamping?(l.theta+=u.theta*n.dampingFactor,l.phi+=u.phi*n.dampingFactor):(l.theta+=u.theta,l.phi+=u.phi);let v=n.minAzimuthAngle,y=n.maxAzimuthAngle;isFinite(v)&&isFinite(y)&&(v<-Math.PI?v+=g:v>Math.PI&&(v-=g),y<-Math.PI?y+=g:y>Math.PI&&(y-=g),v<=y?l.theta=Math.max(v,Math.min(y,l.theta)):l.theta=l.theta>(v+y)/2?Math.max(v,l.theta):Math.min(y,l.theta)),l.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,l.phi)),l.makeSafe(),n.enableDamping===!0?n.target.addScaledVector(f,n.dampingFactor):n.target.add(f),n.zoomToCursor&&T||n.object.isOrthographicCamera?l.radius=te(l.radius):l.radius=te(l.radius*d),t.setFromSpherical(l),t.applyQuaternion(p),_.copy(n.target).add(t),n.object.matrixAutoUpdate||n.object.updateMatrix(),n.object.lookAt(n.target),n.enableDamping===!0?(u.theta*=1-n.dampingFactor,u.phi*=1-n.dampingFactor,f.multiplyScalar(1-n.dampingFactor)):(u.set(0,0,0),f.set(0,0,0));let b=!1;if(n.zoomToCursor&&T){let r=null;if(n.object instanceof un&&n.object.isPerspectiveCamera){let e=t.length();r=te(e*d);let i=e-r;n.object.position.addScaledVector(C,i),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let e=new K(w.x,w.y,0);e.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/d)),n.object.updateProjectionMatrix(),b=!0;let i=new K(w.x,w.y,0);i.unproject(n.object),n.object.position.sub(i).add(e),n.object.updateMatrixWorld(),r=t.length()}else console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled.`),n.zoomToCursor=!1;r!==null&&(n.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(r).add(n.object.position):(tS.origin.copy(n.object.position),tS.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(tS.direction))<rS?e.lookAt(n.target):(nS.setFromNormalAndCoplanarPoint(n.object.up,n.target),tS.intersectPlane(nS,n.target))))}else n.object instanceof to&&n.object.isOrthographicCamera&&(b=d!==1,b&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/d)),n.object.updateProjectionMatrix()));return d=1,T=!1,b||m.distanceToSquared(n.object.position)>c||8*(1-h.dot(n.object.quaternion))>c?(n.dispatchEvent(r),m.copy(n.object.position),h.copy(n.object.quaternion),b=!1,!0):!1}})(),this.connect=e=>{n.domElement=e,n.domElement.style.touchAction=`none`,n.domElement.addEventListener(`contextmenu`,Se),n.domElement.addEventListener(`pointerdown`,ge),n.domElement.addEventListener(`pointercancel`,_e),n.domElement.addEventListener(`wheel`,U)},this.dispose=()=>{var e,t,r,i,a,o;n.domElement&&(n.domElement.style.touchAction=`auto`),(e=n.domElement)==null||e.removeEventListener(`contextmenu`,Se),(t=n.domElement)==null||t.removeEventListener(`pointerdown`,ge),(r=n.domElement)==null||r.removeEventListener(`pointercancel`,_e),(i=n.domElement)==null||i.removeEventListener(`wheel`,U),(a=n.domElement)==null||a.ownerDocument.removeEventListener(`pointermove`,H),(o=n.domElement)==null||o.ownerDocument.removeEventListener(`pointerup`,_e),n._domElementKeyEvents!==null&&n._domElementKeyEvents.removeEventListener(`keydown`,be)};let n=this,r={type:`change`},i={type:`start`},a={type:`end`},o={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},s=o.NONE,c=1e-6,l=new Gt,u=new Gt,d=1,f=new K,p=new Er,m=new Er,h=new Er,g=new Er,_=new Er,v=new Er,y=new Er,b=new Er,x=new Er,C=new K,w=new Er,T=!1,E=[],D={};function O(){return 2*Math.PI/60/60*n.autoRotateSpeed}function k(){return .95**n.zoomSpeed}function A(e){n.reverseOrbit||n.reverseHorizontalOrbit?u.theta+=e:u.theta-=e}function j(e){n.reverseOrbit||n.reverseVerticalOrbit?u.phi+=e:u.phi-=e}let M=(()=>{let e=new K;return function(t,n){e.setFromMatrixColumn(n,0),e.multiplyScalar(-t),f.add(e)}})(),N=(()=>{let e=new K;return function(t,r){n.screenSpacePanning===!0?e.setFromMatrixColumn(r,1):(e.setFromMatrixColumn(r,0),e.crossVectors(n.object.up,e)),e.multiplyScalar(t),f.add(e)}})(),P=(()=>{let e=new K;return function(t,r){let i=n.domElement;if(i&&n.object instanceof un&&n.object.isPerspectiveCamera){let a=n.object.position;e.copy(a).sub(n.target);let o=e.length();o*=Math.tan(n.object.fov/2*Math.PI/180),M(2*t*o/i.clientHeight,n.object.matrix),N(2*r*o/i.clientHeight,n.object.matrix)}else i&&n.object instanceof to&&n.object.isOrthographicCamera?(M(t*(n.object.right-n.object.left)/n.object.zoom/i.clientWidth,n.object.matrix),N(r*(n.object.top-n.object.bottom)/n.object.zoom/i.clientHeight,n.object.matrix)):(console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - pan disabled.`),n.enablePan=!1)}})();function F(e){n.object instanceof un&&n.object.isPerspectiveCamera||n.object instanceof to&&n.object.isOrthographicCamera?d=e:(console.warn(`WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled.`),n.enableZoom=!1)}function I(e){F(d/e)}function L(e){F(d*e)}function ee(e){if(!n.zoomToCursor||!n.domElement)return;T=!0;let t=n.domElement.getBoundingClientRect(),r=e.clientX-t.left,i=e.clientY-t.top,a=t.width,o=t.height;w.x=r/a*2-1,w.y=-(i/o)*2+1,C.set(w.x,w.y,1).unproject(n.object).sub(n.object.position).normalize()}function te(e){return Math.max(n.minDistance,Math.min(n.maxDistance,e))}function ne(e){p.set(e.clientX,e.clientY)}function R(e){ee(e),y.set(e.clientX,e.clientY)}function z(e){g.set(e.clientX,e.clientY)}function B(e){m.set(e.clientX,e.clientY),h.subVectors(m,p).multiplyScalar(n.rotateSpeed);let t=n.domElement;t&&(A(2*Math.PI*h.x/t.clientHeight),j(2*Math.PI*h.y/t.clientHeight)),p.copy(m),n.update()}function V(e){b.set(e.clientX,e.clientY),x.subVectors(b,y),x.y>0?I(k()):x.y<0&&L(k()),y.copy(b),n.update()}function re(e){_.set(e.clientX,e.clientY),v.subVectors(_,g).multiplyScalar(n.panSpeed),P(v.x,v.y),g.copy(_),n.update()}function ie(e){ee(e),e.deltaY<0?L(k()):e.deltaY>0&&I(k()),n.update()}function ae(e){let t=!1;switch(e.code){case n.keys.UP:P(0,n.keyPanSpeed),t=!0;break;case n.keys.BOTTOM:P(0,-n.keyPanSpeed),t=!0;break;case n.keys.LEFT:P(n.keyPanSpeed,0),t=!0;break;case n.keys.RIGHT:P(-n.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),n.update())}function oe(){if(E.length==1)p.set(E[0].pageX,E[0].pageY);else{let e=.5*(E[0].pageX+E[1].pageX),t=.5*(E[0].pageY+E[1].pageY);p.set(e,t)}}function se(){if(E.length==1)g.set(E[0].pageX,E[0].pageY);else{let e=.5*(E[0].pageX+E[1].pageX),t=.5*(E[0].pageY+E[1].pageY);g.set(e,t)}}function ce(){let e=E[0].pageX-E[1].pageX,t=E[0].pageY-E[1].pageY,n=Math.sqrt(e*e+t*t);y.set(0,n)}function le(){n.enableZoom&&ce(),n.enablePan&&se()}function ue(){n.enableZoom&&ce(),n.enableRotate&&oe()}function de(e){if(E.length==1)m.set(e.pageX,e.pageY);else{let t=Ee(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);m.set(n,r)}h.subVectors(m,p).multiplyScalar(n.rotateSpeed);let t=n.domElement;t&&(A(2*Math.PI*h.x/t.clientHeight),j(2*Math.PI*h.y/t.clientHeight)),p.copy(m)}function fe(e){if(E.length==1)_.set(e.pageX,e.pageY);else{let t=Ee(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);_.set(n,r)}v.subVectors(_,g).multiplyScalar(n.panSpeed),P(v.x,v.y),g.copy(_)}function pe(e){let t=Ee(e),r=e.pageX-t.x,i=e.pageY-t.y,a=Math.sqrt(r*r+i*i);b.set(0,a),x.set(0,(b.y/y.y)**+n.zoomSpeed),I(x.y),y.copy(b)}function me(e){n.enableZoom&&pe(e),n.enablePan&&fe(e)}function he(e){n.enableZoom&&pe(e),n.enableRotate&&de(e)}function ge(e){var t,r;n.enabled!==!1&&(E.length===0&&((t=n.domElement)==null||t.ownerDocument.addEventListener(`pointermove`,H),(r=n.domElement)==null||r.ownerDocument.addEventListener(`pointerup`,_e)),Ce(e),e.pointerType===`touch`?W(e):ve(e))}function H(e){n.enabled!==!1&&(e.pointerType===`touch`?xe(e):ye(e))}function _e(e){var t,r,i;we(e),E.length===0&&((t=n.domElement)==null||t.releasePointerCapture(e.pointerId),(r=n.domElement)==null||r.ownerDocument.removeEventListener(`pointermove`,H),(i=n.domElement)==null||i.ownerDocument.removeEventListener(`pointerup`,_e)),n.dispatchEvent(a),s=o.NONE}function ve(e){let t;switch(e.button){case 0:t=n.mouseButtons.LEFT;break;case 1:t=n.mouseButtons.MIDDLE;break;case 2:t=n.mouseButtons.RIGHT;break;default:t=-1}switch(t){case xa.DOLLY:if(n.enableZoom===!1)return;R(e),s=o.DOLLY;break;case xa.ROTATE:if(e.ctrlKey||e.metaKey||e.shiftKey){if(n.enablePan===!1)return;z(e),s=o.PAN}else{if(n.enableRotate===!1)return;ne(e),s=o.ROTATE}break;case xa.PAN:if(e.ctrlKey||e.metaKey||e.shiftKey){if(n.enableRotate===!1)return;ne(e),s=o.ROTATE}else{if(n.enablePan===!1)return;z(e),s=o.PAN}break;default:s=o.NONE}s!==o.NONE&&n.dispatchEvent(i)}function ye(e){if(n.enabled!==!1)switch(s){case o.ROTATE:if(n.enableRotate===!1)return;B(e);break;case o.DOLLY:if(n.enableZoom===!1)return;V(e);break;case o.PAN:if(n.enablePan===!1)return;re(e);break}}function U(e){n.enabled===!1||n.enableZoom===!1||s!==o.NONE&&s!==o.ROTATE||(e.preventDefault(),n.dispatchEvent(i),ie(e),n.dispatchEvent(a))}function be(e){n.enabled===!1||n.enablePan===!1||ae(e)}function W(e){switch(Te(e),E.length){case 1:switch(n.touches.ONE){case S.ROTATE:if(n.enableRotate===!1)return;oe(),s=o.TOUCH_ROTATE;break;case S.PAN:if(n.enablePan===!1)return;se(),s=o.TOUCH_PAN;break;default:s=o.NONE}break;case 2:switch(n.touches.TWO){case S.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;le(),s=o.TOUCH_DOLLY_PAN;break;case S.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;ue(),s=o.TOUCH_DOLLY_ROTATE;break;default:s=o.NONE}break;default:s=o.NONE}s!==o.NONE&&n.dispatchEvent(i)}function xe(e){switch(Te(e),s){case o.TOUCH_ROTATE:if(n.enableRotate===!1)return;de(e),n.update();break;case o.TOUCH_PAN:if(n.enablePan===!1)return;fe(e),n.update();break;case o.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;me(e),n.update();break;case o.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;he(e),n.update();break;default:s=o.NONE}}function Se(e){n.enabled!==!1&&e.preventDefault()}function Ce(e){E.push(e)}function we(e){delete D[e.pointerId];for(let t=0;t<E.length;t++)if(E[t].pointerId==e.pointerId){E.splice(t,1);return}}function Te(e){let t=D[e.pointerId];t===void 0&&(t=new Er,D[e.pointerId]=t),t.set(e.pageX,e.pageY)}function Ee(e){let t=e.pointerId===E[0].pointerId?E[1]:E[0];return D[t.pointerId]}this.dollyIn=(e=k())=>{L(e),n.update()},this.dollyOut=(e=k())=>{I(e),n.update()},this.getScale=()=>d,this.setScale=e=>{F(e),n.update()},this.getZoomScale=()=>k(),t!==void 0&&this.connect(t),this.update()}};function oS(e,t,n,r){var i;return i=class extends Cr{constructor(i){super({vertexShader:t,fragmentShader:n,...i});for(let t in e)this.uniforms[t]=new pa(e[t]),Object.defineProperty(this,t,{get(){return this.uniforms[t].value},set(e){this.uniforms[t].value=e}});this.uniforms=ea.clone(this.uniforms),r?.(this)}},i.key=Hi.generateUUID(),i}var sS=parseInt(`185`.replace(/\D+/g,``)),cS=Y.forwardRef(({makeDefault:e,camera:t,regress:n,domElement:r,enableDamping:i=!0,keyEvents:a=!1,onChange:o,onStart:s,onEnd:c,...l},u)=>{let d=Zy(e=>e.invalidate),f=Zy(e=>e.camera),p=Zy(e=>e.gl),m=Zy(e=>e.events),h=Zy(e=>e.setEvents),g=Zy(e=>e.set),_=Zy(e=>e.get),v=Zy(e=>e.performance),y=t||f,b=r||m.connected||p.domElement,x=Y.useMemo(()=>new aS(y),[y]);return Qy(()=>{x.enabled&&x.update()},-1),Y.useEffect(()=>(a&&x.connect(a===!0?b:a),x.connect(b),()=>void x.dispose()),[a,b,n,x,d]),Y.useEffect(()=>{let e=e=>{d(),n&&v.regress(),o&&o(e)},t=e=>{s&&s(e)},r=e=>{c&&c(e)};return x.addEventListener(`change`,e),x.addEventListener(`start`,t),x.addEventListener(`end`,r),()=>{x.removeEventListener(`start`,t),x.removeEventListener(`end`,r),x.removeEventListener(`change`,e)}},[o,s,c,x,d,h]),Y.useEffect(()=>{if(e){let e=_().controls;return g({controls:x}),()=>g({controls:e})}},[e,x]),Y.createElement(`primitive`,Hx({ref:u,object:x,enableDamping:i},l))}),lS=Y.forwardRef(({children:e,domElement:t,onChange:n,onMouseDown:r,onMouseUp:i,onObjectChange:a,object:o,makeDefault:s,camera:c,enabled:l,axis:u,mode:d,translationSnap:f,rotationSnap:p,scaleSnap:m,space:h,size:g,showX:_,showY:v,showZ:y,...b},x)=>{let S=Zy(e=>e.controls),C=Zy(e=>e.gl),w=Zy(e=>e.events),T=Zy(e=>e.camera),E=Zy(e=>e.invalidate),D=Zy(e=>e.get),O=Zy(e=>e.set),k=c||T,A=t||w.connected||C.domElement,j=Y.useMemo(()=>new Yx(k,A),[k,A]),M=Y.useRef(null);Y.useLayoutEffect(()=>(o?j.attach(o instanceof ke?o:o.current):M.current instanceof ke&&j.attach(M.current),()=>void j.detach()),[o,e,j]),Y.useEffect(()=>{if(S){let e=e=>S.enabled=!e.value;return j.addEventListener(`dragging-changed`,e),()=>j.removeEventListener(`dragging-changed`,e)}},[j,S]);let N=Y.useRef(void 0),P=Y.useRef(void 0),F=Y.useRef(void 0),I=Y.useRef(void 0);return Y.useLayoutEffect(()=>void(N.current=n),[n]),Y.useLayoutEffect(()=>void(P.current=r),[r]),Y.useLayoutEffect(()=>void(F.current=i),[i]),Y.useLayoutEffect(()=>void(I.current=a),[a]),Y.useEffect(()=>{let e=e=>{E(),N.current==null||N.current(e)},t=e=>P.current==null?void 0:P.current(e),n=e=>F.current==null?void 0:F.current(e),r=e=>I.current==null?void 0:I.current(e);return j.addEventListener(`change`,e),j.addEventListener(`mouseDown`,t),j.addEventListener(`mouseUp`,n),j.addEventListener(`objectChange`,r),()=>{j.removeEventListener(`change`,e),j.removeEventListener(`mouseDown`,t),j.removeEventListener(`mouseUp`,n),j.removeEventListener(`objectChange`,r)}},[E,j]),Y.useEffect(()=>{if(s){let e=D().controls;return O({controls:j}),()=>O({controls:e})}},[s,j]),Y.createElement(Y.Fragment,null,Y.createElement(`primitive`,{ref:x,object:j,enabled:l,axis:u,mode:d,translationSnap:f,rotationSnap:p,scaleSnap:m,space:h,size:g,showX:_,showY:v,showZ:y}),Y.createElement(`group`,Hx({ref:M},b),e))}),uS=oS({cellSize:.5,sectionSize:1,fadeDistance:100,fadeStrength:1,fadeFrom:1,cellThickness:.5,sectionThickness:1,cellColor:new Ai,sectionColor:new Ai,infiniteGrid:!1,followCamera:!1,worldCamProjPosition:new K,worldPlanePosition:new K},`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform vec3 worldPlanePosition;
    uniform float fadeDistance;
    uniform bool infiniteGrid;
    uniform bool followCamera;

    void main() {
      localPosition = position.xzy;
      if (infiniteGrid) localPosition *= 1.0 + fadeDistance;
      
      worldPosition = modelMatrix * vec4(localPosition, 1.0);
      if (followCamera) {
        worldPosition.xyz += (worldCamProjPosition - worldPlanePosition);
        localPosition = (inverse(modelMatrix) * worldPosition).xyz;
      }

      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform float cellSize;
    uniform float sectionSize;
    uniform vec3 cellColor;
    uniform vec3 sectionColor;
    uniform float fadeDistance;
    uniform float fadeStrength;
    uniform float fadeFrom;
    uniform float cellThickness;
    uniform float sectionThickness;

    float getGrid(float size, float thickness) {
      vec2 r = localPosition.xz / size;
      vec2 grid = abs(fract(r - 0.5) - 0.5) / fwidth(r);
      float line = min(grid.x, grid.y) + 1.0 - thickness;
      return 1.0 - min(line, 1.0);
    }

    void main() {
      float g1 = getGrid(cellSize, cellThickness);
      float g2 = getGrid(sectionSize, sectionThickness);

      vec3 from = worldCamProjPosition*vec3(fadeFrom);
      float dist = distance(from, worldPosition.xyz);
      float d = 1.0 - min(dist / fadeDistance, 1.0);
      vec3 color = mix(cellColor, sectionColor, min(1.0, sectionThickness * g2));

      gl_FragColor = vec4(color, (g1 + g2) * pow(d, fadeStrength));
      gl_FragColor.a = mix(0.75 * gl_FragColor.a, gl_FragColor.a, g2);
      if (gl_FragColor.a <= 0.0) discard;

      #include <tonemapping_fragment>
      #include <${sS>=154?`colorspace_fragment`:`encodings_fragment`}>
    }
  `),dS=Y.forwardRef(({args:e,cellColor:t=`#000000`,sectionColor:n=`#2080ff`,cellSize:r=.5,sectionSize:i=1,followCamera:a=!1,infiniteGrid:o=!1,fadeDistance:s=100,fadeStrength:c=1,fadeFrom:l=1,cellThickness:u=.5,sectionThickness:d=1,side:f=1,...p},m)=>{Cb({GridMaterial:uS});let h=Y.useRef(null);Y.useImperativeHandle(m,()=>h.current,[]);let g=new Se,_=new K(0,1,0),v=new K(0,0,0);Qy(e=>{g.setFromNormalAndCoplanarPoint(_,v).applyMatrix4(h.current.matrixWorld);let t=h.current.material,n=t.uniforms.worldCamProjPosition,r=t.uniforms.worldPlanePosition;g.projectPoint(e.camera.position,n.value),r.value.set(0,0,0).applyMatrix4(h.current.matrixWorld)});let y={cellSize:r,sectionSize:i,cellColor:t,sectionColor:n,cellThickness:u,sectionThickness:d},b={fadeDistance:s,fadeStrength:c,fadeFrom:l,infiniteGrid:o,followCamera:a};return Y.createElement(`mesh`,Hx({ref:h,frustumCulled:!1},p),Y.createElement(`gridMaterial`,Hx({transparent:!0,"extensions-derivatives":!0,side:f},y,b)),Y.createElement(`planeGeometry`,{args:e}))});function fS(e,t,n,r,i=.1,a=500){if(!Number.isFinite(e)||!Number.isFinite(t)||!Number.isFinite(n)||!Number.isFinite(r)||e<=0||t<=0||n<=0)return{movement:0,nextDepth:e};let o=Math.min(1.35,Math.max(.65,t/n)),s=Math.min(a,Math.max(i,e*o)),c=Math.max(.2,r);return{movement:(e-s)/c,nextDepth:s}}function pS(e,t,n){let r=e.getCenter(new K),i=e.getSize(new K).multiplyScalar(.5),a=t.clone();a.lengthSq()<1e-6&&a.set(0,0,-1),a.normalize();let o=Math.abs(a.x)*i.x+Math.abs(a.y)*i.y+Math.abs(a.z)*i.z,s=Math.max(.02,(Number.isFinite(n)&&n>0?n:.05)*2);return{focus:r,minimumDepth:Math.max(s,o+s)}}var mS=(e,t)=>Math.hypot(e.x-t.x,e.y-t.y);function hS({active:e,resolveAdditionalBounds:t}){let n=Zy(e=>e.camera),r=Zy(e=>e.gl),i=Zy(e=>e.controls),a=q(e=>e.objects),o=q(e=>e.selectedIds),s=(0,Y.useRef)(null),c=(0,Y.useMemo)(()=>{let e=a.filter(e=>o.includes(e.id)&&e.visible).map(e=>Xi(e)),n=t?.(o);return n&&e.push(...n),wi(e)},[a,t,o]);return(0,Y.useEffect)(()=>{s.current=c?.clone()??null},[c]),(0,Y.useEffect)(()=>{if(!e||!i)return;let t=new Map,a=null,o=null,c=()=>{a=null,o=null},l=()=>{if(t.size!==2){c();return}let[e,n]=[...t.values()];!e||!n||(a=mS(e,n),o=s.current?.clone()??null)},u=e=>{e.pointerType===`touch`&&(t.set(e.pointerId,{x:e.clientX,y:e.clientY}),l())},d=e=>{if(e.pointerType!==`touch`||!t.has(e.pointerId)||(t.set(e.pointerId,{x:e.clientX,y:e.clientY}),t.size!==2))return;let[c,l]=[...t.values()];if(!c||!l)return;let u=mS(c,l);if(!a||u<2){a=u,o=s.current?.clone()??null;return}let d=r.domElement.getBoundingClientRect();if(d.width<=0||d.height<=0)return;let f=(c.x+l.x)*.5,p=(c.y+l.y)*.5,m=new K((f-d.left)/d.width*2-1,-((p-d.top)/d.height)*2+1,.5).unproject(n).sub(n.position).normalize(),h=n.getWorldDirection(new K).normalize(),g=`near`in n&&typeof n.near==`number`?n.near:.05,_=o?pS(o,h,g):{focus:i.target.clone(),minimumDepth:Math.max(.1,g*2)},v=fS(_.focus.clone().sub(n.position).dot(h),a,u,m.dot(h),_.minimumDepth,500);a=u,!(Math.abs(v.movement)<1e-6)&&(e.preventDefault(),n.position.addScaledVector(m,v.movement),i.target.copy(n.position).addScaledVector(h,v.nextDepth),n.updateMatrixWorld(!0),i.update())},f=e=>{e.pointerType===`touch`&&(t.delete(e.pointerId),l())},p=r.domElement,m=p.ownerDocument;return p.addEventListener(`pointerdown`,u,{passive:!0}),m.addEventListener(`pointermove`,d,{passive:!1,capture:!0}),m.addEventListener(`pointerup`,f,{passive:!0,capture:!0}),m.addEventListener(`pointercancel`,f,{passive:!0,capture:!0}),()=>{p.removeEventListener(`pointerdown`,u),m.removeEventListener(`pointermove`,d,!0),m.removeEventListener(`pointerup`,f,!0),m.removeEventListener(`pointercancel`,f,!0),t.clear()}},[e,n,i,r]),null}var gS=1e-6,_S=.25;function vS(e,t){return Number.isFinite(e)?e:t}function yS(e){return[...new Set(e.map(e=>Number(e.toFixed(12))))].sort((e,t)=>e-t)}function bS(e,t,n,r){let i=Math.min(vS(t,0),vS(n,0)),a=Math.max(vS(t,0),vS(n,0)),o=(i+a)*.5,s=Math.max(1e-4,Math.abs(vS(r,1))),c=Math.max(0,a-i)*s*.5,l=[];for(let e=_S*.5;e<c-gS;e+=_S){let t=e/s;l.push(o-t,o+t)}let u=yS(l).filter(e=>e>i+gS&&e<a-gS),d=yS([i,...u,a]),f=[];for(let e=0;e<d.length-1;e+=1){let t=d[e],n=d[e+1];if(t===void 0||n===void 0)continue;let r=Math.max(0,(n-t)*s),i=e===0,a=e===d.length-2;f.push({index:e,minimum:t,maximum:n,size:r,edge:i&&a?`both`:i?`negative`:a?`positive`:null,isRemainderCell:r<_S-gS})}return{axis:e,minimum:i,maximum:a,center:o,standardStep:_S,cuts:u,coordinates:d,cells:f}}var xS=1e-5,SS=-.9;function CS(e){return[e.position.x,e.position.y,e.position.z].map(e=>Math.round(e/xS)).join(`:`)}function wS(e){let t=new Map;for(let n of e){let e=CS(n),r=t.get(e);r?r.push(n):t.set(e,[n])}let n=new Set;for(let e of t.values())if(!(e.length<2))for(let t of e)e.some(e=>e!==t&&t.normal.dot(e.normal)<=SS)&&n.add(t);return e.filter(e=>!n.has(e))}new Oa;var TS=1e-6,ES=65536;function DS(e){return[e.x,e.y,e.z].map(e=>Math.round(e/TS)).join(`:`)}function OS(e,t=ES){let n=e.getAttribute(`position`);if(!n||n.itemSize<3||n.count===0)return[];let r=new Map;for(let e=0;e<n.count;e+=1){let t=new K().fromBufferAttribute(n,e),i=DS(t);r.has(i)||r.set(i,t)}let i=[...r.values()];if(i.length<=t)return i;let a=[],o=i.length/t;for(let e=0;e<t;e+=1){let t=i[Math.floor(e*o)];t&&a.push(t)}return a}function kS(e,t){return e.map(e=>e.clone().applyMatrix4(t))}function AS(e,t){let n=1/0;for(let r of e)n=Math.min(n,r.dot(t));return n}var jS=1e-6,MS=32768,NS=[[0,1,2],[0,2,1],[1,2,0]];function PS(e,t){return t===0?e.x:t===1?e.y:e.z}function FS(e,t,n){t===0?e.x=n:t===1?e.y=n:e.z=n}function IS(e){return Math.max(1e-4,Math.abs(e))}function LS(e,t){return new K(_S/IS(t.x),_S/IS(t.y),_S/IS(t.z))}function RS(e,t,n,r){let i=n.clone().sub(t),a=r.clone().sub(t),o=e.clone().sub(t),s=i.dot(i),c=i.dot(a),l=a.dot(a),u=o.dot(i),d=o.dot(a),f=s*l-c*c;if(Math.abs(f)<=jS)return null;let p=(l*u-c*d)/f,m=(s*d-c*u)/f,h=1-p-m;return h<-1e-6||p<-1e-6||m<-1e-6||h>1.000001||p>1.000001||m>1.000001?null:new K(h,p,m)}function zS(e,t,n){let r=t[0].clone().multiplyScalar(e.x).addScaledVector(t[1],e.y).addScaledVector(t[2],e.z);return r.lengthSq()<=jS*jS?n.clone():r.normalize()}function BS(e){return[e.position.x,e.position.y,e.position.z,e.normal.x,e.normal.y,e.normal.z].every(Number.isFinite)&&e.normal.lengthSq()>jS*jS}function VS(e,t){let n=.005;return[Math.round(e.position.x/t),Math.round(e.position.y/t),Math.round(e.position.z/t),Math.round(e.normal.x/n),Math.round(e.normal.y/n),Math.round(e.normal.z/n)].join(`:`)}function HS(e,t,n,r,i){let a=Math.min(t.x,t.y,t.z),o=Math.max(1e-5,a*1e-4),s=new Map;for(let t of e){if(!BS(t))continue;let e={...t,position:t.position.clone(),normal:t.normal.clone().normalize(),componentId:r,scope:i},n=VS(e,o);s.has(n)||s.set(n,e)}let c=[...s.entries()].sort(([e],[t])=>e.localeCompare(t)).map(([e,t])=>({...t,id:`${i}:${r}:${e}`}));if(c.length<=n)return c;let l=[],u=c.length/n;for(let e=0;e<n;e+=1){let t=c[Math.floor(e*u)];t&&l.push(t)}return l}function US(e,t){return e?e.getX(t):t}function WS(e,t,n,r=MS){let i=typeof r==`number`?{maxAnchors:r}:r,a=i.componentId??`component`,o=i.scope??`component`,s=i.maxAnchors??MS,c=e.getAttribute(`position`);if(!c||c.itemSize<3||c.count<3)return[];e.getAttribute(`normal`)||e.computeVertexNormals();let l=e.getAttribute(`normal`);e.computeBoundingBox();let u=e.boundingBox;if(!u||u.isEmpty())return[];let d=[bS(`x`,u.min.x,u.max.x,n.x),bS(`y`,u.min.y,u.max.y,n.y),bS(`z`,u.min.z,u.max.z,n.z)],f=e=>e.cuts.length===0?[...new Set([...e.coordinates,e.center])].sort((e,t)=>e-t):e.coordinates,p=[f(d[0]),f(d[1]),f(d[2])],m=LS(_S,n),h=e.getIndex(),g=Math.floor((h?h.count:c.count)/3),_=[];for(let e=0;e<g;e+=1){let t=[US(h,e*3),US(h,e*3+1),US(h,e*3+2)],n=[new K().fromBufferAttribute(c,t[0]),new K().fromBufferAttribute(c,t[1]),new K().fromBufferAttribute(c,t[2])],r=n[1].clone().sub(n[0]).cross(n[2].clone().sub(n[0]));if(r.lengthSq()<=jS*jS)continue;r.normalize();let i=e=>{if(!l||l.itemSize<3||e>=l.count)return r.clone();let t=new K().fromBufferAttribute(l,e);return t.lengthSq()>jS*jS?t.normalize():r.clone()},s=[i(t[0]),i(t[1]),i(t[2])];for(let[e,t,i]of NS){let c=PS(r,i);if(Math.abs(c)<=jS)continue;let l=Math.min(...n.map(t=>PS(t,e))),u=Math.max(...n.map(t=>PS(t,e))),d=Math.min(...n.map(e=>PS(e,t))),f=Math.max(...n.map(e=>PS(e,t))),m=p[e].map((e,t)=>({value:e,gridIndex:t})).filter(({value:e})=>e>=l-jS&&e<=u+jS),h=p[t].map((e,t)=>({value:e,gridIndex:t})).filter(({value:e})=>e>=d-jS&&e<=f+jS);for(let l of m)for(let u of h){let d=new K;FS(d,e,l.value),FS(d,t,u.value),FS(d,i,PS(n[0],i)-(PS(r,e)*(l.value-PS(n[0],e))+PS(r,t)*(u.value-PS(n[0],t)))/c);let f=RS(d,n[0],n[1],n[2]);if(!f)continue;let p=[null,null,null];p[e]=l.gridIndex,p[t]=u.gridIndex,_.push({position:d,normal:zS(f,s,r),cutterCoordinates:p,componentId:a,scope:o})}}}return HS(_,m,Math.max(64,s),a,o)}function GS(e,t){let n=new Vr().getNormalMatrix(t);return e.map(e=>({...e,position:e.position.clone().applyMatrix4(t),normal:e.normal.clone().applyMatrix3(n).normalize()})).filter(BS)}function KS(e,t=.004){let n=[];for(let r of e){let e=r.position.clone().addScaledVector(r.normal,t);n.push(e.x,e.y,e.z)}let r=new fn;return r.setAttribute(`position`,new Cn(n,3)),r.computeBoundingBox(),r.computeBoundingSphere(),r}var qS=256,JS=64,YS=new K(1,.371,.613).normalize(),XS=new Map,ZS=new Map;function QS(e){return[e.min.x,e.min.y,e.min.z,e.max.x,e.max.y,e.max.z].every(Number.isFinite)&&!e.isEmpty()}function $S(e){return Number(e.toFixed(6))}function eC(e){return new Pr().compose(new K(...e.position),new Ei().setFromEuler(new _n(...e.rotation)),new K(...e.scale))}function tC(e){return JSON.stringify({id:e.id,type:e.type,geometry:e.geometry,scale:e.scale.map(e=>$S(Math.abs(e))),cutterCellSize:_S})}function nC(e,t,n,r){if(e.set(t,n),e.size<=r)return;let i=e.keys().next().value;i&&e.delete(i)}function rC(e){let t=tC(e),n=XS.get(t);if(n)return XS.delete(t),XS.set(t,n),{localBounds:n.localBounds.clone(),anchors:n.anchors,supportPoints:n.supportPoints};let r=Ur(e);try{r.computeBoundingBox();let n=r.boundingBox?.clone();if(!n||!QS(n))return null;let i=WS(r,_S,new K(...e.scale),{componentId:e.id,scope:`component`}),a=OS(r);return i.length===0||a.length===0?null:(nC(XS,t,{localBounds:n,anchors:i,supportPoints:a},qS),{localBounds:n.clone(),anchors:i,supportPoints:a})}finally{r.dispose()}}function iC(e,t=_S){let n=rC(e);return n?{id:e.id,visible:e.visible,localBounds:n.localBounds,matrixWorld:eC(e),anchors:n.anchors,supportPoints:n.supportPoints,scope:`component`}:null}function aC(e){let t=e.clone(),n=t.index?t.toNonIndexed():t;n!==t&&t.dispose();for(let e of Object.keys(n.attributes))e!==`position`&&n.deleteAttribute(e);return n.clearGroups(),n.computeVertexNormals(),n.computeBoundingBox(),n.computeBoundingSphere(),n}function oC(e){return e.length===0?null:e.length===1?e[0]??null:Ri(e,!1)}function sC(e){return[e.x,e.y,e.z].map(e=>Math.round(e/1e-5)).join(`:`)}function cC(e){let t=e.getAttribute(`position`);if(!t||t.itemSize<3||t.count<3)return!1;let n=new Map;for(let e=0;e+2<t.count;e+=3){let r=[0,1,2].map(n=>new K().fromBufferAttribute(t,e+n));for(let[e,t]of[[0,1],[1,2],[2,0]]){let i=sC(r[e]??new K),a=sC(r[t]??new K),o=i<a?`${i}|${a}`:`${a}|${i}`;n.set(o,(n.get(o)??0)+1)}}return n.size>0&&[...n.values()].every(e=>e%2==0)}function lC(e,t,n){if(!t.bounds.containsPoint(e))return!1;n.set(e,YS),n.near=1e-6,n.far=1/0;let r=n.intersectObject(t.mesh,!1).map(e=>e.distance).filter(e=>e>1e-5).sort((e,t)=>e-t),i=0,a=-1/0;for(let e of r)e-a<=1e-5||(a=e,i+=1);return i%2==1}function uC(e,t){let n=wS(e),r=t.filter(cC);if(r.length<2)return n;let i=new Oa({side:2}),a=r.map(e=>{e.computeBoundingBox();let t=e.boundingBox?.clone()??new Xa().makeEmpty(),n=new G(e,i);return n.updateMatrixWorld(!0),{bounds:t,mesh:n}}),o=a.reduce((e,t)=>e.union(t.bounds),new Xa().makeEmpty()).getSize(new K).length(),s=Math.max(1e-4,o*1e-5),c=new En;try{return n.filter(e=>{let t=e.position.clone().addScaledVector(e.normal,s);return!a.some(e=>lC(t,e,c))})}finally{i.dispose()}}function dC(e,t,n){let r=oC(e);if(!r)return null;try{r.computeBoundingBox();let i=r.boundingBox?.clone();if(!i||!QS(i))return null;let a=uC(WS(r,_S,n,{componentId:t,scope:`composite`,maxAnchors:16384}),e),o=OS(r);return a.length>0&&o.length>0?{localBounds:i,anchors:a,supportPoints:o}:null}finally{r.dispose();for(let t of e)t!==r&&t.dispose()}}function fC(e){let t=new Xa().makeEmpty();for(let n of e){let e=iC(n);e&&t.union(e.localBounds.clone().applyMatrix4(e.matrixWorld))}return QS(t)?t:null}function pC(e,t,n){return JSON.stringify({id:t,cutterCellSize:_S,objects:[...e].sort((e,t)=>e.id.localeCompare(t.id)).map(e=>({id:e.id,type:e.type,geometry:e.geometry,relativePosition:e.position.map((e,t)=>$S(e-n.getComponent(t))),rotation:e.rotation.map($S),scale:e.scale.map($S)}))})}function mC(e,t=`composite`){let n=e.filter(e=>e.visible);if(n.length===0)return null;let r=fC(n);if(!r)return null;let i=r.getCenter(new K),a=pC(n,t,i),o=ZS.get(a),s=null;if(o)ZS.delete(a),ZS.set(a,o),s={localBounds:o.localBounds.clone(),anchors:o.anchors,supportPoints:o.supportPoints};else{let e=[];for(let t of n){let n=Ur(t),r=aC(n);n.dispose();let a=new Pr().compose(new K(t.position[0]-i.x,t.position[1]-i.y,t.position[2]-i.z),new Ei().setFromEuler(new _n(...t.rotation)),new K(...t.scale));r.applyMatrix4(a),r.computeVertexNormals(),e.push(r)}s=dC(e,t,new K(1,1,1)),s&&nC(ZS,a,{localBounds:s.localBounds.clone(),anchors:s.anchors,supportPoints:s.supportPoints},JS)}return s?{id:t,visible:!0,localBounds:s.localBounds,matrixWorld:new Pr().makeTranslation(i.x,i.y,i.z),anchors:s.anchors,supportPoints:s.supportPoints,scope:`composite`}:null}var hC=1e-6;function gC(e,t){return e.localBounds.clone().applyMatrix4(e.matrixWorld).expandByScalar(t)}function _C(e,t){return Math.floor(e/t)}function vC(e,t,n){return`${e}:${t}:${n}`}function yC(e,t){let n=new Map;for(let r of e){let e=vC(_C(r.position.x,t),_C(r.position.y,t),_C(r.position.z,t)),i=n.get(e);i?i.push(r):n.set(e,[r])}return n}function bC(e,t,n){let r=_C(t.x,n),i=_C(t.y,n),a=_C(t.z,n),o=[];for(let t=r-1;t<=r+1;t+=1)for(let n=i-1;n<=i+1;n+=1)for(let r=a-1;r<=a+1;r+=1){let i=e.get(vC(t,n,r));i&&o.push(...i)}return o}function xC(e,t){return e.normal.dot(t.normal)<=-.12}function SC(e,t,n,r=.12){let i={position:[n.x,n.y,n.z],targetId:null,distance:1/0,sourceAnchorId:null,targetAnchorId:null},a=GS(e.anchors,e.matrixWorld),o=gC(e,r),s=null,c=null,l=1/0,u=1/0,d=null,f=null,p=null;for(let n of t){if(n.id===e.id||!n.visible||n.anchors.length===0||!o.intersectsBox(gC(n,r)))continue;let t=yC(GS(n.anchors,n.matrixWorld),r);for(let e of a)for(let i of bC(t,e.position,r)){let t=i.position.clone().sub(e.position),a=t.length();if(a>r+hC||!xC(e,i))continue;let o=e.normal.dot(i.normal),m=a<l-hC,h=Math.abs(a-l)<=hC&&o<u;!m&&!h||(s=t,c=n.id,l=a,u=o,d=e.id??null,f=i.id??null,p=i.normal.clone())}}if(!s||!p)return i;let m=n.clone().add(s);return{position:[m.x,m.y,m.z],targetId:c,distance:l,sourceAnchorId:d,targetAnchorId:f,contactNormal:[p.x,p.y,p.z]}}function CC(e,t,n,r=[]){let i=iC(e);if(!i)return{position:[...e.position],targetId:null,distance:1/0,sourceAnchorId:null,targetAnchorId:null};let a=Math.min(.12,Math.max(.04,Math.abs(n)*.4));return SC(i,[...t.flatMap(e=>{let t=iC(e);return t?[t]:[]}),...r],new K(...e.position),a)}function wC({objects:e,highlighted:t}){let n=(0,Y.useMemo)(()=>mC(e,`selected-composite`),[e]),r=(0,Y.useMemo)(()=>KS(n?GS(n.anchors,n.matrixWorld):[]),[n]);return(0,Y.useEffect)(()=>()=>r.dispose(),[r]),n?(0,Q.jsx)(`points`,{geometry:r,renderOrder:903,raycast:()=>void 0,children:(0,Q.jsx)(`pointsMaterial`,{color:`#EFFF00`,size:t?.045:.034,sizeAttenuation:!0,transparent:!0,opacity:t?.98:.74,depthTest:!0,depthWrite:!1,toneMapped:!1})}):null}function TC({active:e}){let t=Zy(e=>e.camera),n=Zy(e=>e.controls),r=q(e=>e.cameraView);return(0,Y.useEffect)(()=>{if(!e)return;let{objects:i,selectedIds:a}=q.getState(),o=i.filter(e=>a.includes(e.id)),s=o.length>0?o.reduce((e,t)=>e.add(new K(...t.position)),new K).divideScalar(o.length):new K(0,.8,0),c=o.length>0?Math.max(3.5,...o.map(e=>Math.max(...e.scale)*4)):8,l={perspective:[s.x+6,s.y+5,s.z+7],front:[s.x,s.y,s.z+c],back:[s.x,s.y,s.z-c],left:[s.x-c,s.y,s.z],right:[s.x+c,s.y,s.z],top:[s.x,s.y+c,s.z+.001],bottom:[s.x,s.y-c,s.z+.001]},u=r===`focus`?[s.x+c,s.y+c*.65,s.z+c]:l[r]??l.perspective;t.up.set(0,1,0),r===`top`&&t.up.set(0,0,-1),r===`bottom`&&t.up.set(0,0,1),t.position.set(u[0],u[1],u[2]),t.lookAt(s),n?.target.copy(s),n?.update(),t.updateProjectionMatrix()},[e,t,q(e=>e.cameraRequestId),r,n]),null}var EC=new Set([`w`,`a`,`s`,`d`,`q`,`e`]);function DC({active:e}){let t=Zy(e=>e.camera),n=Zy(e=>e.controls),r=(0,Y.useRef)(new Set);return(0,Y.useEffect)(()=>{if(!e){r.current.clear();return}let t=e=>{let t=e.key.toLowerCase();EC.has(t)&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),r.current.add(t))},n=e=>{let t=e.key.toLowerCase();EC.has(t)&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),r.current.delete(t))},i=()=>r.current.clear();return window.addEventListener(`keydown`,t,!0),window.addEventListener(`keyup`,n,!0),window.addEventListener(`blur`,i),()=>{window.removeEventListener(`keydown`,t,!0),window.removeEventListener(`keyup`,n,!0),window.removeEventListener(`blur`,i),r.current.clear()}},[e]),Qy((i,a)=>{if(!e||!n||r.current.size===0)return;let o=new K().subVectors(n.target,t.position);o.y=0,o.lengthSq()<1e-6&&(t.getWorldDirection(o),o.y=0),o.normalize();let s=new K().crossVectors(o,t.up).normalize(),c=new K;r.current.has(`w`)&&c.add(o),r.current.has(`s`)&&c.sub(o),r.current.has(`a`)&&c.sub(s),r.current.has(`d`)&&c.add(s),c.lengthSq()>0&&(c.normalize().multiplyScalar(4.5*a),t.position.add(c),n.target.add(c));let l=Number(r.current.has(`q`))-Number(r.current.has(`e`));if(l!==0){let e=t.position.clone().sub(n.target);e.applyAxisAngle(new K(0,1,0),l*1.6*a),t.position.copy(n.target).add(e)}t.updateMatrixWorld(),n.update()}),null}var OC=1e-6,kC=.12,AC=.12,jC=.16,MC=1e-4,NC=.001,PC=.98,FC=.03;function IC(e){return new Pr().compose(new K(...e.position),new Ei().setFromEuler(new _n(...e.rotation)),new K(...e.scale))}function LC(e,t){return e.rotation.every((e,n)=>Math.abs(e-(t.rotation[n]??e))<=OC)&&e.scale.every((e,n)=>Math.abs(e-(t.scale[n]??e))<=OC)}function RC(e,t){let n=t.find(t=>t.id===e.id);return!n||n.type!==e.type||!LC(e,n)?null:new K(...e.position).sub(new K(...n.position)).lengthSq()>OC*OC?n:null}function zC(e,t){return Math.floor(e/t)}function BC(e,t,n){return`${e}:${t}:${n}`}function VC(e){return[e.x,e.y,e.z].map(e=>e.toFixed(5)).join(`:`)}function HC(e,t){let n=new Map;for(let r of e){let e=BC(zC(r.position.x,t),zC(r.position.y,t),zC(r.position.z,t)),i=n.get(e);i?i.push(r):n.set(e,[r])}return n}function UC(e,t,n){let r=zC(t.min.x,n),i=zC(t.min.y,n),a=zC(t.min.z,n),o=zC(t.max.x,n),s=zC(t.max.y,n),c=zC(t.max.z,n),l=[];for(let t=r;t<=o;t+=1)for(let n=i;n<=s;n+=1)for(let r=a;r<=c;r+=1){let i=e.get(BC(t,n,r));i&&l.push(...i)}return l}function WC(e,t){return e.localBounds.clone().applyMatrix4(e.matrixWorld).expandByScalar(t)}function GC(e){let t=e.localBounds.getSize(new K);return Math.min(Math.abs(t.x),Math.abs(t.y),Math.abs(t.z))<=MC}function KC(e,t,n,r){return[...t.flatMap(t=>{if(t.id===e.id)return[];let r=iC(t,n);return r?[r]:[]}),...r]}function qC(e,t){return!t||e.lateralDistance<t.lateralDistance-OC?!0:Math.abs(e.lateralDistance-t.lateralDistance)>OC?!1:e.travel<t.travel-OC?!0:Math.abs(e.travel-t.travel)>OC?!1:e.normalAlignment<t.normalAlignment}function JC(e,t,n,r,i){return{source:r?n.clone():e.normal,target:i?n.clone().negate():t.normal}}function YC(e,t){if(e.source.dot(e.target)>-.12)return!1;let n=t.dot(e.source),r=t.dot(e.target);return n>=kC&&r<=-.12}function XC(e,t,n,r=[],i={}){let a=RC(e,t);if(!a)return null;let o=iC(e,n);if(!o)return null;let s=GS(o.anchors,IC(a)),c=GS(o.anchors,o.matrixWorld);if(s.length!==c.length)return null;let l=new K(...e.position),u=new K(...a.position),d=l.clone().sub(u),f=d.length();if(f<=OC)return null;let p=d.clone().divideScalar(f),m=kS(o.supportPoints?.length?o.supportPoints:o.anchors.map(e=>e.position),o.matrixWorld),h=new Map,g=Math.min(AC,Math.max(.04,Math.abs(n)*.4)),_=Math.min(jC,Math.max(.07,Math.abs(n)*.55)),v=Math.max(.08,_),y=_+g,b=GC(o),x=WC(o,0),S=KC(e,t,n,r),C=null;for(let e of S){if(!e.visible||e.anchors.length===0)continue;let t=GC(e),n=HC(GS(e.anchors,e.matrixWorld),v),r=WC(e,y),a=x.intersectsBox(WC(e,0));for(let o=0;o<c.length;o+=1){let u=c[o],x=s[o];if(!u||!x)continue;let S=new Xa().setFromPoints([x.position,u.position]).expandByScalar(y);if(S.intersectsBox(r)){S.intersect(r);for(let r of UC(n,S,v)){if(i.ignoredTargetAnchorId&&r.id===i.ignoredTargetAnchorId)continue;let n=JC(u,r,p,b,t);if(!YC(n,p)){if(!a)continue;let t=u.normal.dot(r.normal);if(t<PC)continue;let n=r.position.clone().sub(u.position);if(Math.abs(n.dot(r.normal))>FC)continue;let i=n.dot(p);if(Math.abs(i)>g+OC)continue;let o=i+f;if(Math.abs(o)<=Math.abs(i)+OC)continue;let s=p.clone().multiplyScalar(i),c=r.normal.clone().multiplyScalar(n.dot(r.normal)),d=n.clone().sub(s).sub(c).length();if(d>_+OC)continue;let m=Hi.clamp(o/f,0,1),h=l.clone().addScaledVector(p,i),v={position:[h.x,h.y,h.z],targetId:e.id,distance:Math.abs(i),travel:m,lateralDistance:d,normalAlignment:t,sourceAnchorId:u.id??null,targetAnchorId:r.id??null,contactNormal:[p.x,p.y,p.z]};qC(v,C)&&(C=v);continue}let o=VC(n.target),s=h.get(o);s===void 0&&(s=AS(m,n.target),h.set(o,s));let c=r.position.dot(n.target),v=s-c,y=v-d.dot(n.target);if(v-y>=-1e-6||y<-g-OC||v>g+OC||y<=NC&&v<-g-OC)continue;let x=p.dot(n.target);if(x>=-.12)continue;let S=-v/x,w=u.position.clone().addScaledVector(p,S).sub(r.position),T=n.target.clone().multiplyScalar(w.dot(n.target)),E=w.sub(T).length();if(E>_+OC)continue;let D=y-v,O=D>OC?y/D:1,k=Hi.clamp(O,0,1),A=l.clone().addScaledVector(p,S),j={position:[A.x,A.y,A.z],targetId:e.id,distance:Math.abs(S),travel:k,lateralDistance:E,normalAlignment:n.source.dot(n.target),sourceAnchorId:u.id??null,targetAnchorId:r.id??null,contactNormal:[n.target.x,n.target.y,n.target.z]};qC(j,C)&&(C=j)}}}}return C?{position:C.position,targetId:C.targetId,distance:C.distance,sourceAnchorId:C.sourceAnchorId,targetAnchorId:C.targetAnchorId,contactNormal:C.contactNormal}:null}var ZC=1e-6,QC=.12,$C=.12,ew=.16,tw=1e-4,nw=.001;function rw(e,t){return Math.floor(e/t)}function iw(e,t,n){return`${e}:${t}:${n}`}function aw(e){return[e.x,e.y,e.z].map(e=>e.toFixed(5)).join(`:`)}function ow(e,t){let n=new Map;for(let r of e){let e=iw(rw(r.position.x,t),rw(r.position.y,t),rw(r.position.z,t)),i=n.get(e);i?i.push(r):n.set(e,[r])}return n}function sw(e,t,n){let r=rw(t.min.x,n),i=rw(t.min.y,n),a=rw(t.min.z,n),o=rw(t.max.x,n),s=rw(t.max.y,n),c=rw(t.max.z,n),l=[];for(let t=r;t<=o;t+=1)for(let n=i;n<=s;n+=1)for(let r=a;r<=c;r+=1){let i=e.get(iw(t,n,r));i&&l.push(...i)}return l}function cw(e,t){return e.localBounds.clone().applyMatrix4(e.matrixWorld).expandByScalar(t)}function lw(e){let t=e.localBounds.getSize(new K);return Math.min(Math.abs(t.x),Math.abs(t.y),Math.abs(t.z))<=tw}function uw(e,t){return!t||e.lateralDistance<t.lateralDistance-ZC?!0:Math.abs(e.lateralDistance-t.lateralDistance)>ZC?!1:e.travel<t.travel-ZC?!0:Math.abs(e.travel-t.travel)>ZC?!1:e.normalAlignment<t.normalAlignment}function dw(e,t,n,r,i){return{source:r?n.clone():e.normal,target:i?n.clone().negate():t.normal}}function fw(e,t){return e.source.dot(e.target)>-.12?!1:t.dot(e.source)>=QC&&t.dot(e.target)<=-.12}function pw(e,t,n,r,i={}){if(e.id!==t.id||e.anchors.length===0||e.anchors.length!==t.anchors.length)return null;let a=new K().setFromMatrixPosition(e.matrixWorld),o=new K().setFromMatrixPosition(t.matrixWorld),s=o.clone().sub(a),c=s.length();if(c<=ZC)return null;let l=s.clone().divideScalar(c),u=GS(e.anchors,e.matrixWorld),d=GS(t.anchors,t.matrixWorld),f=kS(t.supportPoints?.length?t.supportPoints:t.anchors.map(e=>e.position),t.matrixWorld),p=new Map,m=Math.min($C,Math.max(.04,Math.abs(r)*.4)),h=Math.min(ew,Math.max(.07,Math.abs(r)*.55)),g=Math.max(.08,h),_=h+m,v=lw(t),y=null;for(let e of n){if(!e.visible||e.id===t.id||e.anchors.length===0)continue;let n=lw(e),r=ow(GS(e.anchors,e.matrixWorld),g),a=cw(e,_);for(let t=0;t<d.length;t+=1){let c=d[t],b=u[t];if(!c||!b)continue;let x=new Xa().setFromPoints([b.position,c.position]).expandByScalar(_);if(x.intersectsBox(a)){x.intersect(a);for(let t of sw(r,x,g)){if(i.ignoredTargetAnchorId&&t.id===i.ignoredTargetAnchorId)continue;let r=dw(c,t,l,v,n);if(!fw(r,l))continue;let a=aw(r.target),u=p.get(a);u===void 0&&(u=AS(f,r.target),p.set(a,u));let d=t.position.dot(r.target),g=u-d,_=g-s.dot(r.target);if(g-_>=-1e-6||_<-m-ZC||g>m+ZC||_<=nw&&g<-m-ZC)continue;let b=l.dot(r.target);if(b>=-.12)continue;let x=-g/b,S=c.position.clone().addScaledVector(l,x).sub(t.position),C=r.target.clone().multiplyScalar(S.dot(r.target)),w=S.sub(C).length();if(w>h+ZC)continue;let T=_-g,E=T>ZC?_/T:1,D=Hi.clamp(E,0,1),O=o.clone().addScaledVector(l,x),k={position:[O.x,O.y,O.z],targetId:e.id,distance:Math.abs(x),travel:D,lateralDistance:w,normalAlignment:r.source.dot(r.target),sourceAnchorId:c.id??null,targetAnchorId:t.id??null,contactNormal:[r.target.x,r.target.y,r.target.z]};uw(k,y)&&(y=k)}}}}return y?{position:y.position,targetId:y.targetId,distance:y.distance,sourceAnchorId:y.sourceAnchorId,targetAnchorId:y.targetAnchorId,contactNormal:y.contactNormal}:null}var mw=.14,hw=.12;function gw(){return{active:null,previousCompositeTarget:null}}function _w(e,t){return Math.hypot(e[0]-t[0],e[1]-t[1],e[2]-t[2])}function vw(e){return{position:[...e],targetId:null,distance:1/0,sourceAnchorId:null,targetAnchorId:null,contactNormal:null}}function yw(e,t,n){return{result:{position:t,targetId:e.targetId,distance:0,sourceAnchorId:e.sourceAnchorId,targetAnchorId:e.targetAnchorId,contactNormal:e.normal},session:{active:e,previousCompositeTarget:n}}}function bw(e,t){let n=t.active;if(n?.normal){let r=new K(...n.normal),i=new K(...e).sub(new K(...n.captureRawPosition)),a=i.dot(r),o=i.clone().addScaledVector(r,-a);if(Math.abs(a)<=mw&&o.length()<=mw){let e=new K(...n.acceptedPosition).add(o);return{held:yw(n,[e.x,e.y,e.z],t.previousCompositeTarget),active:n}}return{held:null,active:null}}return n&&_w(e,n.captureRawPosition)<=mw?{held:yw(n,[...n.acceptedPosition],t.previousCompositeTarget),active:n}:{held:null,active:null}}function xw(e,t,n,r){return e?.targetId?{result:e,session:{active:{targetId:e.targetId,targetAnchorId:e.targetAnchorId??null,sourceAnchorId:e.sourceAnchorId??null,captureRawPosition:[...t],acceptedPosition:[...e.position],normal:e.contactNormal??null},previousCompositeTarget:r}}:{result:vw(n),session:{active:null,previousCompositeTarget:r}}}function Sw(e,t){let n=e.matrixWorld.clone();return n.setPosition(t[0],t[1],t[2]),{...e,matrixWorld:n}}function Cw(e){let t=Math.max(1e-4,Math.abs(e));return t>hw?{positionStep:t,worldThreshold:Math.min(hw,Math.max(.04,t*.4))}:{positionStep:Math.max(.1,t/.4),worldThreshold:t}}function ww(e,t,n,r,i,a=[]){let o=bw(r,i);return o.held?o.held:xw(XC(e,t,n,a),r,e.position,null)}function Tw(e,t,n,r,i=hw){let a=bw(n,r);if(a.held)return a.held;let o=new K().setFromMatrixPosition(e.matrixWorld),s=Cw(i),c=(r.previousCompositeTarget?pw(r.previousCompositeTarget,e,t,s.positionStep):null)??SC(e,t,o,s.worldThreshold),l=c.targetId?c:null,u=l?.position??[o.x,o.y,o.z];return xw(l,n,u,Sw(e,u))}var Ew=1e-6;function Dw(e,t,n,r=.02){let i=Math.abs(t);if(!Number.isFinite(e)||!Number.isFinite(i)||!Number.isFinite(n)||i<=Ew||n<=Ew)return Math.max(r,e);let a=i*e,o=Math.round(a/n)*n;return Math.max(r,o/i)}function Ow(e,t,n,r=.02){let i=t.reduce((e,t)=>Number.isFinite(t)?Math.max(e,Math.abs(t)):e,0);if(!Number.isFinite(e)||!Number.isFinite(n)||i<=Ew||n<=Ew)return Math.max(r,e);let a=Math.round(i*e/n)*n;return Math.max(r,a/i)}function kw({selectedIds:e,registry:t,tool:n,snap:r,onSnapTargetChange:i,onTransformDraggingChange:a}){let o=(0,Y.useMemo)(()=>new ke,[]),s=(0,Y.useRef)(null),c=q(e=>e.updateObject),l=q(e=>e.beginTransaction),u=q(e=>e.endTransaction),d=e.join(`:`),f=(0,Y.useCallback)(()=>{let n=e.map(e=>t.current.get(e)).filter(e=>!!e);if(n.length===0)return;let r=n.reduce((e,t)=>e.add(t.getWorldPosition(new K)),new K).divideScalar(n.length);o.position.copy(r),o.rotation.set(0,0,0),o.scale.set(1,1,1),o.updateMatrixWorld(!0)},[o,t,e]);return(0,Y.useEffect)(()=>f(),[f,d]),(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`primitive`,{object:o}),(0,Q.jsx)(lS,{object:o,mode:n,space:`world`,size:n===`rotate`?1.4:1.15,translationSnap:n===`translate`?void 0:r.enabled?r.position:void 0,rotationSnap:r.enabled?Hi.degToRad(r.rotation):void 0,scaleSnap:void 0,onMouseDown:()=>{f();let n=new Map,r=new Xa().makeEmpty();for(let i of e){let e=t.current.get(i);e&&(e.updateMatrixWorld(!0),n.set(i,e.matrixWorld.clone()),r.expandByObject(e,!0))}o.updateMatrixWorld(!0),s.current={proxyMatrix:o.matrixWorld.clone(),objectMatrices:n,groupWorldSize:r.isEmpty()?new K(1,1,1):r.getSize(new K),surfaceSnapSession:gw()},i(null),l(),a(!0)},onObjectChange:()=>{let a=s.current;if(!a)return;o.updateMatrixWorld(!0);let l=o.position.clone(),u=l.clone();n===`translate`&&r.enabled&&r.position>0&&u.set(Math.round(u.x/r.position)*r.position,Math.round(u.y/r.position)*r.position,Math.round(u.z/r.position)*r.position);let d=o.scale.clone();if(n===`scale`&&r.enabled&&r.scale>0){let e=(e,t)=>Math.abs(e-1)<=1e-6?1:Dw(e,t,r.scale);d.set(e(o.scale.x,a.groupWorldSize.x),e(o.scale.y,a.groupWorldSize.y),e(o.scale.z,a.groupWorldSize.z)),o.scale.copy(d),o.updateMatrixWorld(!0)}let f=new Pr().compose(u,o.quaternion,d).multiply(a.proxyMatrix.clone().invert()),p=q.getState().objects,m=new Map;for(let[e,n]of a.objectMatrices){let r=t.current.get(e),i=p.find(t=>t.id===e);if(!r||!i)continue;let a=f.clone().multiply(n);(r.parent?r.parent.matrixWorld.clone().invert().multiply(a):a).decompose(r.position,r.quaternion,r.scale),r.updateMatrixWorld(!0),m.set(e,{...i,position:[r.position.x,r.position.y,r.position.z],rotation:[r.rotation.x,r.rotation.y,r.rotation.z],scale:[r.scale.x,r.scale.y,r.scale.z]})}if(n===`translate`&&r.surface&&m.size>1){let n=mC(e.flatMap(e=>{let t=m.get(e);return t?[t]:[]}),`selected-composite`),s=p.filter(t=>t.visible&&!e.includes(t.id)).flatMap(e=>{let t=iC(e);return t?[t]:[]});if(n){let e=Tw(n,s,[l.x,l.y,l.z],a.surfaceSnapSession,Math.min(.12,Math.max(.04,Math.abs(r.position)*.4)));a.surfaceSnapSession=e.session;let c=new K().setFromMatrixPosition(n.matrixWorld),d=new K(...e.result.position).sub(c);if(d.lengthSq()>1e-10)for(let[e,n]of m){let r=t.current.get(e);r&&(r.position.add(d),r.updateMatrixWorld(!0),m.set(e,{...n,position:[r.position.x,r.position.y,r.position.z]}))}o.position.copy(u).add(d),o.updateMatrixWorld(!0),i(e.result.targetId)}else a.surfaceSnapSession=gw(),o.position.copy(u),o.updateMatrixWorld(!0),i(null)}else a.surfaceSnapSession=gw(),n===`translate`&&(o.position.copy(u),o.updateMatrixWorld(!0)),i(null);for(let[e,t]of m)c(e,{position:t.position,rotation:t.rotation,scale:t.scale},!1)},onMouseUp:()=>{s.current=null,i(null),u(),a(!1),f()}})]})}function Aw({registry:e,onReady:t}){let n=Zy(e=>e.camera),r=Zy(e=>e.gl);return(0,Y.useEffect)(()=>{t({idsInRect:t=>{let i=r.domElement.getBoundingClientRect(),a=[];for(let[r,o]of e.current){if(!o.visible)continue;o.updateMatrixWorld(!0);let e=new Xa().setFromObject(o);if(e.isEmpty())continue;let s=[new K(e.min.x,e.min.y,e.min.z),new K(e.min.x,e.min.y,e.max.z),new K(e.min.x,e.max.y,e.min.z),new K(e.min.x,e.max.y,e.max.z),new K(e.max.x,e.min.y,e.min.z),new K(e.max.x,e.min.y,e.max.z),new K(e.max.x,e.max.y,e.min.z),new K(e.max.x,e.max.y,e.max.z)],c=1/0,l=1/0,u=-1/0,d=-1/0;for(let e of s){let t=e.project(n),r=i.left+(t.x+1)*i.width*.5,a=i.top+(1-t.y)*i.height*.5;c=Math.min(c,r),l=Math.min(l,a),u=Math.max(u,r),d=Math.max(d,a)}u>=t.left&&c<=t.right&&d>=t.top&&l<=t.bottom&&a.push(r)}return a}})},[n,r,t,e]),null}var jw=1e-6;function Mw(e,t){return e.every((e,n)=>Math.abs(e-(t[n]??e))<=jw)}function Nw(e,t){return Mw(e.rotation,t.rotation)&&Mw(e.scale,t.scale)}function Pw(e){return{position:[...e.position],targetId:null,distance:1/0,sourceAnchorId:null,targetAnchorId:null}}function Fw(e,t,n,r=[]){let i=t.find(t=>t.id===e.id);return i&&Nw(e,i)?Mw(e.position,i.position)?Pw(e):XC(e,t,n,r)??Pw(e):CC(e,t.filter(t=>t.id!==e.id),n,r)}function Iw(e,t,n,r=[]){return Fw(e,t,n,r)}var Lw=e=>!0,Rw=1.25,zw=3.75,Bw=1.5,Vw=new WeakMap;function Hw(e){return!Number.isFinite(e)||e<=0?1:Hi.clamp(e,1,Bw)}function Uw(e){let t=Number.isFinite(e)?Math.max(0,e):10;return Hi.clamp(Rw+1.5/(t+.5),Rw,zw)}function Ww(){return Hw(window.devicePixelRatio||1)}function Gw(e,t){Math.abs(e.getPixelRatio()-t)<.001||e.setPixelRatio(t)}function Kw(e,t){e.zoomSpeed=t}function qw(e,t){e.zoomSpeed=t,e.zoomToCursor=!0,e.minDistance=.08,e.maxDistance=500,e.dampingFactor=.1}function Jw(e){e.controls.zoomSpeed=e.previousZoomSpeed,e.controls.zoomToCursor=e.previousZoomToCursor,e.controls.minDistance=e.previousMinDistance,e.controls.maxDistance=e.previousMaxDistance,e.controls.dampingFactor=e.previousDampingFactor}function Yw(e,t){e.shadowMap.autoUpdate=t,e.shadowMap.needsUpdate=!0}function Xw(e){e.shadowMap.needsUpdate=!0}function Zw(e,t){let n=Zy(e=>e.gl),r=Zy(e=>e.scene),i=Zy(e=>e.camera),a=Zy(e=>e.controls),o=e.material.opacity,s=e.material.paintTexture?.dataUrl,[c,l,u]=e.position,[d,f,p]=e.rotation,[m,h,g]=e.scale,_=e.visible;(0,Y.useEffect)(()=>{if(!a)return;let e=Vw.get(r);if(!e){let t=n.getPixelRatio(),o=n.shadowMap.autoUpdate,s=a.zoomSpeed,c=a.zoomToCursor,l=a.minDistance,u=a.maxDistance,d=a.dampingFactor,f=()=>{Kw(a,Uw(i.position.distanceTo(a.target)))};e={references:0,gl:n,controls:a,previousPixelRatio:t,previousShadowAutoUpdate:o,previousZoomSpeed:s,previousZoomToCursor:c,previousMinDistance:l,previousMaxDistance:u,previousDampingFactor:d,handleWheel:f},Vw.set(r,e),qw(a,Uw(i.position.distanceTo(a.target))),n.domElement.addEventListener(`wheel`,f,{capture:!0,passive:!0}),Gw(n,Ww()),Yw(n,!1)}return e.references+=1,()=>{let e=Vw.get(r);e&&(--e.references,!(e.references>0)&&(e.gl.domElement.removeEventListener(`wheel`,e.handleWheel,!0),Jw(e),Yw(e.gl,e.previousShadowAutoUpdate),Gw(e.gl,e.previousPixelRatio),Vw.delete(r)))}},[i,a,n,r]),(0,Y.useEffect)(()=>{Xw(n)},[t,n,o,_,s,c,l,u,d,f,p,m,h,g])}var Qw=`#00E5FF`,$w=`rgba(3, 20, 27, 0.9)`,eT=`300 36px Inter, system-ui, sans-serif`,tT=256,nT=96,rT=2.35;function iT(e,t,n){let r=e*n,i=t*n;return r<=i?[r,i]:[i,r]}function aT(e,t){e.computeBoundingBox();let n=e.boundingBox?.clone()??new Xa(new K(-.5,-.5,-.5),new K(.5,.5,.5)),[r,i]=iT(n.min.x,n.max.x,t[0]),[a,o]=iT(n.min.y,n.max.y,t[1]),[s,c]=iT(n.min.z,n.max.z,t[2]),l=Math.max(0,i-r),u=Math.max(0,o-a),d=Math.max(0,c-s),f=Math.max(l,u,d,.1),p=Math.max(l,u,d,.001);return{min:new K(r,a,s),max:new K(i,o,c),length:l,height:u,depth:d,offset:Math.max(.12,f*.08),labelLift:Math.max(.055,f*.025),labelWidth:p*.34,labelHeight:p*.12,dashSize:Hi.clamp(f*.025,.035,.2),gapSize:Hi.clamp(f*.018,.025,.14)}}function oT(e){let t=Number(e.toFixed(3));return Number.isInteger(t)?t.toFixed(0):String(t)}function sT(e,t,n,r,i,a){let o=Math.min(a,r*.5,i*.5);e.beginPath(),e.moveTo(t+o,n),e.lineTo(t+r-o,n),e.quadraticCurveTo(t+r,n,t+r,n+o),e.lineTo(t+r,n+i-o),e.quadraticCurveTo(t+r,n+i,t+r-o,n+i),e.lineTo(t+o,n+i),e.quadraticCurveTo(t,n+i,t,n+i-o),e.lineTo(t,n+o),e.quadraticCurveTo(t,n,t+o,n),e.closePath()}function cT(e,t,n){let r=e.getImageData(0,0,t,n).data,i=t,a=n,o=-1,s=-1;for(let e=0;e<n;e+=1)for(let n=0;n<t;n+=1)r[(e*t+n)*4+3]!==0&&(i=Math.min(i,n),a=Math.min(a,e),o=Math.max(o,n),s=Math.max(s,e));return o>=i&&s>=a?{minX:i,minY:a,maxX:o,maxY:s}:null}function lT(e){let t=document.createElement(`canvas`),n=t.getContext(`2d`);if(!n)throw Error(`2D-Kontext für Maßbeschriftung nicht verfügbar.`);n.font=eT,t.width=Math.max(96,Math.ceil(n.measureText(e).width)+64),t.height=96;let r=t.getContext(`2d`);if(!r)throw Error(`2D-Kontext für Maßbeschriftung nicht verfügbar.`);r.clearRect(0,0,t.width,t.height),r.fillStyle=`#C9FBFF`,r.font=eT,r.textAlign=`left`,r.textBaseline=`alphabetic`,r.fillText(e,32,64);let i=cT(r,t.width,t.height);if(!i)throw Error(`Maßbeschriftung konnte nicht gerendert werden.`);return{canvas:t,bounds:i}}function uT(e,t,n,r){let i=lT(e),a=i.bounds.maxX-i.bounds.minX+1,o=i.bounds.maxY-i.bounds.minY+1,s=document.createElement(`canvas`);s.height=o+20,s.width=Math.max(a+20,Math.ceil(s.height*rT));let c=s.getContext(`2d`);if(!c)throw Error(`2D-Kontext für Maßbeschriftung nicht verfügbar.`);c.clearRect(0,0,s.width,s.height),sT(c,1,1,s.width-2,s.height-2,8),c.fillStyle=$w,c.fill(),c.lineWidth=2,c.strokeStyle=Qw,c.stroke();let l=Math.round((s.width-a)*.5),u=Math.round((s.height-o)*.5);c.drawImage(i.canvas,i.bounds.minX,i.bounds.minY,a,o,l,u,a,o);let d=new vn(s);d.colorSpace=di,d.minFilter=xn,d.magFilter=xn,d.generateMipmaps=!1,d.needsUpdate=!0;let f=new Zr({map:d,transparent:!0,depthTest:!1,depthWrite:!1});f.toneMapped=!1;let p=new h(f);return p.position.copy(t),p.scale.set(n*(s.width/tT),r*(s.height/nT),1),p.renderOrder=2001,p.frustumCulled=!1,p.raycast=()=>void 0,{sprite:p,dispose:()=>{f.dispose(),d.dispose()}}}function dT(e,t,n,r){let i=new fn().setFromPoints([e,t]),a=new qi({color:Qw,transparent:!0,opacity:.98,dashSize:n,gapSize:r,depthTest:!1,depthWrite:!1});a.toneMapped=!1;let o=new W(i,a);return o.computeLineDistances(),o.renderOrder=2e3,o.frustumCulled=!1,o.raycast=()=>void 0,{line:o,dispose:()=>{i.dispose(),a.dispose()}}}function fT(e){let{min:t,max:n,offset:r}=e,i=(t.x+n.x)*.5,a=(t.y+n.y)*.5,o=(t.z+n.z)*.5;return[{value:e.length,start:new K(t.x,n.y+r,n.z+r),end:new K(n.x,n.y+r,n.z+r),label:new K(i,n.y+r,n.z+r)},{value:e.height,start:new K(n.x+r,t.y,n.z+r),end:new K(n.x+r,n.y,n.z+r),label:new K(n.x+r,a,n.z+r)},{value:e.depth,start:new K(n.x+r,n.y+r,t.z),end:new K(n.x+r,n.y+r,n.z),label:new K(n.x+r,n.y+r,o)}]}function pT(e,t){let n=Zy(e=>e.scene),r=Fv();(0,Y.useEffect)(()=>{if(!r||!e.visible)return;let i=aT(t,e.scale),a=new Pi,o=[];return a.name=`Maße: ${e.name}`,a.position.set(e.position[0],e.position[1],e.position[2]),a.rotation.set(e.rotation[0],e.rotation[1],e.rotation[2]),a.renderOrder=2e3,fT(i).forEach(e=>{let t=dT(e.start,e.end,i.dashSize,i.gapSize),n=uT(oT(e.value),e.label,i.labelWidth,i.labelHeight);a.add(t.line,n.sprite),o.push(t.dispose,n.dispose)}),n.add(a),()=>{n.remove(a),o.forEach(e=>e()),a.clear()}},[t,e.name,e.position[0],e.position[1],e.position[2],e.rotation[0],e.rotation[1],e.rotation[2],e.scale[0],e.scale[1],e.scale[2],e.visible,n,r])}function mT(e){return e instanceof mr}function hT(e){return Array.isArray(e)?e.filter(mT):mT(e)?[e]:[]}function gT(e,t,n){let r=Zy(e=>e.scene);(0,Y.useEffect)(()=>{let i=r.getObjectByProperty(`geometry`,t);if(!(i instanceof G))return;let a=i,o=Hi.clamp(e.material.opacity,0,1),s=Hi.clamp(e.material.roughness,0,1),c=Hi.clamp(e.material.metalness,0,1),l=o<.999,u=a.material;hT(u).forEach(t=>{t instanceof ae&&(t.map=n,t.color.set(n?`#FFFFFF`:e.material.color),t.roughness=s,t.metalness=c,t.opacity=o,t.transparent=l,t.depthWrite=!l,t.alphaTest=n?.001:0,t.flatShading=e.material.flatShading,t.envMapIntensity=1,t.needsUpdate=!0)}),a.castShadow=!l,a.receiveShadow=o>0},[t,e.material.color,e.material.flatShading,e.material.metalness,e.material.opacity,e.material.roughness,r,n])}var _T=`
  varying vec3 vLocalPosition;
  varying vec3 vLocalNormal;

  void main() {
    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
    vLocalPosition = position;
    vLocalNormal = normalize(normal);
    gl_Position = projectionMatrix * viewMatrix * worldPosition;
  }
`,vT=`
  uniform vec3 uColor;
  uniform vec3 uBoundsMin;
  uniform vec3 uBoundsMax;
  uniform vec3 uObjectScale;
  uniform float uCellSize;
  uniform float uGridOffset;
  uniform float uOpacity;

  varying vec3 vLocalPosition;
  varying vec3 vLocalNormal;

  float gridLine(float value) {
    float fraction = fract(value);
    float distanceToLine = min(fraction, 1.0 - fraction);
    return 1.0 - smoothstep(0.006, 0.022, distanceToLine);
  }

  float edgeLine(float value, float extent) {
    float distanceToEdge = min(abs(value), abs(extent - value));
    return 1.0 - smoothstep(0.006, 0.022, distanceToEdge);
  }

  void main() {
    float safeCellSize = max(uCellSize, 0.0001);
    vec3 center = (uBoundsMin + uBoundsMax) * 0.5;

    vec3 centeredCoordinates = ((vLocalPosition - center) * uObjectScale) / safeCellSize;
    vec3 edgeCoordinates = ((vLocalPosition - uBoundsMin) * uObjectScale) / safeCellSize;
    vec3 extents = ((uBoundsMax - uBoundsMin) * uObjectScale) / safeCellSize;
    vec3 axisLines = max(
      vec3(
        gridLine(centeredCoordinates.x - uGridOffset),
        gridLine(centeredCoordinates.y - uGridOffset),
        gridLine(centeredCoordinates.z - uGridOffset)
      ),
      vec3(
        edgeLine(edgeCoordinates.x, extents.x),
        edgeLine(edgeCoordinates.y, extents.y),
        edgeLine(edgeCoordinates.z, extents.z)
      )
    );

    // Rasterachsen und Position liegen im lokalen Raum; daher muss auch die
    // Flächengewichtung lokal bleiben. Rotation und nicht-uniforme Skalierung
    // dürfen nicht auf eine andere Rasterachse umschalten.
    vec3 normalWeight = pow(abs(normalize(vLocalNormal)), vec3(8.0));
    normalWeight /= max(normalWeight.x + normalWeight.y + normalWeight.z, 0.0001);

    float onXFace = max(axisLines.y, axisLines.z);
    float onYFace = max(axisLines.x, axisLines.z);
    float onZFace = max(axisLines.x, axisLines.y);
    float pattern = dot(vec3(onXFace, onYFace, onZFace), normalWeight);
    float alpha = pattern * uOpacity;

    if (alpha < 0.012) discard;
    gl_FragColor = vec4(uColor, alpha);
  }
`;function yT({geometry:e,object:t,cellSize:n,highlighted:r}){let i=q(e=>e.tool)===`translate`,a=t.scale[0],o=t.scale[1],s=t.scale[2],c=(0,Y.useMemo)(()=>new K(a,o,s),[a,o,s]),l=(0,Y.useMemo)(()=>(e.computeBoundingBox(),e.boundingBox?.clone()??new Xa(new K(-.5,-.5,-.5),new K(.5,.5,.5))),[e]),u=(0,Y.useMemo)(()=>WS(e,_S,c,{componentId:t.id,scope:`component`}),[e,t.id,c]),d=(0,Y.useMemo)(()=>KS(u),[u]);(0,Y.useEffect)(()=>()=>d.dispose(),[d]);let f=i?_S*.5:_S,p=i?0:.5,m=(0,Y.useMemo)(()=>({uColor:{value:new Ai(`#EFFF00`)},uBoundsMin:{value:l.min.clone()},uBoundsMax:{value:l.max.clone()},uObjectScale:{value:new K(Math.max(1e-4,Math.abs(a)),Math.max(1e-4,Math.abs(o)),Math.max(1e-4,Math.abs(s)))},uCellSize:{value:f},uGridOffset:{value:p},uOpacity:{value:r?.46:.16}}),[l,r,a,o,s,f,p]),h=Math.min(.075,Math.max(.025,_S*.12));return(0,Q.jsxs)(`group`,{position:t.position,rotation:t.rotation,scale:t.scale,visible:t.visible,children:[(0,Q.jsx)(`mesh`,{geometry:e,renderOrder:900,raycast:()=>void 0,children:(0,Q.jsx)(`shaderMaterial`,{uniforms:m,vertexShader:_T,fragmentShader:vT,transparent:!0,depthTest:!0,depthWrite:!1,side:2,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2})}),!i&&(0,Q.jsx)(`points`,{geometry:d,renderOrder:901,raycast:()=>void 0,children:(0,Q.jsx)(`pointsMaterial`,{color:`#EFFF00`,size:r?h*1.35:h,sizeAttenuation:!0,transparent:!0,opacity:r?.96:.62,depthTest:!0,depthWrite:!1,toneMapped:!1})})]})}var bT=e=>Math.abs(e.x)>1e-6?e.x:Math.abs(e.y)>1e-6?e.y:e.z,xT=(e,t)=>{let n=e.dot(t);return Math.abs(n)>.99?!1:n>1e-6?!0:n<-1e-6?!1:bT(e)>0},ST=.06,CT=.11,wT=.28,TT=1.16,ET=1.55,DT=1.15,OT=new Ua(.0075,.0075,.5,3);OT.translate(0,.25,0);var kT=new Ua(0,.04,.1,12);kT.translate(0,.05,0);var AT=new Ua(.2,0,.6,4),jT=new K,MT=new K,NT=new K,PT=new Ei,FT=[[-1,-1,-1],[-1,-1,1],[-1,1,-1],[-1,1,1],[1,-1,-1],[1,-1,1],[1,1,-1],[1,1,1]],IT=(e,t)=>t===`X`?e.x:t===`Y`?e.y:e.z,LT=(e,t,n)=>{t===`X`?e.x=n:t===`Y`?e.y=n:e.z=n},RT=(e,t)=>e===`X`?new K(t,0,0):e===`Y`?new K(0,t,0):new K(0,0,t),zT=(e,t,n)=>IT(n===`min`?e.min:e.max,t),BT=(e,t)=>new K(t[0]===1?e.max.x:e.min.x,t[1]===1?e.max.y:e.min.y,t[2]===1?e.max.z:e.min.z),VT=(e,t)=>{let n=t.getSize(new K),r=(Math.abs(n.x*e.scale.x)+Math.abs(n.y*e.scale.y)+Math.abs(n.z*e.scale.z))/3;return Math.max(1e-4,r*ST)},HT=(e,t)=>{let n,r=e;if(r.isOrthographicCamera)n=(r.top-r.bottom)/r.zoom;else{let r=e;n=t.distanceTo(e.position)*Math.min(1.9*Math.tan(Math.PI*r.fov/360)/r.zoom,7)}return n*DT/4},UT=(e,t,n)=>e.isOrthographicCamera?e.getWorldDirection(n).negate():n.copy(e.position).sub(t).normalize();function WT({mesh:e,bounds:t,axis:n,side:r,color:i,onPointerDown:a}){let o=(0,Y.useRef)(null),s=Zy(e=>e.camera),c=(0,Y.useMemo)(()=>new Ei().setFromUnitVectors(new K(0,1,0),RT(n,r)),[n,r]);return Qy(()=>{let i=o.current;if(!i)return;e.updateMatrixWorld();let a=t.getCenter(new K);LT(a,n,zT(t,n,r===1?`max`:`min`)),i.position.copy(e.localToWorld(a)),i.quaternion.copy(e.quaternion),i.scale.setScalar(HT(s,i.position)),e.getWorldQuaternion(PT),MT.copy(RT(n,r)).applyQuaternion(PT),t.getCenter(NT),e.localToWorld(NT),UT(s,NT,jT),i.visible=xT(MT,jT)}),(0,Q.jsx)(`group`,{ref:o,renderOrder:1e3,children:(0,Q.jsxs)(`group`,{quaternion:c,children:[(0,Q.jsx)(`mesh`,{geometry:OT,renderOrder:1e3,children:(0,Q.jsx)(`meshBasicMaterial`,{color:i,transparent:!0,opacity:1,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})}),(0,Q.jsx)(`mesh`,{geometry:kT,position:[0,.5,0],renderOrder:1e3,children:(0,Q.jsx)(`meshBasicMaterial`,{color:i,transparent:!0,opacity:1,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})}),(0,Q.jsx)(`mesh`,{geometry:AT,position:[0,.3,0],renderOrder:1e3,onPointerDown:e=>a(n,r,e),children:(0,Q.jsx)(`meshBasicMaterial`,{transparent:!0,opacity:0,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})})]})})}function GT({mesh:e,bounds:t,color:n,onPointerDown:r}){let i=(0,Y.useRef)(null);return Qy(()=>{let n=i.current;if(!n)return;e.updateMatrixWorld(!0);let r=t.getCenter(new K);n.position.copy(e.localToWorld(r)),n.quaternion.identity(),n.scale.setScalar(VT(e,t)/.2)}),(0,Q.jsxs)(`group`,{ref:i,renderOrder:1/0,children:[(0,Q.jsxs)(`mesh`,{renderOrder:1/0,children:[(0,Q.jsx)(`octahedronGeometry`,{args:[CT,0]}),(0,Q.jsx)(`meshBasicMaterial`,{color:n,transparent:!0,opacity:1,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})]}),(0,Q.jsxs)(`mesh`,{renderOrder:1/0,onPointerDown:r,children:[(0,Q.jsx)(`octahedronGeometry`,{args:[wT,0]}),(0,Q.jsx)(`meshBasicMaterial`,{color:n,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})]})]})}function KT({mesh:e,bounds:t,sides:n,onPointerDown:r}){let i=(0,Y.useRef)(null),a=Zy(e=>e.camera);return Qy(()=>{let r=i.current;if(!r)return;e.updateMatrixWorld();let o=BT(t,n);r.position.copy(e.localToWorld(o)),r.quaternion.copy(a.quaternion),r.scale.setScalar(VT(e,t))}),(0,Q.jsxs)(`group`,{ref:i,renderOrder:1001,children:[(0,Q.jsxs)(`mesh`,{renderOrder:1001,children:[(0,Q.jsx)(`planeGeometry`,{args:[TT,TT]}),(0,Q.jsx)(`meshBasicMaterial`,{color:`#ffff00`,transparent:!0,opacity:.48,side:2,depthTest:!1,depthWrite:!1,toneMapped:!1})]}),(0,Q.jsxs)(`mesh`,{renderOrder:1002,onPointerDown:e=>r(n,e),children:[(0,Q.jsx)(`planeGeometry`,{args:[ET,ET]}),(0,Q.jsx)(`meshBasicMaterial`,{transparent:!0,opacity:0,side:2,depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1})]})]})}function qT({mesh:e,geometry:t,object:n,snap:r,onSnapTargetChange:i,onTransformDraggingChange:a}){let o=Zy(e=>e.camera),s=Zy(e=>e.size),c=Zy(e=>e.controls),l=q(e=>e.objects),u=(0,Y.useRef)(null),d=q(e=>e.updateObject),f=q(e=>e.beginTransaction),p=q(e=>e.endTransaction),m=(0,Y.useMemo)(()=>(t.computeBoundingBox(),t.boundingBox?.clone()??new Xa(new K(-.5,-.5,-.5),new K(.5,.5,.5))),[t]),h=(0,Y.useMemo)(()=>m.getSize(new K),[m]),g=()=>{window.removeEventListener(`pointermove`,b,!0),window.removeEventListener(`pointerup`,x,!0),window.removeEventListener(`pointercancel`,x,!0),window.removeEventListener(`blur`,x,!0)},_=()=>{d(n.id,{position:[e.position.x,e.position.y,e.position.z],rotation:[e.rotation.x,e.rotation.y,e.rotation.z],scale:[e.scale.x,e.scale.y,e.scale.z]},!1)},v=e=>[Math.abs(h.x*e.x),Math.abs(h.y*e.y),Math.abs(h.z*e.z)],y=t=>{if(t.kind===`center`){i(null);return}if(!r.surface||!Lw(n.type)){i(null);return}let a=Iw({...n,position:[e.position.x,e.position.y,e.position.z],rotation:[e.rotation.x,e.rotation.y,e.rotation.z],scale:[e.scale.x,e.scale.y,e.scale.z]},l,r.position);if(!a.targetId){i(null);return}let o=new K(...a.position).sub(e.position),s=o.length();if(s<=1e-6){i(a.targetId);return}if(t.kind===`axis`){let n=t.worldAxis.clone().multiplyScalar(t.side),r=o.dot(n);if(Math.abs(r)/s<.7){i(null);return}let c=IT(t.startScale,t.axis),l=IT(e.scale,t.axis),u=Math.max(.02,l+r/t.localSize);LT(e.scale,t.axis,u);let d=t.anchorCoordinate*(c-u);e.position.copy(t.startPosition).addScaledVector(t.worldAxis,d),e.updateMatrixWorld(!0),i(a.targetId);return}let c=o.dot(t.worldDirection);if(Math.abs(c)/s<.35){i(null);return}let u=[Math.abs(t.startScale.x)>1e-6?e.scale.x/t.startScale.x:1,Math.abs(t.startScale.y)>1e-6?e.scale.y/t.startScale.y:1,Math.abs(t.startScale.z)>1e-6?e.scale.z/t.startScale.z:1],d=u.reduce((e,t)=>e+t,0)/u.length,f=Math.max(.02,d+c/t.startDiagonalWorld),p=t.startScale.clone().multiplyScalar(f);e.scale.copy(p);let m=new K(t.anchorLocal.x*(t.startScale.x-p.x),t.anchorLocal.y*(t.startScale.y-p.y),t.anchorLocal.z*(t.startScale.z-p.z)).applyQuaternion(t.startQuaternion);e.position.copy(t.startPosition).add(m),e.updateMatrixWorld(!0),i(a.targetId)};function b(t){let n=u.current;if(!n||t.pointerId!==n.pointerId)return;if(t.preventDefault(),t.stopPropagation(),n.kind===`center`){let a=n.startPointer.y-t.clientY,o=Math.max(.02,1+a/n.pixelsPerFactor);r.enabled&&r.scale>0&&(o=Ow(o,v(n.startScale),r.scale));let s=n.startScale.clone().multiplyScalar(o);e.scale.copy(s);let c=new K(n.anchorLocal.x*(n.startScale.x-s.x),n.anchorLocal.y*(n.startScale.y-s.y),n.anchorLocal.z*(n.startScale.z-s.z)).applyQuaternion(n.startQuaternion);e.position.copy(n.startPosition).add(c),e.updateMatrixWorld(),i(null),_();return}let a=new Er(t.clientX-n.startPointer.x,t.clientY-n.startPointer.y).dot(n.screenAxis)/n.pixelsPerWorldUnit;if(n.kind===`axis`){let t=IT(n.startScale,n.axis),i=n.localSize*t,o=.02,s=Math.max(o,(i+a)/n.localSize);r.enabled&&r.scale>0&&(s=Dw(s,n.localSize,r.scale,o));let c=n.startScale.clone();LT(c,n.axis,s),e.scale.copy(c);let l=n.anchorCoordinate*(t-s);e.position.copy(n.startPosition).addScaledVector(n.worldAxis,l),e.updateMatrixWorld(),y(n),_();return}let o=Math.max(.02,(n.startDiagonalWorld+a)/n.startDiagonalWorld);r.enabled&&r.scale>0&&(o=Ow(o,v(n.startScale),r.scale));let s=n.startScale.clone().multiplyScalar(o);e.scale.copy(s);let c=new K(n.anchorLocal.x*(n.startScale.x-s.x),n.anchorLocal.y*(n.startScale.y-s.y),n.anchorLocal.z*(n.startScale.z-s.z)).applyQuaternion(n.startQuaternion);e.position.copy(n.startPosition).add(c),e.updateMatrixWorld(),y(n),_()}function x(e){let t=u.current;!t||e instanceof PointerEvent&&e.pointerId!==t.pointerId||(e?.preventDefault(),e?.stopPropagation(),u.current=null,g(),_(),i(null),p(),a(!1),c&&(c.enabled=!0))}let S=()=>{c&&(c.enabled=!1),i(null),f(),a(!0),window.addEventListener(`pointermove`,b,!0),window.addEventListener(`pointerup`,x,!0),window.addEventListener(`pointercancel`,x,!0),window.addEventListener(`blur`,x,!0)},C=(t,n,r)=>{r.stopPropagation(),r.nativeEvent.preventDefault(),r.nativeEvent.stopImmediatePropagation();let i=zT(m,t,`max`)-zT(m,t,`min`);if(i<=1e-6)return;let a=e.quaternion.clone(),c=RT(t,1).applyQuaternion(a).normalize(),l=c.clone().multiplyScalar(n),d=e.position.clone().project(o),f=e.position.clone().add(l).project(o),p=new Er((f.x-d.x)*s.width*.5,-(f.y-d.y)*s.height*.5),h=p.length();h<2||(p.normalize(),u.current={kind:`axis`,axis:t,side:n,pointerId:r.pointerId,startPointer:new Er(r.clientX,r.clientY),screenAxis:p,pixelsPerWorldUnit:h,anchorCoordinate:zT(m,t,n===1?`min`:`max`),localSize:i,startPosition:e.position.clone(),startScale:e.scale.clone(),worldAxis:c},S())},w=t=>{t.stopPropagation(),t.nativeEvent.preventDefault(),t.nativeEvent.stopImmediatePropagation();let n=m.getCenter(new K);n.y=m.min.y,u.current={kind:`center`,pointerId:t.pointerId,startPointer:new Er(t.clientX,t.clientY),anchorLocal:n,startPosition:e.position.clone(),startQuaternion:e.quaternion.clone(),startScale:e.scale.clone(),pixelsPerFactor:140},S()},T=(t,n)=>{n.stopPropagation(),n.nativeEvent.preventDefault(),n.nativeEvent.stopImmediatePropagation();let r=e.quaternion.clone(),i=BT(m,t),a=[-t[0],-t[1],-t[2]],c=BT(m,a),l=i.clone().sub(c).multiply(e.scale),d=l.length();if(d<=1e-6)return;let f=l.applyQuaternion(r).normalize(),p=e.position.clone().project(o),h=e.position.clone().add(f).project(o),g=new Er((h.x-p.x)*s.width*.5,-(h.y-p.y)*s.height*.5),_=g.length();_<2||(g.normalize(),u.current={kind:`uniform`,pointerId:n.pointerId,startPointer:new Er(n.clientX,n.clientY),screenAxis:g,pixelsPerWorldUnit:_,startDiagonalWorld:d,worldDirection:f,anchorLocal:c,startPosition:e.position.clone(),startQuaternion:r,startScale:e.scale.clone()},S())};return(0,Y.useEffect)(()=>()=>{u.current&&(g(),u.current=null,i(null),p(),c&&(c.enabled=!0),a(!1))},[c,p,i,a]),(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(GT,{mesh:e,bounds:m,color:Rx(n.material.color),onPointerDown:w}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`X`,side:-1,color:`#ff0000`,onPointerDown:C}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`X`,side:1,color:`#ff0000`,onPointerDown:C}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`Y`,side:-1,color:`#00ff00`,onPointerDown:C}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`Y`,side:1,color:`#00ff00`,onPointerDown:C}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`Z`,side:-1,color:`#0000ff`,onPointerDown:C}),(0,Q.jsx)(WT,{mesh:e,bounds:m,axis:`Z`,side:1,color:`#0000ff`,onPointerDown:C}),FT.map(t=>(0,Q.jsx)(KT,{mesh:e,bounds:m,sides:t,onPointerDown:T},t.join(`:`)))]})}function JT({mesh:e,geometry:t,object:n,snap:r,onSnapTargetChange:i,onTransformDraggingChange:a}){let o=(0,Y.useMemo)(()=>new ke,[]),s=(0,Y.useRef)(null),c=q(e=>e.updateObject),l=q(e=>e.beginTransaction),u=q(e=>e.endTransaction),d=(0,Y.useMemo)(()=>(t.computeBoundingBox(),t.boundingBox?.getCenter(new K)??new K),[t]),f=(0,Y.useCallback)(()=>{e.updateMatrixWorld(!0),o.position.copy(e.localToWorld(d.clone())),o.rotation.set(0,0,0),o.scale.set(1,1,1),o.updateMatrixWorld(!0)},[d,e,o]);return Qy(()=>{s.current||f()}),(0,Y.useEffect)(()=>()=>{s.current&&(s.current=null,i(null),u(),a(!1))},[u,i,a]),(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`primitive`,{object:o}),(0,Q.jsx)(lS,{object:o,mode:`translate`,space:`world`,size:1.15,translationSnap:void 0,onMouseDown:()=>{f(),s.current={lastRawProxyPosition:o.position.clone(),rawMeshWorldPosition:e.getWorldPosition(new K),surfaceSnapSession:gw()},i(null),l(),a(!0)},onObjectChange:()=>{let t=s.current;if(!t)return;let a=o.position.clone(),l=a.clone().sub(t.lastRawProxyPosition);t.lastRawProxyPosition.copy(a),t.rawMeshWorldPosition.add(l);let u=e.parent?e.parent.worldToLocal(t.rawMeshWorldPosition.clone()):t.rawMeshWorldPosition.clone(),f=t.rawMeshWorldPosition.clone();r.enabled&&r.position>0&&f.set(Math.round(f.x/r.position)*r.position,Math.round(f.y/r.position)*r.position,Math.round(f.z/r.position)*r.position);let p=e.parent?e.parent.worldToLocal(f.clone()):f;e.position.copy(p),e.updateMatrixWorld(!0);let m=[e.position.x,e.position.y,e.position.z],h=[e.rotation.x,e.rotation.y,e.rotation.z],g=[e.scale.x,e.scale.y,e.scale.z];if(r.surface&&Lw(n.type)){let a=q.getState().objects,o=ww({...n,position:m,rotation:h,scale:g},a,r.position,[u.x,u.y,u.z],t.surfaceSnapSession);t.surfaceSnapSession=o.session,m=o.result.position,e.position.set(m[0],m[1],m[2]),e.updateMatrixWorld(!0),i(o.result.targetId)}else t.surfaceSnapSession=gw(),i(null);c(n.id,{position:m,rotation:h,scale:g},!1),e.updateMatrixWorld(!0),o.position.copy(e.localToWorld(d.clone())),o.updateMatrixWorld(!0)},onMouseUp:()=>{s.current=null,i(null),u(),a(!1),f()}})]})}function YT({object:e,registry:t,snapTargetId:n,onSnapTargetChange:r,onTransformDraggingChange:i,paintSettings:a}){let o=q(e=>e.selectedIds),s=q(e=>e.select),c=q(e=>e.tool),l=q(e=>e.snap),u=q(e=>e.updateObject),d=q(e=>e.beginTransaction),f=q(e=>e.endTransaction),[p,m]=(0,Y.useState)(null),h=(0,Y.useMemo)(()=>Ur({type:e.type,geometry:e.geometry}),[e.geometry,e.type]),g=o.includes(e.id),_=g&&o.length===1,v=zx(e,_,a,h);Zw(e,h),pT(e,h),gT(e,h,v.texture);let y=c===`translate`||c===`scale`,b=!a.enabled&&l.surface&&y&&Lw(e.type)&&!g&&e.visible;(0,Y.useEffect)(()=>()=>h.dispose(),[h]),(0,Y.useEffect)(()=>(p&&t.current.set(e.id,p),()=>{t.current.delete(e.id)}),[p,e.id,t]);let x=()=>{p&&u(e.id,{position:[p.position.x,p.position.y,p.position.z],rotation:[p.rotation.x,p.rotation.y,p.rotation.z],scale:[p.scale.x,p.scale.y,p.scale.z]},!1)};return(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`mesh`,{ref:m,name:e.name,geometry:h,position:e.position,rotation:e.rotation,scale:e.scale,visible:e.visible,castShadow:!0,receiveShadow:!0,onPointerDown:e=>{if(a.enabled){v.onPointerDown(e),e.stopPropagation();return}e.button===2&&e.stopPropagation()},onPointerMove:v.onPointerMove,onPointerUp:v.onPointerUp,onPointerCancel:v.onPointerCancel,onClick:t=>{t.stopPropagation(),!a.enabled&&s(e.id,t.shiftKey)},children:(0,Q.jsx)(`meshStandardMaterial`,{map:v.texture,color:v.texture?`#FFFFFF`:e.material.color,roughness:e.material.roughness,metalness:e.material.metalness,opacity:e.material.opacity,transparent:e.material.opacity<1||!!v.texture,alphaTest:v.texture?.001:0,flatShading:e.material.flatShading,emissive:`#000000`,emissiveIntensity:0})}),b&&(0,Q.jsx)(yT,{geometry:h,object:e,cellSize:l.position,highlighted:n===e.id}),!a.enabled&&_&&!e.locked&&e.visible&&p&&(c===`scale`?(0,Q.jsx)(qT,{mesh:p,geometry:h,object:e,snap:l,onSnapTargetChange:r,onTransformDraggingChange:i}):c===`translate`?(0,Q.jsx)(JT,{mesh:p,geometry:h,object:e,snap:l,onSnapTargetChange:r,onTransformDraggingChange:i}):(0,Q.jsx)(lS,{object:p,mode:`rotate`,space:`world`,size:1.4,rotationSnap:l.enabled?Hi.degToRad(l.rotation):void 0,onMouseDown:()=>{r(null),d(),i(!0)},onObjectChange:x,onMouseUp:()=>{x(),f(),i(!1)}}))]})}function XT({cellSize:e}){let t={args:[400,400],cellSize:e,cellThickness:.6,cellColor:`#53626a`,sectionSize:e*5,sectionThickness:1,sectionColor:`#4f8f68`,fadeDistance:1e3,fadeStrength:0,followCamera:!1,infiniteGrid:!1,frustumCulled:!1,renderOrder:1};return(0,Q.jsxs)(`group`,{children:[(0,Q.jsx)(dS,{...t,position:[0,.003,0]}),(0,Q.jsx)(dS,{...t,position:[0,-.003,0],rotation:[Math.PI,0,0]})]})}var ZT=class extends ur{constructor(){super(),this.name=`RoomEnvironment`,this.position.y=-3.5;let e=new an;e.deleteAttribute(`uv`);let t=new ae({side:1}),n=new ae,r=new _e(16777215,900,28,2);r.position.set(.418,16.199,.3),this.add(r);let i=new G(e,t);i.position.set(-.757,13.219,.717),i.scale.set(31.713,28.305,28.591),this.add(i);let a=new Qn(e,n,6),o=new ke;o.position.set(-10.906,2.009,1.846),o.rotation.set(0,-.195,0),o.scale.set(2.328,7.905,4.651),o.updateMatrix(),a.setMatrixAt(0,o.matrix),o.position.set(-5.607,-.754,-.758),o.rotation.set(0,.994,0),o.scale.set(1.97,1.534,3.955),o.updateMatrix(),a.setMatrixAt(1,o.matrix),o.position.set(6.167,.857,7.803),o.rotation.set(0,.561,0),o.scale.set(3.927,6.285,3.687),o.updateMatrix(),a.setMatrixAt(2,o.matrix),o.position.set(-2.017,.018,6.124),o.rotation.set(0,.333,0),o.scale.set(2.002,4.566,2.064),o.updateMatrix(),a.setMatrixAt(3,o.matrix),o.position.set(2.291,-.756,-2.621),o.rotation.set(0,-.286,0),o.scale.set(1.546,1.552,1.496),o.updateMatrix(),a.setMatrixAt(4,o.matrix),o.position.set(-2.193,-.369,-5.547),o.rotation.set(0,.516,0),o.scale.set(3.875,3.487,2.986),o.updateMatrix(),a.setMatrixAt(5,o.matrix),this.add(a);let s=new G(e,QT(50));s.position.set(-16.116,14.37,8.208),s.scale.set(.1,2.428,2.739),this.add(s);let c=new G(e,QT(50));c.position.set(-16.109,18.021,-8.207),c.scale.set(.1,2.425,2.751),this.add(c);let l=new G(e,QT(17));l.position.set(14.904,12.198,-1.832),l.scale.set(.15,4.265,6.331),this.add(l);let u=new G(e,QT(43));u.position.set(-.462,8.89,14.52),u.scale.set(4.38,5.441,.088),this.add(u);let d=new G(e,QT(20));d.position.set(3.235,11.486,-12.541),d.scale.set(2.5,2,.1),this.add(d);let f=new G(e,QT(100));f.position.set(0,20,0),f.scale.set(1,.1,1),this.add(f)}dispose(){let e=new Set;this.traverse(t=>{t.isMesh&&(e.add(t.geometry),e.add(t.material))});for(let t of e)t.dispose()}};function QT(e){return new Ha({color:0,emissive:16777215,emissiveIntensity:e})}var $T=new WeakMap;function eE(e,t){e.environment=t}function tE(){let e=Zy(e=>e.gl),t=Zy(e=>e.scene);(0,Y.useEffect)(()=>{let n=$T.get(t);if(!n){let r=new Oo(e),i=r.fromScene(new ZT,.04);r.dispose(),n={target:i,previous:t.environment,references:0},$T.set(t,n),eE(t,i.texture)}return n.references+=1,()=>{let e=$T.get(t);e&&(--e.references,!(e.references>0)&&(t.environment===e.target.texture&&eE(t,e.previous),e.target.dispose(),$T.delete(t)))}},[e,t])}function nE({keyboardActive:e,selectionActive:t,registry:n,onSelectionApi:i,paintSettings:a}){let o=q(e=>e.objects),s=q(e=>e.selectedIds),c=q(e=>e.tool),l=q(e=>e.snap),u=q(e=>e.scene),d=q(e=>e.select),[f,p]=(0,Y.useState)(!1),[m,h]=(0,Y.useState)(null),g=r(),_=o.filter(e=>s.includes(e.id)),v=!a.enabled&&_.length>1&&_.every(e=>e.visible&&!e.locked);return tE(),(0,Y.useEffect)(()=>{(!l.surface||c!==`translate`&&c!==`scale`||a.enabled)&&h(null)},[a.enabled,l.surface,c]),(0,Q.jsxs)(Q.Fragment,{children:[(0,Q.jsx)(`color`,{attach:`background`,args:[u.background]}),(0,Q.jsx)(`ambientLight`,{intensity:1.4}),(0,Q.jsx)(`directionalLight`,{position:[6,10,5],intensity:2.1,castShadow:!0,"shadow-mapSize-width":1024,"shadow-mapSize-height":1024}),(0,Q.jsx)(`hemisphereLight`,{args:[`#dbe7ee`,`#2a312c`,.8]}),u.gridVisible&&(0,Q.jsx)(XT,{cellSize:u.gridSize}),u.axesVisible&&(0,Q.jsx)(`axesHelper`,{args:[3]}),(0,Q.jsxs)(`mesh`,{rotation:[-Math.PI/2,0,0],position:[0,-.01,0],receiveShadow:!0,onClick:e=>{!a.enabled&&e.button===0&&!e.ctrlKey&&d(null)},children:[(0,Q.jsx)(`planeGeometry`,{args:[400,400]}),(0,Q.jsx)(`shadowMaterial`,{opacity:.14,transparent:!0,depthWrite:!1,side:2})]}),o.map(e=>(0,Q.jsx)(YT,{object:e,registry:n,snapTargetId:m,onSnapTargetChange:h,onTransformDraggingChange:p,paintSettings:a},e.id)),v&&l.surface&&(c===`translate`||c===`scale`)&&(0,Q.jsx)(wC,{objects:_,highlighted:m===`selected-composite`}),v&&(0,Q.jsx)(kw,{selectedIds:s,registry:n,tool:c,snap:l,onSnapTargetChange:h,onTransformDraggingChange:p}),(0,Q.jsx)(cS,{makeDefault:!0,enabled:!f&&!t,enablePan:!a.enabled,enableRotate:!a.enabled,enableZoom:!g,zoomToCursor:!0,enableDamping:!0,dampingFactor:.08,mouseButtons:{LEFT:xa.PAN,MIDDLE:xa.PAN,RIGHT:xa.ROTATE}}),(0,Q.jsx)(hS,{active:g&&!f&&!t}),(0,Q.jsx)(DC,{active:!a.enabled&&e&&!f&&!t}),(0,Q.jsx)(TC,{active:!0}),(0,Q.jsx)(Aw,{registry:n,onReady:i})]})}function rE(){let e=q(e=>e.select),t=q(e=>e.selectMany),n=Fx(),i=(0,Y.useRef)(null),a=(0,Y.useRef)(new Map),o=(0,Y.useRef)(null),s=(0,Y.useRef)(null),c=(0,Y.useRef)(!1),l=(0,Y.useRef)(!1),u=(0,Y.useRef)(null),d=r(),[f,p]=(0,Y.useState)(!1),[m,h]=(0,Y.useState)(null),[g,_]=(0,Y.useState)(!1),v=(0,Y.useCallback)(e=>{o.current=e},[]),y=(0,Y.useCallback)(e=>{e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()},[]),b=(0,Y.useCallback)(()=>{let e=u.current;e&&(window.removeEventListener(`pointermove`,e.pointerMove,!0),window.removeEventListener(`pointerup`,e.finish,!0),window.removeEventListener(`pointercancel`,e.finish,!0),window.removeEventListener(`blur`,e.finish,!0),u.current=null)},[]),x=(0,Y.useCallback)(e=>{let t=s.current,n=i.current;if(!t||!n||e.pointerId!==t.pointerId)return;y(e);let r=n.getBoundingClientRect(),a={...t,currentX:Math.max(0,Math.min(r.width,e.clientX-r.left)),currentY:Math.max(0,Math.min(r.height,e.clientY-r.top))};s.current=a,h(a)},[y]),S=(0,Y.useCallback)(e=>{let n=s.current,r=i.current;if(!n||!r||e instanceof PointerEvent&&e.pointerId!==n.pointerId)return;e&&y(e);let a=c.current;b(),s.current=null,c.current=!1,h(null),a&&_(!1);let u=Math.abs(n.currentX-n.startX),d=Math.abs(n.currentY-n.startY);if(l.current=!0,u<4||d<4)return;let f=r.getBoundingClientRect(),p={left:f.left+Math.min(n.startX,n.currentX),top:f.top+Math.min(n.startY,n.currentY),right:f.left+Math.max(n.startX,n.currentX),bottom:f.top+Math.max(n.startY,n.currentY)},m=o.current?.idsInRect(p)??[];t(m,e instanceof PointerEvent&&e.shiftKey)},[b,t,y]);(0,Y.useEffect)(()=>()=>{b(),s.current=null,c.current=!1},[b]),(0,Y.useEffect)(()=>{!n.enabled||!g||_(!1)},[g,n.enabled]);let C=(0,Y.useCallback)(e=>{let t=e.target;if(t instanceof Element&&t.closest(`[data-android-marquee-button="true"]`))return;i.current?.focus();let r=Vx(d,g,e.pointerType);if(n.enabled||e.button!==0||!e.ctrlKey&&!r||!i.current||s.current)return;e.preventDefault(),e.stopPropagation(),e.nativeEvent.stopImmediatePropagation();let a=i.current.getBoundingClientRect(),o={pointerId:e.pointerId,startX:e.clientX-a.left,startY:e.clientY-a.top,currentX:e.clientX-a.left,currentY:e.clientY-a.top};s.current=o,c.current=r,l.current=!1,h(o),b();let f={pointerMove:x,finish:S};u.current=f,window.addEventListener(`pointermove`,f.pointerMove,!0),window.addEventListener(`pointerup`,f.finish,!0),window.addEventListener(`pointercancel`,f.finish,!0),window.addEventListener(`blur`,f.finish,!0)},[g,S,x,d,n.enabled,b]),w=m?{left:Math.min(m.startX,m.currentX),top:Math.min(m.startY,m.currentY),width:Math.abs(m.currentX-m.startX),height:Math.abs(m.currentY-m.startY)}:void 0;return(0,Q.jsxs)(`div`,{ref:i,className:`viewport`,tabIndex:0,onPointerDownCapture:C,onClickCapture:e=>{l.current&&(l.current=!1,e.preventDefault(),e.stopPropagation(),e.nativeEvent.stopImmediatePropagation())},onContextMenu:e=>e.preventDefault(),onFocus:()=>p(!0),onBlur:()=>p(!1),children:[(0,Q.jsx)(bx,{shadows:!0,camera:{position:[6,5,7],fov:45,near:.05,far:500},gl:{antialias:!0,preserveDrawingBuffer:!0},onPointerMissed:t=>{!n.enabled&&t.button===0&&!t.ctrlKey&&!l.current&&e(null)},children:(0,Q.jsx)(nE,{keyboardActive:f,selectionActive:!!m||g,registry:a,onSelectionApi:v,paintSettings:n})}),d&&(0,Q.jsx)(Bx,{active:g,disabled:n.enabled,onToggle:()=>{i.current?.focus(),_(e=>!e)}}),m&&(0,Q.jsx)(`div`,{className:`selection-marquee`,style:w}),n.enabled&&(0,Q.jsx)(`div`,{style:{position:`absolute`,left:12,top:12,zIndex:10,pointerEvents:`none`,padding:`6px 9px`,border:`1px solid #68a47d`,borderRadius:4,background:`rgba(25, 48, 36, 0.9)`,color:`#dff4e7`,fontSize:12},children:`Malmodus aktiv · direkt auf das ausgewählte Objekt malen`}),(0,Q.jsx)(`div`,{className:`viewport-hint`,children:n.enabled?`Malmodus: Mausrad-Zoom und Perspektivwechsel verfügbar · Transformation gesperrt`:`Strg + Linksklick-Ziehen: Auswahlrahmen · Shift + Linksklick: Mehrfachauswahl · Strg + G: gruppieren`})]})}function iE(){let[e,t]=(0,Y.useState)(null),[n,r]=(0,Y.useState)(!1),i=(0,Y.useRef)(null);return(0,Y.useEffect)(()=>{let e=window.requestAnimationFrame(()=>{t(document.querySelector(`.viewport`))});return()=>window.cancelAnimationFrame(e)},[]),(0,Y.useEffect)(()=>{if(!n)return;let e=e=>{let t=e.target instanceof Node?e.target:null;t&&!i.current?.contains(t)&&r(!1)};return window.addEventListener(`pointerdown`,e,!0),()=>window.removeEventListener(`pointerdown`,e,!0)},[n]),e?(0,Av.createPortal)((0,Q.jsxs)(`div`,{ref:i,className:`viewport-help`,onPointerDown:e=>e.stopPropagation(),children:[n&&(0,Q.jsx)(`div`,{className:`viewport-help-popover`,role:`status`,children:`Strg + Linksklick-Ziehen: Auswahlrahmen · Shift + Linksklick: Mehrfachauswahl · Strg + G: gruppieren`}),(0,Q.jsx)(`button`,{type:`button`,className:`viewport-help-button`,"aria-label":`Bedienungshinweise`,"aria-expanded":n,onClick:()=>r(e=>!e),children:`i`})]}),e):null}var aE=e=>!!(e instanceof HTMLElement?e:null)?.closest(`input, textarea, select, [contenteditable="true"]`);function oE(e=!0){(0,Y.useEffect)(()=>{if(!e)return;let t=e=>{if(aE(e.target))return;let t=q.getState(),n=e.key.toLowerCase();if((e.ctrlKey||e.metaKey)&&n===`g`&&e.shiftKey){e.preventDefault(),t.ungroupSelection();return}if((e.ctrlKey||e.metaKey)&&n===`g`){e.preventDefault(),t.groupSelection();return}if((e.ctrlKey||e.metaKey)&&n===`d`){e.preventDefault(),t.duplicateObject();return}if((e.ctrlKey||e.metaKey)&&n===`z`&&e.shiftKey){e.preventDefault(),t.redo();return}if((e.ctrlKey||e.metaKey)&&n===`z`){e.preventDefault(),t.undo();return}if((e.ctrlKey||e.metaKey)&&n===`y`){e.preventDefault(),t.redo();return}if(e.key===`Delete`||e.key===`Backspace`){e.preventDefault(),t.deleteObject();return}n===`w`||n===`g`?t.setTool(`translate`):n===`e`||n===`r`?t.setTool(`rotate`):n===`s`?t.setTool(`scale`):n===`f`?t.requestCameraView(`focus`):e.key===`Escape`&&t.select(null)};return window.addEventListener(`keydown`,t),()=>window.removeEventListener(`keydown`,t)},[e])}var sE=`(max-width: 1180px), (pointer: coarse) and (max-width: 1400px)`,cE=()=>typeof window<`u`&&typeof window.matchMedia==`function`&&window.matchMedia(sE).matches;function lE({active:e=!0}){oE(e);let t=q(e=>e.objects),n=q(e=>e.project),r=q(e=>e.scene),i=q(e=>e.loadProject),a=q(e=>e.setMessage),[o]=(0,Y.useState)(()=>localStorage.getItem(Tl)),[s,c]=(0,Y.useState)(!!o),[l,u]=(0,Y.useState)(cE),[d,f]=(0,Y.useState)(cE),[p,m]=(0,Y.useState)(cE),[h,g]=(0,Y.useState)(cE);(0,Y.useEffect)(()=>{let e=window.setTimeout(()=>{let e=Vl(n,r,t);localStorage.setItem(Tl,zl({project:e.project,scene:e.scene,objects:e.objects}))},450);return()=>window.clearTimeout(e)},[t,n,r]),(0,Y.useEffect)(()=>{let e=window.matchMedia(sE),t=e=>{u(e.matches),e.matches&&(f(!0),m(!0),g(!0))};return typeof e.addEventListener==`function`?(e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)):(e.addListener(t),()=>e.removeListener(t))},[]);let _=()=>{if(!o){c(!1);return}try{i(Bl(o))}catch(e){a(e instanceof Error?`Autosave ungültig: ${e.message}`:`Autosave ungültig`),localStorage.removeItem(Tl)}c(!1)},v=()=>{localStorage.removeItem(Tl),c(!1)},y=()=>{l&&d&&m(!0),f(!d)},b=()=>{l&&p&&f(!0),m(!p)},x=[`workspace`,l?`compact-workspace`:``,d?`inventory-collapsed`:``,p?`properties-collapsed`:``,h?`hierarchy-collapsed`:``].filter(Boolean).join(` `);return(0,Q.jsxs)(`div`,{className:`app-shell`,children:[(0,Q.jsx)(Dg,{}),(0,Q.jsx)(Rv,{}),(0,Q.jsxs)(`main`,{className:x,children:[(0,Q.jsx)(Mg,{collapsed:d,onToggle:y}),e&&(0,Q.jsx)(rE,{}),(0,Q.jsx)(iE,{}),(0,Q.jsx)(Ov,{collapsed:p,onToggle:b}),(0,Q.jsx)(kv,{collapsed:h,onToggle:()=>g(e=>!e)})]}),(0,Q.jsx)(Og,{}),s&&(0,Q.jsx)(zv,{onRestore:_,onDiscard:v})]})}export{lE as App};